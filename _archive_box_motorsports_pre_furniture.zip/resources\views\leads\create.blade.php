@extends('layouts.adminlte')
@section('title', 'New Lead')
@section('content')
    <form method="POST" action="{{ route('leads.store') }}">
        @csrf
        @include('leads._form', ['lead' => null])
        <div class="mb-4">
            <button class="btn btn-brand">Create Lead</button>
            <a href="{{ route('leads.index') }}" class="btn btn-default">Cancel</a>
        </div>
    </form>
@endsection
