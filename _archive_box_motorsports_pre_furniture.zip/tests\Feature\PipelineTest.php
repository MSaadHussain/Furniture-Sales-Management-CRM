<?php

namespace Tests\Feature;

use App\Models\Lead;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class PipelineTest extends TestCase
{
    use RefreshDatabase;

    public function test_manager_can_move_lead(): void
    {
        $manager = User::factory()->create(['role' => 'sales_manager']);
        $lead = Lead::factory()->create(['status' => 'new']);

        $this->actingAs($manager)
            ->patchJson("/pipeline/{$lead->id}/move", ['status' => 'contacted'])
            ->assertOk()
            ->assertJson(['success' => true, 'status' => 'contacted']);

        $this->assertDatabaseHas('leads', ['id' => $lead->id, 'status' => 'contacted']);
        $this->assertDatabaseHas('lead_interactions', ['lead_id' => $lead->id, 'action_type' => 'status_changed']);
    }

    public function test_viewer_cannot_move_lead(): void
    {
        $viewer = User::factory()->create(['role' => 'viewer']);
        $lead = Lead::factory()->create(['status' => 'new']);

        $this->actingAs($viewer)
            ->patchJson("/pipeline/{$lead->id}/move", ['status' => 'contacted'])
            ->assertForbidden();
    }

    public function test_closed_won_logs_dedicated_event(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $lead = Lead::factory()->create(['status' => 'meeting_scheduled']);

        $this->actingAs($admin)
            ->patchJson("/pipeline/{$lead->id}/move", ['status' => 'closed_won'])
            ->assertOk();

        $this->assertDatabaseHas('lead_interactions', ['lead_id' => $lead->id, 'action_type' => 'closed_won']);
    }
}
