<?php

namespace App\Notifications;

use App\Models\Lead;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;

class NewLeadNotification extends Notification
{
    use Queueable;

    public function __construct(public Lead $lead) {}

    public function via(object $notifiable): array
    {
        return ['database'];
    }

    public function toArray(object $notifiable): array
    {
        return [
            'type'    => 'new_lead',
            'lead_id' => $this->lead->id,
            'title'   => 'New lead received',
            'message' => ($this->lead->full_name ?: 'Unnamed lead')
                         . ' via ' . $this->lead->source_channel->label(),
            'color'   => $this->lead->source_channel->color(),
        ];
    }
}
