<?php

namespace App\Services;

use App\Enums\LeadPriority;
use App\Enums\MotorsportInterest;
use App\Enums\SourceChannel;
use App\Models\Lead;

class LeadScoringService
{
    private const HOT_KEYWORDS = ['booking', 'urgent', 'sponsor', 'call me', 'asap'];

    public function evaluate(Lead $lead, int $submissionCount = 1): array
    {
        $score = 0;
        $message = strtolower((string) $lead->message);

        foreach (self::HOT_KEYWORDS as $kw) {
            if (str_contains($message, $kw)) {
                $score += 25;
            }
        }

        if (in_array($lead->motorsport_interest_type, [
            MotorsportInterest::Driver,
            MotorsportInterest::Sponsor,
            MotorsportInterest::BookingInquiry,
        ], true)) {
            $score += 20;
        }

        if ($lead->source_channel === SourceChannel::WhatsApp) {
            $score += 15;
        }

        if ($submissionCount > 1) {
            $score += 20;
        }

        $score = min($score, 100);

        $priority = match (true) {
            $score >= 60 => LeadPriority::Hot,
            $score >= 40 => LeadPriority::High,
            $score >= 20 => LeadPriority::Medium,
            default      => LeadPriority::Low,
        };

        return [$score, $priority];
    }

    public function apply(Lead $lead, int $submissionCount = 1): Lead
    {
        [$score, $priority] = $this->evaluate($lead, $submissionCount);
        $lead->lead_score = $score;
        $lead->priority   = $priority;

        return $lead;
    }
}
