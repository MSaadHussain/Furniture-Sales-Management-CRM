@php $brand = trim(str_ireplace('CRM', '', config('app.name'))) ?: config('app.name'); @endphp
@component('mail::message')
# Meeting Scheduled

@if($forCustomer)
A meeting has been scheduled with you by {{ $brand }}.
@else
A meeting has been scheduled with **{{ $m->attendee_name ?: $m->subjectName() }}** ({{ $m->subjectType() }}).
@endif

@component('mail::panel')
**{{ $m->meeting_title ?: 'Meeting' }}**

**When:** {{ $m->starts_at ? $m->starts_at->format('l, M j, Y g:i A') . ' Central Time (CT)' : 'Time TBD' }}

@unless($forCustomer)
@if($m->attendee_email)
**Email:** {{ $m->attendee_email }}

@endif
@endunless
**Provider:** {{ ucfirst(str_replace('_', ' ', $m->provider)) }}
@endcomponent

@if($m->description)
**Agenda / Description**

{{ $m->description }}
@endif

@if($m->meeting_url)
**Meeting link:** [{{ $m->meeting_url }}]({{ $m->meeting_url }})

@component('mail::button', ['url' => $m->meeting_url, 'color' => 'success'])
Join Meeting
@endcomponent
@endif

@unless($forCustomer)
@if($m->subjectUrl())
@component('mail::button', ['url' => $m->subjectUrl(), 'color' => 'primary'])
View {{ $m->subjectType() }}
@endcomponent
@endif
@endunless

Thanks,<br>
{{ config('app.name') }}
@endcomponent
