@extends('layouts.app')
@section('title', $sponsor->company_name)
@section('breadcrumb')
    <a href="{{ route('sponsors.index') }}" class="hover:text-brand">Sponsors & Vendors</a> / <span>{{ $sponsor->company_name }}</span>
@endsection

@section('header_actions')
    @unless (auth()->user()->role->isReadOnly())
        <a href="{{ route('sponsors.edit', $sponsor) }}" class="btn btn-light"><i class="fa-solid fa-pen"></i> Edit</a>
        <form method="POST" action="{{ route('sponsors.destroy', $sponsor) }}" class="inline" onsubmit="return confirm('Delete this sponsor profile?')">
            @csrf @method('DELETE')
            <button class="btn btn-light text-danger hover:bg-danger/10"><i class="fa-solid fa-trash"></i> Delete</button>
        </form>
    @endunless
@endsection

@section('content')
<div class="grid grid-cols-1 gap-6 lg:grid-cols-3">

    {{-- Left column --}}
    <div class="lg:col-span-2 space-y-6">

        {{-- Company info --}}
        <x-card title="Company Information">
            <div class="flex flex-wrap items-center gap-3 mb-5">
                <span class="flex h-14 w-14 items-center justify-center rounded-xl text-xl font-bold text-white" style="background-color: {{ $sponsor->company_type->color() }};">
                    {{ strtoupper(mb_substr($sponsor->company_name, 0, 2)) }}
                </span>
                <div>
                    <h3 class="text-lg font-bold text-ink dark:text-white">{{ $sponsor->company_name }}</h3>
                    <div class="flex flex-wrap gap-2 mt-1">
                        <x-badge :label="$sponsor->company_type->label()" :color="$sponsor->company_type->color()" />
                        <x-badge :label="$sponsor->status->label()" :color="$sponsor->status->color()" />
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 gap-6 sm:grid-cols-2">
                <dl class="space-y-3 text-sm">
                    <div class="flex items-baseline gap-3"><dt class="w-28 shrink-0 font-medium text-muted">Contact</dt><dd class="text-ink dark:text-gray-300">{{ $sponsor->contact_name ?: '—' }}</dd></div>
                    <div class="flex items-baseline gap-3"><dt class="w-28 shrink-0 font-medium text-muted">Email</dt><dd class="break-all">@if($sponsor->email)<a href="mailto:{{ $sponsor->email }}" class="text-brand hover:underline">{{ $sponsor->email }}</a>@else —@endif</dd></div>
                    <div class="flex items-baseline gap-3"><dt class="w-28 shrink-0 font-medium text-muted">Phone</dt><dd class="text-ink dark:text-gray-300">{{ $sponsor->phone ?: '—' }}</dd></div>
                    <div class="flex items-baseline gap-3"><dt class="w-28 shrink-0 font-medium text-muted">Website</dt><dd>@if($sponsor->website)<a href="{{ $sponsor->website_url }}" target="_blank" rel="noopener" class="text-brand hover:underline">{{ $sponsor->website }}</a>@else —@endif</dd></div>
                </dl>
                <dl class="space-y-3 text-sm">
                    <div class="flex items-baseline gap-3"><dt class="w-32 shrink-0 font-medium text-muted">Industry</dt><dd class="text-ink dark:text-gray-300">{{ $sponsor->industry ?: '—' }}</dd></div>
                    <div class="flex items-baseline gap-3"><dt class="w-32 shrink-0 font-medium text-muted">Location</dt><dd class="text-ink dark:text-gray-300">{{ collect([$sponsor->city, $sponsor->state, $sponsor->country])->filter()->implode(', ') ?: '—' }}</dd></div>
                    <div class="flex items-baseline gap-3"><dt class="w-32 shrink-0 font-medium text-muted">Est. Budget</dt><dd class="text-ink dark:text-gray-300">{{ $sponsor->estimated_budget ? '$' . number_format($sponsor->estimated_budget, 0) : '—' }}</dd></div>
                    <div class="flex items-baseline gap-3"><dt class="w-32 shrink-0 font-medium text-muted">Assigned To</dt><dd class="text-ink dark:text-gray-300">{{ $sponsor->assignee?->name ?? 'Unassigned' }}</dd></div>
                </dl>
            </div>

            @if ($sponsor->notes)
                <div class="mt-5 border-t border-line pt-4 dark:border-strokedark">
                    <h4 class="mb-2 text-xs font-semibold uppercase tracking-wider text-muted">Notes</h4>
                    <p class="text-sm text-ink dark:text-gray-300" style="white-space:pre-line;">{{ $sponsor->notes }}</p>
                </div>
            @endif
        </x-card>

        {{-- Deals --}}
        <x-card title="Sponsorship Deals" padding="p-0">
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="border-b border-line dark:border-strokedark">
                        <tr>
                            <th class="ta-th">Deal</th>
                            <th class="ta-th">Stage</th>
                            <th class="ta-th">Value</th>
                            <th class="ta-th">Probability</th>
                            <th class="ta-th">Close Date</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-line dark:divide-strokedark">
                        @forelse ($sponsor->deals as $deal)
                            <tr>
                                <td class="ta-td">
                                    <span class="font-medium text-ink dark:text-gray-200">{{ $deal->title }}</span>
                                    @if ($deal->package_type)<span class="block text-xs text-muted">{{ $deal->package_type }}</span>@endif
                                </td>
                                <td class="ta-td"><x-badge :label="$deal->stage->label()" :color="$deal->stage->color()" /></td>
                                <td class="ta-td text-ink dark:text-gray-300">{{ $deal->deal_value ? '$' . number_format($deal->deal_value, 0) : '—' }}</td>
                                <td class="ta-td text-muted">{{ $deal->probability }}%</td>
                                <td class="ta-td text-muted">{{ $deal->expected_close_date?->format('M j, Y') ?? '—' }}</td>
                            </tr>
                        @empty
                            <tr><td colspan="5" class="ta-td py-6 text-center text-muted">No deals yet. Create one on the <a href="{{ route('sponsorship-pipeline.index') }}" class="text-brand hover:underline">Sponsorship Pipeline</a>.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </x-card>

        {{-- Linked Drivers --}}
        <x-card title="Linked Drivers" subtitle="Drivers funded by this sponsor">
            @unless (auth()->user()->role->isReadOnly())
            <div x-data="{ open: false }" class="mb-4">
                <button @click="open = !open" class="btn btn-light text-sm"><i class="fa-solid fa-link"></i> Link a Driver</button>
                <form method="POST" action="{{ route('sponsors.link-driver', $sponsor) }}" x-show="open" x-collapse class="mt-4 grid grid-cols-1 gap-4 rounded-xl border border-line p-4 dark:border-strokedark sm:grid-cols-2">
                    @csrf
                    <div>
                        <label class="ta-label">Driver <span class="text-danger">*</span></label>
                        <select name="driver_lead_id" required class="ta-input w-full">
                            <option value="">Select driver...</option>
                            @foreach ($drivers as $d)<option value="{{ $d->id }}">{{ $d->first_name }} {{ $d->last_name }} ({{ $d->email }})</option>@endforeach
                        </select>
                    </div>
                    <div>
                        <label class="ta-label">Related Deal</label>
                        <select name="sponsorship_deal_id" class="ta-input w-full">
                            <option value="">None</option>
                            @foreach ($sponsor->deals as $deal)<option value="{{ $deal->id }}">{{ $deal->title }}</option>@endforeach
                        </select>
                    </div>
                    <div>
                        <label class="ta-label">Funding Amount ($)</label>
                        <input type="number" step="0.01" min="0" name="funding_amount" class="ta-input w-full">
                    </div>
                    <div>
                        <label class="ta-label">Funding Type <span class="text-danger">*</span></label>
                        <select name="funding_type" required class="ta-input w-full">
                            @foreach ($fundingTypes as $ft)<option value="{{ $ft['value'] }}">{{ $ft['label'] }}</option>@endforeach
                        </select>
                    </div>
                    <div>
                        <label class="ta-label">Season / Event</label>
                        <input name="season_or_event" class="ta-input w-full" placeholder="2026 season, race event...">
                    </div>
                    <div>
                        <label class="ta-label">Status <span class="text-danger">*</span></label>
                        <select name="status" required class="ta-input w-full">
                            @foreach ($linkStatuses as $ls)<option value="{{ $ls['value'] }}">{{ $ls['label'] }}</option>@endforeach
                        </select>
                    </div>
                    <div>
                        <label class="ta-label">Start Date</label>
                        <input type="date" name="start_date" class="ta-input w-full">
                    </div>
                    <div>
                        <label class="ta-label">End Date</label>
                        <input type="date" name="end_date" class="ta-input w-full">
                    </div>
                    <div class="sm:col-span-2 flex justify-end">
                        <button class="btn btn-primary"><i class="fa-solid fa-link"></i> Link Driver</button>
                    </div>
                </form>
            </div>
            @endunless

            <div class="space-y-3">
                @forelse ($sponsor->driverLinks as $link)
                    <div class="rounded-xl border border-line p-4 dark:border-strokedark">
                        <div class="flex flex-wrap items-center justify-between gap-2">
                            <div>
                                <a href="{{ route('driver-leads.show', $link->driver_lead_id) }}" class="font-semibold text-ink hover:text-brand dark:text-white">
                                    <i class="fa-solid fa-helmet-safety mr-1 text-muted"></i>{{ $link->driverLead?->full_name ?? 'Deleted driver' }}
                                </a>
                                <div class="mt-1 flex flex-wrap gap-2">
                                    <x-badge :label="$link->funding_type->label()" :color="$link->funding_type->color()" />
                                    <x-badge :label="$link->status->label()" :color="$link->status->color()" />
                                    @if ($link->season_or_event)<span class="text-xs text-muted">{{ $link->season_or_event }}</span>@endif
                                </div>
                            </div>
                            <div class="text-right">
                                <p class="font-bold text-ink dark:text-white">{{ $link->funding_amount ? '$' . number_format($link->funding_amount, 0) : '—' }}</p>
                                @if ($link->deal)<p class="text-xs text-muted">{{ $link->deal->title }}</p>@endif
                                @unless (auth()->user()->role->isReadOnly())
                                    <form method="POST" action="{{ route('sponsor-driver-links.destroy', $link) }}" class="mt-1" onsubmit="return confirm('Unlink this driver?')">
                                        @csrf @method('DELETE')
                                        <button class="text-xs text-danger hover:underline">Unlink</button>
                                    </form>
                                @endunless
                            </div>
                        </div>
                    </div>
                @empty
                    <p class="text-sm text-muted">No drivers linked yet.</p>
                @endforelse
            </div>
        </x-card>
    </div>

    {{-- Right column --}}
    <div class="space-y-6">

        {{-- Log activity --}}
        @unless (auth()->user()->role->isReadOnly())
        <x-card title="Log Activity">
            <form method="POST" action="{{ route('sponsors.activities.store', $sponsor) }}" enctype="multipart/form-data" class="space-y-3">
                @csrf
                <div>
                    <label class="ta-label">Action</label>
                    <select name="action_type" required class="ta-input w-full">
                        @foreach ($actionTypes as $at)<option value="{{ $at['value'] }}">{{ $at['label'] }}</option>@endforeach
                    </select>
                </div>
                <div>
                    <label class="ta-label">Details</label>
                    <textarea name="description" rows="2" class="ta-input w-full" placeholder="What happened..."></textarea>
                </div>
                <div>
                    <label class="ta-label">Related Deal</label>
                    <select name="sponsorship_deal_id" class="ta-input w-full">
                        <option value="">None</option>
                        @foreach ($sponsor->deals as $deal)<option value="{{ $deal->id }}">{{ $deal->title }}</option>@endforeach
                    </select>
                </div>
                <div>
                    <label class="ta-label">Follow-Up Due Date</label>
                    <input type="date" name="due_date" class="ta-input w-full">
                </div>
                <div>
                    <label class="ta-label">Attachment (pitch deck, logo, contract)</label>
                    <input type="file" name="attachment" class="ta-input w-full text-xs">
                </div>
                <button class="btn btn-primary w-full"><i class="fa-solid fa-plus"></i> Log Activity</button>
            </form>
        </x-card>
        @endunless

        {{-- Meetings --}}
        @include('meetings._card', [
            'subject'       => $sponsor,
            'googleRoute'   => route('sponsors.meetings.google-meet', $sponsor),
            'zoomRoute'     => route('sponsors.meetings.zoom', $sponsor),
            'calendlyRoute' => route('sponsors.meetings.calendly-link', $sponsor),
            'defaultTitle'  => $sponsor->contact_name ?: $sponsor->company_name,
        ])

        {{-- Activity timeline --}}
        <x-card title="Activity Timeline">
            <div class="space-y-3 max-h-[32rem] overflow-y-auto">
                @forelse ($sponsor->activities as $activity)
                    <div class="border-l-2 border-brand/40 pl-3 text-sm">
                        <div class="flex items-center justify-between gap-2">
                            <span class="font-semibold text-ink dark:text-white">
                                <i class="fa-solid {{ $activity->action_type->icon() }} mr-1 text-xs text-muted"></i>{{ $activity->action_type->label() }}
                            </span>
                            @if (! $activity->completed_at && $activity->due_date)
                                <span class="rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-semibold text-amber-700 dark:bg-amber-900/30 dark:text-amber-400">Due {{ $activity->due_date->format('M j') }}</span>
                            @endif
                        </div>
                        @if ($activity->description)<p class="text-xs text-muted">{{ $activity->description }}</p>@endif
                        @if ($activity->deal)<p class="text-xs text-muted"><i class="fa-solid fa-handshake mr-1"></i>{{ $activity->deal->title }}</p>@endif
                        @if ($activity->driverLead)<p class="text-xs text-muted"><i class="fa-solid fa-helmet-safety mr-1"></i>{{ $activity->driverLead->full_name }}</p>@endif
                        @if ($activity->attachment_path)
                            <a href="{{ Storage::url($activity->attachment_path) }}" target="_blank" class="text-xs text-brand hover:underline"><i class="fa-solid fa-paperclip mr-1"></i>Attachment</a>
                        @endif
                        <p class="text-xs text-muted">{{ $activity->performer?->name ?? 'System' }} &middot; {{ $activity->created_at->diffForHumans() }}</p>
                        @unless (auth()->user()->role->isReadOnly())
                            <div class="mt-0.5 flex gap-2">
                                @if (! $activity->completed_at)
                                    <form method="POST" action="{{ route('sponsor-activities.complete', $activity) }}">@csrf @method('PATCH')
                                        <button class="text-[11px] text-success hover:underline">Mark complete</button>
                                    </form>
                                @endif
                                <form method="POST" action="{{ route('sponsor-activities.destroy', $activity) }}" onsubmit="return confirm('Remove this activity?')">@csrf @method('DELETE')
                                    <button class="text-[11px] text-danger hover:underline">Remove</button>
                                </form>
                            </div>
                        @endunless
                    </div>
                @empty
                    <p class="text-sm text-muted">No activity yet.</p>
                @endforelse
            </div>
        </x-card>
    </div>
</div>
@endsection
