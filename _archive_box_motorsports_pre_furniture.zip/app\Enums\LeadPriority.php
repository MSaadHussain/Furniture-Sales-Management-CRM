<?php

namespace App\Enums;

enum LeadPriority: string
{
    case Low = 'low';
    case Medium = 'medium';
    case High = 'high';
    case Hot = 'hot';

    public function label(): string
    {
        return ucfirst($this->value);
    }

    public function color(): string
    {
        return match ($this) {
            self::Low    => '#667085',
            self::Medium => '#2E90FA',
            self::High   => '#7A5AF8',
            self::Hot    => '#F04438',
        };
    }

    public function weight(): int
    {
        return match ($this) {
            self::Low    => 1,
            self::Medium => 2,
            self::High   => 3,
            self::Hot    => 4,
        };
    }

    public static function options(): array
    {
        return array_map(
            fn (self $p) => ['value' => $p->value, 'label' => $p->label(), 'color' => $p->color()],
            self::cases()
        );
    }
}
