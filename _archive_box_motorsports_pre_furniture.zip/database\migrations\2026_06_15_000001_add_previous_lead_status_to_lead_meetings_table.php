<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('lead_meetings', function (Blueprint $table) {
            // The lead's status at the moment this meeting was scheduled, so that
            // deleting the meeting can revert the lead to where it was before.
            $table->string('previous_lead_status')->nullable()->after('status');
        });
    }

    public function down(): void
    {
        Schema::table('lead_meetings', function (Blueprint $table) {
            $table->dropColumn('previous_lead_status');
        });
    }
};
