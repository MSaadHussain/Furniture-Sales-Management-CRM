<?php

namespace App\Services;

use App\Models\Lead;

class LeadDeduplicationService
{
    public function __construct(private LeadNormalizerService $normalizer) {}

    public function findDuplicate(?string $email, ?string $phone): ?Lead
    {
        $email = $this->normalizer->email($email);
        $normalizedPhone = $this->normalizer->phone($phone);

        $query = Lead::query();
        $hasCriteria = false;

        if ($email) {
            $query->orWhere('email', $email);
            $hasCriteria = true;
        }

        if ($normalizedPhone) {
            $tail = $this->phoneTail($normalizedPhone);
            $query->orWhere(function ($q) use ($normalizedPhone, $tail) {
                $q->where('normalized_phone', $normalizedPhone);
                if ($tail) {
                    $q->orWhere('normalized_phone', 'like', "%{$tail}");
                }
            });
            $hasCriteria = true;
        }

        if (! $hasCriteria) {
            return null;
        }

        return $query->orderBy('created_at')->first();
    }

    private function phoneTail(string $normalizedPhone): ?string
    {
        $digits = preg_replace('/\D+/', '', $normalizedPhone);
        return strlen($digits) >= 9 ? substr($digits, -9) : null;
    }
}
