<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ImportBatchRow extends Model
{
    use HasFactory;

    protected $fillable = [
        'import_batch_id', 'row_number', 'raw_data', 'mapped_data',
        'status', 'error_message', 'lead_id',
    ];

    protected function casts(): array
    {
        return [
            'raw_data'    => 'array',
            'mapped_data' => 'array',
            'row_number'  => 'integer',
        ];
    }

    public function batch()
    {
        return $this->belongsTo(ImportBatch::class, 'import_batch_id');
    }

    public function lead()
    {
        return $this->belongsTo(Lead::class);
    }
}
