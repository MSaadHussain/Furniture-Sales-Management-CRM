@extends('layouts.app')
@section('title', 'Google Leads')
@section('breadcrumb')
    <a href="{{ route('integrations.index') }}" class="hover:text-brand">Integrations</a> / <span>Google Leads</span>
@endsection

@section('content')
<div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
    <form method="POST" action="{{ route('integrations.google-leads.save') }}" class="lg:col-span-2">
        @csrf
        <x-card class="h-full" title="Google Lead Form Ads" subtitle="Receive leads from Google Ads lead forms">
            <div class="space-y-4">
                <div class="flex items-center justify-between rounded-xl border border-line p-3 dark:border-strokedark">
                    <span class="text-sm font-medium text-ink dark:text-gray-200">Integration active</span>
                    <input type="checkbox" name="enabled" value="1" @checked($setting->enabled)
                           class="h-5 w-9 rounded-full text-brand focus:ring-brand">
                </div>

                @foreach ([
                    'google_client_id' => 'Google Client ID', 'google_client_secret' => 'Google Client Secret',
                    'developer_token' => 'Developer Token', 'customer_id' => 'Customer ID',
                    'refresh_token' => 'Refresh Token', 'webhook_secret' => 'Webhook Secret',
                ] as $field => $label)
                    <div>
                        <label class="ta-label">{{ $label }}</label>
                        <input type="{{ str_contains($field, 'secret') || str_contains($field, 'token') ? 'password' : 'text' }}"
                               name="{{ $field }}" class="ta-input"
                               value="{{ $config[$field] ?? '' }}" autocomplete="off">
                    </div>
                @endforeach

                <div class="flex justify-end gap-2 pt-2">
                    <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save</button>
                </div>
            </div>
        </x-card>
    </form>

    <div class="space-y-6">
        <x-card title="Webhook URL" subtitle="Use in Google Ads lead form">
            <code class="block break-all rounded-lg bg-surface p-3 text-xs dark:bg-boxdark">{{ $webhookUrl }}</code>
            <p class="mt-3 text-xs text-muted">Set the <strong>Webhook URL</strong> and <strong>Key</strong> in your Google Ads lead form delivery options. The Key must match the Webhook Secret above.</p>
        </x-card>
        <x-card title="Test connection">
            <form method="POST" action="{{ route('integrations.google-leads.test') }}">
                @csrf
                <button type="submit" class="btn btn-light w-full"><i class="fa-solid fa-plug-circle-check"></i> Test configuration</button>
            </form>
        </x-card>
    </div>
</div>
@endsection
