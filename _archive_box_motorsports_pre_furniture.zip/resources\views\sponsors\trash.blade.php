@extends('layouts.app')
@section('title', 'Sponsors & Vendors — Trash')
@section('breadcrumb')
    <a href="{{ route('sponsors.index') }}" class="hover:text-brand">Sponsors & Vendors</a> / <span>Trash</span>
@endsection

@section('header_actions')
    <a href="{{ route('sponsors.index') }}" class="btn btn-light"><i class="fa-solid fa-arrow-left"></i> Back to Sponsors</a>
@endsection

@section('content')
<x-card padding="p-0">
    <div class="flex items-center justify-between border-b border-line px-6 py-4 dark:border-strokedark">
        <div>
            <h3 class="text-lg font-semibold text-ink dark:text-white">Deleted Sponsors & Vendors</h3>
            <p class="text-sm text-muted">Restoring a sponsor also restores its pipeline deals.</p>
        </div>
        <form method="GET" class="hidden sm:block">
            <input type="search" name="search" value="{{ request('search') }}" placeholder="Search trash…" class="ta-input !py-2 text-sm">
        </form>
    </div>

    <div class="overflow-x-auto">
        <table class="w-full">
            <thead class="border-b border-line dark:border-strokedark">
                <tr>
                    <th class="ta-th">Company</th>
                    <th class="ta-th">Contact</th>
                    <th class="ta-th">Type</th>
                    <th class="ta-th">Deleted</th>
                    <th class="ta-th text-right">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-line dark:divide-strokedark">
                @forelse ($sponsors as $sponsor)
                    <tr>
                        <td class="ta-td">
                            <div class="flex items-center gap-3">
                                <span class="flex h-9 w-9 items-center justify-center rounded-lg text-xs font-bold text-white" style="background-color: {{ $sponsor->company_type->color() }};">
                                    {{ strtoupper(mb_substr($sponsor->company_name, 0, 2)) }}
                                </span>
                                <span class="font-medium text-ink dark:text-gray-200">{{ $sponsor->company_name }}</span>
                            </div>
                        </td>
                        <td class="ta-td text-muted">
                            {{ $sponsor->contact_name ?: '—' }}<br><span class="text-xs">{{ $sponsor->email }}</span>
                        </td>
                        <td class="ta-td"><x-badge :label="$sponsor->company_type->label()" :color="$sponsor->company_type->color()" /></td>
                        <td class="ta-td text-muted">{{ $sponsor->deleted_at?->diffForHumans() }}</td>
                        <td class="ta-td">
                            <div class="flex items-center justify-end gap-2">
                                <form method="POST" action="{{ route('sponsors.restore', $sponsor->id) }}">
                                    @csrf @method('PATCH')
                                    <button class="btn btn-light !px-3 !py-1.5 text-xs"><i class="fa-solid fa-rotate-left"></i> Restore</button>
                                </form>
                                <form method="POST" action="{{ route('sponsors.force', $sponsor->id) }}"
                                      onsubmit="return confirm('Permanently delete this sponsor? Its deals, activities, and driver links will also be removed. This cannot be undone.');">
                                    @csrf @method('DELETE')
                                    <button class="btn btn-danger !px-3 !py-1.5 text-xs"><i class="fa-solid fa-trash"></i> Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="5" class="ta-td py-12 text-center text-muted">
                        <i class="fa-solid fa-trash-can mb-2 block text-2xl"></i>
                        Trash is empty.
                    </td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="border-t border-line px-6 py-4 dark:border-strokedark">{{ $sponsors->links() }}</div>
</x-card>
@endsection
