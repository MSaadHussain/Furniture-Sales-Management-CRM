@extends('layouts.app')
@section('title', 'Driver Leads Report')
@section('breadcrumb')
    <a href="{{ route('reports.index') }}" class="hover:text-brand">Reports</a> / <span>Driver Leads</span>
@endsection

@section('header_actions')
    <a href="{{ route('reports.index') }}" class="btn btn-light"><i class="fa-solid fa-chart-column"></i> Overview</a>
    <a href="{{ route('reports.drivers.export', $filters) }}" class="btn btn-primary"><i class="fa-solid fa-download"></i> Export CSV</a>
@endsection

@section('content')
{{-- Date filter --}}
<form method="GET" class="mb-6 flex flex-wrap items-center gap-2">
    <select name="range" onchange="this.form.submit()" class="ta-input !w-auto !py-2 text-sm">
        @foreach ($presets as $value => $label)
            <option value="{{ $value }}" @selected($currentRange === $value)>{{ $label }}</option>
        @endforeach
    </select>
    <span class="text-sm text-muted">{{ $rangeLabel }}</span>
</form>

{{-- Summary KPI cards --}}
<div class="grid grid-cols-2 gap-4 sm:grid-cols-3 xl:grid-cols-6">
    <x-stat-card label="Total Drivers" :value="number_format($summary['total'])" icon="fa-helmet-safety" iconColor="#465FFF" />
    <x-stat-card label="Qualified" :value="number_format($summary['qualified'])" icon="fa-circle-check" iconColor="#12B76A" />
    <x-stat-card label="Declined" :value="number_format($summary['declined'])" icon="fa-circle-xmark" iconColor="#F04438" />
    <x-stat-card label="Contacted" :value="number_format($summary['contacted'])" icon="fa-phone" iconColor="#7C3AED" />
    <x-stat-card label="Seeking Sponsor" :value="number_format($summary['seeking'])" icon="fa-star" iconColor="#F79009" />
    <x-stat-card label="Avg Wins" :value="$summary['avgWins']" icon="fa-trophy" iconColor="#0EA5E9" />
</div>

<div class="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
    {{-- By Status --}}
    <x-card title="Drivers by Status" padding="p-0">
        <div class="divide-y divide-line dark:divide-strokedark">
            @forelse ($statusReport as $row)
                <div class="flex items-center justify-between px-6 py-3">
                    <span class="flex items-center gap-2 text-sm text-ink dark:text-gray-200">
                        <span class="h-2.5 w-2.5 rounded-full" style="background:{{ $row['color'] }}"></span>{{ $row['label'] }}
                    </span>
                    <span class="text-sm font-semibold text-ink dark:text-gray-200">{{ $row['value'] }}</span>
                </div>
            @empty
                <p class="px-6 py-6 text-center text-sm text-muted">No data.</p>
            @endforelse
        </div>
    </x-card>

    {{-- By Tier --}}
    <x-card title="Drivers by Tier" padding="p-0">
        <div class="divide-y divide-line dark:divide-strokedark">
            @forelse ($tierReport as $row)
                <div class="flex items-center justify-between px-6 py-3">
                    <span class="flex items-center gap-2 text-sm text-ink dark:text-gray-200">
                        <span class="h-2.5 w-2.5 rounded-full" style="background:{{ $row['color'] }}"></span>{{ $row['label'] }}
                    </span>
                    <div class="flex items-center gap-3">
                        <div class="hidden h-2 w-24 overflow-hidden rounded-full bg-gray-200 dark:bg-gray-700 sm:block">
                            @if ($summary['total'] > 0)
                                <div class="h-full rounded-full" style="background:{{ $row['color'] }}; width:{{ round($row['value'] / $summary['total'] * 100) }}%"></div>
                            @endif
                        </div>
                        <span class="text-sm font-semibold text-ink dark:text-gray-200">{{ $row['value'] }}</span>
                    </div>
                </div>
            @empty
                <p class="px-6 py-6 text-center text-sm text-muted">No data.</p>
            @endforelse
        </div>
    </x-card>
</div>

{{-- Contract KPIs --}}
<div class="mt-6 grid grid-cols-2 gap-4 xl:grid-cols-4">
    <x-stat-card label="Active Contracts" :value="number_format($contractStats['active'])" icon="fa-file-signature" iconColor="#16A34A" />
    <x-stat-card label="Expired Contracts" :value="number_format($contractStats['expired'])" icon="fa-file-circle-xmark" iconColor="#9CA3AF" />
    <x-stat-card label="No Active Contract" :value="number_format($contractStats['noActive'])" icon="fa-file-circle-question" iconColor="#F79009" />
    <x-stat-card label="Sponsor-Linked Drivers" :value="number_format($contractStats['linked'])" icon="fa-link" iconColor="#465FFF" />
</div>

<div class="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-3">
    {{-- By Racing Level --}}
    <x-card title="Drivers by Racing Level" padding="p-0">
        <div class="divide-y divide-line dark:divide-strokedark">
            @forelse ($levelReport as $row)
                <div class="flex items-center justify-between px-6 py-3">
                    <span class="flex items-center gap-2 text-sm text-ink dark:text-gray-200">
                        <span class="h-2.5 w-2.5 rounded-full" style="background:{{ $row['color'] }}"></span>{{ $row['label'] }}
                    </span>
                    <span class="text-sm font-semibold text-ink dark:text-gray-200">{{ $row['value'] }}</span>
                </div>
            @empty
                <p class="px-6 py-6 text-center text-sm text-muted">No racing level data yet.</p>
            @endforelse
        </div>
    </x-card>

    {{-- By Car Type --}}
    <x-card title="Drivers by Car Type" padding="p-0">
        <div class="divide-y divide-line dark:divide-strokedark">
            @forelse ($carTypeReport as $row)
                <div class="flex items-center justify-between px-6 py-3">
                    <span class="flex items-center gap-2 text-sm text-ink dark:text-gray-200">
                        <span class="h-2.5 w-2.5 rounded-full" style="background:{{ $row['color'] }}"></span>{{ $row['label'] }}
                    </span>
                    <span class="text-sm font-semibold text-ink dark:text-gray-200">{{ $row['value'] }}</span>
                </div>
            @empty
                <p class="px-6 py-6 text-center text-sm text-muted">No car type data yet.</p>
            @endforelse
        </div>
    </x-card>

    {{-- By Age Group --}}
    <x-card title="Drivers by Age Group" padding="p-0">
        <div class="divide-y divide-line dark:divide-strokedark">
            @forelse ($ageGroupReport as $group => $count)
                <div class="flex items-center justify-between px-6 py-3">
                    <span class="text-sm text-ink dark:text-gray-200">{{ $group }}</span>
                    <span class="text-sm font-semibold text-ink dark:text-gray-200">{{ $count }}</span>
                </div>
            @empty
                <p class="px-6 py-6 text-center text-sm text-muted">No DOB data yet.</p>
            @endforelse
        </div>
    </x-card>
</div>

<div class="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
    {{-- By Country --}}
    <x-card title="Top Countries" padding="p-0">
        <div class="divide-y divide-line dark:divide-strokedark">
            @forelse ($byCountry as $country => $count)
                <div class="flex items-center justify-between px-6 py-3">
                    <span class="text-sm text-ink dark:text-gray-200">{{ $country }}</span>
                    <span class="text-sm font-semibold text-ink dark:text-gray-200">{{ $count }}</span>
                </div>
            @empty
                <p class="px-6 py-6 text-center text-sm text-muted">No country data.</p>
            @endforelse
        </div>
    </x-card>

    {{-- By Series --}}
    <x-card title="Top Racing Series" padding="p-0">
        <div class="divide-y divide-line dark:divide-strokedark">
            @forelse ($bySeries as $series => $count)
                <div class="flex items-center justify-between px-6 py-3">
                    <span class="text-sm text-ink dark:text-gray-200">{{ $series }}</span>
                    <span class="text-sm font-semibold text-ink dark:text-gray-200">{{ $count }}</span>
                </div>
            @empty
                <p class="px-6 py-6 text-center text-sm text-muted">No series data.</p>
            @endforelse
        </div>
    </x-card>
</div>

<div class="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
    {{-- Sponsorship breakdown --}}
    <x-card title="Sponsorship Interest">
        <div class="flex items-center gap-8">
            <div class="text-center">
                <p class="text-3xl font-bold text-amber-500">{{ number_format($seekingCount) }}</p>
                <p class="mt-1 text-xs text-muted">Seeking Sponsorship</p>
            </div>
            <div class="text-center">
                <p class="text-3xl font-bold text-ink dark:text-gray-300">{{ number_format($notSeekingCount) }}</p>
                <p class="mt-1 text-xs text-muted">Not Seeking</p>
            </div>
        </div>
        @if ($summary['total'] > 0)
            <div class="mt-4 flex h-3 overflow-hidden rounded-full bg-gray-200 dark:bg-gray-700">
                <div class="h-full bg-amber-500" style="width:{{ round($seekingCount / $summary['total'] * 100) }}%"></div>
            </div>
            <p class="mt-2 text-xs text-muted">{{ round($seekingCount / $summary['total'] * 100, 1) }}% of drivers are seeking sponsorship</p>
        @endif
    </x-card>

    {{-- Monthly trend --}}
    <x-card title="Monthly Intake (Last 6 Months)" padding="p-0">
        <div class="divide-y divide-line dark:divide-strokedark">
            @forelse ($trend as $month => $count)
                <div class="flex items-center justify-between px-6 py-3">
                    <span class="text-sm text-ink dark:text-gray-200">{{ \Carbon\Carbon::createFromFormat('Y-m', $month)->format('M Y') }}</span>
                    <div class="flex items-center gap-3">
                        <div class="hidden h-2 w-24 overflow-hidden rounded-full bg-gray-200 dark:bg-gray-700 sm:block">
                            @if ($trend->max() > 0)
                                <div class="h-full rounded-full bg-brand" style="width:{{ round($count / $trend->max() * 100) }}%"></div>
                            @endif
                        </div>
                        <span class="text-sm font-semibold text-ink dark:text-gray-200">{{ $count }}</span>
                    </div>
                </div>
            @empty
                <p class="px-6 py-6 text-center text-sm text-muted">No data yet.</p>
            @endforelse
        </div>
    </x-card>
</div>

{{-- Top drivers by career wins --}}
<x-card class="mt-6" title="Top Drivers by Career Wins" padding="p-0">
    <div class="overflow-x-auto">
        <table class="w-full">
            <thead class="border-b border-line dark:border-strokedark">
                <tr>
                    <th class="ta-th">#</th>
                    <th class="ta-th">Driver</th>
                    <th class="ta-th">Email</th>
                    <th class="ta-th">Career Wins</th>
                    <th class="ta-th">Years Racing</th>
                    <th class="ta-th">Tier</th>
                    <th class="ta-th">Followers</th>
                    <th class="ta-th"></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-line dark:divide-strokedark">
                @forelse ($topDrivers as $i => $driver)
                    <tr>
                        <td class="ta-td text-muted">{{ $i + 1 }}</td>
                        <td class="ta-td font-medium text-ink dark:text-gray-200">{{ $driver->full_name }}</td>
                        <td class="ta-td text-muted">{{ $driver->email }}</td>
                        <td class="ta-td font-semibold text-ink dark:text-gray-200">{{ $driver->career_wins }}</td>
                        <td class="ta-td text-muted">{{ $driver->years_racing }}</td>
                        <td class="ta-td"><x-badge :label="$driver->inferred_tier->label()" :color="$driver->inferred_tier->color()" /></td>
                        <td class="ta-td text-muted">{{ number_format($driver->instagram_followers) }}</td>
                        <td class="ta-td">
                            <a href="{{ route('driver-leads.show', $driver) }}" class="btn btn-light !px-3 !py-1.5 text-xs">View</a>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="8" class="ta-td py-6 text-center text-muted">No driver leads in this period.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</x-card>
@endsection
