<?php

namespace App\Services;

use App\Models\DriverLead;
use App\Models\Lead;
use App\Models\SponsorProfile;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Pushes newly created CRM records to a Google Apps Script Web App,
 * which appends them as rows in the matching Google Sheet tab:
 *
 *   Lead           → BaseLeads
 *   DriverLead     → DriverLeads
 *   SponsorProfile → sponserleads
 */
class GoogleSheetSyncService
{
    public function enabled(): bool
    {
        return (bool) config('services.google_sheets.url');
    }

    /** Send one record. Returns true when the sheet acknowledged the row. */
    public function sync(Model $record): bool
    {
        if (! $this->enabled()) {
            return false;
        }

        [$sheetName, $data] = match (true) {
            $record instanceof DriverLead     => ['DriverLeads', $this->driverLeadRow($record)],
            $record instanceof SponsorProfile => ['sponserleads', $this->sponsorRow($record)],
            $record instanceof Lead           => ['BaseLeads', $this->baseLeadRow($record)],
            default => throw new \InvalidArgumentException('Unsupported model: ' . $record::class),
        };

        $payload = [
            'secret'    => config('services.google_sheets.secret'),
            'sheetName' => $sheetName,
            'data'      => $data,
        ];

        try {
            $response = Http::timeout(20)
                ->withHeaders(['Content-Type' => 'application/json'])
                ->post(config('services.google_sheets.url'), $payload);

            $json = $response->json();

            if ($response->successful() && ($json['success'] ?? false) === true) {
                return true;
            }

            Log::warning('Google Sheet sync rejected', [
                'sheet'  => $sheetName,
                'id'     => $record->getKey(),
                'status' => $response->status(),
                'body'   => $response->body(),
            ]);
        } catch (\Throwable $e) {
            Log::warning('Google Sheet sync failed', [
                'sheet' => $sheetName,
                'id'    => $record->getKey(),
                'error' => $e->getMessage(),
            ]);
        }

        return false;
    }

    private function driverLeadRow(DriverLead $d): array
    {
        return [
            'CRM Lead ID'           => $d->id,
            'Created At'            => $d->created_at?->format('Y-m-d H:i:s'),
            'Contact First Name'    => $d->first_name ?? '',
            'Contact Last Name'     => $d->last_name ?? '',
            'Contact Email'         => $d->email ?? '',
            'Contact Phone'         => $d->phone ?? '',
            'Contact Country'       => $d->country ?? '',
            'DOB'                   => $d->dob?->format('Y-m-d') ?? '',
            'Age Group'             => $d->age_group ?? '',
            'Racing Years Racing'   => (string) ($d->years_racing ?? ''),
            'Racing Highest Series' => $d->highest_series ?? '',
            'Racing Level'          => $d->racing_level?->label() ?? '',
            'Car Type'              => $d->car_type?->label() ?? '',
            'Racing Career Wins'    => (string) ($d->career_wins ?? ''),
            'Racing Team / Series'  => $d->current_team_series ?? '',
            'Social Instagram'      => $d->instagram_handle ?? '',
            'Social Followers'      => (string) ($d->instagram_followers ?? ''),
            'Seeking Sponsorship'   => $d->seeking_sponsorship ? 'Yes' : 'No',
            'Contract Interest'     => $d->contract_interest_type?->label() ?? '',
            'Tier'                  => $d->inferred_tier?->label() ?? '',
            'Lead Status'           => $d->status?->label() ?? 'New',
        ];
    }

    private function sponsorRow(SponsorProfile $s): array
    {
        return [
            'CRM Lead ID'        => $s->id,
            'Created At'         => $s->created_at?->format('Y-m-d H:i:s'),
            'Company Name'       => $s->company_name ?? '',
            'Company Type'       => $s->company_type?->label() ?? '',
            'Industry'           => $s->industry ?? '',
            'Website'            => $s->website ?? '',
            'Contact Person'     => $s->contact_name ?? '',
            'Contact Email'      => $s->email ?? '',
            'Contact Phone'      => $s->phone ?? '',
            'Country'            => $s->country ?? '',
            'State'              => $s->state ?? '',
            'City'               => $s->city ?? '',
            'Estimated Budget'   => $s->estimated_budget !== null ? (string) $s->estimated_budget : '',
            'Status'             => $s->status?->label() ?? 'Prospect',
            'Assigned To'        => $s->assignee?->name ?? '',
            'Notes'              => $s->notes ?? '',
        ];
    }

    private function baseLeadRow(Lead $l): array
    {
        return [
            'CRM Lead ID'         => $l->id,
            'Created At'          => $l->created_at?->format('Y-m-d H:i:s'),
            'Contact First Name'  => $l->first_name ?? '',
            'Contact Last Name'   => $l->last_name ?? '',
            'Contact Full Name'   => $l->full_name ?? '',
            'Contact Email'       => $l->email ?? '',
            'Contact Phone'       => $l->phone ?? '',
            'Contact Country'     => $l->country ?? '',
            'Contact State'       => $l->loc_state ?? '',
            'Contact City'        => $l->city ?? '',
            'Company'             => $l->company ?? '',
            'Motorsport Interest' => $l->motorsport_interest_type?->label() ?? '',
            'Motorsport Notes'    => $l->motorsport_notes ?? '',
            'Message'             => $l->message ?? '',
            'Lead Source'         => $l->source_channel?->label() ?? 'CRM',
            'Lead Status'         => $l->status?->label() ?? 'New',
            'Priority'            => $l->priority?->label() ?? '',
            'Lead Score'          => (string) ($l->lead_score ?? ''),
            'Assigned To'         => $l->assignee?->name ?? '',
        ];
    }
}
