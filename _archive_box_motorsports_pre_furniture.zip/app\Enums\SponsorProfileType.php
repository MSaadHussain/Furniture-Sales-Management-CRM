<?php

namespace App\Enums;

enum SponsorProfileType: string
{
    case Sponsor = 'sponsor';
    case Vendor = 'vendor';
    case TrackPartner = 'track_partner';
    case RacingAssetProvider = 'racing_asset_provider';
    case MediaPartner = 'media_partner';

    public function label(): string
    {
        return match ($this) {
            self::Sponsor             => 'Sponsor',
            self::Vendor              => 'Vendor',
            self::TrackPartner        => 'Track Partner',
            self::RacingAssetProvider => 'Racing Asset Provider',
            self::MediaPartner        => 'Media Partner',
        };
    }

    public function color(): string
    {
        return match ($this) {
            self::Sponsor             => '#465FFF',
            self::Vendor              => '#F97316',
            self::TrackPartner        => '#16A34A',
            self::RacingAssetProvider => '#7C3AED',
            self::MediaPartner        => '#0EA5E9',
        };
    }

    public static function options(): array
    {
        return array_map(
            fn (self $t) => ['value' => $t->value, 'label' => $t->label(), 'color' => $t->color()],
            self::cases()
        );
    }
}
