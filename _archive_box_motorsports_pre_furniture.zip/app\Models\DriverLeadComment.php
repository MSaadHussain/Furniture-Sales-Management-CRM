<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DriverLeadComment extends Model
{
    protected $table = 'driver_leads_comments';

    protected $fillable = [
        'driver_lead_id', 'user_id', 'body',
    ];

    public function driverLead()
    {
        return $this->belongsTo(DriverLead::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
