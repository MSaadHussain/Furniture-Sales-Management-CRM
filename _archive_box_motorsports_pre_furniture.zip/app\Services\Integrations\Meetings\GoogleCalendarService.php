<?php

namespace App\Services\Integrations\Meetings;

use App\Models\IntegrationSetting;
use App\Models\LeadMeeting;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

/**
 * Creates Google Calendar events with an attached Google Meet link, using a
 * stored OAuth refresh token to mint short-lived access tokens. No SDK needed —
 * plain Google REST endpoints. Credentials live in the `google_meet`
 * integration_settings row (env fallbacks in services.google_meet).
 */
class GoogleCalendarService
{
    private const TOKEN_URL = 'https://oauth2.googleapis.com/token';
    private const CAL_URL   = 'https://www.googleapis.com/calendar/v3/calendars';

    private array $config;

    public function __construct()
    {
        $this->config = IntegrationSetting::where('channel', 'google_meet')->value('config') ?? [];
    }

    private function cfg(string $key, ?string $envKey = null): ?string
    {
        return $this->config[$key] ?? ($envKey ? config("services.google_meet.{$envKey}") : null);
    }

    public function accessToken(): ?string
    {
        $refresh = $this->cfg('refresh_token', 'refresh_token');
        $id      = $this->cfg('client_id', 'client_id');
        $secret  = $this->cfg('client_secret', 'client_secret');

        if (! $refresh || ! $id || ! $secret) {
            return null;
        }

        $response = Http::asForm()->timeout(10)->post(self::TOKEN_URL, [
            'client_id'     => $id,
            'client_secret' => $secret,
            'refresh_token' => $refresh,
            'grant_type'    => 'refresh_token',
        ]);

        return $response->successful() ? $response->json('access_token') : null;
    }

    /**
     * Create a Calendar event + Meet link and persist a LeadMeeting attached to
     * any meetable record (Lead, DriverLead or SponsorProfile).
     */
    public function createMeeting(
        Model $meetable,
        string $title,
        Carbon $start,
        Carbon $end,
        ?string $attendeeEmail = null,
        ?string $attendeeName = null,
        ?int $userId = null,
        ?string $description = null,
    ): LeadMeeting {
        $token = $this->accessToken();
        $calendarId = $this->cfg('calendar_id', 'calendar_id') ?: 'primary';

        $meetingUrl = null;
        $externalId = null;
        $raw = [];

        if ($token) {
            $tz = config('app.timezone') ?: 'UTC';

            $event = [
                'summary' => $title,
                'start'   => ['dateTime' => $start->toRfc3339String(), 'timeZone' => $tz],
                'end'     => ['dateTime' => $end->toRfc3339String(), 'timeZone' => $tz],
                'attendees' => array_filter([
                    $attendeeEmail ? ['email' => $attendeeEmail] : null,
                ]),
                'conferenceData' => [
                    'createRequest' => [
                        'requestId' => (string) Str::uuid(),
                        'conferenceSolutionKey' => ['type' => 'hangoutsMeet'],
                    ],
                ],
            ];

            if (filled($description)) {
                $event['description'] = $description;
            }

            // sendUpdates=none → Google does NOT email attendees the raw "unknown
            // sender" calendar invite; the lead gets our own branded email instead.
            $response = Http::withToken($token)->timeout(15)->post(
                self::CAL_URL . "/{$calendarId}/events?conferenceDataVersion=1&sendUpdates=none",
                $event
            );

            if ($response->successful()) {
                $raw = $response->json();
                $externalId = $raw['id'] ?? null;
                $meetingUrl = $raw['hangoutLink']
                    ?? data_get($raw, 'conferenceData.entryPoints.0.uri');
            }
        }

        $meeting = new LeadMeeting([
            'provider'          => 'google_meet',
            'external_event_id' => $externalId,
            'meeting_title'     => $title,
            'description'       => $description,
            'meeting_url'       => $meetingUrl,
            'starts_at'         => $start,
            'ends_at'           => $end,
            'attendee_email'    => $attendeeEmail,
            'attendee_name'     => $attendeeName,
            'status'            => 'scheduled',
            'raw_payload'       => $raw ?: null,
            'created_by'        => $userId,
        ]);
        $meeting->meetable()->associate($meetable);
        $meeting->save();

        return $meeting;
    }

    /**
     * Delete a Calendar event (and its Meet link) by its external event id.
     * Best-effort: returns false if no token or the call fails.
     */
    public function deleteEvent(string $eventId): bool
    {
        $token = $this->accessToken();
        if (! $token) {
            return false;
        }

        $calendarId = $this->cfg('calendar_id', 'calendar_id') ?: 'primary';

        $response = Http::withToken($token)->timeout(15)
            ->delete(self::CAL_URL . "/{$calendarId}/events/{$eventId}");

        // 200/204 = deleted, 410 = already gone — both are success for our purposes.
        return $response->successful() || $response->status() === 410;
    }

    public function testConnection(): array
    {
        return $this->accessToken()
            ? [true, 'Google Calendar connected.']
            : [false, 'Could not obtain an access token. Check client ID/secret and refresh token.'];
    }
}
