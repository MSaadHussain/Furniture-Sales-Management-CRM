<?php

use App\Models\ReportSetting;
use Illuminate\Support\Facades\Schedule;

// Process queued notifications on shared hosting (runs via cron schedule:run)
Schedule::command('queue:work --stop-when-empty --max-time=55')
    ->everyMinute()
    ->withoutOverlapping();

// Weekly lead report — day/time configurable in Settings (default Monday 09:00).
// Guarded so artisan still runs before the report_settings table exists.
$reportDay = 1;        // Monday
$reportTime = '09:00';
try {
    if (\Illuminate\Support\Facades\Schema::hasTable('report_settings')) {
        $reportDay  = (int) ReportSetting::get('weekly_report_day', 1);
        $reportTime = (string) ReportSetting::get('weekly_report_time', '09:00');
    }
} catch (\Throwable $e) {
    // DB not ready; fall back to defaults.
}

Schedule::command('crm:weekly-report')
    ->weeklyOn($reportDay, $reportTime)
    ->timezone(config('app.timezone'))   // honour APP_TIMEZONE so the set time = local time
    ->withoutOverlapping();
