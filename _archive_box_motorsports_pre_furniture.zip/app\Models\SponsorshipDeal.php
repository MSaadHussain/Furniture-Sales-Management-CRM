<?php

namespace App\Models;

use App\Enums\LeadPriority;
use App\Enums\SponsorshipStage;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class SponsorshipDeal extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'sponsor_profile_id', 'title', 'stage', 'deal_value', 'probability',
        'expected_close_date', 'package_type', 'assigned_to', 'priority', 'closed_at',
    ];

    protected function casts(): array
    {
        return [
            'stage'               => SponsorshipStage::class,
            'priority'            => LeadPriority::class,
            'deal_value'          => 'decimal:2',
            'probability'         => 'integer',
            'expected_close_date' => 'date',
            'closed_at'           => 'datetime',
        ];
    }

    public function sponsor()
    {
        return $this->belongsTo(SponsorProfile::class, 'sponsor_profile_id');
    }

    public function activities()
    {
        return $this->hasMany(SponsorActivity::class)->latest();
    }

    public function driverLinks()
    {
        return $this->hasMany(SponsorDriverLink::class);
    }

    public function assignee()
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    public function getWeightedValueAttribute(): float
    {
        return (float) $this->deal_value * $this->probability / 100;
    }
}
