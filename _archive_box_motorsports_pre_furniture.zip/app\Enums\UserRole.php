<?php

namespace App\Enums;

enum UserRole: string
{
    case SuperAdmin = 'super_admin';
    case Admin = 'admin';
    case SalesManager = 'sales_manager';
    case SalesRep = 'sales_rep';
    case Viewer = 'viewer';

    public function label(): string
    {
        return match ($this) {
            self::SuperAdmin   => 'Super Admin',
            self::Admin        => 'Admin',
            self::SalesManager => 'Sales Manager',
            self::SalesRep     => 'Sales Representative',
            self::Viewer       => 'Viewer',
        };
    }

    public function canManageUsers(): bool
    {
        return in_array($this, [self::SuperAdmin, self::Admin], true);
    }

    public function canManagePipeline(): bool
    {
        return in_array($this, [self::SuperAdmin, self::Admin, self::SalesManager], true);
    }

    public function isReadOnly(): bool
    {
        return $this === self::Viewer;
    }

    public static function options(): array
    {
        return array_map(
            fn (self $r) => ['value' => $r->value, 'label' => $r->label()],
            self::cases()
        );
    }
}
