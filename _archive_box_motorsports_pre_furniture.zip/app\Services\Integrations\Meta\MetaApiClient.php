<?php

namespace App\Services\Integrations\Meta;

use App\Models\IntegrationSetting;
use Illuminate\Support\Facades\Http;

/**
 * Thin client for the Meta (Facebook) Graph API. Reads credentials from the
 * `meta` integration_settings row (config) with env fallbacks.
 */
class MetaApiClient
{
    private const GRAPH = 'https://graph.facebook.com/v19.0';

    private array $config;

    public function __construct()
    {
        $this->config = IntegrationSetting::where('channel', 'meta')->value('config') ?? [];
    }

    public function accessToken(): ?string
    {
        return $this->config['access_token'] ?? config('services.meta.access_token');
    }

    /** Fetch a single lead's field data from Graph by leadgen id. */
    public function fetchLead(string $leadgenId): ?array
    {
        $token = $this->accessToken();
        if (! $token) {
            return null;
        }

        $response = Http::timeout(10)->get(self::GRAPH . "/{$leadgenId}", [
            'access_token' => $token,
            'fields'       => 'id,created_time,field_data,form_id,campaign_name,ad_name',
        ]);

        return $response->successful() ? $response->json() : null;
    }

    /** Verify credentials by calling the page node. */
    public function testConnection(): array
    {
        $token  = $this->accessToken();
        $pageId = $this->config['page_id'] ?? config('services.meta.page_id');

        if (! $token || ! $pageId) {
            return [false, 'Missing access token or page ID.'];
        }

        $response = Http::timeout(10)->get(self::GRAPH . "/{$pageId}", [
            'access_token' => $token,
            'fields'       => 'id,name',
        ]);

        return $response->successful()
            ? [true, 'Connected to page: ' . ($response->json('name') ?? $pageId)]
            : [false, 'Meta API error: ' . $response->json('error.message', 'unknown')];
    }
}
