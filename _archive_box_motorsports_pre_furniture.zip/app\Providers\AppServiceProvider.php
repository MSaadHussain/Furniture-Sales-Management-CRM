<?php

namespace App\Providers;

use App\Enums\UserRole;
use App\Jobs\SyncLeadToGoogleSheet;
use App\Models\DriverLead;
use App\Models\Lead;
use App\Models\SponsorProfile;
use App\Models\User;
use App\Policies\LeadPolicy;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void {}

    public function boot(): void
    {
        Gate::policy(Lead::class, LeadPolicy::class);

        Gate::define('manage-users', fn (User $u) => $u->role->canManageUsers() && $u->is_active);
        Gate::define('manage-integrations', fn (User $u) => $u->hasRole(UserRole::SuperAdmin, UserRole::Admin));
        Gate::define('manage-pipeline', fn (User $u) => $u->role->canManagePipeline() && $u->is_active);
        Gate::define('view-reports', fn (User $u) => ! $u->hasRole(UserRole::SalesRep) || $u->is_active);
        // Phase 4: only Super Admin can view user activity / time-spent reports.
        Gate::define('view-activity', fn (User $u) => $u->hasRole(UserRole::SuperAdmin) && $u->is_active);

        Gate::before(fn (User $u) => $u->hasRole(UserRole::SuperAdmin) ? true : null);

        RateLimiter::for('webhooks', function (Request $request) {
            return Limit::perMinute(60)->by($request->ip());
        });

        // Google Sheets outbound sync — every new lead of any type is pushed
        // to the Apps Script Web App (BaseLeads / DriverLeads / sponserleads).
        // No-ops when GOOGLE_SHEETS_SYNC_URL is not configured.
        if (config('services.google_sheets.url')) {
            Lead::created(fn (Lead $l) => SyncLeadToGoogleSheet::dispatch(Lead::class, $l->id));
            DriverLead::created(fn (DriverLead $d) => SyncLeadToGoogleSheet::dispatch(DriverLead::class, $d->id));
            SponsorProfile::created(fn (SponsorProfile $s) => SyncLeadToGoogleSheet::dispatch(SponsorProfile::class, $s->id));
        }
    }
}
