@extends('layouts.app')
@section('title', 'Preview Import')
@section('breadcrumb')
    <a href="{{ route('sponsors.index') }}" class="hover:text-brand">Sponsors & Vendors</a> /
    <a href="{{ route('sponsors.import') }}" class="hover:text-brand">Import</a> /
    <span>Preview</span>
@endsection

@section('content')
<form method="POST" action="{{ route('sponsors.import.confirm') }}">
    @csrf
    <input type="hidden" name="stored_path" value="{{ $storedPath }}">

    <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">

        {{-- Column mapping --}}
        <div class="lg:col-span-2">
            <x-card class="h-full" title="Column Mapping" subtitle="Map each CSV column to a sponsor field. Unmapped columns will be skipped.">
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="border-b border-line dark:border-strokedark">
                            <tr>
                                <th class="ta-th">CSV Column</th>
                                <th class="ta-th">Maps To</th>
                                <th class="ta-th">Sample Values</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-line dark:divide-strokedark">
                            @foreach ($headers as $i => $header)
                                <tr>
                                    <td class="ta-td font-medium text-ink dark:text-gray-200">{{ $header }}</td>
                                    <td class="ta-td">
                                        <select name="column_map[{{ $i }}]" class="ta-input !py-1.5 text-sm">
                                            <option value="">— Skip —</option>
                                            @foreach ($fields as $field)
                                                <option value="{{ $field }}" @selected(($suggestedMap[$i] ?? '') === $field)>
                                                    {{ str_replace('_', ' ', ucfirst($field)) }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </td>
                                    <td class="ta-td text-sm text-muted">
                                        @foreach (array_slice($rows, 0, 3) as $row)
                                            {{ \Illuminate\Support\Str::limit($row[$i] ?? '', 30) }}@if (!$loop->last), @endif
                                        @endforeach
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </x-card>
        </div>

        {{-- Options sidebar --}}
        <div class="space-y-6">
            <x-card title="Import Options">
                <p class="mb-3 text-sm text-ink dark:text-gray-300">
                    <i class="fa-solid fa-file-csv mr-1 text-brand"></i>
                    <strong>{{ $fileName }}</strong> — {{ $totalRows }} row{{ $totalRows !== 1 ? 's' : '' }}
                </p>

                <h4 class="mb-2 text-xs font-semibold uppercase tracking-wider text-muted">Duplicates</h4>
                <p class="mb-3 text-xs text-muted">When a sponsor matches an existing email or company name</p>
                <div class="space-y-2">
                    <label class="flex cursor-pointer items-center gap-3 rounded-lg border border-line p-3 text-sm transition hover:border-brand dark:border-strokedark">
                        <input type="radio" name="duplicate" value="skip" checked class="text-brand focus:ring-brand">
                        <div>
                            <span class="font-medium text-ink dark:text-white">Skip</span>
                            <p class="text-xs text-muted">Leave existing sponsors untouched; do not import the row.</p>
                        </div>
                    </label>
                    <label class="flex cursor-pointer items-center gap-3 rounded-lg border border-line p-3 text-sm transition hover:border-brand dark:border-strokedark">
                        <input type="radio" name="duplicate" value="merge" class="text-brand focus:ring-brand">
                        <div>
                            <span class="font-medium text-ink dark:text-white">Merge</span>
                            <p class="text-xs text-muted">Fill only the blank fields on the existing sponsor.</p>
                        </div>
                    </label>
                    <label class="flex cursor-pointer items-center gap-3 rounded-lg border border-line p-3 text-sm transition hover:border-brand dark:border-strokedark">
                        <input type="radio" name="duplicate" value="update" class="text-brand focus:ring-brand">
                        <div>
                            <span class="font-medium text-ink dark:text-white">Update</span>
                            <p class="text-xs text-muted">Overwrite existing fields with the imported values.</p>
                        </div>
                    </label>
                </div>
            </x-card>

            <div class="flex flex-col gap-3">
                <button type="submit" class="btn btn-primary w-full"><i class="fa-solid fa-check"></i> Confirm Import</button>
                <a href="{{ route('sponsors.import') }}" class="btn btn-light w-full text-center"><i class="fa-solid fa-arrow-left"></i> Re-upload</a>
            </div>
        </div>
    </div>

    {{-- Data preview --}}
    <x-card class="mt-6" title="Data Preview" subtitle="Showing first {{ count($rows) }} of {{ $totalRows }} rows" padding="p-0">
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="border-b border-line dark:border-strokedark">
                    <tr>
                        @foreach ($headers as $h)
                            <th class="ta-th whitespace-nowrap">{{ $h }}</th>
                        @endforeach
                    </tr>
                </thead>
                <tbody class="divide-y divide-line dark:divide-strokedark">
                    @foreach ($rows as $row)
                        <tr>
                            @foreach ($headers as $i => $h)
                                <td class="ta-td whitespace-nowrap">{{ \Illuminate\Support\Str::limit($row[$i] ?? '', 40) }}</td>
                            @endforeach
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </x-card>
</form>
@endsection
