<?php

namespace Database\Factories;

use App\Enums\LeadPriority;
use App\Enums\LeadStatus;
use App\Enums\MotorsportInterest;
use App\Enums\SourceChannel;
use Illuminate\Database\Eloquent\Factories\Factory;

class LeadFactory extends Factory
{
    public function definition(): array
    {
            $faker = \Faker\Factory::create();

            $first = $faker->firstName();
            $last  = $faker->lastName();
            $phone = $faker->numerify('+9715########');

        $countries = [
            ['United Arab Emirates', 'AE', 'Dubai'],
            ['United Kingdom', 'GB', 'London'],
            ['United States', 'US', 'New York'],
            ['Germany', 'DE', 'Berlin'],
            ['France', 'FR', 'Paris'],
            ['Italy', 'IT', 'Milan'],
            ['Spain', 'ES', 'Madrid'],
            ['Australia', 'AU', 'Sydney'],
            ['India', 'IN', 'Mumbai'],
            ['Saudi Arabia', 'SA', 'Riyadh'],
        ];
        [$country, $code, $city] = $this->faker->randomElement($countries);

        return [
            'first_name'               => $first,
            'last_name'                => $last,
            'full_name'                => "$first $last",
            'email'                    => $this->faker->unique()->safeEmail(),
            'phone'                    => $phone,
            'normalized_phone'         => preg_replace('/[^\d+]/', '', $phone),
            'loc_state'                => $city,
            'country'                  => $country,
            'country_code'             => $code,
            'city'                     => $city,
            'company'                  => $this->faker->optional()->company(),
            'ip_address'               => $this->faker->ipv4(),
            'source_channel'           => $this->faker->randomElement(SourceChannel::cases())->value,
            'status'                   => $this->faker->randomElement(LeadStatus::cases())->value,
            'priority'                 => $this->faker->randomElement(LeadPriority::cases())->value,
            'lead_score'               => $this->faker->numberBetween(0, 100),
            'motorsport_interest_type' => $this->faker->randomElement(MotorsportInterest::cases())->value,
            'message'                  => $this->faker->sentence(12),
            'last_activity_at'         => now()->subHours($this->faker->numberBetween(0, 240)),
        ];
    }
}
