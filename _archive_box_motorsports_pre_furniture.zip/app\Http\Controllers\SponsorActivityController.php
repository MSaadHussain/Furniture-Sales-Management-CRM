<?php

namespace App\Http\Controllers;

use App\Enums\SponsorActionType;
use App\Models\SponsorActivity;
use App\Models\SponsorProfile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rules\Enum;

class SponsorActivityController extends Controller
{
    public function store(Request $request, SponsorProfile $sponsor)
    {
        $validated = $request->validate([
            'action_type'         => ['required', new Enum(SponsorActionType::class)],
            'description'         => ['nullable', 'string', 'max:2000'],
            'sponsorship_deal_id' => ['nullable', 'exists:sponsorship_deals,id'],
            'driver_lead_id'      => ['nullable', 'exists:driver_leads,id'],
            'due_date'            => ['nullable', 'date'],
            'completed'           => ['nullable', 'boolean'],
            'attachment'          => ['nullable', 'file', 'max:10240'],
        ]);

        $attachmentPath = null;
        if ($request->hasFile('attachment')) {
            $attachmentPath = $request->file('attachment')->store('sponsor-attachments', 'public');
        }

        SponsorActivity::create([
            'sponsor_profile_id'  => $sponsor->id,
            'sponsorship_deal_id' => $validated['sponsorship_deal_id'] ?? null,
            'driver_lead_id'      => $validated['driver_lead_id'] ?? null,
            'action_type'         => $validated['action_type'],
            'description'         => $validated['description'] ?? null,
            'performed_by'        => Auth::id(),
            'due_date'            => $validated['due_date'] ?? null,
            'completed_at'        => $request->boolean('completed', true) ? now() : null,
            'attachment_path'     => $attachmentPath,
        ]);

        return back()->with('toast', 'Activity logged.');
    }

    public function complete(SponsorActivity $activity)
    {
        $activity->update(['completed_at' => now()]);

        return back()->with('toast', 'Activity marked complete.');
    }

    public function destroy(SponsorActivity $activity)
    {
        $activity->delete();

        return back()->with('toast', 'Activity removed.');
    }
}
