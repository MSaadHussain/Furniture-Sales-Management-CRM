@extends('layouts.app')
@section('title', 'Driver Lead Form')
@section('breadcrumb')
    <a href="{{ route('integrations.index') }}" class="hover:text-brand">Integrations</a> / <span>Driver Lead Form</span>
@endsection

@section('content')
<div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
    <form method="POST" action="{{ route('integrations.driver-lead-form.save') }}" class="lg:col-span-2">
        @csrf
        <x-card class="h-full" title="Driver Lead Form Settings" subtitle="Configure the webhook integration for your Google Form that collects racing driver leads">
            <div class="space-y-4">
                <div class="flex items-center justify-between rounded-xl border border-line p-3 dark:border-strokedark">
                    <span class="text-sm font-medium text-ink dark:text-gray-200">Integration active</span>
                    <input type="checkbox" name="enabled" value="1" @checked($setting->enabled)
                           class="h-5 w-9 rounded-full text-brand focus:ring-brand">
                </div>

                <div class="pt-2">
                    <h4 class="text-sm font-medium text-ink dark:text-gray-200 mb-2">Instructions</h4>
                    <p class="text-xs text-muted leading-relaxed">
                        1. Create a Google Form with these 16 questions: First Name, Last Name, Email, Phone, Country, DOB, Years Racing, Highest Series, Racing Level, Car Type, Career Wins, Current Team / Series, Instagram Handle, Instagram Followers, Seeking Sponsorship, Interested Contract Type. Answers are matched by question title, so order doesn't matter.<br>
                        2. Open the form's <strong>Script Editor</strong> (three-dot menu → Script Editor).<br>
                        3. Paste the Apps Script snippet below.<br>
                        4. Go to <strong>Triggers</strong> → <strong>Add Trigger</strong> → select <code>onFormSubmit</code> → From form → On form submit.<br>
                        5. Save and authorize the script.
                    </p>
                </div>

                <div class="flex justify-end gap-2 pt-2">
                    <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save Settings</button>
                </div>
            </div>
        </x-card>
    </form>

    <div class="space-y-6">
        <x-card title="Webhook Endpoint" subtitle="Configure in your Apps Script">
            <div>
                <label class="ta-label">Webhook URL</label>
                <div class="flex gap-2">
                    <input type="text" readonly value="{{ $webhookUrl }}" id="dl-webhook-url" class="ta-input flex-1 font-mono text-xs">
                    <button type="button" class="btn btn-light" onclick="navigator.clipboard.writeText(document.getElementById('dl-webhook-url').value); this.innerHTML='<i class=\'fa-solid fa-check\'></i>'; setTimeout(()=>this.innerHTML='<i class=\'fa-regular fa-copy\'></i>',1500)"><i class="fa-regular fa-copy"></i></button>
                </div>
            </div>

            <div class="mt-4">
                <label class="ta-label">Secret Key</label>
                <div class="flex gap-2">
                    <input type="password" readonly value="{{ $setting->secret_key }}" id="dl-secret-key" class="ta-input flex-1 font-mono text-xs">
                    <button type="button" class="btn btn-light" onclick="var f=document.getElementById('dl-secret-key'); f.type=f.type==='password'?'text':'password'; this.querySelector('i').className=f.type==='password'?'fa-solid fa-eye':'fa-solid fa-eye-slash'"><i class="fa-solid fa-eye"></i></button>
                    <button type="button" class="btn btn-light" onclick="navigator.clipboard.writeText(document.getElementById('dl-secret-key').value); this.innerHTML='<i class=\'fa-solid fa-check\'></i>'; setTimeout(()=>this.innerHTML='<i class=\'fa-regular fa-copy\'></i>',1500)"><i class="fa-regular fa-copy"></i></button>
                </div>
            </div>

            <div class="flex gap-2 mt-4">
                <form method="POST" action="{{ route('integrations.driver-lead-form.regenerate') }}" class="flex-1"
                      onsubmit="return confirm('Regenerate the secret? You will need to update your Google Apps Script.')">
                    @csrf
                    <button type="submit" class="btn btn-light w-full text-danger hover:bg-danger/10"><i class="fa-solid fa-rotate"></i> Regenerate Secret</button>
                </form>
            </div>
        </x-card>

        <x-card title="Test Connection">
            <form method="POST" action="{{ route('integrations.driver-lead-form.test') }}">
                @csrf
                <button type="submit" class="btn btn-light w-full"><i class="fa-solid fa-plug-circle-check"></i> Test Webhook Secret</button>
            </form>
        </x-card>
    </div>
</div>

{{-- Apps Script snippet --}}
<div class="mt-6">
    <x-card title="Google Apps Script" subtitle="Copy this code into your Google Form's Script Editor">
        <div class="relative min-w-0 overflow-hidden rounded-xl">
            <pre class="max-h-96 overflow-auto bg-gray-900 p-4 pr-28 text-xs text-gray-100" id="apps-script-code"><code>
var WEBHOOK_URL    = '{{ $webhookUrl }}';
var WEBHOOK_SECRET = '{{ $setting->secret_key }}';

function onFormSubmit(e) {
  // Map answers by question title — question order in the form doesn't matter.
  var map = {};
  e.response.getItemResponses().forEach(function (r) {
    map[r.getItem().getTitle().trim().toLowerCase()] = r.getResponse();
  });

  var payload = {
    first_name:             pick(map, 'first name'),
    last_name:              pick(map, 'last name'),
    email:                  pick(map, 'email'),
    phone:                  pick(map, 'phone'),
    country:                pick(map, 'country'),
    dob:                    pick(map, 'dob'),
    years_racing:           parseInt(pick(map, 'years racing'), 10) || 0,
    highest_series:         pick(map, 'highest series'),
    racing_level:           pick(map, 'racing level'),
    car_type:               pick(map, 'car type'),
    career_wins:            parseInt(pick(map, 'career wins'), 10) || 0,
    current_team_series:    pick(map, 'current team'),
    instagram_handle:       pick(map, 'instagram handle'),
    instagram_followers:    parseInt(pick(map, 'instagram followers'), 10) || 0,
    seeking_sponsorship:    isTruthy(pick(map, 'seeking sponsorship')),
    contract_interest_type: pick(map, 'interested contract type'),
  };

  var options = {
    method: 'post',
    contentType: 'application/json',
    headers: { 'X-Webhook-Secret': WEBHOOK_SECRET },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true,
  };
  var response = UrlFetchApp.fetch(WEBHOOK_URL, options);
  Logger.log('CRM Response (' + response.getResponseCode() + '): ' + response.getContentText());
}

// Finds the answer whose question title starts with (or contains) the key.
function pick(map, key) {
  if (map[key] !== undefined) return String(map[key]).trim();
  var titles = Object.keys(map);
  for (var i = 0; i &lt; titles.length; i++) {
    if (titles[i].indexOf(key) !== -1) return String(map[titles[i]]).trim();
  }
  return '';
}

function isTruthy(val) {
  if (!val) return false;
  var lower = String(val).toLowerCase().trim();
  return lower === 'yes' || lower === 'true' || lower === '1' || lower === 'y';
}</code></pre>
            <button type="button" onclick="navigator.clipboard.writeText(document.getElementById('apps-script-code').querySelector('code').textContent); this.innerHTML='Copied!'; setTimeout(()=>this.innerHTML='<i class=\'fa-solid fa-copy\'></i> Copy Script',1500)" class="btn btn-primary absolute right-3 top-3 text-xs">
                <i class="fa-solid fa-copy"></i> Copy Script
            </button>
        </div>
        <p class="mt-3 text-xs text-muted leading-relaxed">
            <i class="fa-solid fa-circle-info mr-1"></i>
            Answers are matched by question title (e.g. a question containing "Racing Level" maps to racing_level), so question order doesn't matter.
            Racing Level and Car Type are independent questions — the CRM never derives Car Type from Racing Level.
            For Racing Level use one of: Karting, Formula 4, Formula 3, Formula 2, Formula 1, GT Racing, Touring Car, Prototype, Stock Car, Sim Racing, Other.
            For Car Type use one of: Kart, Formula Car, GT Car, Touring Car, Prototype, Stock Car, Sim Racing, Other.
        </p>
    </x-card>
</div>

{{-- Expected fields reference --}}
<div class="mt-6">
    <x-card title="Webhook Payload Fields" subtitle="Fields accepted by the Driver Lead webhook endpoint">
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="border-b border-line dark:border-strokedark">
                    <tr>
                        <th class="ta-th">Field</th>
                        <th class="ta-th">Type</th>
                        <th class="ta-th">Description</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-line dark:divide-strokedark">
                    @foreach ([
                        ['first_name', 'string', 'Driver first name (required)'],
                        ['last_name', 'string', 'Driver last name (required)'],
                        ['email', 'string', 'Email address (required, used for dedup)'],
                        ['phone', 'string', 'Phone number'],
                        ['country', 'string', 'Country of residence'],
                        ['dob', 'date', 'Date of birth (YYYY-MM-DD) — age and age group are computed from this'],
                        ['years_racing', 'integer', 'Total years of racing experience'],
                        ['highest_series', 'string', 'Highest racing series competed in'],
                        ['racing_level', 'string', 'Racing level (Karting … Formula 1) — independent of car type'],
                        ['car_type', 'string', 'Car type (Kart, Formula Car, GT Car…) — manually selected, never auto-derived'],
                        ['career_wins', 'integer', 'Total career race wins'],
                        ['current_team_series', 'string', 'Current team and/or series'],
                        ['instagram_handle', 'string', 'Instagram username (with or without @)'],
                        ['instagram_followers', 'integer', 'Instagram follower count'],
                        ['seeking_sponsorship', 'boolean', 'Whether the driver seeks sponsorship (yes/true/1)'],
                        ['contract_interest_type', 'string', 'Contract type the driver is interested in (Sponsorship, Team Seat…)'],
                    ] as [$field, $type, $desc])
                        <tr>
                            <td class="ta-td font-mono text-xs">{{ $field }}</td>
                            <td class="ta-td text-muted">{{ $type }}</td>
                            <td class="ta-td text-muted">{{ $desc }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </x-card>
</div>
@endsection
