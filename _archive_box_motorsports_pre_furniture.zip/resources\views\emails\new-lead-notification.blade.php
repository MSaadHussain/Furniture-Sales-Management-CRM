@component('mail::message')
# New Lead Received

A new lead has just entered the CRM.

@component('mail::panel')
**{{ $lead->full_name ?: 'Unnamed lead' }}**

@if($lead->email)
**Email:** {{ $lead->email }}

@endif
@if($lead->phone)
**Phone:** {{ $lead->phone }}

@endif
@if($lead->country || $lead->loc_state || $lead->city)
**Location:** {{ collect([$lead->city, $lead->loc_state, $lead->country])->filter()->join(', ') }}
@endif
@endcomponent

| Field | Value |
|:----- |:----- |
| **Source** | {{ $lead->source_channel->label() }} |
| **Status** | {{ $lead->status->label() }} |
| **Priority** | {{ $lead->priority->label() }} |
@if($lead->motorsport_interest_type)
| **Interest** | {{ $lead->motorsport_interest_type->label() }} |
@endif
| **Received** | {{ $lead->created_at->format('M j, Y g:i A') . ' (CT)' }} |

@if($lead->message)
**Message:**

> {{ \Illuminate\Support\Str::limit($lead->message, 400) }}
@endif

@component('mail::button', ['url' => route('leads.show', $lead), 'color' => 'primary'])
View Lead
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent
