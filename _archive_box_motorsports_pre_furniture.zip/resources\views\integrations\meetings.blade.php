@extends('layouts.app')
@section('title', 'Meeting Integrations')
@section('breadcrumb')
    <a href="{{ route('integrations.index') }}" class="hover:text-brand">Integrations</a> / <span>Meetings</span>
@endsection

@section('content')
<div class="grid grid-cols-1 gap-6 lg:grid-cols-2">

    {{-- Google Meet / Calendar --}}
    <form method="POST" action="{{ route('integrations.google-meet.save') }}">
        @csrf
        <x-card title="Google Meet / Calendar" subtitle="Create Meet links from a lead">
            <div class="space-y-4">
                <div class="flex items-center justify-between rounded-xl border border-line p-3 dark:border-strokedark">
                    <span class="text-sm font-medium text-ink dark:text-gray-200">Active</span>
                    <input type="checkbox" name="enabled" value="1" @checked($google->enabled) class="h-5 w-9 rounded-full text-brand focus:ring-brand">
                </div>
                @foreach ([
                    'client_id'=>'Google Client ID','client_secret'=>'Google Client Secret','redirect_uri'=>'Redirect URI',
                    'refresh_token'=>'Refresh Token','calendar_id'=>'Calendar ID',
                ] as $f=>$label)
                    <div>
                        <label class="ta-label">{{ $label }}</label>
                        <input type="{{ str_contains($f,'secret')||str_contains($f,'token')?'password':'text' }}"
                               name="{{ $f }}" class="ta-input" value="{{ $googleConfig[$f] ?? '' }}" autocomplete="off">
                    </div>
                @endforeach
                <div class="flex gap-2 pt-2">
                    <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save</button>
                    <button type="submit" formaction="{{ route('integrations.google-meet.test') }}" class="btn btn-light"><i class="fa-solid fa-plug-circle-check"></i> Test</button>
                </div>
            </div>
        </x-card>
    </form>

    {{-- Zoom --}}
    <form method="POST" action="{{ route('integrations.zoom.save') }}">
        @csrf
        <x-card title="Zoom" subtitle="Create Zoom meetings from a lead (Server-to-Server OAuth app)">
            <div class="space-y-4">
                <div class="flex items-center justify-between rounded-xl border border-line p-3 dark:border-strokedark">
                    <span class="text-sm font-medium text-ink dark:text-gray-200">Active</span>
                    <input type="checkbox" name="enabled" value="1" @checked($zoom->enabled) class="h-5 w-9 rounded-full text-brand focus:ring-brand">
                </div>
                @foreach ([
                    'account_id'=>'Zoom Account ID','client_id'=>'Zoom Client ID','client_secret'=>'Zoom Client Secret',
                ] as $f=>$label)
                    <div>
                        <label class="ta-label">{{ $label }}</label>
                        <input type="{{ str_contains($f,'secret')?'password':'text' }}"
                               name="{{ $f }}" class="ta-input" value="{{ $zoomConfig[$f] ?? '' }}" autocomplete="off">
                    </div>
                @endforeach
                <p class="text-xs text-muted">Create a <strong>Server-to-Server OAuth</strong> app at marketplace.zoom.us with the <code>meeting:write</code> scope, then paste its Account ID, Client ID and Client Secret here.</p>
                <div class="flex gap-2 pt-2">
                    <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save</button>
                    <button type="submit" formaction="{{ route('integrations.zoom.test') }}" class="btn btn-light"><i class="fa-solid fa-plug-circle-check"></i> Test</button>
                </div>
            </div>
        </x-card>
    </form>

    {{-- Calendly integration is hidden from the CRM for now. --}}
</div>
@endsection
