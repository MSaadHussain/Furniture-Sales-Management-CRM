<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LeadMeeting extends Model
{
    protected $fillable = [
        'meetable_type', 'meetable_id', 'provider', 'external_event_id', 'meeting_title', 'description', 'meeting_url',
        'starts_at', 'ends_at', 'attendee_email', 'attendee_name', 'status',
        'previous_lead_status', 'raw_payload', 'created_by',
    ];

    protected function casts(): array
    {
        return [
            'starts_at'   => 'datetime',
            'ends_at'     => 'datetime',
            'raw_payload' => 'array',
        ];
    }

    /** The owning record: a Lead, DriverLead or SponsorProfile. */
    public function meetable()
    {
        return $this->morphTo();
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    /** Human label for the meeting's subject (lead/driver/sponsor name). */
    public function subjectName(): string
    {
        $m = $this->meetable;

        return match (true) {
            $m instanceof Lead           => $m->full_name ?: ('Lead #' . $m->id),
            $m instanceof DriverLead     => ($m->full_name ?: ('Driver #' . $m->id)),
            $m instanceof SponsorProfile => ($m->company_name ?: ('Sponsor #' . $m->id)),
            default                      => $this->attendee_name ?: '—',
        };
    }

    /** Short type label for grouping in the UI. */
    public function subjectType(): string
    {
        return match (true) {
            $this->meetable instanceof DriverLead     => 'Driver Lead',
            $this->meetable instanceof SponsorProfile => 'Sponsor',
            default                                   => 'Lead',
        };
    }

    /** Link to the subject's detail page, or null. */
    public function subjectUrl(): ?string
    {
        $m = $this->meetable;

        return match (true) {
            $m instanceof Lead           => route('leads.show', $m),
            $m instanceof DriverLead     => route('driver-leads.show', $m),
            $m instanceof SponsorProfile => route('sponsors.show', $m),
            default                      => null,
        };
    }
}
