@extends('layouts.app')
@section('title', 'Add Driver Lead')
@section('breadcrumb')
    <a href="{{ route('driver-leads.index') }}" class="hover:text-brand">Driver Leads</a> / <span>Add</span>
@endsection

@section('content')
<x-card title="New Driver Lead" subtitle="Manually add a racing driver. Tier is auto-computed after saving.">
    <form method="POST" action="{{ route('driver-leads.store') }}" enctype="multipart/form-data">
        @csrf

        <h4 class="mb-3 text-xs font-semibold uppercase tracking-wider text-muted">Contact</h4>
        <div class="grid grid-cols-1 gap-5 sm:grid-cols-2">
            <div>
                <label class="ta-label">First Name <span class="text-danger">*</span></label>
                <input name="first_name" value="{{ old('first_name') }}" required class="ta-input w-full">
                @error('first_name')<p class="mt-1 text-xs text-danger">{{ $message }}</p>@enderror
            </div>
            <div>
                <label class="ta-label">Last Name <span class="text-danger">*</span></label>
                <input name="last_name" value="{{ old('last_name') }}" required class="ta-input w-full">
                @error('last_name')<p class="mt-1 text-xs text-danger">{{ $message }}</p>@enderror
            </div>
            <div>
                <label class="ta-label">Email <span class="text-danger">*</span></label>
                <input type="email" name="email" value="{{ old('email') }}" required class="ta-input w-full">
                @error('email')<p class="mt-1 text-xs text-danger">{{ $message }}</p>@enderror
            </div>
            <div>
                <label class="ta-label">Phone <span class="text-danger">*</span></label>
                <input name="phone" value="{{ old('phone') }}" required class="ta-input w-full">
                @error('phone')<p class="mt-1 text-xs text-danger">{{ $message }}</p>@enderror
            </div>
            <div>
                <label class="ta-label">Country</label>
                <input name="country" value="{{ old('country') }}" class="ta-input w-full">
            </div>
            <div class="sm:col-span-2" x-data="{ preview: null, name: '' }">
                <label class="ta-label">Profile Picture</label>
                <div class="flex items-center gap-3">
                    <img x-show="preview" x-cloak :src="preview" alt="" class="h-14 w-14 rounded-full object-cover">
                    <input type="file" name="photo" accept="image/*" class="ta-input w-full"
                           @change="const f=$event.target.files[0]; preview = f ? URL.createObjectURL(f) : null; name = f ? f.name : ''">
                </div>
                <p class="mt-1 text-xs text-brand" x-show="name" x-cloak><i class="fa-solid fa-image"></i> <span x-text="name"></span></p>
                <p class="mt-1 text-xs text-muted">Optional. JPG/PNG/WebP/GIF up to 5 MB</p>
                @error('photo')<p class="mt-1 text-xs text-danger">{{ $message }}</p>@enderror
            </div>
            <div>
                <label class="ta-label">DOB</label>
                <input type="date" name="dob" value="{{ old('dob') }}" max="{{ now()->subDay()->format('Y-m-d') }}" class="ta-input w-full">
                @error('dob')<p class="mt-1 text-xs text-danger">{{ $message }}</p>@enderror
                <p class="mt-1 text-xs text-muted">Age and age group are computed automatically. Under 12 → Kart/Karting only; under 18 → no Formula 1.</p>
            </div>
        </div>

        <h4 class="mb-3 mt-7 text-xs font-semibold uppercase tracking-wider text-muted">Racing</h4>
        <div class="grid grid-cols-1 gap-5 sm:grid-cols-2">
            <div>
                <label class="ta-label">Years Racing</label>
                <input type="number" min="0" name="years_racing" value="{{ old('years_racing', 0) }}" class="ta-input w-full">
            </div>
            <div>
                <label class="ta-label">Career Wins</label>
                <input type="number" min="0" name="career_wins" value="{{ old('career_wins', 0) }}" class="ta-input w-full">
            </div>
            <div>
                <label class="ta-label">Highest Series</label>
                <input name="highest_series" value="{{ old('highest_series') }}" class="ta-input w-full" placeholder="F4 British Championship...">
            </div>
            <div>
                <label class="ta-label">Current Team / Series</label>
                <input name="current_team_series" value="{{ old('current_team_series') }}" class="ta-input w-full">
            </div>
            <div>
                <label class="ta-label">Racing Level</label>
                <select name="racing_level" class="ta-input w-full">
                    <option value="">— Not set —</option>
                    @foreach ($racingLevels as $l)<option value="{{ $l['value'] }}" @selected(old('racing_level')===$l['value'])>{{ $l['label'] }}</option>@endforeach
                </select>
                @error('racing_level')<p class="mt-1 text-xs text-danger">{{ $message }}</p>@enderror
            </div>
            <div>
                <label class="ta-label">Car Type</label>
                <select name="car_type" class="ta-input w-full">
                    <option value="">Select car type...</option>
                    @foreach ($carTypes as $c)<option value="{{ $c['value'] }}" @selected(old('car_type')===$c['value'])>{{ $c['label'] }}</option>@endforeach
                </select>
                @error('car_type')<p class="mt-1 text-xs text-danger">{{ $message }}</p>@enderror
                <p class="mt-1 text-xs text-muted">Selected manually — independent of Racing Level.</p>
            </div>
        </div>

        <h4 class="mb-3 mt-7 text-xs font-semibold uppercase tracking-wider text-muted">Social & Sponsorship</h4>
        <div class="grid grid-cols-1 gap-5 sm:grid-cols-2">
            <div>
                <label class="ta-label">Instagram Handle</label>
                <input name="instagram_handle" value="{{ old('instagram_handle') }}" class="ta-input w-full" placeholder="@username">
            </div>
            <div>
                <label class="ta-label">Instagram Followers</label>
                <input type="number" min="0" name="instagram_followers" value="{{ old('instagram_followers', 0) }}" class="ta-input w-full">
            </div>
            <div>
                <label class="ta-label">Interested Contract Type</label>
                <select name="contract_interest_type" class="ta-input w-full">
                    <option value="">— Not set —</option>
                    @foreach ($contractTypes as $ct)<option value="{{ $ct['value'] }}" @selected(old('contract_interest_type')===$ct['value'])>{{ $ct['label'] }}</option>@endforeach
                </select>
            </div>
            <div>
                <label class="ta-label">Status <span class="text-danger">*</span></label>
                <select name="status" required class="ta-input w-full">
                    @foreach ($statuses as $s)<option value="{{ $s['value'] }}" @selected(old('status', 'new')===$s['value'])>{{ $s['label'] }}</option>@endforeach
                </select>
            </div>
            <div class="flex items-center gap-3 sm:col-span-2">
                <input type="hidden" name="seeking_sponsorship" value="0">
                <input type="checkbox" id="seeking" name="seeking_sponsorship" value="1" @checked(old('seeking_sponsorship')) class="h-4 w-4 rounded text-brand focus:ring-brand">
                <label for="seeking" class="text-sm font-medium text-ink dark:text-gray-200">Seeking Sponsorship</label>
            </div>
        </div>

        <div class="mt-7 flex justify-end gap-3">
            <a href="{{ route('driver-leads.index') }}" class="btn btn-light">Cancel</a>
            <button class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Create Driver Lead</button>
        </div>
    </form>
</x-card>
@endsection
