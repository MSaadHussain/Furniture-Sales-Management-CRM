<?php

namespace App\Console\Commands;

use App\Enums\LeadPriority;
use App\Enums\LeadStatus;
use App\Enums\MotorsportInterest;
use App\Enums\SourceChannel;
use App\Models\Lead;
use App\Models\User;
use Illuminate\Console\Command;
use Illuminate\Support\Str;

class DummyDataCommand extends Command
{
    protected $signature = 'crm:dummy-data {count=40 : How many dummy leads to create} {--clear : Remove all dummy leads instead}';

    protected $description = 'Generate or clear demo/dummy leads (tagged "demo"). Works WITHOUT faker.';

    private array $first = ['Lewis','Max','Carlos','Lando','Charles','Sergio','Fernando','George','Oscar','Pierre','Esteban','Lance','Yuki','Alex','Valtteri','Daniel','Kevin','Nico','Liam','Franco','Ava','Mia','Sofia','Emma','Olivia','Noah','Liam','Aria','Zoe','Hassan','Ali','Omar','Sara','Fatima','Bilal','Ayesha'];
    private array $last  = ['Hamilton','Verstappen','Sainz','Norris','Leclerc','Perez','Alonso','Russell','Piastri','Gasly','Ocon','Stroll','Tsunoda','Albon','Bottas','Ricciardo','Khan','Ahmed','Malik','Sheikh','Smith','Johnson','Williams','Brown','Davis','Miller','Wilson'];
    private array $companies = ['Apex Racing','Velocity Motors','Track Dynamics','Pole Position Ltd','RedLine Garage','Summit Autosport','Nitro Performance','GridIron Racing','Carbon Speed','Turbo Works','','',''];

    public function handle(): int
    {
        if ($this->option('clear')) {
            $count = Lead::withTrashed()->whereJsonContains('tags', 'demo')->forceDelete();
            $this->info("Removed {$count} dummy lead(s).");
            return self::SUCCESS;
        }

        $count = max(1, (int) $this->argument('count'));
        $assignable = User::where('is_active', true)->pluck('id');
        $creator = User::first()?->id;

        $countries = [
            ['Pakistan', 'PK', 'Karachi'],
            ['Pakistan', 'PK', 'Lahore'],
            ['Pakistan', 'PK', 'Islamabad'],
            ['United Arab Emirates', 'AE', 'Dubai'],
            ['United Kingdom', 'GB', 'London'],
            ['United States', 'US', 'New York'],
            ['Germany', 'DE', 'Berlin'],
            ['France', 'FR', 'Paris'],
            ['Italy', 'IT', 'Milan'],
            ['Spain', 'ES', 'Madrid'],
            ['Australia', 'AU', 'Sydney'],
            ['India', 'IN', 'Mumbai'],
            ['Saudi Arabia', 'SA', 'Riyadh'],
        ];

        $sources    = array_map(fn ($c) => $c->value, SourceChannel::cases());
        $statuses   = array_map(fn ($c) => $c->value, LeadStatus::cases());
        $priorities = array_map(fn ($c) => $c->value, LeadPriority::cases());
        $interests  = array_map(fn ($c) => $c->value, MotorsportInterest::cases());

        $bar = $this->output->createProgressBar($count);
        for ($i = 0; $i < $count; $i++) {
            $first = $this->first[array_rand($this->first)];
            $last  = $this->last[array_rand($this->last)];
            [$country, $code, $city] = $countries[array_rand($countries)];
            $phone = '+9715' . str_pad((string) random_int(0, 99999999), 8, '0', STR_PAD_LEFT);

            Lead::create([
                'first_name'               => $first,
                'last_name'                => $last,
                'full_name'                => "$first $last",
                'email'                    => strtolower($first . '.' . $last . random_int(1, 9999)) . '@example.com',
                'phone'                    => $phone,
                'normalized_phone'         => preg_replace('/[^\d+]/', '', $phone),
                'loc_state'                => $city,
                'country'                  => $country,
                'country_code'             => $code,
                'city'                     => $city,
                'company'                  => $this->companies[array_rand($this->companies)] ?: null,
                'ip_address'               => random_int(1, 255) . '.' . random_int(0, 255) . '.' . random_int(0, 255) . '.' . random_int(1, 255),
                'source_channel'           => $sources[array_rand($sources)],
                'status'                   => $statuses[array_rand($statuses)],
                'priority'                 => $priorities[array_rand($priorities)],
                'lead_score'               => random_int(0, 100),
                'motorsport_interest_type' => $interests[array_rand($interests)],
                'message'                  => 'Demo lead generated for testing. ' . Str::random(20),
                'tags'                     => ['demo'],
                'assigned_to'              => $assignable->isNotEmpty() ? $assignable->random() : null,
                'created_by'               => $creator,
                'last_activity_at'         => now()->subHours(random_int(0, 240)),
                'created_at'               => now()->subDays(random_int(0, 27))->subHours(random_int(0, 23)),
            ]);
            $bar->advance();
        }
        $bar->finish();
        $this->newLine();
        $this->info("Created {$count} dummy lead(s) tagged 'demo'. Clear: php artisan crm:dummy-data --clear");

        return self::SUCCESS;
    }
}