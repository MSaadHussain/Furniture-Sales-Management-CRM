@extends('layouts.adminlte')
@section('title', 'Edit Lead')
@section('content')
    <form method="POST" action="{{ route('leads.update', $lead) }}">
        @csrf @method('PUT')
        @include('leads._form', ['lead' => $lead])
        <div class="mb-4">
            <button class="btn btn-brand">Save Changes</button>
            <a href="{{ route('leads.show', $lead) }}" class="btn btn-default">Cancel</a>
        </div>
    </form>
@endsection
