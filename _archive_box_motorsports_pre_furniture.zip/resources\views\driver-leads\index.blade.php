@extends('layouts.app')
@section('title', 'Driver Leads')

@section('header_actions')
    @if (auth()->user()->hasRole(\App\Enums\UserRole::SuperAdmin, \App\Enums\UserRole::Admin, \App\Enums\UserRole::SalesManager))
        <x-export-menu route="driver-leads.export" />
    @endif
    @unless (auth()->user()->role->isReadOnly())
        <a href="{{ route('driver-leads.create') }}" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Add Driver Lead</a>
    @endunless
@endsection

@section('content')

{{-- Search + collapsible filters --}}
@php
    $activeFilters = collect($filters)->except('search')->filter(fn ($v) => filled($v))->count();
@endphp
<x-card class="mb-6">
    <form method="GET" x-data="{ open: {{ $activeFilters > 0 ? 'true' : 'false' }} }">
        {{-- Always-visible search row --}}
        <div class="flex flex-wrap items-end gap-3">
            <div class="min-w-0 flex-1">
                <label class="ta-label">Search</label>
                <input type="search" name="search" value="{{ $filters['search'] ?? '' }}" class="ta-input w-full" placeholder="Name, email, phone, Instagram...">
            </div>
            <button class="btn btn-primary"><i class="fa-solid fa-magnifying-glass"></i> Search</button>
            <button type="button" @click="open = !open" class="btn btn-light">
                <i class="fa-solid fa-filter"></i> Filters
                @if ($activeFilters > 0)
                    <span class="ml-1 rounded-full bg-brand px-1.5 py-0.5 text-[10px] font-bold text-white">{{ $activeFilters }}</span>
                @endif
                <i class="fa-solid fa-chevron-down ml-1 text-xs transition-transform duration-300" :class="open && 'rotate-180'"></i>
            </button>
        </div>

        {{-- Collapsible filter grid --}}
        <div x-show="open" x-collapse>
            <div class="mt-4 grid grid-cols-1 gap-4 border-t border-line pt-4 dark:border-strokedark sm:grid-cols-2 lg:grid-cols-4">
                <div>
                    <label class="ta-label">Status</label>
                    <select name="status" class="ta-input">
                        <option value="">All</option>
                        @foreach ($statuses as $s)<option value="{{ $s['value'] }}" @selected(($filters['status'] ?? '')===$s['value'])>{{ $s['label'] }}</option>@endforeach
                    </select>
                </div>
                <div>
                    <label class="ta-label">Tier</label>
                    <select name="tier" class="ta-input">
                        <option value="">All</option>
                        @foreach ($tiers as $t)<option value="{{ $t['value'] }}" @selected(($filters['tier'] ?? '')===$t['value'])>{{ $t['label'] }}</option>@endforeach
                    </select>
                </div>
                <div>
                    <label class="ta-label">Racing Level</label>
                    <select name="racing_level" class="ta-input">
                        <option value="">All</option>
                        @foreach ($racingLevels as $l)<option value="{{ $l['value'] }}" @selected(($filters['racing_level'] ?? '')===$l['value'])>{{ $l['label'] }}</option>@endforeach
                    </select>
                </div>
                <div>
                    <label class="ta-label">Car Type</label>
                    <select name="car_type" class="ta-input">
                        <option value="">All</option>
                        @foreach ($carTypes as $c)<option value="{{ $c['value'] }}" @selected(($filters['car_type'] ?? '')===$c['value'])>{{ $c['label'] }}</option>@endforeach
                    </select>
                </div>
                <div>
                    <label class="ta-label">Age Group</label>
                    <select name="age_group" class="ta-input">
                        <option value="">All</option>
                        @foreach ($ageGroups as $value => $label)<option value="{{ $value }}" @selected(($filters['age_group'] ?? '')===$value)>{{ $label }}</option>@endforeach
                    </select>
                </div>
                <div>
                    <label class="ta-label">Seeking Sponsorship</label>
                    <select name="seeking" class="ta-input">
                        <option value="">All</option>
                        <option value="yes" @selected(($filters['seeking'] ?? '')==='yes')>Yes</option>
                        <option value="no" @selected(($filters['seeking'] ?? '')==='no')>No</option>
                    </select>
                </div>
                <div>
                    <label class="ta-label">Contract</label>
                    <select name="contract" class="ta-input">
                        <option value="">All</option>
                        <option value="active" @selected(($filters['contract'] ?? '')==='active')>Has active contract</option>
                        <option value="none" @selected(($filters['contract'] ?? '')==='none')>No active contract</option>
                    </select>
                </div>
                <div class="flex items-end gap-2">
                    <button class="btn btn-primary"><i class="fa-solid fa-filter"></i> Apply Filters</button>
                    <a href="{{ route('driver-leads.index') }}" class="btn btn-light">Reset</a>
                </div>
            </div>
        </div>
    </form>
</x-card>

{{-- Desktop table --}}
<x-card padding="p-0" class="hidden lg:block">
    <table class="w-full">
        <thead class="border-b border-line dark:border-strokedark">
            <tr>
                <th class="ta-th">Driver</th>
                <th class="ta-th">Racing</th>
                <th class="ta-th">Instagram</th>
                <th class="ta-th">Tier / Status</th>
                <th class="ta-th">Created</th>
                <th class="ta-th"></th>
            </tr>
        </thead>
        <tbody class="divide-y divide-line dark:divide-strokedark">
            @forelse ($driverLeads as $driver)
                <tr class="transition hover:bg-surface dark:hover:bg-boxdark/40">
                    <td class="ta-td">
                        <a href="{{ route('driver-leads.show', $driver) }}" class="font-semibold text-ink hover:text-brand dark:text-white">{{ $driver->full_name }}</a>
                        @if ($driver->seeking_sponsorship)
                            <span class="ml-1 inline-block rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-semibold uppercase text-amber-700 dark:bg-amber-900/30 dark:text-amber-400">Sponsor</span>
                        @endif
                        <span class="block text-xs text-muted">{{ $driver->email }} · {{ $driver->phone ?: '—' }}</span>
                        <span class="block text-xs text-muted">{{ $driver->country ?: '' }}</span>
                    </td>
                    <td class="ta-td">
                        <span class="text-ink dark:text-gray-300">{{ $driver->years_racing }}y · {{ $driver->career_wins }}W</span>
                        <span class="block text-xs text-muted">{{ $driver->highest_series ?: '—' }}</span>
                    </td>
                    <td class="ta-td">
                        @if ($driver->instagram_handle)
                            <a href="{{ $driver->instagram_url }}" target="_blank" rel="noopener" class="text-brand hover:underline">{{ $driver->instagram_handle }}</a>
                            <span class="block text-xs text-muted">{{ number_format($driver->instagram_followers) }}</span>
                        @else
                            <span class="text-muted">—</span>
                        @endif
                    </td>
                    <td class="ta-td">
                        <div class="flex flex-wrap gap-1">
                            <x-badge :label="$driver->inferred_tier->label()" :color="$driver->inferred_tier->color()" />
                            <x-badge :label="$driver->status->label()" :color="$driver->status->color()" />
                        </div>
                    </td>
                    <td class="ta-td text-muted text-xs">{{ $driver->created_at->diffForHumans() }}</td>
                    <td class="ta-td">
                        <a href="{{ route('driver-leads.show', $driver) }}" class="btn btn-light !px-3 !py-1.5 text-xs">View</a>
                    </td>
                </tr>
            @empty
                <tr><td colspan="6" class="ta-td py-12 text-center">
                    <p class="text-muted">No driver leads found.</p>
                </td></tr>
            @endforelse
        </tbody>
    </table>
    <div class="border-t border-line px-6 py-4 dark:border-strokedark">{{ $driverLeads->links() }}</div>
</x-card>

{{-- Mobile cards --}}
<div class="space-y-3 lg:hidden">
    @forelse ($driverLeads as $driver)
        <x-card padding="p-4">
            <div class="flex items-start justify-between gap-3">
                <a href="{{ route('driver-leads.show', $driver) }}" class="font-semibold text-ink hover:text-brand dark:text-white">{{ $driver->full_name }}</a>
                <x-badge :label="$driver->inferred_tier->label()" :color="$driver->inferred_tier->color()" />
            </div>
            <div class="mt-1 text-sm">
                <p class="text-ink dark:text-gray-300">{{ $driver->email }}</p>
                <p class="text-xs text-muted">{{ $driver->phone ?: '—' }} · {{ $driver->country ?: '—' }}</p>
            </div>
            <div class="mt-3 grid grid-cols-2 gap-y-2 text-sm">
                <span class="text-muted">Racing</span>
                <span class="text-right text-ink dark:text-gray-300">{{ $driver->years_racing }}y · {{ $driver->career_wins }}W</span>
                <span class="text-muted">Status</span>
                <span class="text-right"><x-badge :label="$driver->status->label()" :color="$driver->status->color()" /></span>
                @if ($driver->instagram_handle)
                    <span class="text-muted">Instagram</span>
                    <span class="text-right"><a href="{{ $driver->instagram_url }}" target="_blank" class="text-brand">{{ $driver->instagram_handle }}</a></span>
                @endif
            </div>
            <a href="{{ route('driver-leads.show', $driver) }}" class="btn btn-light mt-3 w-full !py-2 text-sm">View driver</a>
        </x-card>
    @empty
        <x-card padding="p-8">
            <p class="text-center text-muted">No driver leads found.</p>
        </x-card>
    @endforelse
    <div>{{ $driverLeads->links() }}</div>
</div>
@endsection
