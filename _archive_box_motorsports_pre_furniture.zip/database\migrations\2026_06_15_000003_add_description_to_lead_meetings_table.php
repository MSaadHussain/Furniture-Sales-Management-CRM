<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('lead_meetings', function (Blueprint $table) {
            // Optional agenda / description, also pushed to the Google Calendar event.
            $table->text('description')->nullable()->after('meeting_title');
        });
    }

    public function down(): void
    {
        Schema::table('lead_meetings', function (Blueprint $table) {
            $table->dropColumn('description');
        });
    }
};
