<?php

namespace Database\Seeders;

use App\Models\Lead;
use App\Models\User;
use Illuminate\Database\Seeder;

class LeadSeeder extends Seeder
{
    public function run(): void
    {
        $assignees = User::whereIn('role', ['sales_manager', 'sales_rep'])->pluck('id');
        $creatorId = User::where('role', 'admin')->value('id');

        Lead::factory(60)->create([
            'assigned_to' => fn () => $assignees->isNotEmpty() ? $assignees->random() : null,
            'created_by'  => $creatorId,
        ]);
    }
}
