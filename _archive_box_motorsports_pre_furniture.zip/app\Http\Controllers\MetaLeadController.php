<?php

namespace App\Http\Controllers;

use App\Models\IntegrationSetting;
use App\Services\Integrations\Meta\MetaApiClient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

class MetaLeadController extends Controller
{
    public function index()
    {
        Gate::authorize('manage-integrations');

        $setting = IntegrationSetting::firstOrCreate(['channel' => 'meta'], ['enabled' => false, 'config' => []]);

        return view('integrations.meta', [
            'setting'     => $setting,
            'config'      => $setting->config ?? [],
            'webhookUrl'  => url('/api/v1/webhooks/meta'),
        ]);
    }

    public function save(Request $request)
    {
        Gate::authorize('manage-integrations');

        $data = $request->validate([
            'app_id'               => ['nullable', 'string', 'max:191'],
            'app_secret'           => ['nullable', 'string', 'max:191'],
            'page_id'              => ['nullable', 'string', 'max:191'],
            'access_token'         => ['nullable', 'string', 'max:1000'],
            'webhook_verify_token' => ['nullable', 'string', 'max:191'],
            'lead_form_id'         => ['nullable', 'string', 'max:191'],
            'enabled'              => ['nullable', 'boolean'],
        ]);

        $setting = IntegrationSetting::firstOrCreate(['channel' => 'meta']);
        $setting->update([
            'enabled' => $request->boolean('enabled'),
            'config'  => array_merge($setting->config ?? [], collect($data)->except('enabled')->toArray()),
        ]);

        return back()->with('toast', 'Meta integration saved.');
    }

    public function test(MetaApiClient $api)
    {
        Gate::authorize('manage-integrations');

        [$ok, $message] = $api->testConnection();

        return back()->with($ok ? 'toast' : 'error', $message);
    }
}
