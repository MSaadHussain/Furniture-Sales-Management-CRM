<?php

namespace App\Http\Controllers;

use App\Enums\FundingType;
use App\Enums\SponsorActionType;
use App\Enums\SponsorProfileType;
use App\Enums\SponsorshipStage;
use App\Enums\SponsorStatus;
use App\Models\SponsorActivity;
use App\Models\SponsorDriverLink;
use App\Models\SponsorProfile;
use App\Models\SponsorshipDeal;
use App\Services\DateRangeService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Symfony\Component\HttpFoundation\StreamedResponse;

class SponsorReportController extends Controller
{
    public function __construct(private DateRangeService $dates) {}

    public function index(Request $request)
    {
        Gate::authorize('view-reports');

        [$from, $to, $label] = $this->dates->resolve($request);

        // ---- In-range KPIs (records created within the selected period) ----
        $newSponsors  = SponsorProfile::whereBetween('created_at', [$from, $to])->count();
        $newDeals     = SponsorshipDeal::whereBetween('created_at', [$from, $to])->count();
        $wonInRange   = SponsorshipDeal::where('stage', SponsorshipStage::ClosedWon)
            ->whereBetween('closed_at', [$from, $to])->sum('deal_value');
        $lostInRange  = SponsorshipDeal::where('stage', SponsorshipStage::ClosedLost)
            ->whereBetween('closed_at', [$from, $to])->count();

        // ---- Current-state KPIs (live, not range-bound) ----
        $activeSponsors = SponsorProfile::where('status', SponsorStatus::Active)->count();
        $openStages = [SponsorshipStage::ClosedWon->value, SponsorshipStage::ClosedLost->value];
        $openPipeline = SponsorshipDeal::whereNotIn('stage', $openStages)->sum('deal_value');
        $weightedPipeline = SponsorshipDeal::whereNotIn('stage', $openStages)
            ->sum(DB::raw('COALESCE(deal_value, 0) * probability / 100'));
        $contractPendingValue = SponsorshipDeal::where('stage', SponsorshipStage::ContractPending)->sum('deal_value');
        $fundingCommitted = SponsorDriverLink::where('status', 'active')->sum('funding_amount');
        $driversFunded = SponsorDriverLink::where('status', 'active')->distinct('driver_lead_id')->count('driver_lead_id');

        // ---- Live pipeline funnel by stage ----
        $byStage = SponsorshipDeal::select('stage', DB::raw('count(*) as total'), DB::raw('sum(COALESCE(deal_value,0)) as value'))
            ->groupBy('stage')->get()->keyBy(fn ($r) => $r->stage->value);
        $maxStageValue = max(1, (float) $byStage->max('value'));
        $stageReport = collect(SponsorshipStage::pipelineOrder())->map(fn ($s) => [
            'label'   => $s->label(),
            'color'   => $s->color(),
            'count'   => (int) ($byStage[$s->value]->total ?? 0),
            'value'   => (float) ($byStage[$s->value]->value ?? 0),
            'percent' => round((float) ($byStage[$s->value]->value ?? 0) / $maxStageValue * 100),
        ]);

        // ---- Sponsors by type / status ----
        $totalSponsors = max(1, SponsorProfile::count());
        $byType = SponsorProfile::select('company_type', DB::raw('count(*) as total'))
            ->groupBy('company_type')->pluck('total', 'company_type');
        $typeReport = collect(SponsorProfileType::cases())->map(fn ($t) => [
            'label'   => $t->label(),
            'color'   => $t->color(),
            'value'   => (int) ($byType[$t->value] ?? 0),
            'percent' => round((int) ($byType[$t->value] ?? 0) / $totalSponsors * 100),
        ]);

        $byStatus = SponsorProfile::select('status', DB::raw('count(*) as total'))
            ->groupBy('status')->pluck('total', 'status');
        $statusReport = collect(SponsorStatus::cases())->map(fn ($s) => [
            'label' => $s->label(),
            'color' => $s->color(),
            'value' => (int) ($byStatus[$s->value] ?? 0),
        ]);

        // ---- Driver funding by type ----
        $byFunding = SponsorDriverLink::select('funding_type', DB::raw('count(*) as total'), DB::raw('sum(COALESCE(funding_amount,0)) as amount'))
            ->groupBy('funding_type')->get()->keyBy(fn ($r) => $r->funding_type->value);
        $fundingReport = collect(FundingType::cases())->map(fn ($f) => [
            'label'  => $f->label(),
            'color'  => $f->color(),
            'count'  => (int) ($byFunding[$f->value]->total ?? 0),
            'amount' => (float) ($byFunding[$f->value]->amount ?? 0),
        ])->filter(fn ($r) => $r['count'] > 0)->values();

        // ---- Top sponsors by open pipeline value ----
        $topSponsors = SponsorProfile::withCount('deals')
            ->withSum(['deals as open_value' => fn ($q) => $q->whereNotIn('stage', $openStages)], 'deal_value')
            ->withSum(['deals as won_value' => fn ($q) => $q->where('stage', SponsorshipStage::ClosedWon)], 'deal_value')
            ->orderByDesc('open_value')
            ->limit(10)->get();

        // ---- Pending follow-ups (due, not completed) ----
        $pendingFollowUps = SponsorActivity::with(['sponsor:id,company_name', 'performer:id,name'])
            ->whereNull('completed_at')->whereNotNull('due_date')
            ->orderBy('due_date')->limit(10)->get();

        // ---- Activity mix (in range) ----
        $byAction = SponsorActivity::whereBetween('created_at', [$from, $to])
            ->select('action_type', DB::raw('count(*) as total'))
            ->groupBy('action_type')->pluck('total', 'action_type');
        $activityReport = collect(SponsorActionType::cases())->map(fn ($a) => [
            'label' => $a->label(),
            'icon'  => $a->icon(),
            'value' => (int) ($byAction[$a->value] ?? 0),
        ])->filter(fn ($r) => $r['value'] > 0)->sortByDesc('value')->values();

        // ---- Monthly new-sponsor trend (last 6 months) ----
        $trend = SponsorProfile::where('created_at', '>=', now()->subMonths(6)->startOfMonth())
            ->select(DB::raw("DATE_FORMAT(created_at, '%Y-%m') as month"), DB::raw('count(*) as total'))
            ->groupBy('month')->orderBy('month')
            ->pluck('total', 'month');

        return view('reports.sponsors', [
            'rangeLabel'   => $label,
            'presets'      => $this->dates->presets(),
            'currentRange' => $request->string('range', 'last_30')->value(),
            'filters'      => $request->only(['range', 'from', 'to']),
            'kpis' => [
                'newSponsors'     => $newSponsors,
                'newDeals'        => $newDeals,
                'wonInRange'      => (float) $wonInRange,
                'lostInRange'     => $lostInRange,
                'activeSponsors'  => $activeSponsors,
                'openPipeline'    => (float) $openPipeline,
                'weighted'        => (float) $weightedPipeline,
                'contractPending' => (float) $contractPendingValue,
                'fundingCommitted'=> (float) $fundingCommitted,
                'driversFunded'   => $driversFunded,
            ],
            'stageReport'      => $stageReport,
            'typeReport'       => $typeReport,
            'statusReport'     => $statusReport,
            'fundingReport'    => $fundingReport,
            'topSponsors'      => $topSponsors,
            'pendingFollowUps' => $pendingFollowUps,
            'activityReport'   => $activityReport,
            'trend'            => $trend,
        ]);
    }

    public function export(Request $request): StreamedResponse
    {
        Gate::authorize('view-reports');

        $openStages = [SponsorshipStage::ClosedWon->value, SponsorshipStage::ClosedLost->value];

        $sponsors = SponsorProfile::with('assignee')
            ->withCount('deals')
            ->withSum(['deals as open_value' => fn ($q) => $q->whereNotIn('stage', $openStages)], 'deal_value')
            ->withSum(['deals as won_value' => fn ($q) => $q->where('stage', SponsorshipStage::ClosedWon)], 'deal_value')
            ->orderByDesc('open_value');

        $filename = 'sponsor_report_' . now()->format('Y_m_d_His') . '.csv';

        return response()->streamDownload(function () use ($sponsors) {
            $handle = fopen('php://output', 'w');
            fputcsv($handle, [
                'ID', 'Company', 'Type', 'Status', 'Industry', 'Contact', 'Email', 'Phone',
                'Country', 'Estimated Budget', 'Deals', 'Open Pipeline Value', 'Closed Won Value',
                'Assigned To', 'Created',
            ]);
            $sponsors->chunk(500, function ($chunk) use ($handle) {
                foreach ($chunk as $s) {
                    fputcsv($handle, [
                        $s->id, $s->company_name, $s->company_type->label(), $s->status->label(),
                        $s->industry, $s->contact_name, $s->email, $s->phone, $s->country,
                        $s->estimated_budget, $s->deals_count,
                        $s->open_value ?? 0, $s->won_value ?? 0,
                        $s->assignee?->name, $s->created_at?->toDateTimeString(),
                    ]);
                }
            });
            fclose($handle);
        }, $filename, ['Content-Type' => 'text/csv']);
    }
}
