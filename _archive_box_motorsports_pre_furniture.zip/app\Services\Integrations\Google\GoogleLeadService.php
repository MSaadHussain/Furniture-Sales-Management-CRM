<?php

namespace App\Services\Integrations\Google;

use App\Enums\SourceChannel;
use App\Services\LeadIntakeService;

class GoogleLeadService
{
    public function __construct(private LeadIntakeService $intake) {}

    /**
     * Ingest a Google Lead Form webhook payload. Returns [Lead, isNew].
     */
    public function handle(array $payload, ?string $ip = null): array
    {
        $externalId = $payload['lead_id'] ?? $payload['gcl_id'] ?? null;
        if ($externalId) {
            $payload['source_external_id'] = $externalId;
        }

        [$lead, $isNew] = $this->intake->ingest(SourceChannel::GoogleLeadForm, $payload, $ip);

        if ($externalId && blank($lead->source_external_id)) {
            $lead->forceFill(['source_external_id' => $externalId])->saveQuietly();
        }

        return [$lead, $isNew];
    }
}
