<?php

namespace App\Http\Controllers;

use App\Models\IntegrationSetting;
use App\Services\Integrations\Meetings\CalendlyService;
use App\Services\Integrations\Meetings\GoogleCalendarService;
use App\Services\Integrations\Meetings\ZoomService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

class MeetingIntegrationController extends Controller
{
    public function index()
    {
        Gate::authorize('manage-integrations');

        $google   = IntegrationSetting::firstOrCreate(['channel' => 'google_meet'], ['enabled' => false, 'config' => []]);
        $calendly = IntegrationSetting::firstOrCreate(['channel' => 'calendly'], ['enabled' => false, 'config' => []]);
        $zoom     = IntegrationSetting::firstOrCreate(['channel' => 'zoom'], ['enabled' => false, 'config' => []]);

        return view('integrations.meetings', [
            'google'        => $google,
            'googleConfig'  => $google->config ?? [],
            'calendly'      => $calendly,
            'calendlyConfig' => $calendly->config ?? [],
            'calendlyWebhook' => url('/api/v1/webhooks/calendly'),
            'zoom'          => $zoom,
            'zoomConfig'    => $zoom->config ?? [],
        ]);
    }

    public function saveGoogle(Request $request)
    {
        Gate::authorize('manage-integrations');

        $data = $request->validate([
            'client_id'     => ['nullable', 'string', 'max:191'],
            'client_secret' => ['nullable', 'string', 'max:191'],
            'redirect_uri'  => ['nullable', 'string', 'max:300'],
            'refresh_token' => ['nullable', 'string', 'max:1000'],
            'calendar_id'   => ['nullable', 'string', 'max:191'],
            'enabled'       => ['nullable', 'boolean'],
        ]);

        $s = IntegrationSetting::firstOrCreate(['channel' => 'google_meet']);
        $s->update([
            'enabled' => $request->boolean('enabled'),
            'config'  => array_merge($s->config ?? [], collect($data)->except('enabled')->toArray()),
        ]);

        return back()->with('toast', 'Google Meet settings saved.');
    }

    public function saveCalendly(Request $request)
    {
        Gate::authorize('manage-integrations');

        $data = $request->validate([
            'api_token'           => ['nullable', 'string', 'max:1000'],
            'organization_uri'    => ['nullable', 'string', 'max:300'],
            'user_uri'            => ['nullable', 'string', 'max:300'],
            'webhook_signing_key' => ['nullable', 'string', 'max:300'],
            'enabled'             => ['nullable', 'boolean'],
        ]);

        $s = IntegrationSetting::firstOrCreate(['channel' => 'calendly']);
        $s->update([
            'enabled' => $request->boolean('enabled'),
            'config'  => array_merge($s->config ?? [], collect($data)->except('enabled')->toArray()),
        ]);

        return back()->with('toast', 'Calendly settings saved.');
    }

    public function saveZoom(Request $request)
    {
        Gate::authorize('manage-integrations');

        $data = $request->validate([
            'account_id'    => ['nullable', 'string', 'max:191'],
            'client_id'     => ['nullable', 'string', 'max:191'],
            'client_secret' => ['nullable', 'string', 'max:191'],
            'enabled'       => ['nullable', 'boolean'],
        ]);

        $s = IntegrationSetting::firstOrCreate(['channel' => 'zoom']);
        $s->update([
            'enabled' => $request->boolean('enabled'),
            'config'  => array_merge($s->config ?? [], collect($data)->except('enabled')->toArray()),
        ]);

        return back()->with('toast', 'Zoom settings saved.');
    }

    public function testGoogle(GoogleCalendarService $google)
    {
        Gate::authorize('manage-integrations');
        [$ok, $msg] = $google->testConnection();
        return back()->with($ok ? 'toast' : 'error', $msg);
    }

    public function testZoom(ZoomService $zoom)
    {
        Gate::authorize('manage-integrations');
        [$ok, $msg] = $zoom->testConnection();
        return back()->with($ok ? 'toast' : 'error', $msg);
    }

    public function testCalendly(CalendlyService $calendly)
    {
        Gate::authorize('manage-integrations');
        [$ok, $msg] = $calendly->testConnection();
        return back()->with($ok ? 'toast' : 'error', $msg);
    }
}
