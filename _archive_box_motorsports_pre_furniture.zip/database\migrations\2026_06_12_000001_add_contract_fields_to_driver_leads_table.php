<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('driver_leads', function (Blueprint $table) {
            $table->date('dob')->nullable()->after('country');
            $table->string('racing_level')->nullable()->after('highest_series');
            $table->string('car_type')->nullable()->after('racing_level');
            $table->string('contract_interest_type')->nullable()->after('seeking_sponsorship');
        });
    }

    public function down(): void
    {
        Schema::table('driver_leads', function (Blueprint $table) {
            $table->dropColumn(['dob', 'racing_level', 'car_type', 'contract_interest_type']);
        });
    }
};
