<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class UserManagementTest extends TestCase
{
    use RefreshDatabase;

    public function test_admin_can_create_user(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);

        $this->actingAs($admin)->post('/users', [
            'name' => 'New Rep', 'email' => 'newrep@test.com',
            'role' => 'sales_rep', 'is_active' => 1,
            'password' => 'password123', 'password_confirmation' => 'password123',
        ])->assertRedirect('/users');

        $this->assertDatabaseHas('users', ['email' => 'newrep@test.com', 'role' => 'sales_rep']);
    }

    public function test_sales_rep_cannot_access_user_management(): void
    {
        $rep = User::factory()->create(['role' => 'sales_rep']);
        $this->actingAs($rep)->get('/users')->assertForbidden();
    }

    public function test_user_cannot_deactivate_self(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $this->actingAs($admin)->patch("/users/{$admin->id}/toggle")->assertForbidden();
    }
}
