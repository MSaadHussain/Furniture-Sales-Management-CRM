<?php

namespace App\Services\Import\Parsers;

use App\Contracts\LeadFileParser;
use RuntimeException;
use Smalot\PdfParser\Parser as PdfTextParser;

/**
 * PDF parser built on smalot/pdfparser.
 *
 * PDFs are unstructured, so we:
 *   1. Extract all text.
 *   2. Try to split it into "records" (one lead per block) using blank-line
 *      and email-anchored heuristics.
 *   3. Detect name / email / phone / country / city / message per record.
 *
 * Output conforms to the same {headers, rows} contract as the CSV/XLSX parsers,
 * using a fixed pseudo-header so the column-mapping UI works identically.
 * When detection is messy the user can still re-map on the preview screen.
 */
class PdfLeadParser implements LeadFileParser
{
    /** Fixed logical columns emitted for every PDF. */
    public const COLUMNS = ['full_name', 'email', 'phone', 'country', 'city', 'message'];

    public function extensions(): array
    {
        return ['pdf'];
    }

    public function parse(string $absolutePath): array
    {
        if (! is_readable($absolutePath)) {
            throw new RuntimeException('PDF file is not readable.');
        }

        try {
            $text = (new PdfTextParser())->parseFile($absolutePath)->getText();
        } catch (\Throwable $e) {
            throw new RuntimeException('Unable to extract text from PDF: ' . $e->getMessage());
        }

        $text = trim(preg_replace('/\r\n?/', "\n", $text) ?? '');
        if ($text === '') {
            throw new RuntimeException('No extractable text found in PDF (it may be a scanned image — OCR required).');
        }

        $records = $this->splitIntoRecords($text);

        $rows = [];
        foreach ($records as $block) {
            $row = $this->detectFields($block);
            // Keep a record only if at least one identifying field was found.
            if ($row['email'] || $row['phone'] || $row['full_name']) {
                $rows[] = array_values($row);
            }
        }

        if ($rows === []) {
            // Fall back to one row containing the raw text so the user can map manually.
            $rows[] = [null, null, null, null, null, $text];
        }

        return ['headers' => self::COLUMNS, 'rows' => $rows];
    }

    /**
     * Split extracted text into per-lead blocks. Strategy, in priority order:
     *   1. If "Name:" style labels repeat, split on those (most reliable for forms).
     *   2. Else if multiple emails exist, split into one block per email while
     *      keeping the email intact (split on the whitespace/newline *before* it).
     *   3. Else split on blank lines (paragraphs).
     */
    private function splitIntoRecords(string $text): array
    {
        // 1. Repeated "Name:" / "Full Name:" / "Contact:" labels -> split before each.
        $labelCount = preg_match_all('/(?:^|\n)\s*(?:full name|name|contact)\s*[:\-]/i', $text);
        if ($labelCount > 1) {
            $parts = preg_split('/(?=(?:^|\n)\s*(?:full name|name|contact)\s*[:\-])/i', $text);
            $parts = array_values(array_filter(array_map('trim', $parts ?: []), fn ($p) => $p !== ''));
            if (count($parts) > 1) {
                return $parts;
            }
        }

        // 2. Multiple emails -> split on the boundary just before each email,
        //    so the email itself stays whole at the start of the next block.
        $emailCount = preg_match_all('/[\w.+-]+@[\w-]+\.[\w.-]+/', $text);
        if ($emailCount > 1) {
            $parts = preg_split('/\s+(?=[\w.+-]+@[\w-]+\.[\w.-]+)/', $text);
            $parts = array_values(array_filter(array_map('trim', $parts ?: []), fn ($p) => $p !== ''));
            if (count($parts) > 1) {
                return $parts;
            }
        }

        // 3. Paragraph split on blank lines.
        $paras = preg_split('/\n\s*\n/', $text) ?: [];
        $paras = array_values(array_filter(array_map('trim', $paras), fn ($p) => $p !== ''));

        return $paras === [] ? [$text] : $paras;
    }

    private function detectFields(string $block): array
    {
        $email = null;
        if (preg_match('/[\w.+-]+@[\w-]+\.[\w.-]+/', $block, $m)) {
            $email = strtolower($m[0]);
        }

        $phone = null;
        if (preg_match('/(\+?\d[\d\s().-]{7,}\d)/', $block, $m)) {
            $phone = trim($m[1]);
        }

        $name = $this->detectLabeled($block, ['name', 'full name', 'contact'])
            ?? $this->guessName($block);

        $country = $this->detectLabeled($block, ['country']);
        $city    = $this->detectLabeled($block, ['city', 'town']);
        $message = $this->detectLabeled($block, ['message', 'notes', 'comment', 'enquiry', 'inquiry']);

        return [
            'full_name' => $name,
            'email'     => $email,
            'phone'     => $phone,
            'country'   => $country,
            'city'      => $city,
            'message'   => $message,
        ];
    }

    /** Find "Label: value" style lines for any of the given labels. */
    private function detectLabeled(string $block, array $labels): ?string
    {
        foreach ($labels as $label) {
            if (preg_match('/' . preg_quote($label, '/') . '\s*[:\-]\s*(.+)/i', $block, $m)) {
                $val = trim($m[1]);
                // Stop at the next labelled field if everything is on one line.
                $val = preg_split('/\s{2,}|\n/', $val)[0] ?? $val;
                if ($val !== '') {
                    return $val;
                }
            }
        }
        return null;
    }

    /** Heuristic: first line that looks like a person's name (2-3 capitalised words). */
    private function guessName(string $block): ?string
    {
        foreach (preg_split('/\n/', $block) ?: [] as $line) {
            $line = trim($line);
            if (preg_match('/^([A-Z][a-z]+(?:\s+[A-Z][a-z\'.-]+){1,2})$/', $line)) {
                return $line;
            }
        }
        return null;
    }
}
