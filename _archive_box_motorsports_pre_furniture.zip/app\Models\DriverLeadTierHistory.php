<?php

namespace App\Models;

use App\Enums\DriverTier;
use Illuminate\Database\Eloquent\Model;

class DriverLeadTierHistory extends Model
{
    protected $table = 'driver_lead_tier_history';

    protected $fillable = [
        'driver_lead_id', 'user_id', 'old_tier', 'new_tier', 'reason',
    ];

    protected function casts(): array
    {
        return [
            'old_tier' => DriverTier::class,
            'new_tier' => DriverTier::class,
        ];
    }

    public function driverLead()
    {
        return $this->belongsTo(DriverLead::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
