<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header"><h3 class="card-title">Contact Information</h3></div>
            <div class="card-body">
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label>First Name <span class="text-danger">*</span></label>
                        <input name="first_name" value="{{ old('first_name', $lead->first_name ?? '') }}" required class="form-control @error('first_name') is-invalid @enderror">
                        @error('first_name')<span class="invalid-feedback">{{ $message }}</span>@enderror
                    </div>
                    <div class="form-group col-md-6">
                        <label>Last Name</label>
                        <input name="last_name" value="{{ old('last_name', $lead->last_name ?? '') }}" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label>Email <span class="text-danger">*</span></label>
                    <input type="email" name="email" value="{{ old('email', $lead->email ?? '') }}" required class="form-control @error('email') is-invalid @enderror">
                    @error('email')<span class="invalid-feedback">{{ $message }}</span>@enderror
                </div>
                <div class="form-group">
                    <label>Phone <span class="text-danger">*</span></label>
                    <input name="phone" value="{{ old('phone', $lead->phone ?? '') }}" required class="form-control @error('phone') is-invalid @enderror">
                    @error('phone')<span class="invalid-feedback">{{ $message }}</span>@enderror
                </div>
                <div class="form-group">
                    <label>Location / State</label>
                    <input name="loc_state" value="{{ old('loc_state', $lead->loc_state ?? '') }}" class="form-control">
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="card">
            <div class="card-header"><h3 class="card-title">Lead Details</h3></div>
            <div class="card-body">
                <div class="form-group">
                    <label>Source Channel</label>
                    <select name="source_channel" class="form-control">
                        @foreach ($sources as $s)<option value="{{ $s['value'] }}" @selected(old('source_channel', $lead->source_channel->value ?? 'manual')===$s['value'])>{{ $s['label'] }}</option>@endforeach
                    </select>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label>Status</label>
                        <select name="status" class="form-control">
                            @foreach ($statuses as $s)<option value="{{ $s['value'] }}" @selected(old('status', $lead->status->value ?? 'new')===$s['value'])>{{ $s['label'] }}</option>@endforeach
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label>Priority</label>
                        <select name="priority" class="form-control">
                            @foreach ($priorities as $p)<option value="{{ $p['value'] }}" @selected(old('priority', $lead->priority->value ?? 'medium')===$p['value'])>{{ $p['label'] }}</option>@endforeach
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>Motorsport Interest</label>
                    <select name="motorsport_interest_type" class="form-control">
                        <option value="">—</option>
                        @foreach ($interests as $i)<option value="{{ $i['value'] }}" @selected(old('motorsport_interest_type', $lead->motorsport_interest_type->value ?? '')===$i['value'])>{{ $i['label'] }}</option>@endforeach
                    </select>
                </div>
                @unless (auth()->user()->hasRole(\App\Enums\UserRole::SalesRep))
                <div class="form-group">
                    <label>Assigned To</label>
                    <select name="assigned_to" class="form-control">
                        <option value="">Unassigned</option>
                        @foreach ($assignableUsers as $u)<option value="{{ $u->id }}" @selected(old('assigned_to', $lead->assigned_to ?? '')==$u->id)>{{ $u->name }}</option>@endforeach
                    </select>
                </div>
                @endunless
            </div>
        </div>
    </div>

    <div class="col-12">
        <div class="card">
            <div class="card-header"><h3 class="card-title">Message</h3></div>
            <div class="card-body">
                <textarea name="message" rows="4" class="form-control">{{ old('message', $lead->message ?? '') }}</textarea>
            </div>
        </div>
    </div>
</div>