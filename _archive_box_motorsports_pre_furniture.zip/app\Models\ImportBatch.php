<?php

namespace App\Models;

use App\Enums\SourceChannel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ImportBatch extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id', 'file_name', 'file_path', 'file_type', 'source_channel',
        'total_rows', 'successful_rows', 'failed_rows', 'duplicate_rows',
        'status', 'column_map', 'duplicate_strategy', 'error_log',
    ];

    protected function casts(): array
    {
        return [
            'source_channel' => SourceChannel::class,
            'column_map'     => 'array',
            'total_rows'      => 'integer',
            'successful_rows' => 'integer',
            'failed_rows'     => 'integer',
            'duplicate_rows'  => 'integer',
        ];
    }

    public function rows()
    {
        return $this->hasMany(ImportBatchRow::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function failedRows()
    {
        return $this->rows()->where('status', 'failed');
    }
}
