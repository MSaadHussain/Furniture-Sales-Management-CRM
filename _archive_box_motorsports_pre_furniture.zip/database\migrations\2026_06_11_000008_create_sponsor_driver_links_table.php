<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('sponsor_driver_links', function (Blueprint $table) {
            $table->id();
            $table->foreignId('sponsor_profile_id')->constrained('sponsor_profiles')->cascadeOnDelete();
            $table->foreignId('driver_lead_id')->constrained('driver_leads')->cascadeOnDelete();
            $table->foreignId('sponsorship_deal_id')->nullable()->constrained('sponsorship_deals')->nullOnDelete();
            $table->decimal('funding_amount', 12, 2)->nullable();
            $table->string('funding_type')->default('cash');
            $table->string('season_or_event')->nullable();
            $table->string('status')->default('proposed')->index();
            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('sponsor_driver_links');
    }
};
