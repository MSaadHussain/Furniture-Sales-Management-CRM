@extends('layouts.app')
@section('title', 'Sponsorship Pipeline')

@section('header_actions')
    <a href="{{ route('sponsors.index') }}" class="btn btn-light"><i class="fa-solid fa-building"></i> Sponsors & Vendors</a>
    @unless (auth()->user()->role->isReadOnly())
        <a href="{{ route('sponsors.create') }}" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Add Sponsor / Vendor</a>
    @endunless
@endsection

@section('content')

{{-- Kanban board --}}
<div class="flex gap-4 overflow-x-auto pb-4">
    @foreach ($columns as $column)
        <div class="w-80 shrink-0">
            <div class="ta-card overflow-hidden">
                <div class="flex items-center justify-between border-b border-line px-4 py-3 dark:border-strokedark" style="border-top: 3px solid {{ $column['color'] }};">
                    <span class="flex items-center gap-2 text-sm font-semibold text-ink dark:text-white">
                        <span class="h-2.5 w-2.5 rounded-full" style="background:{{ $column['color'] }}"></span>{{ $column['label'] }}
                    </span>
                    <div class="text-right">
                        <span class="deal-count rounded-full bg-surface px-2 py-0.5 text-xs font-semibold text-muted dark:bg-boxdark">{{ $column['deals']->count() + (isset($column['prospects']) ? $column['prospects']->count() : 0) }}</span>
                        <span class="block text-xs text-muted">${{ number_format($column['value'], 0) }}</span>
                    </div>
                </div>
                <div class="kanban-col min-h-[12rem] space-y-2 p-2" data-stage="{{ $column['stage'] }}">
                    {{-- Lead Identified intake: sponsors without an open deal.
                         Not draggable — "+ New Deal" is the explicit conversion. --}}
                    @foreach ($column['prospects'] ?? [] as $prospect)
                        <div class="no-drag rounded-xl border border-dashed border-line bg-surface/60 p-3 dark:border-strokedark dark:bg-boxdark/40">
                            <div class="flex items-start justify-between gap-2">
                                <a href="{{ route('sponsors.show', $prospect) }}" class="text-sm font-semibold text-ink hover:text-brand dark:text-white">{{ $prospect->company_name }}</a>
                                <x-badge :label="$prospect->company_type->label()" :color="$prospect->company_type->color()" />
                            </div>
                            <p class="mt-1 text-xs text-muted">
                                {{ $prospect->contact_name ?: '—' }}
                                @if ($prospect->industry) · {{ $prospect->industry }}@endif
                            </p>
                            <div class="mt-2 flex items-center justify-between text-xs">
                                <span class="font-bold text-ink dark:text-white">{{ $prospect->estimated_budget ? '$' . number_format($prospect->estimated_budget, 0) . ' est.' : '—' }}</span>
                                <span class="text-muted">{{ $prospect->created_at->diffForHumans() }}</span>
                            </div>
                            @unless (auth()->user()->role->isReadOnly())
                                <button type="button"
                                        onclick="openDealModal({{ $prospect->id }}, {{ json_encode($prospect->company_name) }})"
                                        class="btn btn-primary mt-2 w-full !py-1.5 text-xs">
                                    <i class="fa-solid fa-plus"></i> New Deal
                                </button>
                            @endunless
                        </div>
                    @endforeach

                    @foreach ($column['deals'] as $deal)
                        <div class="kanban-card cursor-grab rounded-xl border border-line bg-white p-3 shadow-sm dark:border-strokedark dark:bg-boxdark" data-deal-id="{{ $deal->id }}">
                            <div class="flex items-start justify-between gap-2">
                                <a href="{{ route('sponsors.show', $deal->sponsor_profile_id) }}" class="text-sm font-semibold text-ink hover:text-brand dark:text-white">{{ $deal->sponsor?->company_name }}</a>
                                <x-badge :label="$deal->priority->label()" :color="$deal->priority->color()" />
                            </div>
                            <p class="mt-1 text-xs text-muted">{{ $deal->title }}</p>
                            <div class="mt-2 flex items-center justify-between text-xs">
                                <span class="font-bold text-ink dark:text-white">{{ $deal->deal_value ? '$' . number_format($deal->deal_value, 0) : '—' }}</span>
                                <span class="text-muted">{{ $deal->probability }}%</span>
                            </div>
                            @if ($deal->driverLinks->isNotEmpty())
                                <p class="mt-1 text-xs text-muted"><i class="fa-solid fa-helmet-safety mr-1"></i>{{ $deal->driverLinks->map(fn ($l) => $l->driverLead?->full_name)->filter()->implode(', ') }}</p>
                            @endif
                            <div class="mt-2 flex items-center justify-between border-t border-line pt-2 text-xs text-muted dark:border-strokedark">
                                <span>{{ $deal->assignee?->name ?? 'Unassigned' }}</span>
                                <div class="flex items-center gap-2">
                                    <span>{{ $deal->expected_close_date?->format('M j') ?? '' }}</span>
                                    @unless (auth()->user()->role->isReadOnly())
                                        @php
                                            $dealPayload = json_encode([
                                                'id'                  => $deal->id,
                                                'title'               => $deal->title,
                                                'deal_value'          => $deal->deal_value,
                                                'probability'         => $deal->probability,
                                                'expected_close_date' => $deal->expected_close_date?->format('Y-m-d'),
                                                'package_type'        => $deal->package_type,
                                                'priority'            => $deal->priority->value,
                                                'sponsor'             => $deal->sponsor?->company_name,
                                            ]);
                                        @endphp
                                        <button type="button" title="Edit deal" class="text-muted hover:text-brand"
                                                onclick="openEditDealModal({{ $dealPayload }})">
                                            <i class="fa-solid fa-pen"></i>
                                        </button>
                                        <form method="POST" action="{{ route('sponsorship-pipeline.destroy', $deal) }}"
                                              onsubmit="return confirm('Delete this deal? This cannot be undone from the board.')">
                                            @csrf @method('DELETE')
                                            <button title="Delete deal" class="text-muted hover:text-danger"><i class="fa-solid fa-trash"></i></button>
                                        </form>
                                    @endunless
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    @endforeach
</div>

{{-- New Deal modal --}}
<div id="new-deal-modal" class="fixed inset-0 z-50 hidden items-center justify-center overflow-y-auto bg-black/50 p-4" onclick="if(event.target===this){closeDealModal()}">
    <div class="ta-card my-8 w-full max-w-lg p-6" onclick="event.stopPropagation()">
        <div class="mb-4 flex items-center justify-between">
            <div>
                <h3 class="text-lg font-semibold text-ink dark:text-white">New Sponsorship Deal</h3>
                <p id="new-deal-sponsor-name" class="text-xs text-muted"></p>
            </div>
            <button type="button" onclick="closeDealModal()" class="text-muted hover:text-ink"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <form method="POST" action="{{ route('sponsorship-pipeline.store') }}" class="space-y-4">
            @csrf
            <input type="hidden" name="sponsor_profile_id" id="new-deal-sponsor-id" value="">
            <div>
                <label class="ta-label">Deal Title <span class="text-danger">*</span></label>
                <input name="title" required class="ta-input w-full" placeholder="2026 Driver Sponsorship Package">
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="ta-label">Deal Value ($)</label>
                    <input type="number" step="0.01" min="0" name="deal_value" class="ta-input w-full">
                </div>
                <div>
                    <label class="ta-label">Probability (%)</label>
                    <input type="number" min="0" max="100" name="probability" value="50" class="ta-input w-full">
                </div>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="ta-label">Expected Close</label>
                    <input type="date" name="expected_close_date" class="ta-input w-full">
                </div>
                <div>
                    <label class="ta-label">Priority</label>
                    <select name="priority" class="ta-input w-full">
                        <option value="low">Low</option>
                        <option value="medium" selected>Medium</option>
                        <option value="high">High</option>
                        <option value="hot">Hot</option>
                    </select>
                </div>
            </div>
            <div>
                <label class="ta-label">Package Type</label>
                <input name="package_type" class="ta-input w-full" placeholder="Driver funding, track support, event sponsor...">
            </div>
            <p class="rounded-lg bg-surface px-3 py-2 text-xs text-muted dark:bg-boxdark">
                <i class="fa-solid fa-circle-info mr-1"></i>
                The deal will enter the pipeline at <strong>Proposal Sent</strong> — drag it forward as it progresses.
            </p>
            <div class="flex justify-end gap-3 pt-2">
                <button type="button" onclick="closeDealModal()" class="btn btn-light">Cancel</button>
                <button class="btn btn-primary"><i class="fa-solid fa-plus"></i> Create Deal</button>
            </div>
        </form>
    </div>
</div>

{{-- Edit Deal modal --}}
@unless (auth()->user()->role->isReadOnly())
<div id="edit-deal-modal" class="fixed inset-0 z-50 hidden items-center justify-center overflow-y-auto bg-black/50 p-4" onclick="if(event.target===this){closeEditDealModal()}">
    <div class="ta-card my-8 w-full max-w-lg p-6" onclick="event.stopPropagation()">
        <div class="mb-4 flex items-center justify-between">
            <div>
                <h3 class="text-lg font-semibold text-ink dark:text-white">Edit Deal</h3>
                <p id="edit-deal-sponsor" class="text-xs text-muted"></p>
            </div>
            <button type="button" onclick="closeEditDealModal()" class="text-muted hover:text-ink"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <form id="edit-deal-form" method="POST" action="" class="space-y-4">
            @csrf @method('PATCH')
            <div>
                <label class="ta-label">Deal Title <span class="text-danger">*</span></label>
                <input name="title" id="edit-deal-title" required class="ta-input w-full">
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="ta-label">Deal Value ($)</label>
                    <input type="number" step="0.01" min="0" name="deal_value" id="edit-deal-value" class="ta-input w-full">
                </div>
                <div>
                    <label class="ta-label">Probability (%)</label>
                    <input type="number" min="0" max="100" name="probability" id="edit-deal-probability" class="ta-input w-full">
                </div>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="ta-label">Expected Close</label>
                    <input type="date" name="expected_close_date" id="edit-deal-close" class="ta-input w-full">
                </div>
                <div>
                    <label class="ta-label">Priority</label>
                    <select name="priority" id="edit-deal-priority" class="ta-input w-full">
                        <option value="low">Low</option>
                        <option value="medium">Medium</option>
                        <option value="high">High</option>
                        <option value="hot">Hot</option>
                    </select>
                </div>
            </div>
            <div>
                <label class="ta-label">Package Type</label>
                <input name="package_type" id="edit-deal-package" class="ta-input w-full">
            </div>
            <div class="flex justify-end gap-3 pt-2">
                <button type="button" onclick="closeEditDealModal()" class="btn btn-light">Cancel</button>
                <button class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save Changes</button>
            </div>
        </form>
    </div>
</div>
@endunless

@endsection

@push('scripts')
<script>
    function openDealModal(sponsorId, sponsorName) {
        const m = document.getElementById('new-deal-modal');
        document.getElementById('new-deal-sponsor-id').value = sponsorId;
        document.getElementById('new-deal-sponsor-name').textContent = sponsorName || '';
        m.classList.remove('hidden');
        m.classList.add('flex');
    }
    function closeDealModal() {
        const m = document.getElementById('new-deal-modal');
        m.classList.add('hidden');
        m.classList.remove('flex');
    }
    function openEditDealModal(deal) {
        const m = document.getElementById('edit-deal-modal');
        if (!m) return;
        document.getElementById('edit-deal-form').action = '/sponsorship-pipeline/' + deal.id;
        document.getElementById('edit-deal-sponsor').textContent = deal.sponsor || '';
        document.getElementById('edit-deal-title').value = deal.title || '';
        document.getElementById('edit-deal-value').value = deal.deal_value || '';
        document.getElementById('edit-deal-probability').value = deal.probability ?? 50;
        document.getElementById('edit-deal-close').value = deal.expected_close_date || '';
        document.getElementById('edit-deal-priority').value = deal.priority || 'medium';
        document.getElementById('edit-deal-package').value = deal.package_type || '';
        m.classList.remove('hidden');
        m.classList.add('flex');
    }
    function closeEditDealModal() {
        const m = document.getElementById('edit-deal-modal');
        if (!m) return;
        m.classList.add('hidden');
        m.classList.remove('flex');
    }
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') { closeDealModal(); closeEditDealModal(); }
    });

    document.addEventListener('DOMContentLoaded', function () {
        @unless (auth()->user()->role->isReadOnly())
        const token = document.querySelector('meta[name=csrf-token]').content;
        document.querySelectorAll('.kanban-col').forEach(function (col) {
            new Sortable(col, {
                group: 'sponsorship-pipeline', animation: 150, ghostClass: 'opacity-50',
                filter: '.no-drag', // prospect intake cards convert via "+ New Deal", not by dragging
                onAdd: function (evt) {
                    const dealId = evt.item.dataset.dealId;
                    const newStage = evt.to.dataset.stage;
                    fetch('/sponsorship-pipeline/' + dealId + '/stage', {
                        method: 'PATCH',
                        headers: { 'Content-Type':'application/json', 'X-CSRF-TOKEN':token, 'Accept':'application/json' },
                        body: JSON.stringify({ stage: newStage })
                    })
                    .then(r => { if (!r.ok) throw new Error(); return r.json(); })
                    .then(() => {
                        document.querySelectorAll('.kanban-col').forEach(function (c) {
                            const badge = c.closest('.ta-card').querySelector('.deal-count');
                            if (badge) badge.textContent = c.querySelectorAll('.kanban-card, .no-drag').length;
                        });
                    })
                    .catch(() => { alert('Could not update deal. Reloading.'); location.reload(); });
                }
            });
        });
        @endunless
    });
</script>
@endpush
