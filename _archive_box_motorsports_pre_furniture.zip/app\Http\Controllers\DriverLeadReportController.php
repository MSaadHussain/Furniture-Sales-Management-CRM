<?php

namespace App\Http\Controllers;

use App\Enums\DriverLeadStatus;
use App\Enums\DriverTier;
use App\Models\DriverLead;
use App\Services\DateRangeService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Symfony\Component\HttpFoundation\StreamedResponse;

class DriverLeadReportController extends Controller
{
    public function __construct(private DateRangeService $dates) {}

    public function index(Request $request)
    {
        Gate::authorize('view-reports');

        [$from, $to, $label] = $this->dates->resolve($request);
        $base = fn () => DriverLead::whereBetween('created_at', [$from, $to]);

        // Summary KPIs
        $total     = $base()->count();
        $qualified = $base()->where('status', DriverLeadStatus::Qualified)->count();
        $declined  = $base()->where('status', DriverLeadStatus::Declined)->count();
        $contacted = $base()->where('status', DriverLeadStatus::Contacted)->count();
        $seeking   = $base()->where('seeking_sponsorship', true)->count();
        $avgWins   = round($base()->avg('career_wins') ?? 0, 1);

        // By status
        $byStatus = $base()->select('status', DB::raw('count(*) as total'))
            ->groupBy('status')->pluck('total', 'status');
        $statusReport = collect(DriverLeadStatus::cases())->map(fn ($s) => [
            'label' => $s->label(),
            'value' => (int) ($byStatus[$s->value] ?? 0),
            'color' => $s->color(),
        ]);

        // By tier
        $byTier = $base()->select('inferred_tier', DB::raw('count(*) as total'))
            ->groupBy('inferred_tier')->pluck('total', 'inferred_tier');
        $tierReport = collect(DriverTier::cases())->map(fn ($t) => [
            'label' => $t->label(),
            'value' => (int) ($byTier[$t->value] ?? 0),
            'color' => $t->color(),
        ]);

        // By country (top 10)
        $byCountry = $base()->whereNotNull('country')->where('country', '!=', '')
            ->select('country', DB::raw('count(*) as total'))
            ->groupBy('country')->orderByDesc('total')->limit(10)
            ->pluck('total', 'country');

        // By highest series (top 10)
        $bySeries = $base()->whereNotNull('highest_series')->where('highest_series', '!=', '')
            ->select('highest_series', DB::raw('count(*) as total'))
            ->groupBy('highest_series')->orderByDesc('total')->limit(10)
            ->pluck('total', 'highest_series');

        // By racing level
        $byLevel = $base()->whereNotNull('racing_level')
            ->select('racing_level', DB::raw('count(*) as total'))
            ->groupBy('racing_level')->pluck('total', 'racing_level');
        $levelReport = collect(\App\Enums\DriverRacingLevel::cases())->map(fn ($l) => [
            'label' => $l->label(),
            'value' => (int) ($byLevel[$l->value] ?? 0),
            'color' => $l->color(),
        ])->filter(fn ($r) => $r['value'] > 0)->values();

        // By car type
        $byCarType = $base()->whereNotNull('car_type')
            ->select('car_type', DB::raw('count(*) as total'))
            ->groupBy('car_type')->pluck('total', 'car_type');
        $carTypeReport = collect(\App\Enums\CarType::cases())->map(fn ($c) => [
            'label' => $c->label(),
            'value' => (int) ($byCarType[$c->value] ?? 0),
            'color' => $c->color(),
        ])->filter(fn ($r) => $r['value'] > 0)->values();

        // By age group (computed from DOB in SQL)
        $ageGroupReport = $base()->whereNotNull('dob')
            ->select(DB::raw("CASE
                WHEN TIMESTAMPDIFF(YEAR, dob, CURDATE()) < 12 THEN 'Under 12'
                WHEN TIMESTAMPDIFF(YEAR, dob, CURDATE()) <= 15 THEN '12–15'
                WHEN TIMESTAMPDIFF(YEAR, dob, CURDATE()) <= 18 THEN '16–18'
                WHEN TIMESTAMPDIFF(YEAR, dob, CURDATE()) <= 25 THEN '19–25'
                WHEN TIMESTAMPDIFF(YEAR, dob, CURDATE()) <= 35 THEN '26–35'
                ELSE '36+' END as age_group"), DB::raw('count(*) as total'))
            ->groupBy('age_group')->pluck('total', 'age_group');

        // Contract KPIs
        $activeContracts  = \App\Models\DriverContract::where('contract_status', 'active')->count();
        $expiredContracts = \App\Models\DriverContract::where('contract_status', 'expired')->count();
        $noActiveContract = $base()->whereDoesntHave('contracts', fn ($q) => $q->where('contract_status', 'active'))->count();
        $sponsorLinked    = $base()->whereHas('sponsorLinks')->count();

        // Top drivers by career wins
        $topDrivers = $base()->orderByDesc('career_wins')->limit(10)
            ->get(['id', 'first_name', 'last_name', 'email', 'career_wins', 'years_racing', 'inferred_tier', 'instagram_followers']);

        // Sponsorship breakdown
        $seekingCount    = $seeking;
        $notSeekingCount = $total - $seeking;

        // Monthly trend (last 6 months)
        $trend = DriverLead::where('created_at', '>=', now()->subMonths(6)->startOfMonth())
            ->select(DB::raw("DATE_FORMAT(created_at, '%Y-%m') as month"), DB::raw('count(*) as total'))
            ->groupBy('month')->orderBy('month')
            ->pluck('total', 'month');

        return view('reports.drivers', [
            'rangeLabel'   => $label,
            'presets'      => $this->dates->presets(),
            'currentRange' => $request->string('range', 'last_30')->value(),
            'filters'      => $request->only(['range', 'from', 'to']),
            'summary'      => compact('total', 'qualified', 'declined', 'contacted', 'seeking', 'avgWins'),
            'statusReport' => $statusReport,
            'tierReport'   => $tierReport,
            'levelReport'  => $levelReport,
            'carTypeReport'=> $carTypeReport,
            'ageGroupReport' => $ageGroupReport,
            'contractStats' => [
                'active'   => $activeContracts,
                'expired'  => $expiredContracts,
                'noActive' => $noActiveContract,
                'linked'   => $sponsorLinked,
            ],
            'byCountry'    => $byCountry,
            'bySeries'     => $bySeries,
            'topDrivers'   => $topDrivers,
            'seekingCount' => $seekingCount,
            'notSeekingCount' => $notSeekingCount,
            'trend'        => $trend,
        ]);
    }

    public function export(Request $request): StreamedResponse
    {
        Gate::authorize('view-reports');

        [$from, $to] = $this->dates->resolve($request);

        $leads = DriverLead::whereBetween('created_at', [$from, $to])->orderByDesc('created_at');

        $filename = 'driver_leads_report_' . now()->format('Y_m_d_His') . '.csv';

        return response()->streamDownload(function () use ($leads) {
            $handle = fopen('php://output', 'w');
            fputcsv($handle, [
                'ID', 'First Name', 'Last Name', 'Email', 'Phone', 'Country', 'DOB', 'Age', 'Age Group',
                'Years Racing', 'Highest Series', 'Racing Level', 'Car Type', 'Career Wins', 'Current Team/Series',
                'Instagram', 'Followers', 'Seeking Sponsorship', 'Contract Interest', 'Tier', 'Status', 'Created',
            ]);
            $leads->chunk(500, function ($chunk) use ($handle) {
                foreach ($chunk as $d) {
                    fputcsv($handle, [
                        $d->id, $d->first_name, $d->last_name, $d->email, $d->phone, $d->country,
                        $d->dob?->format('Y-m-d'), $d->age, $d->age_group,
                        $d->years_racing, $d->highest_series,
                        $d->racing_level?->label(), $d->car_type?->label(),
                        $d->career_wins, $d->current_team_series,
                        $d->instagram_handle, $d->instagram_followers,
                        $d->seeking_sponsorship ? 'Yes' : 'No',
                        $d->contract_interest_type?->label(),
                        $d->inferred_tier->label(), $d->status->label(),
                        $d->created_at?->toDateTimeString(),
                    ]);
                }
            });
            fclose($handle);
        }, $filename, ['Content-Type' => 'text/csv']);
    }
}
