<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WeeklyReportLog extends Model
{
    protected $fillable = [
        'period_start', 'period_end', 'new_leads', 'updated_leads',
        'duplicate_leads', 'recipients', 'status', 'error',
    ];

    protected function casts(): array
    {
        return [
            'period_start' => 'date',
            'period_end'   => 'date',
            'recipients'   => 'array',
        ];
    }
}
