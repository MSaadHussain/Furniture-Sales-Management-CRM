<?php

namespace App\Services;

use App\Models\Lead;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Log;

/**
 * Resolves lead geography and aggregates leads-by-country for the dashboard map.
 *
 * Country resolution priority (per the spec):
 *   1. Explicit submitted country / country_code on the lead.
 *   2. GeoIP lookup from ip_address (if geoip2/geoip2 + a GeoLite2 DB are available).
 *   3. 'Unknown'.
 *
 * GeoIP is entirely optional: if the package or database is absent the service
 * silently skips it and relies on explicit country data. No hard dependency.
 */
class LeadLocationService
{
    /** @var array<string,array{name:string,lat:float,lng:float}> */
    private array $countries;

    /** @var array<string,string> lowercase name => code */
    private array $nameIndex;

    public function __construct()
    {
        $this->countries = config('countries', []);
        $this->nameIndex = [];
        foreach ($this->countries as $code => $info) {
            $this->nameIndex[strtolower($info['name'])] = $code;
        }
    }

    /**
     * Resolve a [code, name] pair for a lead, applying the priority rules.
     *
     * @return array{0: string|null, 1: string} [countryCode|null, countryName]
     */
    public function resolveForLead(Lead $lead): array
    {
        // 1. Explicit code.
        if ($lead->country_code && isset($this->countries[strtoupper($lead->country_code)])) {
            $code = strtoupper($lead->country_code);
            return [$code, $this->countries[$code]['name']];
        }

        // 1b. Explicit country name -> code.
        if ($lead->country) {
            $code = $this->codeFromName($lead->country);
            if ($code) {
                return [$code, $this->countries[$code]['name']];
            }
            // Name present but unmapped: keep the raw name, no code.
            return [null, $lead->country];
        }

        // 2. GeoIP from IP.
        if ($lead->ip_address) {
            $geo = $this->lookupIp($lead->ip_address);
            if ($geo) {
                return $geo;
            }
        }

        // 3. Unknown.
        return [null, 'Unknown'];
    }

    /**
     * Persist resolved country/code (and centroid coords if missing) onto a lead.
     * Safe to call on import or intake. Does not overwrite explicit coordinates.
     */
    public function stampLead(Lead $lead): Lead
    {
        [$code, $name] = $this->resolveForLead($lead);

        if ($name !== 'Unknown') {
            $lead->country = $lead->country ?: $name;
        }
        if ($code) {
            $lead->country_code = $lead->country_code ?: $code;
            if (blank($lead->latitude) && isset($this->countries[$code])) {
                $lead->latitude  = $this->countries[$code]['lat'];
                $lead->longitude = $this->countries[$code]['lng'];
            }
        }

        return $lead;
    }

    /**
     * Aggregate leads by country for the map.
     *
     * @param Builder $query  a (already scoped/filtered) Lead query
     * @return array{
     *   countries: array<int,array{code:string|null,name:string,total:int,percentage:float,lat:float|null,lng:float|null}>,
     *   total: int
     * }
     */
    public function aggregate(Builder $query): array
    {
        $leads = $query->get(['id', 'country', 'country_code', 'ip_address']);
        $total = $leads->count();

        $buckets = []; // key => [code, name, total]
        foreach ($leads as $lead) {
            [$code, $name] = $this->resolveForLead($lead);
            $key = $code ?? ('name:' . strtolower($name));
            if (! isset($buckets[$key])) {
                $buckets[$key] = ['code' => $code, 'name' => $name, 'total' => 0];
            }
            $buckets[$key]['total']++;
        }

        $countries = [];
        foreach ($buckets as $b) {
            $coords = ($b['code'] && isset($this->countries[$b['code']]))
                ? $this->countries[$b['code']]
                : null;
            $countries[] = [
                'code'       => $b['code'],
                'name'       => $b['name'],
                'total'      => $b['total'],
                'percentage' => $total > 0 ? round($b['total'] / $total * 100, 1) : 0.0,
                'lat'        => $coords['lat'] ?? null,
                'lng'        => $coords['lng'] ?? null,
            ];
        }

        usort($countries, fn ($a, $b) => $b['total'] <=> $a['total']);

        return ['countries' => $countries, 'total' => $total];
    }

    public function codeFromName(?string $name): ?string
    {
        if (! $name) {
            return null;
        }
        $needle = strtolower(trim($name));

        if (isset($this->nameIndex[$needle])) {
            return $this->nameIndex[$needle];
        }

        // Common aliases.
        $aliases = [
            'uk' => 'GB', 'u.k.' => 'GB', 'great britain' => 'GB', 'england' => 'GB',
            'usa' => 'US', 'u.s.a.' => 'US', 'u.s.' => 'US', 'america' => 'US', 'united states of america' => 'US',
            'uae' => 'AE', 'u.a.e.' => 'AE', 'emirates' => 'AE',
            'korea' => 'KR', 'south korea' => 'KR',
        ];

        return $aliases[$needle] ?? null;
    }

    /**
     * Optional GeoIP lookup. Returns [code, name] or null.
     * Uses geoip2/geoip2 + a GeoLite2-Country.mmdb at storage/app/geoip if present.
     */
    private function lookupIp(string $ip): ?array
    {
        $dbPath = storage_path('app/geoip/GeoLite2-Country.mmdb');

        if (! class_exists(\GeoIp2\Database\Reader::class) || ! is_file($dbPath)) {
            return null; // GeoIP not configured — graceful no-op.
        }

        try {
            $reader = new \GeoIp2\Database\Reader($dbPath);
            $record = $reader->country($ip);
            $code   = $record->country->isoCode;
            if ($code && isset($this->countries[$code])) {
                return [$code, $this->countries[$code]['name']];
            }
            if ($code) {
                return [$code, $record->country->name ?? $code];
            }
        } catch (\Throwable $e) {
            Log::debug('GeoIP lookup failed', ['ip' => $ip, 'error' => $e->getMessage()]);
        }

        return null;
    }
}
