@extends('layouts.adminlte')
@section('title', 'Pipeline')

@section('content')
<div class="d-flex" style="gap:1rem; overflow-x:auto; padding-bottom:1rem;">
    @foreach ($columns as $column)
        <div style="min-width:300px; flex:0 0 auto;">
            <div class="card mb-0">
                <div class="card-header d-flex justify-content-between align-items-center" style="border-top:3px solid {{ $column['color'] }};">
                    <span><span class="badge-dot mr-2" style="background-color: {{ $column['color'] }}"></span><strong>{{ $column['label'] }}</strong></span>
                    <span class="badge badge-light">{{ $column['leads']->count() }}</span>
                </div>
                <div class="card-body kanban-col p-2" data-status="{{ $column['status'] }}">
                    @forelse ($column['leads'] as $lead)
                        <div class="card kanban-card mb-2 shadow-sm" data-lead-id="{{ $lead->id }}">
                            <div class="card-body p-2">
                                <div class="d-flex justify-content-between">
                                    <a href="{{ route('leads.show', $lead) }}" class="font-weight-bold text-dark">{{ $lead->full_name ?: 'Unnamed' }}</a>
                                    @include('layouts._badge', ['label'=>$lead->priority->label(),'color'=>$lead->priority->color()])
                                </div>
                                <div class="text-muted small mb-1">{{ $lead->email ?: $lead->phone ?: '—' }}</div>
                                @include('layouts._badge', ['label'=>$lead->source_channel->label(),'color'=>$lead->source_channel->color()])
                                <div class="d-flex justify-content-between align-items-center mt-2 small text-muted">
                                    <span>@if($lead->assignee)<span class="avatar-circle mr-1" style="background-color: {{ $lead->assignee->avatar_color }}; height:22px; width:22px; font-size:10px;">{{ $lead->assignee->initials() }}</span>{{ $lead->assignee->name }}@else Unassigned @endif</span>
                                    <span>{{ $lead->created_at->format('M j') }}</span>
                                </div>
                            </div>
                        </div>
                    @empty
                        <p class="text-center text-muted small py-3">Drop leads here</p>
                    @endforelse
                </div>
            </div>
        </div>
    @endforeach
</div>
@endsection

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const token = document.querySelector('meta[name=csrf-token]').content;
        document.querySelectorAll('.kanban-col').forEach(function (col) {
            new Sortable(col, {
                group: 'pipeline', animation: 150, ghostClass: 'bg-light',
                onAdd: function (evt) {
                    const leadId = evt.item.dataset.leadId;
                    const newStatus = evt.to.dataset.status;
                    fetch('/pipeline/' + leadId + '/move', {
                        method: 'PATCH',
                        headers: { 'Content-Type':'application/json', 'X-CSRF-TOKEN':token, 'Accept':'application/json' },
                        body: JSON.stringify({ status: newStatus })
                    })
                    .then(r => { if (!r.ok) throw new Error(); return r.json(); })
                    .then(() => {
                        document.querySelectorAll('.kanban-col').forEach(function (c) {
                            const badge = c.closest('.card').querySelector('.badge-light');
                            if (badge) badge.textContent = c.querySelectorAll('.kanban-card').length;
                        });
                    })
                    .catch(() => { alert('Could not update lead. Reloading.'); location.reload(); });
                }
            });
        });
    });
</script>
@endpush
