{{--
    TailAdmin-style sidebar. Dark (#111827) chrome, brand-active pills.
    Menu items whose routes belong to later phases are guarded with Route::has()
    so the sidebar renders cleanly today and lights up automatically as phases land.
--}}
<aside
    x-data="{ }"
    class="fixed left-0 top-0 z-50 flex h-screen w-72 flex-col overflow-y-hidden bg-sidebar
           transition-transform duration-300 ease-in-out lg:static lg:translate-x-0"
    :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'"
>
    {{-- Brand --}}
    <div class="flex items-center justify-between gap-2 px-6 py-5">
        <a href="{{ route('dashboard') }}" class="flex items-center gap-2.5">
            <span class="flex h-9 w-9 items-center justify-center rounded-lg bg-brand text-white">
                <i class="fa-solid fa-flag-checkered"></i>
            </span>
            <span class="text-[15px] font-bold tracking-wide text-white">
                <span class="text-box">BOX</span> MOTORSPORTS
            </span>
        </a>
        <button class="text-gray-400 lg:hidden" @click="sidebarOpen = false">
            <i class="fa-solid fa-xmark text-lg"></i>
        </button>
    </div>

    <nav class="no-scrollbar flex flex-1 flex-col overflow-y-auto px-4 pb-6">
        <p class="mb-3 mt-2 px-3 text-xs font-semibold uppercase tracking-wider text-gray-500">Menu</p>
        <ul class="flex flex-col gap-1">

            {{-- Dashboard --}}
            <li>
                <a href="{{ route('dashboard') }}"
                   class="ta-nav-link {{ request()->routeIs('dashboard') ? 'active' : '' }}">
                    <i class="fa-solid fa-gauge-high w-5 text-center"></i><span>Dashboard</span>
                </a>
            </li>

            {{-- Leads (collapsible: list + import) --}}
            <li x-data="{ open: {{ request()->routeIs('leads.*') ? 'true' : 'false' }} }">
                <button @click="open = !open"
                        class="ta-nav-link w-full {{ request()->routeIs('leads.*') ? 'active' : '' }}">
                    <i class="fa-solid fa-users w-5 text-center"></i>
                    <span class="flex-1 text-left">Leads</span>
                    <i class="fa-solid fa-chevron-down text-xs transition-transform" :class="open && 'rotate-180'"></i>
                </button>
                <ul x-show="open" x-collapse class="mt-1 flex flex-col gap-1 pl-9">
                    <li>
                        <a href="{{ route('leads.index') }}"
                           class="ta-nav-sub {{ request()->routeIs('leads.index') || request()->routeIs('leads.show') || request()->routeIs('leads.create') || request()->routeIs('leads.edit') ? 'active' : '' }}">
                            All Leads
                        </a>
                    </li>
                    @if (Route::has('leads.import.index'))
                        <li>
                            <a href="{{ route('leads.import.index') }}"
                               class="ta-nav-sub {{ request()->routeIs('leads.import.*') ? 'active' : '' }}">
                                Import Leads
                            </a>
                        </li>
                    @endif
                    <li>
                        <a href="{{ route('leads.trash') }}"
                           class="ta-nav-sub {{ request()->routeIs('leads.trash') ? 'active' : '' }}">
                            Trash
                        </a>
                    </li>
                </ul>
            </li>

            {{-- Driver Leads (collapsible: list + import + trash) --}}
            @if (Route::has('driver-leads.index'))
                <li x-data="{ open: {{ request()->routeIs('driver-leads.*') ? 'true' : 'false' }} }">
                    <button @click="open = !open"
                            class="ta-nav-link w-full {{ request()->routeIs('driver-leads.*') ? 'active' : '' }}">
                        <i class="fa-solid fa-helmet-safety w-5 text-center"></i>
                        <span class="flex-1 text-left">Driver Leads</span>
                        <i class="fa-solid fa-chevron-down text-xs transition-transform" :class="open && 'rotate-180'"></i>
                    </button>
                    <ul x-show="open" x-collapse class="mt-1 flex flex-col gap-1 pl-9">
                        <li>
                            <a href="{{ route('driver-leads.index') }}"
                               class="ta-nav-sub {{ request()->routeIs('driver-leads.index') || request()->routeIs('driver-leads.show') ? 'active' : '' }}">
                                All Driver Leads
                            </a>
                        </li>
                        @if (Route::has('driver-leads.import'))
                            <li>
                                <a href="{{ route('driver-leads.import') }}"
                                   class="ta-nav-sub {{ request()->routeIs('driver-leads.import*') ? 'active' : '' }}">
                                    Import
                                </a>
                            </li>
                        @endif
                        @if (Route::has('driver-leads.trash'))
                            <li>
                                <a href="{{ route('driver-leads.trash') }}"
                                   class="ta-nav-sub {{ request()->routeIs('driver-leads.trash') ? 'active' : '' }}">
                                    Trash
                                </a>
                            </li>
                        @endif
                    </ul>
                </li>
            @endif

            {{-- Sponsors & Vendors (collapsible: list + import + trash) --}}
            @if (Route::has('sponsors.index'))
                <li x-data="{ open: {{ request()->routeIs('sponsors.*') ? 'true' : 'false' }} }">
                    <button @click="open = !open"
                            class="ta-nav-link w-full {{ request()->routeIs('sponsors.*') ? 'active' : '' }}">
                        <i class="fa-solid fa-handshake w-5 text-center"></i>
                        <span class="flex-1 text-left">Sponsors & Vendors</span>
                        <i class="fa-solid fa-chevron-down text-xs transition-transform" :class="open && 'rotate-180'"></i>
                    </button>
                    <ul x-show="open" x-collapse class="mt-1 flex flex-col gap-1 pl-9">
                        <li>
                            <a href="{{ route('sponsors.index') }}"
                               class="ta-nav-sub {{ request()->routeIs('sponsors.index') || request()->routeIs('sponsors.show') || request()->routeIs('sponsors.create') || request()->routeIs('sponsors.edit') ? 'active' : '' }}">
                                All Sponsors & Vendors
                            </a>
                        </li>
                        @if (Route::has('sponsors.import'))
                            <li>
                                <a href="{{ route('sponsors.import') }}"
                                   class="ta-nav-sub {{ request()->routeIs('sponsors.import*') ? 'active' : '' }}">
                                    Import
                                </a>
                            </li>
                        @endif
                        @if (Route::has('sponsors.trash'))
                            <li>
                                <a href="{{ route('sponsors.trash') }}"
                                   class="ta-nav-sub {{ request()->routeIs('sponsors.trash') ? 'active' : '' }}">
                                    Trash
                                </a>
                            </li>
                        @endif
                    </ul>
                </li>
            @endif

            {{-- Sponsorship Pipeline --}}
            @if (Route::has('sponsorship-pipeline.index'))
                <li>
                    <a href="{{ route('sponsorship-pipeline.index') }}"
                       class="ta-nav-link {{ request()->routeIs('sponsorship-pipeline.*') ? 'active' : '' }}">
                        <i class="fa-solid fa-sack-dollar w-5 text-center"></i><span>Sponsorship Pipeline</span>
                    </a>
                </li>
            @endif

            {{-- Pipeline --}}
            <li>
                <a href="{{ route('pipeline.index') }}"
                   class="ta-nav-link {{ request()->routeIs('pipeline.*') ? 'active' : '' }}">
                    <i class="fa-solid fa-table-columns w-5 text-center"></i><span>Pipeline</span>
                </a>
            </li>

            {{-- Calendar / Meetings (Phase 6) --}}
            @if (Route::has('meetings.index'))
                <li>
                    <a href="{{ route('meetings.index') }}"
                       class="ta-nav-link {{ request()->routeIs('meetings.*') ? 'active' : '' }}">
                        <i class="fa-solid fa-calendar-days w-5 text-center"></i><span>Calendar / Meetings</span>
                    </a>
                </li>
            @endif

            {{-- Reports --}}
            <li x-data="{ open: {{ request()->routeIs('reports.*') ? 'true' : 'false' }} }">
                <button @click="open = !open"
                        class="ta-nav-link w-full {{ request()->routeIs('reports.*') ? 'active' : '' }}">
                    <i class="fa-solid fa-chart-column w-5 text-center"></i>
                    <span class="flex-1 text-left">Reports</span>
                    <i class="fa-solid fa-chevron-down text-xs transition-transform" :class="open && 'rotate-180'"></i>
                </button>
                <ul x-show="open" x-collapse class="mt-1 flex flex-col gap-1 pl-9">
                    <li>
                        <a href="{{ route('reports.index') }}"
                           class="ta-nav-sub {{ request()->routeIs('reports.index') ? 'active' : '' }}">Overview</a>
                    </li>
                    <li>
                        <a href="{{ route('reports.location') }}"
                           class="ta-nav-sub {{ request()->routeIs('reports.location') ? 'active' : '' }}">Location</a>
                    </li>
                    @if (Route::has('reports.drivers'))
                        <li>
                            <a href="{{ route('reports.drivers') }}"
                               class="ta-nav-sub {{ request()->routeIs('reports.drivers*') ? 'active' : '' }}">Driver Leads</a>
                        </li>
                    @endif
                    @if (Route::has('reports.sponsors'))
                        <li>
                            <a href="{{ route('reports.sponsors') }}"
                               class="ta-nav-sub {{ request()->routeIs('reports.sponsors*') ? 'active' : '' }}">Sponsors & Vendors</a>
                        </li>
                    @endif
                </ul>
            </li>
        </ul>

        @can('manage-integrations')
            <p class="mb-3 mt-6 px-3 text-xs font-semibold uppercase tracking-wider text-gray-500">Admin</p>
            <ul class="flex flex-col gap-1">
                @can('manage-users')
                    <li>
                        <a href="{{ route('users.index') }}"
                           class="ta-nav-link {{ request()->routeIs('users.*') ? 'active' : '' }}">
                            <i class="fa-solid fa-user-shield w-5 text-center"></i><span>Users</span>
                        </a>
                    </li>
                @endcan
                <li x-data="{ open: {{ request()->routeIs('integrations.*') ? 'true' : 'false' }} }">
                    <button @click="open = !open"
                            class="ta-nav-link w-full {{ request()->routeIs('integrations.*') ? 'active' : '' }}">
                        <i class="fa-solid fa-plug w-5 text-center"></i>
                        <span class="flex-1 text-left">Integrations</span>
                        <i class="fa-solid fa-chevron-down text-xs transition-transform" :class="open && 'rotate-180'"></i>
                    </button>
                    <ul x-show="open" x-collapse class="mt-1 flex flex-col gap-1 pl-9">
                        <li><a href="{{ route('integrations.index') }}" class="ta-nav-sub {{ request()->routeIs('integrations.index') ? 'active' : '' }}">Channels</a></li>
                        <li><a href="{{ route('integrations.meta') }}" class="ta-nav-sub {{ request()->routeIs('integrations.meta') ? 'active' : '' }}">Meta Lead Ads</a></li>
                        <li><a href="{{ route('integrations.google-leads') }}" class="ta-nav-sub {{ request()->routeIs('integrations.google-leads') ? 'active' : '' }}">Google Leads</a></li>
                        <li><a href="{{ route('integrations.google-contact-form') }}" class="ta-nav-sub {{ request()->routeIs('integrations.google-contact-form') ? 'active' : '' }}">Google Contact Form</a></li>
                        @if (Route::has('integrations.driver-lead-form'))
                            <li><a href="{{ route('integrations.driver-lead-form') }}" class="ta-nav-sub {{ request()->routeIs('integrations.driver-lead-form') ? 'active' : '' }}">Driver Lead Form</a></li>
                        @endif
                        @if (Route::has('integrations.sponsor-lead-form'))
                            <li><a href="{{ route('integrations.sponsor-lead-form') }}" class="ta-nav-sub {{ request()->routeIs('integrations.sponsor-lead-form') ? 'active' : '' }}">Sponsor Lead Form</a></li>
                        @endif
                        @if (Route::has('integrations.meetings'))
                            <li><a href="{{ route('integrations.meetings') }}" class="ta-nav-sub {{ request()->routeIs('integrations.meetings') ? 'active' : '' }}">Meetings</a></li>
                        @endif
                    </ul>
                </li>
                @if (Route::has('settings.index'))
                    <li>
                        <a href="{{ route('settings.index') }}"
                           class="ta-nav-link {{ request()->routeIs('settings.*') ? 'active' : '' }}">
                            <i class="fa-solid fa-gear w-5 text-center"></i><span>Settings</span>
                        </a>
                    </li>
                @endif
                @can('view-activity')
                    <li x-data="{ open: {{ request()->routeIs('activity.*') ? 'true' : 'false' }} }">
                        <button @click="open = !open"
                                class="ta-nav-link w-full {{ request()->routeIs('activity.*') ? 'active' : '' }}">
                            <i class="fa-solid fa-clock-rotate-left w-5 text-center"></i>
                            <span class="flex-1 text-left">User Activity</span>
                            <i class="fa-solid fa-chevron-down text-xs transition-transform" :class="open && 'rotate-180'"></i>
                        </button>
                        <ul x-show="open" x-collapse class="mt-1 flex flex-col gap-1 pl-9">
                            <li><a href="{{ route('activity.logs') }}" class="ta-nav-sub {{ request()->routeIs('activity.logs') ? 'active' : '' }}">Activity Logs</a></li>
                            <li><a href="{{ route('activity.sessions') }}" class="ta-nav-sub {{ request()->routeIs('activity.sessions') ? 'active' : '' }}">Time Spent</a></li>
                        </ul>
                    </li>
                @endcan
            </ul>
        @endcan

        {{-- Upgrade / help card at the bottom --}}
        <div class="mt-auto rounded-2xl bg-white/5 p-4 text-center">
            <p class="text-sm font-semibold text-white">Box Motorsports CRM</p>
            <p class="mt-1 text-xs text-gray-400">Inbound Lead Management</p>
        </div>
    </nav>
</aside>
