<?php

namespace App\Http\Controllers\Api\V1;

use App\Enums\SourceChannel;
use App\Http\Controllers\Controller;
use App\Services\LeadIntakeService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class WebhookController extends Controller
{
    public function __construct(protected LeadIntakeService $intake) {}

    public function __invoke(Request $request): JsonResponse
    {
        $channel = SourceChannel::tryFrom($request->input('source_channel', 'website'))
            ?? SourceChannel::Website;

        return $this->process($channel, $request->all(), $request);
    }

    protected function process(SourceChannel $channel, array $payload, Request $request): JsonResponse
    {
        try {
            [$lead, $isNew] = $this->intake->ingest($channel, $payload, $request->ip());

            return response()->json([
                'success' => true,
                'created' => $isNew,
                'merged'  => ! $isNew,
                'lead_id' => $lead->id,
                'status'  => $lead->status->value,
            ], $isNew ? 201 : 200);
        } catch (\Throwable $e) {
            report($e);

            return response()->json([
                'success' => false,
                'message' => 'Failed to process lead.',
            ], 422);
        }
    }
}
