<?php

namespace Tests\Feature;

use App\Models\IntegrationSetting;
use App\Models\Lead;
use App\Models\LeadMeeting;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Mail;
use Tests\TestCase;

class MeetingTest extends TestCase
{
    use RefreshDatabase;

    public function test_meetings_page_loads(): void
    {
        $user = User::factory()->create(['role' => 'admin']);
        $this->actingAs($user)->get('/meetings')->assertOk()->assertSee('Scheduled Meetings');
    }

    public function test_add_calendly_link_creates_meeting(): void
    {
        Mail::fake();
        $user = User::factory()->create(['role' => 'admin']);
        $lead = Lead::factory()->create();

        $this->actingAs($user)->post("/leads/{$lead->id}/meetings/calendly-link", [
            'meeting_url' => 'https://calendly.com/box/intro',
            'title'       => 'Intro call',
        ])->assertRedirect();

        $this->assertDatabaseHas('lead_meetings', [
            'lead_id'  => $lead->id,
            'provider' => 'calendly',
            'meeting_url' => 'https://calendly.com/box/intro',
        ]);
    }

    public function test_calendly_webhook_attaches_meeting_and_updates_status(): void
    {
        // No signing key configured -> signature check is skipped.
        IntegrationSetting::create(['channel' => 'calendly', 'enabled' => true, 'config' => []]);
        $lead = Lead::factory()->create(['email' => 'invitee@example.com', 'status' => 'new']);

        $this->postJson('/api/v1/webhooks/calendly', [
            'event' => 'invitee.created',
            'payload' => [
                'email' => 'invitee@example.com',
                'name'  => 'Invitee Person',
                'uri'   => 'https://api.calendly.com/scheduled_events/ABC/invitees/XYZ',
                'scheduled_event' => [
                    'name'       => 'Strategy Call',
                    'start_time' => now()->addDay()->toIso8601String(),
                    'end_time'   => now()->addDay()->addHour()->toIso8601String(),
                    'location'   => ['join_url' => 'https://meet.example.com/abc'],
                ],
            ],
        ])->assertOk()->assertJson(['received' => true]);

        $this->assertDatabaseHas('lead_meetings', ['lead_id' => $lead->id, 'provider' => 'calendly']);
        $this->assertSame('meeting_scheduled', $lead->fresh()->status->value);
    }

    public function test_calendly_webhook_ignores_unmatched_email(): void
    {
        IntegrationSetting::create(['channel' => 'calendly', 'enabled' => true, 'config' => []]);

        $this->postJson('/api/v1/webhooks/calendly', [
            'event' => 'invitee.created',
            'payload' => ['email' => 'nobody@example.com', 'scheduled_event' => ['name' => 'X']],
        ])->assertOk();

        $this->assertDatabaseCount('lead_meetings', 0);
    }
}
