<?php

namespace App\Console\Commands;

use App\Enums\UserRole;
use App\Mail\WeeklyLeadReportMail;
use App\Models\EmailNotificationLog;
use App\Models\ReportSetting;
use App\Models\User;
use App\Models\WeeklyReportLog;
use App\Services\WeeklyLeadReportService;
use Carbon\CarbonImmutable;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;

class SendWeeklyLeadReportCommand extends Command
{
    protected $signature = 'crm:weekly-report {--force : Send even if disabled in settings}';

    protected $description = 'Send the weekly lead report email to configured recipients.';

    public function handle(WeeklyLeadReportService $service): int
    {
        if (! ReportSetting::get('weekly_report_enabled', true) && ! $this->option('force')) {
            $this->info('Weekly report is disabled in settings. Skipping.');
            return self::SUCCESS;
        }

        $recipients = $this->recipients();
        if (empty($recipients)) {
            $this->warn('No recipients configured for the weekly report.');
            WeeklyReportLog::create([
                'period_start' => now()->subWeek()->startOfWeek(),
                'period_end'   => now()->subWeek()->endOfWeek(),
                'status'       => 'skipped',
                'error'        => 'No recipients',
            ]);
            return self::SUCCESS;
        }

        $report = $service->build();
        $includeCsv = (bool) ReportSetting::get('weekly_report_include_csv', true);

        $csvFiles = [];
        if ($includeCsv) {
            $stamp = $report['period_start']->format('Y-m-d');
            $csvFiles = array_filter([
                "weekly-basic-leads-{$stamp}.csv"   => $service->csv($report['period_start'], $report['period_end']),
                "weekly-driver-leads-{$stamp}.csv"  => $service->driverCsv($report['period_start'], $report['period_end']),
                "weekly-sponsor-leads-{$stamp}.csv" => $service->sponsorCsv($report['period_start'], $report['period_end']),
            ], fn ($c) => trim((string) $c) !== '' && substr_count((string) $c, "\n") > 1);
        }

        $sent = 0;
        $error = null;
        foreach ($recipients as $email) {
            try {
                Mail::to($email)->send(new WeeklyLeadReportMail($report, $csvFiles));
                EmailNotificationLog::record('weekly_report', $email, null, 'Weekly Lead Report', 'sent');
                $sent++;
            } catch (\Throwable $e) {
                $error = $e->getMessage();
                EmailNotificationLog::record('weekly_report', $email, null, 'Weekly Lead Report', 'failed', $error);
                $this->error("Failed for {$email}: {$error}");
            }
        }

        WeeklyReportLog::create([
            'period_start'    => $report['period_start'],
            'period_end'      => $report['period_end'],
            'new_leads'       => $report['new_count'],
            'updated_leads'   => $report['updated_count'],
            'duplicate_leads' => $report['duplicate_count'],
            'recipients'      => $recipients,
            'status'          => $sent > 0 ? 'sent' : 'failed',
            'error'           => $sent > 0 ? null : $error,
        ]);

        $this->info("Weekly report sent to {$sent} recipient(s).");
        return self::SUCCESS;
    }

    /** @return array<int,string> */
    private function recipients(): array
    {
        $configured = ReportSetting::get('weekly_report_recipients', []);
        if (is_string($configured)) {
            $configured = array_filter(array_map('trim', explode(',', $configured)));
        }

        if (! empty($configured)) {
            return array_values($configured);
        }

        // Fallback: all active admins.
        return User::where('is_active', true)
            ->whereIn('role', [UserRole::SuperAdmin->value, UserRole::Admin->value])
            ->pluck('email')->all();
    }
}
