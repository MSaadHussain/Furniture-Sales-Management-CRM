{{--
    Reusable Meetings card for a meetable subject (Driver Lead or Sponsor).
    Required vars: $subject, $googleRoute, $calendlyRoute, $defaultTitle
--}}
<x-card title="Meetings" subtitle="Google Meet & Zoom meetings">
    <div class="mb-5 space-y-2">
        @forelse ($subject->meetings as $m)
            <div class="flex items-center justify-between rounded-xl border border-line p-3 dark:border-strokedark">
                <div>
                    <div class="font-semibold text-ink dark:text-white">{{ $m->meeting_title ?: ucfirst($m->provider) }}</div>
                    <div class="text-xs text-muted">
                        {{ $m->starts_at?->format('M j, Y g:i A') ?? 'Time TBD' }}
                        · {{ ucfirst(str_replace('_', ' ', $m->provider)) }}
                    </div>
                    @if ($m->description)<div class="mt-1 text-xs text-muted" style="white-space:pre-line;">{{ $m->description }}</div>@endif
                </div>
                <div class="flex items-center gap-2">
                    @if ($m->meeting_url)
                        <a href="{{ $m->meeting_url }}" target="_blank" rel="noopener" class="btn btn-primary btn-sm"><i class="fa-solid fa-video"></i> Join</a>
                    @endif
                    @unless (auth()->user()->role->isReadOnly())
                        <form method="POST" action="{{ route('meetings.destroy', $m) }}"
                              onsubmit="return confirm('Delete this meeting?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-light btn-sm text-danger" title="Delete meeting"><i class="fa-solid fa-trash"></i></button>
                        </form>
                    @endunless
                </div>
            </div>
        @empty
            <p class="text-sm text-muted">No meetings yet.</p>
        @endforelse
    </div>

    @unless (auth()->user()->role->isReadOnly())
        {{-- Schedule a video meeting (Google Meet or Zoom) --}}
        <form method="POST" action="{{ $googleRoute }}" class="mb-4 space-y-2">
            @csrf
            <label class="ta-label">Schedule Meeting</label>
            <input type="text" name="title" class="ta-input w-full" placeholder="Meeting title" value="Call with {{ $defaultTitle }}" required>
            <div class="flex gap-2">
                <input type="datetime-local" name="starts_at" class="ta-input w-full" required>
                <input type="number" name="duration" class="ta-input" style="max-width:96px;" value="30" min="15" max="480" title="Minutes">
            </div>
            <textarea name="description" rows="2" class="ta-input w-full" placeholder="Agenda / description (optional) — shown on the calendar / meeting invite"></textarea>
            <div class="flex gap-2">
                <button type="submit" class="btn btn-primary w-full"><i class="fa-brands fa-google"></i> Google Meet</button>
                <button type="submit" formaction="{{ $zoomRoute }}" class="btn w-full text-white" style="background-color:#2D8CFF;"><i class="fa-solid fa-video"></i> Zoom</button>
            </div>
        </form>
    @endunless
</x-card>
