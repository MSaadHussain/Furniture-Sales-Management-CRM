<?php

namespace App\Http\Controllers;

use App\Enums\UserRole;
use App\Models\Lead;
use App\Services\Export\TabularExport;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;

class LeadExportController extends Controller
{
    public function __invoke(Request $request): StreamedResponse
    {
        abort_unless($request->user()->can('export', Lead::class), 403);

        $query = Lead::query()->with('assignee');

        if ($request->user()->hasRole(UserRole::SalesRep)) {
            $query->where('assigned_to', $request->user()->id);
        }

        foreach (['source_channel', 'status', 'priority'] as $filter) {
            if ($value = $request->string($filter)->value()) {
                $query->where($filter, $value);
            }
        }

        $format  = $request->string('format')->value() === 'xlsx' ? 'xlsx' : 'csv';
        $headers = [
            'ID', 'Full Name', 'Email', 'Phone', 'Source', 'Interest',
            'Location', 'Status', 'Priority', 'Score', 'Assigned To',
            'Created At', 'Last Activity',
        ];

        $rows = (function () use ($query) {
            foreach ($query->cursor() as $lead) {
                yield [
                    $lead->id,
                    $lead->full_name,
                    $lead->email,
                    $lead->phone,
                    $lead->source_channel?->label(),
                    $lead->motorsport_interest_type?->label(),
                    $lead->loc_state,
                    $lead->status->label(),
                    $lead->priority->label(),
                    $lead->lead_score,
                    $lead->assignee?->name,
                    $lead->created_at?->toDateTimeString(),
                    $lead->last_activity_at?->toDateTimeString(),
                ];
            }
        })();

        return TabularExport::download('leads_' . now()->format('Y_m_d_His'), $headers, $rows, $format);
    }
}
