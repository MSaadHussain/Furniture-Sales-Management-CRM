<?php

namespace Tests\Feature;

use App\Models\IntegrationSetting;
use App\Models\Lead;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class WebhookIntakeTest extends TestCase
{
    use RefreshDatabase;

    private function secretFor(string $channel): string
    {
        return IntegrationSetting::where('channel', $channel)->value('secret_key')
            ?? IntegrationSetting::create(['channel' => $channel, 'secret_key' => 'test-secret-'.$channel, 'enabled' => true])->secret_key;
    }

    public function test_website_webhook_creates_lead(): void
    {
        $secret = $this->secretFor('website');

        $this->withHeaders(['X-Webhook-Secret' => $secret])
            ->postJson('/api/v1/leads/website', [
                'name' => 'Lewis Hamilton', 'email' => 'lewis@example.com',
                'phone' => '+971501234567', 'message' => 'I want a booking ASAP',
            ])
            ->assertCreated()
            ->assertJson(['success' => true, 'created' => true]);

        $this->assertDatabaseHas('leads', ['email' => 'lewis@example.com']);
    }

    public function test_invalid_secret_rejected(): void
    {
        $this->secretFor('website');

        $this->withHeaders(['X-Webhook-Secret' => 'wrong'])
            ->postJson('/api/v1/leads/website', ['email' => 'x@example.com'])
            ->assertStatus(401);
    }

    public function test_duplicate_email_merges(): void
    {
        $secret = $this->secretFor('website');
        $headers = ['X-Webhook-Secret' => $secret];

        $this->withHeaders($headers)->postJson('/api/v1/leads/website', [
            'name' => 'Max V', 'email' => 'max@example.com', 'phone' => '+971502223333',
        ])->assertCreated();

        $this->withHeaders($headers)->postJson('/api/v1/leads/website', [
            'name' => 'Max V', 'email' => 'max@example.com', 'message' => 'second submission',
        ])->assertOk()->assertJson(['merged' => true]);

        $this->assertSame(1, Lead::where('email', 'max@example.com')->count());
    }

    public function test_missing_contact_returns_422(): void
    {
        $secret = $this->secretFor('website');

        $this->withHeaders(['X-Webhook-Secret' => $secret])
            ->postJson('/api/v1/leads/website', ['name' => 'No Contact'])
            ->assertStatus(422);
    }
}
