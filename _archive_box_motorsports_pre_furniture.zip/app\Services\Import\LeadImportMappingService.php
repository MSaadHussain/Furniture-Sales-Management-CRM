<?php

namespace App\Services\Import;

/**
 * Maps arbitrary file headers onto the canonical lead fields, and applies a
 * confirmed map to turn a raw row into an associative lead-attribute array.
 */
class LeadImportMappingService
{
    /** Canonical lead fields the importer can populate. */
    public const FIELDS = [
        'first_name', 'last_name', 'full_name', 'email', 'phone',
        'company', 'country', 'state', 'city', 'message',
        'motorsport_interest_type', 'status', 'priority', 'notes',
    ];

    /** Header aliases -> canonical field. Lower-cased, non-alphanumeric stripped. */
    private const ALIASES = [
        'firstname' => 'first_name', 'fname' => 'first_name', 'givenname' => 'first_name',
        'lastname' => 'last_name', 'lname' => 'last_name', 'surname' => 'last_name', 'familyname' => 'last_name',
        'fullname' => 'full_name', 'name' => 'full_name', 'contactname' => 'full_name',
        'email' => 'email', 'emailaddress' => 'email', 'mail' => 'email', 'emailid' => 'email',
        'phone' => 'phone', 'phonenumber' => 'phone', 'mobile' => 'phone', 'contactnumber' => 'phone', 'tel' => 'phone', 'cell' => 'phone',
        'company' => 'company', 'organisation' => 'company', 'organization' => 'company', 'business' => 'company',
        'country' => 'country', 'nation' => 'country',
        'state' => 'state', 'province' => 'state', 'region' => 'state',
        'city' => 'city', 'town' => 'city',
        'message' => 'message', 'enquiry' => 'message', 'inquiry' => 'message', 'comments' => 'message', 'comment' => 'message',
        'motorsportinteresttype' => 'motorsport_interest_type', 'interest' => 'motorsport_interest_type',
        'interesttype' => 'motorsport_interest_type', 'category' => 'motorsport_interest_type', 'role' => 'motorsport_interest_type',
        'status' => 'status', 'stage' => 'status', 'leadstatus' => 'status',
        'priority' => 'priority', 'leadpriority' => 'priority',
        'notes' => 'notes', 'note' => 'notes', 'remarks' => 'notes',
    ];

    /**
     * Suggest a header -> field map. Returns [headerIndex => field|null].
     *
     * @param array<int,string> $headers
     * @return array<int, string|null>
     */
    public function suggestMap(array $headers): array
    {
        $map = [];
        foreach ($headers as $i => $header) {
            $map[$i] = self::ALIASES[$this->normalizeHeader($header)] ?? null;
        }
        return $map;
    }

    /**
     * Apply a confirmed map to a single raw row.
     *
     * @param array<int,string|null> $row
     * @param array<int,string|null> $map  headerIndex => field
     * @return array<string,string|null> field => value
     */
    public function applyMap(array $row, array $map): array
    {
        $out = [];
        foreach ($map as $index => $field) {
            if ($field === null || $field === '') {
                continue;
            }
            $value = $row[$index] ?? null;
            // If two columns map to the same field, keep the first non-empty one.
            if (! isset($out[$field]) || ($out[$field] === null && $value !== null)) {
                $out[$field] = is_string($value) && trim($value) === '' ? null : $value;
            }
        }
        return $out;
    }

    private function normalizeHeader(string $header): string
    {
        return preg_replace('/[^a-z0-9]/', '', strtolower(trim($header))) ?? '';
    }
}
