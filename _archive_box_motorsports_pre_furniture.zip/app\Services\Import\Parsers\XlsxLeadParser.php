<?php

namespace App\Services\Import\Parsers;

use App\Contracts\LeadFileParser;
use PhpOffice\PhpSpreadsheet\IOFactory;
use RuntimeException;

/**
 * XLSX / XLS parser built on PhpSpreadsheet (a dependency of Laravel Excel,
 * which the project installs in Phase 2). Reads the first worksheet, treats
 * the first non-empty row as the header, and returns a tabular structure
 * matching CsvLeadParser so the downstream mapping logic is parser-agnostic.
 */
class XlsxLeadParser implements LeadFileParser
{
    public function extensions(): array
    {
        return ['xlsx', 'xls'];
    }

    public function parse(string $absolutePath): array
    {
        if (! is_readable($absolutePath)) {
            throw new RuntimeException('Spreadsheet file is not readable.');
        }

        try {
            $reader = IOFactory::createReaderForFile($absolutePath);
            $reader->setReadDataOnly(true);
            $spreadsheet = $reader->load($absolutePath);
        } catch (\Throwable $e) {
            throw new RuntimeException('Unable to read spreadsheet: ' . $e->getMessage());
        }

        $sheet = $spreadsheet->getActiveSheet();
        $matrix = $sheet->toArray(null, true, true, false); // 0-indexed columns

        // Drop leading fully-empty rows.
        $matrix = array_values(array_filter(
            $matrix,
            fn ($row) => count(array_filter($row, fn ($c) => $c !== null && trim((string) $c) !== '')) > 0
        ));

        if ($matrix === []) {
            throw new RuntimeException('Spreadsheet appears to be empty.');
        }

        $headers = array_map(fn ($h) => trim((string) $h), array_shift($matrix));

        $rows = array_map(
            fn ($row) => array_map(fn ($v) => $v === null ? null : trim((string) $v), $row),
            $matrix
        );

        // Free memory for large files.
        $spreadsheet->disconnectWorksheets();
        unset($spreadsheet);

        return ['headers' => $headers, 'rows' => $rows];
    }
}
