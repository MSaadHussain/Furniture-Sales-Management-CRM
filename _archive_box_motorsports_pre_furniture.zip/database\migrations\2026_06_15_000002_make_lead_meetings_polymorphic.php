<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Converts lead_meetings from a leads-only table to a polymorphic one so the
 * same meeting system can attach to Leads, Driver Leads and Sponsor Profiles.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('lead_meetings', function (Blueprint $table) {
            $table->nullableMorphs('meetable'); // meetable_type + meetable_id (+ index)
        });

        // Backfill existing rows — they were all attached to leads.
        DB::table('lead_meetings')
            ->whereNotNull('lead_id')
            ->update([
                'meetable_type' => \App\Models\Lead::class,
                'meetable_id'   => DB::raw('lead_id'),
            ]);

        Schema::table('lead_meetings', function (Blueprint $table) {
            $table->dropForeign(['lead_id']);
            $table->dropColumn('lead_id');
        });
    }

    public function down(): void
    {
        Schema::table('lead_meetings', function (Blueprint $table) {
            $table->foreignId('lead_id')->nullable()->after('id')->constrained('leads')->cascadeOnDelete();
        });

        DB::table('lead_meetings')
            ->where('meetable_type', \App\Models\Lead::class)
            ->update(['lead_id' => DB::raw('meetable_id')]);

        Schema::table('lead_meetings', function (Blueprint $table) {
            $table->dropMorphs('meetable');
        });
    }
};
