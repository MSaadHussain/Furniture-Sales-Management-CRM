<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('email_notification_logs', function (Blueprint $table) {
            $table->id();
            $table->string('type')->index();             // new_lead | weekly_report | meeting | ...
            $table->string('recipient');                  // email address
            $table->foreignId('lead_id')->nullable()->constrained('leads')->nullOnDelete();
            $table->string('subject')->nullable();
            $table->string('status')->default('sent')->index(); // sent | failed
            $table->text('error')->nullable();
            $table->timestamps();

            $table->index(['type', 'created_at']);
        });

        Schema::create('weekly_report_logs', function (Blueprint $table) {
            $table->id();
            $table->date('period_start');
            $table->date('period_end');
            $table->unsignedInteger('new_leads')->default(0);
            $table->unsignedInteger('updated_leads')->default(0);
            $table->unsignedInteger('duplicate_leads')->default(0);
            $table->json('recipients')->nullable();
            $table->string('status')->default('sent');    // sent | failed | skipped
            $table->text('error')->nullable();
            $table->timestamps();
        });

        Schema::create('report_settings', function (Blueprint $table) {
            $table->id();
            $table->string('key')->unique();
            $table->json('value')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('email_notification_logs');
        Schema::dropIfExists('weekly_report_logs');
        Schema::dropIfExists('report_settings');
    }
};
