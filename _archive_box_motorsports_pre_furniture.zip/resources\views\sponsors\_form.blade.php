@csrf
<div class="grid grid-cols-1 gap-5 sm:grid-cols-2">
    <div>
        <label class="ta-label">Company Name <span class="text-danger">*</span></label>
        <input name="company_name" value="{{ old('company_name', $sponsor->company_name ?? '') }}" required class="ta-input w-full">
        @error('company_name')<p class="mt-1 text-xs text-danger">{{ $message }}</p>@enderror
    </div>
    <div>
        <label class="ta-label">Contact Person</label>
        <input name="contact_name" value="{{ old('contact_name', $sponsor->contact_name ?? '') }}" class="ta-input w-full">
    </div>
    <div>
        <label class="ta-label">Email <span class="text-danger">*</span></label>
        <input type="email" name="email" value="{{ old('email', $sponsor->email ?? '') }}" required class="ta-input w-full">
        @error('email')<p class="mt-1 text-xs text-danger">{{ $message }}</p>@enderror
    </div>
    <div>
        <label class="ta-label">Phone <span class="text-danger">*</span></label>
        <input name="phone" value="{{ old('phone', $sponsor->phone ?? '') }}" required class="ta-input w-full">
        @error('phone')<p class="mt-1 text-xs text-danger">{{ $message }}</p>@enderror
    </div>
    <div>
        <label class="ta-label">Website</label>
        <input name="website" value="{{ old('website', $sponsor->website ?? '') }}" class="ta-input w-full" placeholder="example.com">
    </div>
    <div>
        <label class="ta-label">Industry</label>
        <input name="industry" value="{{ old('industry', $sponsor->industry ?? '') }}" class="ta-input w-full" placeholder="Automotive, finance, energy drink...">
    </div>
    <div>
        <label class="ta-label">Company Type <span class="text-danger">*</span></label>
        <select name="company_type" required class="ta-input w-full">
            @foreach ($types as $t)
                <option value="{{ $t['value'] }}" @selected(old('company_type', isset($sponsor) ? $sponsor->company_type->value : 'sponsor')===$t['value'])>{{ $t['label'] }}</option>
            @endforeach
        </select>
    </div>
    <div>
        <label class="ta-label">Status <span class="text-danger">*</span></label>
        <select name="status" required class="ta-input w-full">
            @foreach ($statuses as $s)
                <option value="{{ $s['value'] }}" @selected(old('status', isset($sponsor) ? $sponsor->status->value : 'prospect')===$s['value'])>{{ $s['label'] }}</option>
            @endforeach
        </select>
    </div>
    <div>
        <label class="ta-label">Country</label>
        <input name="country" value="{{ old('country', $sponsor->country ?? '') }}" class="ta-input w-full">
    </div>
    <div class="grid grid-cols-2 gap-4">
        <div>
            <label class="ta-label">State</label>
            <input name="state" value="{{ old('state', $sponsor->state ?? '') }}" class="ta-input w-full">
        </div>
        <div>
            <label class="ta-label">City</label>
            <input name="city" value="{{ old('city', $sponsor->city ?? '') }}" class="ta-input w-full">
        </div>
    </div>
    <div>
        <label class="ta-label">Estimated Budget ($)</label>
        <input type="number" step="0.01" min="0" name="estimated_budget" value="{{ old('estimated_budget', $sponsor->estimated_budget ?? '') }}" class="ta-input w-full">
    </div>
    <div>
        <label class="ta-label">Assigned To</label>
        <select name="assigned_to" class="ta-input w-full">
            <option value="">Unassigned</option>
            @foreach ($users as $u)
                <option value="{{ $u->id }}" @selected(old('assigned_to', $sponsor->assigned_to ?? '')==$u->id)>{{ $u->name }}</option>
            @endforeach
        </select>
    </div>
    <div class="sm:col-span-2">
        <label class="ta-label">Internal Notes</label>
        <textarea name="notes" rows="4" class="ta-input w-full">{{ old('notes', $sponsor->notes ?? '') }}</textarea>
    </div>
</div>
