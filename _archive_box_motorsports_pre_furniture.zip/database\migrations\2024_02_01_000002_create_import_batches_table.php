<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('import_batches', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('file_name');
            $table->string('file_path')->nullable();      // stored temp path for re-processing
            $table->string('file_type', 10);              // csv | xlsx | pdf
            $table->string('source_channel');             // imported_csv | imported_xlsx | imported_pdf
            $table->unsignedInteger('total_rows')->default(0);
            $table->unsignedInteger('successful_rows')->default(0);
            $table->unsignedInteger('failed_rows')->default(0);
            $table->unsignedInteger('duplicate_rows')->default(0);
            $table->string('status')->default('pending')->index(); // pending|previewing|processing|completed|failed
            $table->json('column_map')->nullable();       // user-confirmed header -> field map
            $table->string('duplicate_strategy')->default('skip'); // skip|merge|update
            $table->text('error_log')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('import_batches');
    }
};
