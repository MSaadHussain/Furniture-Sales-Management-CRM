<?php

namespace Tests\Feature;

use App\Models\Lead;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ReportTest extends TestCase
{
    use RefreshDatabase;

    public function test_manager_sees_reports_with_range(): void
    {
        $manager = User::factory()->create(['role' => 'sales_manager']);
        Lead::factory(5)->create(['status' => 'closed_won', 'created_at' => now()]);
        Lead::factory(3)->create(['status' => 'closed_lost', 'created_at' => now()]);

        $this->actingAs($manager)->get('/reports?range=last_7')
            ->assertOk()->assertSee('Conversion');
    }

    public function test_report_csv_export(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        Lead::factory(3)->create(['priority' => 'hot', 'created_at' => now()]);

        $this->actingAs($admin)->get('/reports/export?range=last_30&type=hot')
            ->assertOk()->assertHeader('content-type', 'text/csv; charset=UTF-8');
    }
}
