<?php

namespace App\Services\Import;

use App\Contracts\LeadFileParser;
use App\Services\Import\Parsers\CsvLeadParser;
use App\Services\Import\Parsers\PdfLeadParser;
use App\Services\Import\Parsers\XlsxLeadParser;
use InvalidArgumentException;

/**
 * Resolves the correct parser for a given file extension and returns the
 * tabular {headers, rows} structure. Parser-agnostic by design.
 */
class LeadFileParserService
{
    /** @var array<int, LeadFileParser> */
    private array $parsers;

    public function __construct(
        CsvLeadParser $csv,
        XlsxLeadParser $xlsx,
        PdfLeadParser $pdf,
    ) {
        $this->parsers = [$csv, $xlsx, $pdf];
    }

    public function parse(string $absolutePath, string $extension): array
    {
        return $this->parserFor($extension)->parse($absolutePath);
    }

    public function parserFor(string $extension): LeadFileParser
    {
        $extension = strtolower($extension);
        foreach ($this->parsers as $parser) {
            if (in_array($extension, $parser->extensions(), true)) {
                return $parser;
            }
        }
        throw new InvalidArgumentException("No parser available for .{$extension} files.");
    }

    /** Map a file extension to its import SourceChannel value. */
    public function channelFor(string $extension): string
    {
        return match (strtolower($extension)) {
            'xlsx', 'xls'        => 'imported_xlsx',
            'pdf'                => 'imported_pdf',
            default              => 'imported_csv', // csv, txt, tsv
        };
    }

    public function fileTypeFor(string $extension): string
    {
        return match (strtolower($extension)) {
            'xlsx', 'xls' => 'xlsx',
            'pdf'         => 'pdf',
            default       => 'csv',
        };
    }
}
