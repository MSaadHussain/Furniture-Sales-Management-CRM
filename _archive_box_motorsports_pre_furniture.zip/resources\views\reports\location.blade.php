@extends('layouts.app')
@section('title', 'Location Report')
@section('breadcrumb')
    <a href="{{ route('reports.index') }}" class="hover:text-brand">Reports</a> / <span>Location</span>
@endsection

@section('content')
    {{-- Map + top countries (reuses the dashboard component, full width) --}}
    <x-location-map
        :presets="$presets"
        :sources="$sources"
        :compact="false"
        :initial-range="$filters['range']"
        :initial-source="$filters['source']" />

    {{-- Detailed country breakdown table (server-rendered for the current filters) --}}
    <x-card class="mt-6" padding="p-0">
        <div class="flex items-center justify-between border-b border-line px-6 py-4 dark:border-strokedark">
            <div>
                <h3 class="text-lg font-semibold text-ink dark:text-white">Country Breakdown</h3>
                <p class="text-sm text-muted">{{ number_format($total) }} leads · {{ $rangeLabel }}</p>
            </div>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="border-b border-line dark:border-strokedark">
                    <tr>
                        <th class="ta-th">Country</th>
                        <th class="ta-th">Leads</th>
                        <th class="ta-th">Share</th>
                        <th class="ta-th w-1/3">Distribution</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-line dark:divide-strokedark">
                    @forelse ($countries as $c)
                        <tr>
                            <td class="ta-td font-medium">
                                @if ($c['code'])
                                    <span class="mr-2">{{ \App\Support\Flag::emoji($c['code']) }}</span>
                                @endif
                                {{ $c['name'] }}
                            </td>
                            <td class="ta-td">{{ number_format($c['total']) }}</td>
                            <td class="ta-td">{{ $c['percentage'] }}%</td>
                            <td class="ta-td">
                                <div class="h-2 w-full overflow-hidden rounded-full bg-line dark:bg-strokedark">
                                    <div class="h-full rounded-full bg-brand" style="width: {{ $c['percentage'] }}%"></div>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="4" class="ta-td py-8 text-center text-muted">No location data for this period.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </x-card>
@endsection
