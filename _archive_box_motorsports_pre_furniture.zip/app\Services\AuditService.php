<?php

namespace App\Services;

use App\Models\AuditLog;
use App\Models\UserActivityLog;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Request;

class AuditService
{
    public function log(string $action, ?object $auditable = null, ?string $description = null): AuditLog
    {
        $log = AuditLog::create([
            'user_id'        => Auth::id(),
            'action'         => $action,
            'auditable_type' => $auditable ? get_class($auditable) : null,
            'auditable_id'   => $auditable?->getKey(),
            'description'    => $description,
            'ip_address'     => Request::ip(),
        ]);

        // Phase 4: mirror into the user activity log so Super Admin reports
        // capture every tracked action. Never let this break the main flow.
        try {
            UserActivityLog::create([
                'user_id'     => Auth::id(),
                'action'      => $action,
                'description' => $description,
                'model_type'  => $auditable ? get_class($auditable) : null,
                'model_id'    => $auditable?->getKey(),
                'route_name'  => optional(Request::route())->getName(),
                'url'         => substr((string) Request::fullUrl(), 0, 500),
                'method'      => Request::method(),
                'ip_address'  => Request::ip(),
                'user_agent'  => substr((string) Request::userAgent(), 0, 500),
                'created_at'  => now(),
            ]);
        } catch (\Throwable $e) {
            // activity-log table may not exist yet (pre-migration) — ignore.
        }

        return $log;
    }
}
