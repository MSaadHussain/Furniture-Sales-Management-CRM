<?php

namespace App\Enums;

enum SponsorLinkStatus: string
{
    case Proposed = 'proposed';
    case Active = 'active';
    case Completed = 'completed';
    case Cancelled = 'cancelled';

    public function label(): string
    {
        return match ($this) {
            self::Proposed  => 'Proposed',
            self::Active    => 'Active',
            self::Completed => 'Completed',
            self::Cancelled => 'Cancelled',
        };
    }

    public function color(): string
    {
        return match ($this) {
            self::Proposed  => '#F59E0B',
            self::Active    => '#16A34A',
            self::Completed => '#2563EB',
            self::Cancelled => '#DC2626',
        };
    }

    public static function options(): array
    {
        return array_map(
            fn (self $s) => ['value' => $s->value, 'label' => $s->label(), 'color' => $s->color()],
            self::cases()
        );
    }
}
