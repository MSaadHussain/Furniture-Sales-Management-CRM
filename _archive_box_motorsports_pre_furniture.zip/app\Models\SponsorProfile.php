<?php

namespace App\Models;

use App\Enums\SponsorProfileType;
use App\Enums\SponsorStatus;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class SponsorProfile extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'company_name', 'contact_name', 'email', 'phone', 'website',
        'company_type', 'industry', 'country', 'state', 'city',
        'estimated_budget', 'status', 'assigned_to', 'notes',
    ];

    protected function casts(): array
    {
        return [
            'company_type'     => SponsorProfileType::class,
            'status'           => SponsorStatus::class,
            'estimated_budget' => 'decimal:2',
        ];
    }

    protected static function booted(): void
    {
        // Cascade: deleting a sponsor removes its deals from the pipeline,
        // unlinks funded drivers, and clears its activity log.
        static::deleting(function (SponsorProfile $sponsor) {
            if ($sponsor->isForceDeleting()) {
                return; // DB foreign keys cascade on hard delete
            }

            $sponsor->deals()->delete();           // soft-delete deals (off the Kanban)
            $sponsor->driverLinks()->delete();      // unlink funded drivers
            $sponsor->activities()->delete();       // remove activity log
        });
    }

    public function deals()
    {
        return $this->hasMany(SponsorshipDeal::class)->latest();
    }

    public function activities()
    {
        return $this->hasMany(SponsorActivity::class)->latest();
    }

    public function meetings()
    {
        return $this->morphMany(LeadMeeting::class, 'meetable')->latest('starts_at');
    }

    public function driverLinks()
    {
        return $this->hasMany(SponsorDriverLink::class)->latest();
    }

    public function drivers()
    {
        return $this->belongsToMany(DriverLead::class, 'sponsor_driver_links')
            ->withPivot(['funding_amount', 'funding_type', 'season_or_event', 'status', 'start_date', 'end_date'])
            ->withTimestamps();
    }

    public function assignee()
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    public function getWebsiteUrlAttribute(): ?string
    {
        if (! $this->website) {
            return null;
        }

        return str_starts_with($this->website, 'http') ? $this->website : "https://{$this->website}";
    }

    /** Sum of open (not closed) deal values. */
    public function getOpenPipelineValueAttribute(): float
    {
        return (float) $this->deals
            ->whereNotIn('stage', [\App\Enums\SponsorshipStage::ClosedWon, \App\Enums\SponsorshipStage::ClosedLost])
            ->sum('deal_value');
    }
}
