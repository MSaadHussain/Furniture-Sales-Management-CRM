<?php

namespace Tests\Unit;

use App\Services\Import\LeadImportMappingService;
use App\Services\Import\Parsers\CsvLeadParser;
use PHPUnit\Framework\TestCase;

class LeadImportParsingTest extends TestCase
{
    private function makeCsv(string $contents): string
    {
        $path = tempnam(sys_get_temp_dir(), 'imp') . '.csv';
        file_put_contents($path, $contents);
        return $path;
    }

    public function test_csv_parser_reads_headers_and_rows(): void
    {
        $path = $this->makeCsv("First Name,Email,Phone\nLewis,lewis@example.com,+44 7700 900123\nMax,max@example.com,+31 612345678\n");

        $parsed = (new CsvLeadParser())->parse($path);

        $this->assertSame(['First Name', 'Email', 'Phone'], $parsed['headers']);
        $this->assertCount(2, $parsed['rows']);
        $this->assertSame('lewis@example.com', $parsed['rows'][0][1]);

        unlink($path);
    }

    public function test_csv_parser_detects_semicolon_delimiter(): void
    {
        $path = $this->makeCsv("name;email\nLando;lando@example.com\n");

        $parsed = (new CsvLeadParser())->parse($path);

        $this->assertSame(['name', 'email'], $parsed['headers']);
        $this->assertSame('Lando', $parsed['rows'][0][0]);

        unlink($path);
    }

    public function test_csv_parser_strips_utf8_bom(): void
    {
        $path = $this->makeCsv("\xEF\xBB\xBFEmail\na@example.com\n");

        $parsed = (new CsvLeadParser())->parse($path);

        $this->assertSame(['Email'], $parsed['headers']);

        unlink($path);
    }

    public function test_mapper_auto_detects_common_headers(): void
    {
        $mapper = new LeadImportMappingService();
        $map = $mapper->suggestMap(['First Name', 'Email Address', 'Mobile', 'Interest', 'Unknown Col']);

        $this->assertSame('first_name', $map[0]);
        $this->assertSame('email', $map[1]);
        $this->assertSame('phone', $map[2]);
        $this->assertSame('motorsport_interest_type', $map[3]);
        $this->assertNull($map[4]);
    }

    public function test_mapper_applies_map_to_row(): void
    {
        $mapper = new LeadImportMappingService();
        $map = [0 => 'first_name', 1 => 'email', 2 => null];
        $out = $mapper->applyMap(['Lewis', 'lewis@example.com', 'ignored'], $map);

        $this->assertSame(['first_name' => 'Lewis', 'email' => 'lewis@example.com'], $out);
    }
}
