<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserCreationOtp extends Model
{
    protected $fillable = [
        'requested_by', 'target_user_payload', 'otp_hash', 'sent_to_email',
        'expires_at', 'verified_at', 'attempts', 'resent_count',
    ];

    protected function casts(): array
    {
        return [
            'target_user_payload' => 'encrypted:array',
            'expires_at'          => 'datetime',
            'verified_at'         => 'datetime',
        ];
    }

    public function isExpired(): bool
    {
        return $this->expires_at->isPast();
    }

    public function isVerified(): bool
    {
        return $this->verified_at !== null;
    }
}
