<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('leads', function (Blueprint $table) {
            $table->id();
            $table->string('first_name')->nullable();
            $table->string('last_name')->nullable();
            $table->string('full_name')->nullable();
            $table->string('email')->nullable()->index();
            $table->string('phone')->nullable();
            $table->string('normalized_phone')->nullable()->index();
            $table->string('loc_state')->nullable();
            $table->string('ip_address', 45)->nullable();
            $table->string('source_channel')->default('manual')->index();
            $table->string('status')->default('new')->index();
            $table->string('priority')->default('medium')->index();
            $table->unsignedInteger('lead_score')->default(0);
            $table->string('motorsport_interest_type')->nullable();
            $table->text('motorsport_notes')->nullable();
            $table->text('message')->nullable();
            $table->json('tags')->nullable();
            $table->foreignId('assigned_to')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('last_activity_at')->nullable();
            $table->softDeletes();
            $table->timestamps();

            $table->index(['status', 'priority']);
            $table->index('created_at');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('leads');
    }
};
