# Box Motorsports CRM — Project Reference

Laravel 12 inbound lead management CRM for Box Motorsports.
PHP 8.2+ · MySQL · Blade + Alpine.js · Tailwind CSS 3 · Vite · Laravel Breeze.

## Quick Commands

```bash
composer install
php artisan migrate:fresh --seed   # full reset with sample data
php artisan migrate                # incremental
npm install && npm run build       # frontend assets
php artisan serve                  # http://localhost:8000
php artisan queue:work             # background jobs (emails, notifications)
php artisan test                   # run test suite
```

## Test Accounts

| Role          | Email                          | Password |
|---------------|--------------------------------|----------|
| Super Admin   | superadmin@boxmotorsports.test | password |
| Admin         | admin@boxmotorsports.test      | password |
| Sales Manager | manager@boxmotorsports.test    | password |
| Sales Rep     | rep@boxmotorsports.test        | password |
| Viewer        | viewer@boxmotorsports.test     | password |

## Roles (app/Enums/UserRole.php)

- **Super Admin** — full access, user management, settings, security, activity logs
- **Admin** — same as Super Admin except some security restrictions
- **Sales Manager** — leads, pipeline, reports, meetings (all leads)
- **Sales Rep** — own assigned leads only
- **Viewer** — read-only access

---

## Architecture Overview

### Route Files

- `routes/web.php` — all authenticated web routes (~70 routes)
- `routes/api.php` — webhook endpoints for lead intake + ad platforms + driver leads
- `routes/auth.php` — Laravel Breeze authentication routes

### Middleware (app/Http/Middleware/)

| Middleware             | Alias            | Purpose                                |
|------------------------|------------------|----------------------------------------|
| VerifyWebhookSecret    | webhook.secret   | Validates shared secret or HMAC on API |
| TrackUserActivity      | track.activity   | Logs page views and session tracking   |
| ConfirmPasswordEvery24h| password.24h     | Forces re-auth every 24 hours          |
| EnsureUserRole         | role             | Gate-checks user role level             |

---

## Module: Leads (General CRM Leads)

The core lead management system — captures inbound leads from multiple channels into a unified pipeline.

### Database Tables

| Table                | Migration File                                                | Purpose                          |
|----------------------|---------------------------------------------------------------|----------------------------------|
| leads                | 2024_01_01_000002_create_leads_table.php                      | Main leads table (soft deletes)  |
| lead_interactions    | 2024_01_01_000003_create_lead_interactions_table.php          | Activity timeline per lead       |
| lead_notes           | 2024_01_01_000004_create_lead_notes_table.php                 | Notes, call logs, meeting notes  |
| lead_assignments     | 2024_01_01_000005_create_lead_assignments_table.php           | Assignment history               |
| lead_raw_payloads    | 2024_01_01_000006_create_lead_raw_payloads_table.php          | Raw webhook payloads stored      |
| lead_meetings        | 2024_04_01_000001_create_lead_meetings_table.php              | Google Meet / Calendly meetings  |

### Models (app/Models/)

| Model            | Key Relationships                                    |
|------------------|------------------------------------------------------|
| Lead             | interactions, notes, assignments, rawPayloads, meetings, assignee, creator |
| LeadInteraction  | lead, performer (User)                               |
| LeadNote         | lead, user                                           |
| LeadAssignment   | lead, user                                           |
| LeadRawPayload   | lead                                                 |
| LeadMeeting      | lead                                                 |

### Enums (app/Enums/)

| Enum               | Values                                                                    |
|--------------------|---------------------------------------------------------------------------|
| LeadStatus         | new, contacted, under_review, meeting_scheduled, closed_won, closed_lost  |
| LeadPriority       | low, medium, high, hot                                                    |
| SourceChannel      | jotform, google_form, website, whatsapp, email, manual, meta, google_lead_form, imported_csv, imported_xlsx, imported_pdf |
| MotorsportInterest | (various motorsport types)                                                |
| InteractionType    | (note, call, email, status_change, etc.)                                  |

### Controllers

| Controller                | Route Prefix    | Key Actions                                    |
|---------------------------|-----------------|------------------------------------------------|
| LeadController            | /leads          | CRUD, updateStatus, assign, markHot, trash, restore, forceDelete |
| LeadNoteController        | /leads/{id}/notes | store                                        |
| LeadBulkController        | /leads/bulk     | bulk update                                    |
| LeadExportController      | /leads/export   | CSV export                                     |
| LeadImportController      | /leads/import   | upload, preview, confirm, batches              |
| PipelineController        | /pipeline       | drag-and-drop pipeline board                   |

### Views (resources/views/)

| Directory       | Templates                                         |
|-----------------|---------------------------------------------------|
| leads/          | index, show, create, edit, _form, trash           |
| leads/import/   | index, preview, show, batches, _status            |
| pipeline/       | index (drag-and-drop Kanban)                      |

### Services (app/Services/)

| Service                   | Purpose                                      |
|---------------------------|----------------------------------------------|
| LeadIntakeService         | Unified ingestion from all webhook channels  |
| LeadScoringService        | Auto-score leads (keyword + interest + channel) |
| LeadDeduplicationService  | Merge by email/phone (country-code tolerant) |
| LeadInteractionService    | Log interactions on leads                    |
| LeadNotificationService   | In-app + Slack/Discord notifications         |
| LeadLocationService       | Geographic aggregation for location map      |
| AuditService              | Audit log entries                            |
| WebhookSecurityService    | Shared secret + HMAC verification            |
| WhatsAppWebhookService    | Parse WhatsApp payloads                      |
| EmailParsingService       | Parse inbound email payloads                 |
| DateRangeService          | Date preset helpers for filters              |
| ActivityTrackingService   | User page-view and session tracking          |

### Lead Import (app/Services/Import/)

| Service/Parser             | Purpose                           |
|----------------------------|-----------------------------------|
| LeadImportService          | Orchestrates import flow          |
| LeadImportValidationService| Validates import rows             |
| LeadImportMappingService   | Column mapping                    |
| LeadFileParserService      | Delegates to format-specific parsers |
| CsvLeadParser              | CSV file parsing                  |
| XlsxLeadParser             | Excel file parsing (PhpSpreadsheet) |
| PdfLeadParser              | PDF file parsing (smalot/pdfparser) |

---

## Module: Driver Leads

Separate lead pipeline for racing drivers seeking sponsorship. Not mixed with general CRM leads.

### Database Tables

| Table                    | Migration File                                                    | Purpose                          |
|--------------------------|-------------------------------------------------------------------|----------------------------------|
| driver_leads             | 2026_06_11_000001_create_driver_leads_table.php                   | Main driver leads (soft deletes) |
| driver_leads_activity    | 2026_06_11_000002_create_driver_leads_activity_table.php          | Activity log per driver lead     |
| driver_leads_comments    | 2026_06_11_000003_create_driver_leads_comments_table.php          | Team discussion comments         |
| driver_lead_tier_history | 2026_06_11_000004_create_driver_lead_tier_history_table.php       | Tier change audit trail          |

### driver_leads columns

- Contact: first_name, last_name, email, phone, country, dob
- Racing: years_racing, highest_series, racing_level, car_type, career_wins, current_team_series
- Social: instagram_handle, instagram_followers
- Status: seeking_sponsorship (bool), contract_interest_type, inferred_tier (enum), status (enum)

`age` and `age_group` are computed accessors from `dob` (not stored columns). Age groups: Under 12, 12–15, 16–18, 19–25, 26–35, 36+. SQL filtering uses `TIMESTAMPDIFF(YEAR, dob, CURDATE())`.

**IMPORTANT RULE: Racing Level and Car Type are independent manual fields. Car Type is NEVER auto-derived from Racing Level — not in forms, not in the webhook, not anywhere.**

### Models (app/Models/)

| Model                 | Table                    | Relationships                 |
|-----------------------|--------------------------|-------------------------------|
| DriverLead            | driver_leads             | activities, comments, tierHistory |
| DriverLeadActivity    | driver_leads_activity    | driverLead, user              |
| DriverLeadComment     | driver_leads_comments    | driverLead, user              |
| DriverLeadTierHistory | driver_lead_tier_history | driverLead, user              |

### Enums

| Enum              | File                          | Values                              |
|-------------------|-------------------------------|-------------------------------------|
| DriverLeadStatus  | app/Enums/DriverLeadStatus.php | new, qualified, declined, contacted |
| DriverTier        | app/Enums/DriverTier.php       | development, amateur, pro_am, professional, elite |
| DriverRacingLevel | app/Enums/DriverRacingLevel.php | karting, formula_4, formula_3, formula_2, formula_1, gt_racing, touring_car, prototype, stock_car, sim_racing, other |
| CarType           | app/Enums/CarType.php          | kart, formula_car, gt_car, touring_car, prototype, stock_car, sim_racing, other |

### Auto-Tier Logic

Five tiers: `development`, `amateur`, `pro_am`, `professional`, `elite` (DriverTier enum).

`DriverTier::inferFromDriver(DriverLead)` — primary inference, used by `DriverLead::recomputeTier()`:

```
Formula 1                       → Elite
Formula 2                       → Professional
Formula 3 (5+ wins)             → Pro-Am, else Development
Formula 4 (10+ wins)            → Pro-Am, else Development
Karting + under 16              → Development
Karting (16+)                   → Amateur
No racing level: 8y AND 50+ wins → Elite, else legacy infer()
```

`DriverTier::infer(years, wins)` — legacy shim (Professional 5y/20w, Pro-Am 3y/5w, else Amateur), still used by CSV import. Car type is never an input to tier. Changes are logged in `driver_lead_tier_history`.

### Driver Contracts

| Item | Details |
|------|---------|
| Table | `driver_contracts` (2026_06_12_000002) — FKs to driver_leads (cascade), sponsor_profiles + sponsorship_deals (nullOnDelete), soft deletes, created_by/updated_by |
| Model | `DriverContract` — relations: driverLead, sponsor, deal, creator, updater |
| Enums | `DriverContractType` (sponsorship/team_seat/driver_management/track_time/coaching/vendor_support/media_package/other, each with icon()), `DriverContractStatus` (draft/sent/under_review/signed/active/expired/cancelled) |
| Controller | `DriverContractController` — store, update, changeStatus (auto-sets signed_date on Signed), destroy |
| Routes | `POST driver-leads/{driverLead}/contracts`, `PATCH/DELETE driver-contracts/{contract}`, `PATCH driver-contracts/{contract}/status` |
| Documents | Uploaded to `storage/app/public/driver-contracts` (pdf/doc/docx/jpg/png, 10MB) |
| DriverLead relations | `contracts()`, `activeContract()` (ofMany with active filter), `latestContract()` |
| Activity log | contract_created / contract_updated / contract_status_changed / contract_deleted / racing_profile_updated in driver_leads_activity; sponsor-linked contracts also log to sponsor_activities |
| UI | driver-leads/show.blade.php: Contracts card (overview of active/latest contract, collapsible new-contract form, history table with inline status dropdown + document link + delete); Racing Profile editor (DOB, Racing Level, Car Type, Interested Contract Type — all manual) |
| Filters | driver-leads index: status, tier, racing_level, car_type, age_group, seeking sponsorship, contract (has active / none) |
| Reports | reports/drivers: contract KPI cards (active/expired/no-active/sponsor-linked) + Drivers by Racing Level / Car Type / Age Group. reports/sponsors (SponsorReportController): period KPIs (new sponsors/deals, won value, lost), live KPIs (open/weighted pipeline, contract-pending value, driver funding), stage funnel with value bars, sponsors by type/status, funding by type, top-10 sponsors by open pipeline, pending follow-ups (overdue highlighting), team activity mix, 6-month trend, CSV export |
| Sheets sync | driverLeadRow() includes DOB, Age Group, Racing Level, Car Type, Contract Interest |

### Controllers

| Controller                   | Route Prefix              | Actions                                        |
|------------------------------|---------------------------|-------------------------------------------------|
| DriverLeadController         | /driver-leads             | index, show, updateStatus, qualify, decline, comment, regenerateSecret |
| DriverLeadWebhookController  | /api/v1/driver-leads      | receive (create-or-update by email, auto-tier)  |

### Web Routes (under auth middleware)

| Method | URI                                   | Name                              |
|--------|---------------------------------------|-----------------------------------|
| GET    | /driver-leads                         | driver-leads.index                |
| GET    | /driver-leads/create                  | driver-leads.create (manual add)  |
| POST   | /driver-leads                         | driver-leads.store                |
| GET    | /driver-leads/{driverLead}            | driver-leads.show                 |
| PATCH  | /driver-leads/{driverLead}/status     | driver-leads.status               |
| PATCH  | /driver-leads/{driverLead}/qualify    | driver-leads.qualify              |
| PATCH  | /driver-leads/{driverLead}/decline    | driver-leads.decline              |
| POST   | /driver-leads/{driverLead}/comments   | driver-leads.comments.store       |
| POST   | /driver-leads/webhook/regenerate      | driver-leads.webhook.regenerate   |

### API Routes

| Method | URI                              | Auth                    | Purpose                     |
|--------|----------------------------------|-------------------------|-----------------------------|
| POST   | /api/v1/driver-leads/webhook     | webhook.secret:driver_leads | Receive driver lead from Google Form |

### Webhook Integration

- Secret stored in `integration_settings` table, channel = `driver_leads`
- Auto-created on first visit to Driver Leads index page
- Webhook URL + secret displayed on the Driver Leads index page (admin only)
- Pre-filled Google Apps Script available with copy button
- Secret can be regenerated from the UI

### Google Apps Script

File: `google_apps_script_driver_leads.js`

Maps 16 Google Form questions to webhook fields **by question title** (order doesn't matter — `pick()` matches titles case-insensitively with a contains fallback):

1. First Name → first_name
2. Last Name → last_name
3. Email → email
4. Phone → phone
5. Country → country
6. DOB → dob
7. Years Racing → years_racing
8. Highest Series → highest_series
9. Racing Level → racing_level (label normalized to enum; unknown values become null)
10. Car Type → car_type (independent of Racing Level — never auto-derived)
11. Career Wins → career_wins
12. Current Team / Series → current_team_series
13. Instagram Handle → instagram_handle
14. Instagram Followers → instagram_followers
15. Seeking Sponsorship → seeking_sponsorship
16. Interested Contract Type → contract_interest_type

### Views

| File                                  | Purpose                                    |
|---------------------------------------|--------------------------------------------|
| resources/views/driver-leads/index.blade.php | List with filters (status, tier, search), webhook info card, 15/page |
| resources/views/driver-leads/show.blade.php  | Detail: contact/racing/social info, qualify/decline, comments, activity log, tier history |

### Sidebar

Driver Leads appears in the sidebar (helmet icon) below the Leads section, above Pipeline. Uses `Route::has('driver-leads.index')` guard.

---

## Module: Vendor & Sponsor Space

Commercial engine for sponsors, vendors, tracks, and racing asset providers. Sits beside Leads and Driver Leads; cross-links to Driver Leads via a pivot table.

### Database Tables

| Table                | Migration File                                              | Purpose                              |
|----------------------|-------------------------------------------------------------|--------------------------------------|
| sponsor_profiles     | 2026_06_11_000005_create_sponsor_profiles_table.php         | Company/partner profiles (soft deletes) |
| sponsorship_deals    | 2026_06_11_000006_create_sponsorship_deals_table.php        | Deals powering the Kanban pipeline (soft deletes) |
| sponsor_activities   | 2026_06_11_000007_create_sponsor_activities_table.php       | Vendor action tracking (pitch decks, contracts, payments) |
| sponsor_driver_links | 2026_06_11_000008_create_sponsor_driver_links_table.php     | Sponsor ↔ Driver funding pivot       |

### Models (app/Models/)

| Model             | Key Relationships                                              |
|-------------------|----------------------------------------------------------------|
| SponsorProfile    | deals, activities, driverLinks, drivers (belongsToMany), assignee |
| SponsorshipDeal   | sponsor, activities, driverLinks, assignee; `weighted_value` accessor |
| SponsorActivity   | sponsor, deal, driverLead, performer                            |
| SponsorDriverLink | sponsor, driverLead, deal                                       |

DriverLead extended with: `sponsorLinks()`, `sponsors()`, `fundedDeals()`.

### Enums

| Enum               | Values                                                                          |
|--------------------|----------------------------------------------------------------------------------|
| SponsorProfileType | sponsor, vendor, track_partner, racing_asset_provider, media_partner            |
| SponsorStatus      | prospect, active, inactive                                                       |
| SponsorshipStage   | lead_identified, proposal_sent, negotiation, contract_pending, closed_won, closed_lost |
| SponsorActionType  | pitch_deck_sent, proposal_sent, follow_up_call, track_time_reserved, logo_assets_received, contract_sent, contract_signed, invoice_sent, payment_received, driver_linked, meeting_scheduled, stage_changed, note |
| FundingType        | cash, track_time, equipment, vehicle, event_fee, media_package, other           |
| SponsorLinkStatus  | proposed, active, completed, cancelled                                           |

`SponsorActionType::manualCases()` excludes system-generated `stage_changed`. Each action type has an `icon()`.

### Controllers

| Controller                   | Route Prefix          | Actions                                          |
|------------------------------|-----------------------|---------------------------------------------------|
| SponsorProfileController     | /sponsors             | resource CRUD (index, create, store, show, edit, update, destroy) |
| SponsorshipPipelineController| /sponsorship-pipeline | index (Kanban), store (new deal), moveStage, destroy |
| SponsorActivityController    | /sponsors/{id}/activities, /sponsor-activities | store, complete, destroy |
| SponsorDriverLinkController  | /sponsors/{id}/link-driver, /sponsor-driver-links | store, update, destroy |

### Routes

- `Route::resource('sponsors', ...)` — full CRUD
- Trash/Import routes are declared BEFORE the resource so they aren't swallowed by `{sponsor}`: `GET sponsors/trash`, `PATCH sponsors/{id}/restore` (also restores cascaded deals), `DELETE sponsors/{id}/force`, `GET sponsors/import`, `POST sponsors/import/upload`, `POST sponsors/import/confirm`, `GET sponsors/import/template`
- `POST sponsors/{sponsor}/activities` — log activity (supports file attachment to `storage/app/public/sponsor-attachments`)
- `PATCH sponsor-activities/{activity}/complete`, `DELETE sponsor-activities/{activity}`
- `POST sponsors/{sponsor}/link-driver`, `PATCH/DELETE sponsor-driver-links/{link}`
- `GET sponsorship-pipeline`, `POST sponsorship-pipeline`, `PATCH sponsorship-pipeline/{deal}/stage`, `DELETE sponsorship-pipeline/{deal}`

### Views

| File                                          | Purpose                                                       |
|-----------------------------------------------|---------------------------------------------------------------|
| sponsors/index.blade.php                      | List with filters (search, type, status, assigned), desktop table + mobile cards |
| sponsors/create.blade.php / edit.blade.php / _form.blade.php | Profile form                                  |
| sponsors/show.blade.php                       | Company info, deals table, linked drivers (with link-driver form), log-activity form, activity timeline |
| sponsorship-pipeline/index.blade.php          | SortableJS drag-drop Kanban (6 stage columns with per-column value totals), per-prospect new-deal modal, edit-deal modal, per-card delete |

### Pipeline intake flow (Lead Identified)

- **Lead Identified is an intake column**: every sponsor with NO open deal (imported, webhook, or admin-created) automatically appears there as a dashed, non-draggable card (Sortable `filter: '.no-drag'`) showing company, type, contact, and estimated budget (budget counts toward the column value total).
- There is no global "New Deal" button — each prospect card has its own **+ New Deal** button which opens the modal with the sponsor pre-locked.
- **New deals always start at Proposal Sent** (`SponsorshipPipelineController::store` forces the stage and logs a `proposal_sent` activity); admin drags them forward from there.
- Once a sponsor has an open deal, its intake card disappears (the deal card represents it). If all its deals close (won/lost), the sponsor returns to intake.
| sponsors/trash.blade.php                      | Deleted sponsors with Restore (restores cascaded deals too) / permanent Delete |
| sponsors/import.blade.php                     | Drag-drop CSV upload + template download + expected columns sidebar |
| sponsors/import-preview.blade.php             | Column mapping (auto-suggested), Skip/Merge/Update duplicate strategy (matched by email OR company name), data preview |

### Import (SponsorProfileController)

`IMPORT_FIELDS`: company_name (required), contact_name, email, phone, website, company_type, industry, country, state, city, estimated_budget, status, notes. Type/status labels normalize to enums (defaults: Sponsor / Prospect); budget strings like "$50,000" are stripped to numeric. Sidebar entry is collapsible: All / Import / Trash.

### Cross-linking

- Driver show page (`driver-leads/show.blade.php`) has a **Sponsor Funding** card listing linked sponsors with funding amount/type, link status, deal stage, and dates.
- Linking/unlinking a driver writes to both `sponsor_activities` (action: driver_linked) and `driver_leads_activity` (action: sponsor_linked / sponsor_unlinked).
- Stage moves on the Kanban auto-log a `stage_changed` sponsor activity.

### Role behavior

- Sales Rep: sees only own assigned sponsors/deals (index + pipeline scoped, show 403s for others).
- Viewer: read-only — create/edit/delete/link/log-activity UI is hidden via `role->isReadOnly()`.

### Sidebar

"Sponsors & Vendors" (handshake icon) and "Sponsorship Pipeline" (sack-dollar icon) appear between Driver Leads and Pipeline, guarded with `Route::has()`.

---

## Module: Dashboard & Reports

### Controllers

| Controller                | Route         | Purpose                              |
|---------------------------|---------------|--------------------------------------|
| DashboardController       | /dashboard    | Eight KPIs + charts                  |
| DashboardLocationController| /dashboard/location-data | Geographic lead data (jsVectorMap) |
| ReportController          | /reports      | Overview reports + CSV export        |
| DriverLeadReportController| /reports/drivers | Driver Leads report + CSV export  |
| SponsorReportController   | /reports/sponsors | Sponsors & Vendors report + CSV export |
| ActivityController        | /activity     | User activity logs + session time    |

### Views

| File                  | Purpose                              |
|-----------------------|--------------------------------------|
| dashboard.blade.php   | Main dashboard with stat cards + charts |
| reports/index.blade.php | Reports with date filters + export  |
| reports/location.blade.php | Location map report              |
| activity/logs.blade.php | User activity log (Super Admin)    |
| activity/sessions.blade.php | Time-spent report               |

---

## Module: Integrations

### Webhook Intake Channels (routes/api.php)

| Endpoint                    | Channel        | Controller                  | Auth Method       |
|-----------------------------|----------------|-----------------------------|-------------------|
| POST /api/v1/leads/webhook  | generic        | WebhookController           | shared secret     |
| POST /api/v1/leads/jotform  | jotform        | JotformController           | shared secret     |
| POST /api/v1/leads/google-form | google_form | GoogleFormController        | shared secret     |
| POST /api/v1/leads/website  | website        | WebsiteController           | shared secret     |
| POST /api/v1/leads/whatsapp | whatsapp       | WhatsAppController          | HMAC              |
| POST /api/v1/leads/email    | email          | EmailController             | shared secret     |
| POST /api/v1/webhooks/meta  | meta           | MetaWebhookController       | Meta verify-token |
| POST /api/v1/webhooks/google-leads | google  | GoogleLeadWebhookController | Google shared key |
| POST /api/v1/webhooks/calendly | calendly    | CalendlyWebhookController   | Calendly HMAC     |
| POST /api/v1/driver-leads/webhook | driver_leads | DriverLeadWebhookController | shared secret |
| POST /api/v1/sponsor-leads/webhook | sponsor_leads | SponsorLeadWebhookController | shared secret |

All webhook routes are rate-limited via the `throttle:webhooks` middleware.

### Integration Config (app/Models/IntegrationSetting.php)

Stored in `integration_settings` table. Columns: channel, enabled, secret_key, config (JSON).

### Integration Controllers

| Controller                  | Route Prefix              | Purpose                        |
|-----------------------------|---------------------------|--------------------------------|
| IntegrationController       | /integrations             | Channel webhook URLs + secrets |
| MetaLeadController          | /integrations/meta        | Meta Lead Ads config           |
| GoogleLeadController        | /integrations/google-leads| Google Lead Form config        |
| GoogleContactFormController | /integrations/google-contact-form | Google Contact Form config |
| DriverLeadFormController    | /integrations/driver-lead-form    | Driver Lead Google Form config (URL, secret, regenerate, Apps Script) |
| SponsorLeadFormController   | /integrations/sponsor-lead-form   | Sponsor Lead Google Form config (URL, secret, regenerate, Apps Script) |
| MeetingIntegrationController| /integrations/meetings    | Google Meet + Calendly config  |

### Sponsor Lead Webhook (SponsorLeadWebhookController::receive)

Vendor & Sponsor Space intake from a Google Form. `company_name`, `email`, `phone` required; `company_type` is normalized onto `SponsorProfileType` (vendor/track/asset|racing/media → else Sponsor); `estimated_budget` strings like `"$50,000"` are stripped to numeric; free-text `partnership_scope` / `agreement_terms` are folded into `notes`. New profiles default to `SponsorStatus::Prospect`. **Dedup** by email then exact company name — existing profiles get blank fields backfilled (never overwritten), notes appended, and a `SponsorActionType::Note` activity logged. Returns `created` / `merged` flags.

### Integration Services

| Service                    | Purpose                              |
|----------------------------|--------------------------------------|
| MetaApiClient              | Meta Lead Ads API calls              |
| MetaLeadService            | Normalize Meta leads                 |
| GoogleLeadApiClient        | Google Lead Form API calls           |
| GoogleLeadService          | Normalize Google leads               |
| GoogleCalendarService      | Create Google Calendar events + Meet links |
| CalendlyService            | Calendly webhook + booking attachment |
| GoogleSheetSyncService     | Push new Lead/DriverLead/SponsorProfile rows to Google Sheets (see below) |

### Google Sheets Outbound Sync

| Item | Details |
|------|---------|
| Trigger | `Lead`/`DriverLead`/`SponsorProfile` `created` model events registered in `AppServiceProvider::boot` dispatch the queued `SyncLeadToGoogleSheet` job (`$tries = 3`, backoff `[30, 120]`) |
| Service | `GoogleSheetSyncService::sync(Model)` — maps the model to a sheet tab and POSTs `{secret, sheetName, data}` to the Apps Script Web App (20s timeout) |
| Sheet tabs | `Lead → BaseLeads`, `DriverLead → DriverLeads`, `SponsorProfile → sponserleads` — each with its own column set (`baseLeadRow`/`driverLeadRow`/`sponsorRow`) |
| Config | `config/services.php` → `google_sheets.url` / `google_sheets.secret` from `.env` `GOOGLE_SHEETS_SYNC_URL` / `GOOGLE_SHEETS_SYNC_SECRET`. Empty URL = sync disabled (`enabled()` short-circuits) |
| Test command | `php artisan sheets:test [--sheet=base|driver|sponsor]` (`TestGoogleSheetSyncCommand`) sends sample rows without touching the DB. Requires `php artisan queue:work` for live syncing |

---

## Module: Users & Auth

### Tables

| Table               | Purpose                          |
|---------------------|----------------------------------|
| users               | User accounts with role field    |
| user_sessions       | Login session tracking           |
| user_activity_logs  | Page-view activity tracking      |
| user_creation_otps  | OTP approval for new users       |
| audit_logs          | Generic action audit trail (AuditLog model, written by AuditService — user_id, action, auditable_type/id, description, ip_address) |

### Controllers

| Controller     | Purpose                                       |
|----------------|-----------------------------------------------|
| UserController | CRUD, toggleActive, OTP verify flow           |
| ProfileController | Edit profile, avatar, password, delete account |
| SecurityController | Idle logout, security settings (Admin+)    |

---

## Module: Notifications

- In-app bell notifications (database driver)
- Optional Slack + Discord webhook notifications
- Three notification classes: NewLeadNotification, HotLeadNotification, LeadAssignedNotification
- Controller: NotificationController (index, markRead, markAllRead)

---

## Module: Email Reports

- WeeklyLeadReportService — sends weekly summary
- SendWeeklyLeadReportCommand — artisan command for cron
- Email templates in resources/views/emails/

---

## Frontend Stack

| Library     | Purpose                        | Loaded Via     |
|-------------|--------------------------------|----------------|
| Alpine.js   | Reactive UI (sidebar, dropdowns, modals) | Vite bundle |
| Tailwind CSS 3 | Utility-first CSS           | Vite bundle    |
| Chart.js    | Dashboard charts               | CDN fallback   |
| ApexCharts  | Additional dashboard charts    | CDN fallback   |
| SortableJS  | Drag-and-drop pipeline board   | Vite bundle    |
| jsVectorMap | Location map visualization     | Vite bundle    |

### Layouts

| File                              | Purpose                           |
|-----------------------------------|-----------------------------------|
| layouts/app.blade.php             | TailAdmin theme (primary layout)  |
| layouts/adminlte.blade.php        | Legacy AdminLTE layout (lead show)|
| layouts/guest.blade.php           | Auth pages (login, register)      |
| layouts/partials/sidebar.blade.php| Sidebar navigation                |
| layouts/partials/header.blade.php | Top header bar                    |

### Blade Components (resources/views/components/)

card, badge, stat-card, modal, dropdown, dropdown-link, nav-link, user-avatar, location-map, primary-button, secondary-button, danger-button, text-input, input-label, input-error, auth-session-status, app-layout, application-logo, responsive-nav-link

---

## Database Seeder Files

| Seeder                    | Purpose                    |
|---------------------------|----------------------------|
| DatabaseSeeder            | Orchestrates all seeders   |
| UserSeeder                | Creates test accounts      |
| LeadSeeder                | Sample lead data           |
| IntegrationSettingSeeder  | Default integration configs|

---

## Tests (tests/)

| Test File                   | Covers                              |
|-----------------------------|--------------------------------------|
| WebhookIntakeTest           | All webhook channels                 |
| PipelineTest                | Drag-and-drop pipeline moves         |
| LeadImportTest              | CSV/XLSX/PDF import flow             |
| LeadImportParsingTest       | Parser unit tests                    |
| AdPlatformWebhookTest       | Meta + Google webhook normalization  |
| MeetingTest                 | Google Meet + Calendly               |
| ReportTest                  | Report generation + export           |
| LocationReportTest          | Location aggregation                 |
| NotificationTest            | Notification dispatch                |
| EmailNotificationTest       | Email report sending                 |
| UserManagementTest          | User CRUD + roles                    |
| ProfileTest                 | Profile update                       |
| Auth/*                      | Login, registration, password, email verification |

---

## Key Patterns & Conventions

- **Enums** — PHP 8.1 backed enums with `label()`, `color()`, `options()` methods
- **Webhook auth** — `VerifyWebhookSecret` middleware reads from `integration_settings.secret_key` or env fallback
- **Activity logging** — every state change creates an interaction/activity record
- **Soft deletes** — Lead and DriverLead models use soft deletes
- **Views** — TailAdmin theme (`layouts/app.blade.php`) is the primary layout; some legacy pages still use `layouts/adminlte.blade.php`
- **CSS classes** — `ta-input`, `ta-label`, `ta-th`, `ta-td`, `ta-nav-link`, `ta-nav-sub`, `btn btn-primary`, `btn btn-light` are the standard TailAdmin utility classes
- **Flash messages** — `session('toast')` for success, `session('error')` for errors
- **Sidebar guards** — `Route::has()` wraps optional menu items so they only appear when routes exist
