<?php

namespace App\Http\Controllers;

use App\Enums\InteractionType;
use App\Enums\LeadStatus;
use App\Enums\UserRole;
use App\Mail\MeetingNotificationMail;
use App\Models\DriverLead;
use App\Models\Lead;
use App\Models\LeadMeeting;
use App\Models\SponsorProfile;
use App\Services\AuditService;
use App\Services\Integrations\Meetings\GoogleCalendarService;
use App\Services\Integrations\Meetings\ZoomService;
use App\Services\LeadInteractionService;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Mail;

class MeetingController extends Controller
{
    public function __construct(
        private LeadInteractionService $interactions,
        private AuditService $audit,
    ) {}

    /** GET /meetings — meetings grouped by subject type (leads / drivers / sponsors). */
    public function index(Request $request)
    {
        $user = $request->user();
        $isRep = $user->hasRole(UserRole::SalesRep);

        // Lead meetings (rep sees only their own leads' meetings).
        $leadMeetings = LeadMeeting::with('meetable')
            ->where('meetable_type', Lead::class)
            ->when($isRep, fn ($q) => $q->whereHasMorph('meetable', [Lead::class],
                fn ($qq) => $qq->where('assigned_to', $user->id)))
            ->orderByDesc('starts_at')
            ->paginate(10, ['*'], 'leads_page')
            ->withQueryString();

        // Driver lead meetings (driver leads are not rep-assigned — visible to all).
        $driverMeetings = LeadMeeting::with('meetable')
            ->where('meetable_type', DriverLead::class)
            ->orderByDesc('starts_at')
            ->paginate(10, ['*'], 'drivers_page')
            ->withQueryString();

        // Sponsor meetings (rep sees only their own assigned sponsors' meetings).
        $sponsorMeetings = LeadMeeting::with('meetable')
            ->where('meetable_type', SponsorProfile::class)
            ->when($isRep, fn ($q) => $q->whereHasMorph('meetable', [SponsorProfile::class],
                fn ($qq) => $qq->where('assigned_to', $user->id)))
            ->orderByDesc('starts_at')
            ->paginate(10, ['*'], 'sponsors_page')
            ->withQueryString();

        return view('meetings.index', compact('leadMeetings', 'driverMeetings', 'sponsorMeetings'));
    }

    /** GET /meetings/search?q= — cross-type search (basic leads / drivers / sponsors). */
    public function search(Request $request)
    {
        $q = trim((string) $request->query('q', ''));
        if (mb_strlen($q) < 2) {
            return response()->json([]);
        }

        $user  = $request->user();
        $isRep = $user->hasRole(UserRole::SalesRep);
        $like  = '%' . $q . '%';

        $leads = Lead::query()
            ->when($isRep, fn ($x) => $x->where('assigned_to', $user->id))
            ->where(fn ($x) => $x->where('full_name', 'like', $like)
                ->orWhere('first_name', 'like', $like)->orWhere('last_name', 'like', $like)
                ->orWhere('email', 'like', $like)->orWhere('phone', 'like', $like))
            ->limit(8)->get()
            ->map(fn ($l) => ['type' => 'basic', 'id' => $l->id, 'name' => $l->full_name ?: ('Lead #' . $l->id), 'email' => $l->email, 'label' => 'Basic Lead']);

        // Driver leads are not rep-assigned — visible to all roles.
        $drivers = DriverLead::query()
            ->where(fn ($x) => $x->where('first_name', 'like', $like)
                ->orWhere('last_name', 'like', $like)->orWhere('email', 'like', $like)->orWhere('phone', 'like', $like))
            ->limit(8)->get()
            ->map(fn ($d) => ['type' => 'driver', 'id' => $d->id, 'name' => $d->full_name ?: ('Driver #' . $d->id), 'email' => $d->email, 'label' => 'Driver Lead']);

        $sponsors = SponsorProfile::query()
            ->when($isRep, fn ($x) => $x->where('assigned_to', $user->id))
            ->where(fn ($x) => $x->where('company_name', 'like', $like)
                ->orWhere('contact_name', 'like', $like)->orWhere('email', 'like', $like)->orWhere('phone', 'like', $like))
            ->limit(8)->get()
            ->map(fn ($s) => ['type' => 'sponsor', 'id' => $s->id, 'name' => $s->company_name ?: ('Sponsor #' . $s->id), 'email' => $s->email, 'label' => 'Sponsor']);

        return response()->json($leads->concat($drivers)->concat($sponsors)->values());
    }

    /** POST /meetings/schedule — create a meeting for any subject, any provider. */
    public function schedule(Request $request, GoogleCalendarService $google, ZoomService $zoom)
    {
        $data = $request->validate([
            'subject_type'            => ['required', 'in:basic,driver,sponsor,new'],
            'subject_id'              => ['nullable', 'required_unless:subject_type,new', 'integer'],
            'provider'                => ['required', 'in:google_meet,zoom,calendly'],
            // Fields for creating a brand-new basic lead inline (present-but-null in
            // existing mode, so they must be nullable to skip the type rules).
            'new_first_name'          => ['nullable', 'required_if:subject_type,new', 'string', 'max:191'],
            'new_email'               => ['nullable', 'required_if:subject_type,new', 'email', 'max:191'],
            'new_phone'               => ['nullable', 'required_if:subject_type,new', 'string', 'max:50'],
            'new_motorsport_interest' => ['nullable', new \Illuminate\Validation\Rules\Enum(\App\Enums\MotorsportInterest::class)],
        ]);

        $meetable = match ($data['subject_type']) {
            'new'     => $this->createInstantLead($request, $data),
            'basic'   => Lead::findOrFail($data['subject_id']),
            'driver'  => DriverLead::findOrFail($data['subject_id']),
            'sponsor' => SponsorProfile::findOrFail($data['subject_id']),
        };

        $this->ensureCanManage($request, $meetable);

        // The store* helpers advance a Lead to "Meeting Scheduled" automatically.
        return match ($data['provider']) {
            'google_meet' => $this->storeGoogleMeet($request, $meetable, $google),
            'zoom'        => $this->storeZoom($request, $meetable, $zoom),
            'calendly'    => $this->storeCalendlyLink($request, $meetable),
        };
    }

    /**
     * Create a Basic Lead on the fly for an instant meeting. Reuses an existing
     * lead if one already has the same email, to avoid duplicates.
     */
    private function createInstantLead(Request $request, array $data): Lead
    {
        $user  = $request->user();
        $email = strtolower(trim($data['new_email']));

        $existing = Lead::where('email', $email)->first();
        if ($existing) {
            return $existing;
        }

        return Lead::create([
            'first_name'               => $data['new_first_name'],
            'full_name'                => $data['new_first_name'],
            'email'                    => $email,
            'phone'                    => $data['new_phone'],
            'normalized_phone'         => preg_replace('/[^0-9+]/', '', $data['new_phone']),
            'source_channel'           => \App\Enums\SourceChannel::Manual,
            'status'                   => LeadStatus::New,
            'motorsport_interest_type' => $data['new_motorsport_interest'] ?? null,
            'created_by'               => $user->id,
            'assigned_to'              => $user->hasRole(UserRole::SalesRep) ? $user->id : null,
            'last_activity_at'         => now(),
        ]);
    }

    // ---- Leads -------------------------------------------------------------

    /** POST /leads/{lead}/meetings/google-meet */
    public function googleMeet(Request $request, Lead $lead, GoogleCalendarService $google)
    {
        Gate::authorize('update', $lead);

        return $this->storeGoogleMeet($request, $lead, $google);
    }

    /** POST /leads/{lead}/meetings/zoom */
    public function zoom(Request $request, Lead $lead, ZoomService $zoom)
    {
        Gate::authorize('update', $lead);

        return $this->storeZoom($request, $lead, $zoom);
    }

    /** POST /leads/{lead}/meetings/calendly-link */
    public function calendlyLink(Request $request, Lead $lead)
    {
        Gate::authorize('update', $lead);

        return $this->storeCalendlyLink($request, $lead);
    }

    // ---- Driver Leads ------------------------------------------------------

    /** POST /driver-leads/{driverLead}/meetings/google-meet */
    public function driverGoogleMeet(Request $request, DriverLead $driverLead, GoogleCalendarService $google)
    {
        $this->ensureCanManage($request, $driverLead);

        return $this->storeGoogleMeet($request, $driverLead, $google);
    }

    /** POST /driver-leads/{driverLead}/meetings/zoom */
    public function driverZoom(Request $request, DriverLead $driverLead, ZoomService $zoom)
    {
        $this->ensureCanManage($request, $driverLead);

        return $this->storeZoom($request, $driverLead, $zoom);
    }

    /** POST /driver-leads/{driverLead}/meetings/calendly-link */
    public function driverCalendlyLink(Request $request, DriverLead $driverLead)
    {
        $this->ensureCanManage($request, $driverLead);

        return $this->storeCalendlyLink($request, $driverLead);
    }

    // ---- Sponsors ----------------------------------------------------------

    /** POST /sponsors/{sponsor}/meetings/google-meet */
    public function sponsorGoogleMeet(Request $request, SponsorProfile $sponsor, GoogleCalendarService $google)
    {
        $this->ensureCanManage($request, $sponsor);

        return $this->storeGoogleMeet($request, $sponsor, $google);
    }

    /** POST /sponsors/{sponsor}/meetings/zoom */
    public function sponsorZoom(Request $request, SponsorProfile $sponsor, ZoomService $zoom)
    {
        $this->ensureCanManage($request, $sponsor);

        return $this->storeZoom($request, $sponsor, $zoom);
    }

    /** POST /sponsors/{sponsor}/meetings/calendly-link */
    public function sponsorCalendlyLink(Request $request, SponsorProfile $sponsor)
    {
        $this->ensureCanManage($request, $sponsor);

        return $this->storeCalendlyLink($request, $sponsor);
    }

    // ---- Delete ------------------------------------------------------------

    /** DELETE /meetings/{meeting} — remove a meeting; revert the lead status if applicable. */
    public function destroy(Request $request, LeadMeeting $meeting, GoogleCalendarService $google, ZoomService $zoom)
    {
        $subject = $meeting->meetable;
        abort_if(! $subject, 404);

        $this->ensureCanManage($request, $subject);

        // Best-effort removal of the upstream event behind the meeting link.
        if ($meeting->external_event_id) {
            if ($meeting->provider === 'google_meet') {
                rescue(fn () => $google->deleteEvent($meeting->external_event_id), report: false);
            } elseif ($meeting->provider === 'zoom') {
                rescue(fn () => $zoom->deleteMeeting($meeting->external_event_id), report: false);
            }
        }

        $previousStatus = $meeting->previous_lead_status;
        $meeting->delete();

        // Status revert only applies to general CRM leads.
        if ($subject instanceof Lead) {
            $this->revertLeadStatus($subject, $previousStatus);
        }

        return back()->with('toast', 'Meeting deleted.');
    }

    // ---- Shared create logic ----------------------------------------------

    private function storeGoogleMeet(Request $request, Model $meetable, GoogleCalendarService $google)
    {
        $data = $request->validate([
            'title'       => ['required', 'string', 'max:191'],
            'starts_at'   => ['required', 'date'],
            'duration'    => ['nullable', 'integer', 'between:15,480'],
            'description' => ['nullable', 'string', 'max:5000'],
        ]);

        $start = Carbon::parse($data['starts_at']);
        $end   = (clone $start)->addMinutes((int) ($data['duration'] ?? 30));

        [$email, $name] = $this->contact($meetable);

        $meeting = $google->createMeeting($meetable, $data['title'], $start, $end, $email, $name, $request->user()->id, $data['description'] ?? null);

        if ($meetable instanceof Lead) {
            $this->advanceLeadToScheduled($meetable, $meeting);
        }
        $this->notify($meeting);

        $msg = $meeting->meeting_url
            ? 'Google Meet created.'
            : 'Meeting saved, but no Meet link was returned (check Google integration credentials).';

        return back()->with('toast', $msg);
    }

    private function storeZoom(Request $request, Model $meetable, ZoomService $zoom)
    {
        $data = $request->validate([
            'title'       => ['required', 'string', 'max:191'],
            'starts_at'   => ['required', 'date'],
            'duration'    => ['nullable', 'integer', 'between:15,480'],
            'description' => ['nullable', 'string', 'max:5000'],
        ]);

        $start = Carbon::parse($data['starts_at']);
        $end   = (clone $start)->addMinutes((int) ($data['duration'] ?? 30));

        [$email, $name] = $this->contact($meetable);

        $meeting = $zoom->createMeeting($meetable, $data['title'], $start, $end, $email, $name, $request->user()->id, $data['description'] ?? null);

        if ($meetable instanceof Lead) {
            $this->advanceLeadToScheduled($meetable, $meeting);
        }
        $this->notify($meeting);

        $msg = $meeting->meeting_url
            ? 'Zoom meeting created.'
            : 'Meeting saved, but no Zoom link was returned (check Zoom integration credentials).';

        return back()->with('toast', $msg);
    }

    private function storeCalendlyLink(Request $request, Model $meetable)
    {
        $data = $request->validate([
            'meeting_url' => ['required', 'url', 'max:500'],
            'title'       => ['nullable', 'string', 'max:191'],
            'starts_at'   => ['nullable', 'date'],
            'description' => ['nullable', 'string', 'max:5000'],
        ]);

        [$email, $name] = $this->contact($meetable);

        $meeting = new LeadMeeting([
            'provider'       => 'calendly',
            'meeting_title'  => $data['title'] ?? 'Calendly meeting',
            'description'    => $data['description'] ?? null,
            'meeting_url'    => $data['meeting_url'],
            'starts_at'      => isset($data['starts_at']) ? Carbon::parse($data['starts_at']) : null,
            'attendee_email' => $email,
            'attendee_name'  => $name,
            'status'         => 'scheduled',
            'created_by'     => $request->user()->id,
        ]);
        $meeting->meetable()->associate($meetable);
        $meeting->save();

        if ($meetable instanceof Lead) {
            $this->advanceLeadToScheduled($meetable, $meeting);
        }
        $this->notify($meeting);

        return back()->with('toast', 'Calendly link added.');
    }

    /** Email/name to seed the meeting + calendar invite from the subject record. */
    private function contact(Model $meetable): array
    {
        return match (true) {
            $meetable instanceof Lead           => [$meetable->email, $meetable->full_name],
            $meetable instanceof DriverLead     => [$meetable->email, $meetable->full_name],
            $meetable instanceof SponsorProfile => [$meetable->email, $meetable->contact_name ?: $meetable->company_name],
            default                             => [null, null],
        };
    }

    /** Authorize a mutation on the meeting's subject record. */
    private function ensureCanManage(Request $request, Model $meetable): void
    {
        $user = $request->user();

        if ($meetable instanceof Lead) {
            Gate::authorize('update', $meetable);
            return;
        }

        abort_if($user->role->isReadOnly(), 403);

        if ($meetable instanceof SponsorProfile
            && $user->hasRole(UserRole::SalesRep)
            && $meetable->assigned_to !== $user->id) {
            abort(403);
        }
    }

    /**
     * Move a lead into Meeting Scheduled when a meeting is booked, remembering
     * the prior status on the meeting so it can be restored if the meeting is deleted.
     * Closed leads are left untouched.
     */
    private function advanceLeadToScheduled(Lead $lead, LeadMeeting $meeting): void
    {
        $current = $lead->status;

        if (in_array($current, [LeadStatus::MeetingScheduled, LeadStatus::ClosedWon, LeadStatus::ClosedLost], true)) {
            return;
        }

        $meeting->forceFill(['previous_lead_status' => $current->value])->save();

        $lead->update(['status' => LeadStatus::MeetingScheduled]);

        $this->interactions->record(
            $lead, InteractionType::MEETING_SCHEDULED, 'Status updated (meeting scheduled).',
            $current->label(), LeadStatus::MeetingScheduled->label()
        );
        $this->audit->log('lead.status_changed', $lead, "Status {$current->label()} -> {$lead->status->label()}");
    }

    /**
     * Revert a lead's status after its meeting is deleted. Only reverts when the
     * lead is still in Meeting Scheduled and has no other remaining meetings.
     */
    private function revertLeadStatus(Lead $lead, ?string $previousStatus): void
    {
        $lead->refresh();

        if ($lead->status !== LeadStatus::MeetingScheduled) {
            return;
        }

        if ($lead->meetings()->exists()) {
            return; // another meeting still keeps it scheduled
        }

        $target = LeadStatus::tryFrom((string) $previousStatus) ?? LeadStatus::Contacted;

        if ($target === LeadStatus::MeetingScheduled) {
            $target = LeadStatus::Contacted;
        }

        $old = $lead->status;
        $lead->update(['status' => $target]);

        $this->interactions->record(
            $lead, InteractionType::STATUS_CHANGED, 'Status reverted (meeting deleted).',
            $old->label(), $target->label()
        );
        $this->audit->log('lead.status_changed', $lead, "Status {$old->label()} -> {$target->label()} (meeting deleted)");
    }

    private function notify(LeadMeeting $meeting): void
    {
        // Internal team: all active admins / managers (Sales Managers included).
        $emails = \App\Models\User::where('is_active', true)
            ->whereIn('role', [UserRole::SuperAdmin->value, UserRole::Admin->value, UserRole::SalesManager->value])
            ->pluck('email');

        $subject = $meeting->meetable;

        // The owning Sales Rep (assignee on the lead / sponsor).
        if ($subject && method_exists($subject, 'assignee') && $subject->assignee) {
            $emails->push($subject->assignee->email);
        }

        // The customer / driver / sponsor the meeting is with.
        if ($meeting->attendee_email) {
            $emails->push($meeting->attendee_email);
        }

        $emails = $emails->filter()->map(fn ($e) => strtolower(trim($e)))->unique();

        $customerEmail = $meeting->attendee_email ? strtolower(trim($meeting->attendee_email)) : null;

        foreach ($emails as $email) {
            $forCustomer = $customerEmail !== null && $email === $customerEmail;
            rescue(fn () => Mail::to($email)->send(new MeetingNotificationMail($meeting, $forCustomer)), report: false);
        }
    }
}
