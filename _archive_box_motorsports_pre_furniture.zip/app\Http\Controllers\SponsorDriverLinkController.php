<?php

namespace App\Http\Controllers;

use App\Enums\FundingType;
use App\Enums\SponsorActionType;
use App\Enums\SponsorLinkStatus;
use App\Models\DriverLead;
use App\Models\DriverLeadActivity;
use App\Models\SponsorActivity;
use App\Models\SponsorDriverLink;
use App\Models\SponsorProfile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rules\Enum;

class SponsorDriverLinkController extends Controller
{
    public function store(Request $request, SponsorProfile $sponsor)
    {
        $validated = $request->validate([
            'driver_lead_id'      => ['required', 'exists:driver_leads,id'],
            'sponsorship_deal_id' => ['nullable', 'exists:sponsorship_deals,id'],
            'funding_amount'      => ['nullable', 'numeric', 'min:0'],
            'funding_type'        => ['required', new Enum(FundingType::class)],
            'season_or_event'     => ['nullable', 'string', 'max:255'],
            'status'              => ['required', new Enum(SponsorLinkStatus::class)],
            'start_date'          => ['nullable', 'date'],
            'end_date'            => ['nullable', 'date', 'after_or_equal:start_date'],
        ]);

        $link = SponsorDriverLink::create(array_merge($validated, [
            'sponsor_profile_id' => $sponsor->id,
        ]));

        $driver = DriverLead::find($validated['driver_lead_id']);

        SponsorActivity::create([
            'sponsor_profile_id'  => $sponsor->id,
            'sponsorship_deal_id' => $validated['sponsorship_deal_id'] ?? null,
            'driver_lead_id'      => $driver->id,
            'action_type'         => SponsorActionType::DriverLinked,
            'description'         => "Linked driver {$driver->full_name} ({$link->funding_type->label()})",
            'performed_by'        => Auth::id(),
            'completed_at'        => now(),
        ]);

        DriverLeadActivity::create([
            'driver_lead_id' => $driver->id,
            'user_id'        => Auth::id(),
            'action'         => 'sponsor_linked',
            'description'    => "Linked to sponsor {$sponsor->company_name} ({$link->funding_type->label()})",
        ]);

        return back()->with('toast', "Driver {$driver->full_name} linked to {$sponsor->company_name}.");
    }

    public function update(Request $request, SponsorDriverLink $link)
    {
        $validated = $request->validate([
            'funding_amount'  => ['nullable', 'numeric', 'min:0'],
            'funding_type'    => ['required', new Enum(FundingType::class)],
            'season_or_event' => ['nullable', 'string', 'max:255'],
            'status'          => ['required', new Enum(SponsorLinkStatus::class)],
            'start_date'      => ['nullable', 'date'],
            'end_date'        => ['nullable', 'date', 'after_or_equal:start_date'],
        ]);

        $link->update($validated);

        return back()->with('toast', 'Sponsor-driver link updated.');
    }

    public function destroy(SponsorDriverLink $link)
    {
        $driverName  = $link->driverLead?->full_name ?? 'driver';
        $sponsorName = $link->sponsor?->company_name ?? 'sponsor';

        if ($link->driver_lead_id) {
            DriverLeadActivity::create([
                'driver_lead_id' => $link->driver_lead_id,
                'user_id'        => Auth::id(),
                'action'         => 'sponsor_unlinked',
                'description'    => "Unlinked from sponsor {$sponsorName}",
            ]);
        }

        $link->delete();

        return back()->with('toast', "{$driverName} unlinked from {$sponsorName}.");
    }
}
