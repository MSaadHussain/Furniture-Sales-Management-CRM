@extends('layouts.app')
@section('title', 'Edit ' . $sponsor->company_name)
@section('breadcrumb')
    <a href="{{ route('sponsors.index') }}" class="hover:text-brand">Sponsors & Vendors</a> /
    <a href="{{ route('sponsors.show', $sponsor) }}" class="hover:text-brand">{{ $sponsor->company_name }}</a> / <span>Edit</span>
@endsection

@section('content')
<x-card title="Edit Sponsor / Vendor Profile">
    <form method="POST" action="{{ route('sponsors.update', $sponsor) }}">
        @method('PATCH')
        @include('sponsors._form')
        <div class="mt-6 flex justify-end gap-3">
            <a href="{{ route('sponsors.show', $sponsor) }}" class="btn btn-light">Cancel</a>
            <button class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save Changes</button>
        </div>
    </form>
</x-card>
@endsection
