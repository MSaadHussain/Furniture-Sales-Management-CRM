@extends('layouts.adminlte')
@section('title', 'Notifications')
@section('header_actions')
    <div class="text-right">
        <form method="POST" action="{{ route('notifications.readAll') }}">@csrf<button class="btn btn-default btn-sm">Mark all read</button></form>
    </div>
@endsection

@section('content')
<div class="card">
    <div class="card-body p-0">
        <ul class="list-group list-group-flush">
            @forelse ($notifications as $n)
                <li class="list-group-item d-flex align-items-start {{ $n->read_at ? '' : 'bg-light' }}">
                    <span class="badge-dot mt-2 mr-3" style="background-color: {{ $n->data['color'] ?? '#6B7280' }}"></span>
                    <div class="flex-grow-1">
                        <a href="{{ route('leads.show', $n->data['lead_id'] ?? 0) }}" class="font-weight-bold text-dark">{{ $n->data['title'] ?? 'Notification' }}</a>
                        <p class="mb-1 text-muted">{{ $n->data['message'] ?? '' }}</p>
                        <span class="small text-muted">{{ $n->created_at->diffForHumans() }}</span>
                    </div>
                    @unless ($n->read_at)
                        <form method="POST" action="{{ route('notifications.read', $n->id) }}">@csrf<button class="btn btn-sm btn-link">Mark read</button></form>
                    @endunless
                </li>
            @empty<li class="list-group-item text-center text-muted py-5">No notifications.</li>@endforelse
        </ul>
    </div>
    <div class="card-footer">{{ $notifications->links() }}</div>
</div>
@endsection
