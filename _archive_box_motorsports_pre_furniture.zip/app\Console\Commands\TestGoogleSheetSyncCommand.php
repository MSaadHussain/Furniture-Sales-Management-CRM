<?php

namespace App\Console\Commands;

use App\Models\DriverLead;
use App\Models\Lead;
use App\Models\SponsorProfile;
use App\Services\GoogleSheetSyncService;
use Illuminate\Console\Command;

class TestGoogleSheetSyncCommand extends Command
{
    protected $signature = 'sheets:test
                            {--sheet=all : Which sheet to test (all, base, driver, sponsor)}';

    protected $description = 'Send a sample row to each Google Sheet tab (BaseLeads, DriverLeads, sponserleads) to verify the Apps Script sync';

    public function handle(GoogleSheetSyncService $sheets): int
    {
        if (! $sheets->enabled()) {
            $this->error('GOOGLE_SHEETS_SYNC_URL is not set in .env — sync is disabled.');
            return self::FAILURE;
        }

        $this->info('Web App URL: ' . config('services.google_sheets.url'));
        $this->newLine();

        $which = strtolower($this->option('sheet'));
        $results = [];

        if (in_array($which, ['all', 'base'], true)) {
            $results['BaseLeads (Lead)'] = $sheets->sync($this->sampleLead());
        }

        if (in_array($which, ['all', 'driver'], true)) {
            $results['DriverLeads (DriverLead)'] = $sheets->sync($this->sampleDriverLead());
        }

        if (in_array($which, ['all', 'sponsor'], true)) {
            $results['sponserleads (SponsorProfile)'] = $sheets->sync($this->sampleSponsor());
        }

        if (empty($results)) {
            $this->error("Unknown --sheet option '{$which}'. Use: all, base, driver, sponsor.");
            return self::FAILURE;
        }

        $failed = false;
        foreach ($results as $label => $ok) {
            if ($ok) {
                $this->info("  ✔ {$label} — row appended");
            } else {
                $this->error("  ✘ {$label} — FAILED (see storage/logs/laravel.log for the response)");
                $failed = true;
            }
        }

        $this->newLine();
        if ($failed) {
            $this->warn('Checklist: secret in .env matches SECRET_TOKEN in the Apps Script; the Web App is deployed as "Anyone" can access; the deployment URL ends in /exec.');
            return self::FAILURE;
        }

        $this->info('All test rows accepted. Check the sheet tabs — each one should show its own column headers in row 1 and a TEST row below.');
        return self::SUCCESS;
    }

    /** Unsaved sample models — nothing touches the database. */
    private function sampleLead(): Lead
    {
        return (new Lead)->forceFill([
            'id'                       => 0,
            'created_at'               => now(),
            'first_name'               => 'TEST',
            'last_name'                => 'BaseLead',
            'full_name'                => 'TEST BaseLead',
            'email'                    => 'test-base@example.com',
            'phone'                    => '+1 555 0000',
            'country'                  => 'United States',
            'loc_state'                => 'Texas',
            'city'                     => 'Austin',
            'company'                  => 'Test Co',
            'message'                  => 'Sheet sync test row — safe to delete',
            'source_channel'           => 'manual',
            'status'                   => 'new',
            'priority'                 => 'medium',
            'lead_score'               => 42,
        ]);
    }

    private function sampleDriverLead(): DriverLead
    {
        return (new DriverLead)->forceFill([
            'id'                  => 0,
            'created_at'          => now(),
            'first_name'          => 'TEST',
            'last_name'           => 'Driver',
            'email'               => 'test-driver@example.com',
            'phone'               => '+44 7700 900000',
            'country'                => 'United Kingdom',
            'dob'                    => '1985-01-07',
            'years_racing'           => 17,
            'highest_series'         => 'Formula 1',
            'racing_level'           => 'formula_1',
            'car_type'               => 'formula_car',
            'career_wins'            => 103,
            'current_team_series'    => 'Test Racing Team',
            'instagram_handle'       => '@testdriver',
            'instagram_followers'    => 35000000,
            'seeking_sponsorship'    => true,
            'contract_interest_type' => 'sponsorship_contract',
            'inferred_tier'          => 'elite',
            'status'                 => 'new',
        ]);
    }

    private function sampleSponsor(): SponsorProfile
    {
        return (new SponsorProfile)->forceFill([
            'id'               => 0,
            'created_at'       => now(),
            'company_name'     => 'TEST Apex Auto Group',
            'company_type'     => 'sponsor',
            'industry'         => 'Automotive',
            'website'          => 'apexauto.example.com',
            'contact_name'     => 'John Smith',
            'email'            => 'test-sponsor@example.com',
            'phone'            => '+1 555 0100',
            'country'          => 'United States',
            'state'            => 'California',
            'city'             => 'Los Angeles',
            'estimated_budget' => 50000,
            'status'           => 'prospect',
            'notes'            => 'Sheet sync test row — safe to delete',
        ]);
    }
}
