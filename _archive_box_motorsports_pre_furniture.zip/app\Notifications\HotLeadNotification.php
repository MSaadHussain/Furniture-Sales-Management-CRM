<?php

namespace App\Notifications;

use App\Models\Lead;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;

class HotLeadNotification extends Notification
{
    use Queueable;

    public function __construct(public Lead $lead) {}

    public function via(object $notifiable): array
    {
        return ['database'];
    }

    public function toArray(object $notifiable): array
    {
        return [
            'type'    => 'hot_lead',
            'lead_id' => $this->lead->id,
            'title'   => 'Hot lead!',
            'message' => ($this->lead->full_name ?: 'Unnamed lead')
                         . ' - score ' . $this->lead->lead_score,
            'color'   => '#E10600',
        ];
    }
}
