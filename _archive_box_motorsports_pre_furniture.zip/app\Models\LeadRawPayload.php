<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LeadRawPayload extends Model
{
    protected $fillable = [
        'lead_id', 'source_channel', 'payload', 'ip_address', 'processed', 'error',
    ];

    protected function casts(): array
    {
        return ['payload' => 'array', 'processed' => 'boolean'];
    }

    public function lead()
    {
        return $this->belongsTo(Lead::class);
    }
}
