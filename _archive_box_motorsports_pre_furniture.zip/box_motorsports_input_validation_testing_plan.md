# Box Motorsports CRM — Input Validation Testing Plan

## Purpose

This document defines the input validation testing plan for the **Box Motorsports CRM** Laravel application.  
The goal is to make sure every form, webhook, import flow, and role-based action accepts only clean, expected data and rejects invalid, unsafe, or unauthorized input.

The CRM includes multiple intake points such as:

- General CRM leads
- Website lead forms
- Jotform / Google Form leads
- WhatsApp / Email intake
- Meta and Google lead form webhooks
- Driver lead webhook
- Sponsor and vendor profiles
- Sponsorship pipeline deals
- Lead imports through CSV, XLSX, and PDF
- User management and role-based access

---

# 1. Testing Objectives

The validation testing should confirm that:

1. Required fields are enforced.
2. Invalid data is rejected before saving to the database.
3. API and webhook requests return proper validation errors.
4. Blade forms show clean error messages.
5. Unsafe inputs like scripts or oversized text are handled safely.
6. Enum fields only accept allowed values.
7. Numeric fields reject negative or unrealistic values.
8. Files are validated by type, size, and structure.
9. Role-based restrictions cannot be bypassed by manually editing requests.
10. Duplicate leads are merged correctly instead of creating unnecessary duplicate records.

---

# 2. Laravel Testing Command

Run the complete test suite with:

```bash
php artisan test
```

For a specific test file:

```bash
php artisan test tests/Feature/LeadValidationTest.php
```

For a specific test method:

```bash
php artisan test --filter=test_lead_requires_valid_email
```

---

# 3. Recommended Test Files

Create these test files inside the Laravel project:

```text
tests/Feature/LeadValidationTest.php
tests/Feature/WebhookValidationTest.php
tests/Feature/DriverLeadValidationTest.php
tests/Feature/SponsorValidationTest.php
tests/Feature/SponsorshipPipelineValidationTest.php
tests/Feature/LeadImportValidationTest.php
tests/Feature/UserRoleValidationTest.php
tests/Feature/SecurityInputValidationTest.php
```

---

# 4. General Lead Validation Testing

## Module

General CRM Leads

## Routes To Test

```text
POST /leads
PUT /leads/{lead}
PATCH /leads/{lead}/status
PATCH /leads/{lead}/assign
POST /leads/{lead}/notes
```

## Fields To Validate

| Field | Validation Rule |
|---|---|
| first_name | required, string, max length |
| last_name | nullable/string, max length |
| full_name | nullable/string, max length |
| email | nullable or required depending on flow, valid email |
| phone | nullable, valid phone format |
| country | nullable/string/max length |
| city | nullable/string/max length |
| loc_state | nullable/string/max length |
| company | nullable/string/max length |
| source_channel | must be valid enum |
| status | must be valid enum |
| priority | must be valid enum |
| motorsport_interest_type | must be valid enum |
| message | nullable/string/max length |
| tags | nullable/array |
| assigned_to | must exist in users table |
| lead_score | integer, min 0, max 100 |

## Bad Inputs To Test

```text
email = "wrong-email"
phone = "abc@@@123"
first_name = ""
status = "random_status"
priority = "super_hot"
source_channel = "unknown_channel"
lead_score = 999
assigned_to = 999999
message = "<script>alert('xss')</script>"
tags = "not-an-array"
```

## Expected Result

- Request should fail validation.
- Invalid record should not be saved.
- User should see clear error messages.
- API should return `422 Unprocessable Entity`.
- Script input should never execute in the browser.

## Example Test

```php
public function test_lead_requires_valid_email(): void
{
    $user = User::factory()->create();

    $response = $this->actingAs($user)->post('/leads', [
        'first_name' => 'John',
        'email' => 'wrong-email',
        'phone' => '+1234567890',
    ]);

    $response->assertSessionHasErrors(['email']);

    $this->assertDatabaseMissing('leads', [
        'email' => 'wrong-email',
    ]);
}
```

---

# 5. Lead Status Validation

## Route

```text
PATCH /leads/{lead}/status
```

## Allowed Status Values

```text
new
contacted
under_review
meeting_scheduled
closed_won
closed_lost
```

## Bad Inputs

```text
status = "done"
status = "paid"
status = "deleted"
status = ""
status = null
```

## Expected Result

- Invalid status should be rejected.
- Existing lead status should remain unchanged.
- Status change interaction should not be created for failed requests.

## Example Test

```php
public function test_invalid_lead_status_is_rejected(): void
{
    $user = User::factory()->create();
    $lead = Lead::factory()->create([
        'status' => LeadStatus::NEW,
    ]);

    $response = $this->actingAs($user)->patch("/leads/{$lead->id}/status", [
        'status' => 'done',
    ]);

    $response->assertSessionHasErrors(['status']);

    $this->assertDatabaseHas('leads', [
        'id' => $lead->id,
        'status' => LeadStatus::NEW->value,
    ]);
}
```

---

# 6. Lead Assignment Validation

## Route

```text
PATCH /leads/{lead}/assign
```

## Validation Rules

| Field | Rule |
|---|---|
| assigned_to | required, exists:users,id |
| assigned user | must be active |
| assigned user role | should be sales rep, manager, admin, or allowed CRM user |

## Bad Inputs

```text
assigned_to = 999999
assigned_to = "abc"
assigned_to = inactive_user_id
assigned_to = viewer_user_id
```

## Expected Result

- Invalid user assignment should fail.
- Lead assignee should not change.
- Assignment history should not be created.

---

# 7. Lead Notes Validation

## Route

```text
POST /leads/{lead}/notes
```

## Fields

| Field | Rule |
|---|---|
| body | required, string, max length |
| type | nullable, allowed note type |

## Bad Inputs

```text
body = ""
body = very large text above allowed limit
body = "<script>alert(1)</script>"
type = "random_type"
```

## Expected Result

- Empty notes should be rejected.
- Long notes should be rejected or trimmed based on business rule.
- Script should be safely escaped in Blade.
- Invalid note type should be rejected.

---

# 8. Webhook Validation Testing

## Module

External Lead Intake

## Routes To Test

```text
POST /api/v1/leads/webhook
POST /api/v1/leads/jotform
POST /api/v1/leads/google-form
POST /api/v1/leads/website
POST /api/v1/leads/whatsapp
POST /api/v1/leads/email
POST /api/v1/webhooks/meta
POST /api/v1/webhooks/google-leads
POST /api/v1/webhooks/calendly
```

## Security Validation

| Test Case | Expected Result |
|---|---|
| Missing webhook secret | reject request |
| Wrong webhook secret | reject request |
| Missing HMAC for HMAC-based services | reject request |
| Invalid HMAC signature | reject request |
| Disabled integration channel | reject request or ignore safely |
| Unknown source channel | reject request |

## Payload Validation

| Test Case | Expected Result |
|---|---|
| Empty JSON body | reject |
| Invalid JSON | reject |
| Missing email and phone | reject or save as incomplete depending on business rule |
| Invalid email | reject |
| Invalid phone | reject |
| Unknown enum values | reject |
| Very large message | reject |
| Nested unexpected payload | ignore unknown keys safely |
| Duplicate email | merge with existing lead |
| Duplicate phone | merge with existing lead |

## Example Test: Invalid Secret

```php
public function test_webhook_rejects_invalid_secret(): void
{
    $response = $this->postJson('/api/v1/leads/webhook', [
        'first_name' => 'John',
        'email' => 'john@example.com',
        'phone' => '+1234567890',
    ], [
        'X-Webhook-Secret' => 'wrong-secret',
    ]);

    $response->assertStatus(403);
}
```

## Example Test: Invalid Payload

```php
public function test_webhook_rejects_invalid_email(): void
{
    $response = $this->postJson('/api/v1/leads/webhook', [
        'first_name' => 'John',
        'email' => 'not-valid-email',
        'phone' => '+1234567890',
    ], [
        'X-Webhook-Secret' => config('services.webhook.secret'),
    ]);

    $response->assertStatus(422);
    $response->assertJsonValidationErrors(['email']);
}
```

---

# 9. Duplicate Lead Validation

## Rules To Confirm

The CRM should check duplicate leads using:

- Same email
- Same normalized phone
- Country-code tolerant phone matching

## Test Cases

| Case | Expected Result |
|---|---|
| New lead with same email | merge into existing lead |
| New lead with same phone | merge into existing lead |
| New lead with same email and different source | add interaction log |
| New lead with new message | save as lead note |
| New lead with missing old field | backfill empty field |
| Duplicate lead assigned to another user | keep original assignee |

## Example Test

```php
public function test_duplicate_email_merges_into_existing_lead(): void
{
    $existingLead = Lead::factory()->create([
        'email' => 'driver@example.com',
        'first_name' => 'Old',
        'phone' => '+1234567890',
    ]);

    $response = $this->postJson('/api/v1/leads/webhook', [
        'first_name' => 'New',
        'email' => 'driver@example.com',
        'phone' => '+1987654321',
        'message' => 'I want to book urgently.',
    ], [
        'X-Webhook-Secret' => config('services.webhook.secret'),
    ]);

    $response->assertSuccessful();

    $this->assertEquals(1, Lead::where('email', 'driver@example.com')->count());
}
```

---

# 10. Driver Lead Validation Testing

## Module

Driver Leads

## Routes To Test

```text
POST /api/v1/driver-leads/webhook
GET /driver-leads
GET /driver-leads/{driverLead}
PATCH /driver-leads/{driverLead}/status
PATCH /driver-leads/{driverLead}/qualify
PATCH /driver-leads/{driverLead}/decline
POST /driver-leads/{driverLead}/comments
```

## Fields To Validate

| Field | Validation Rule |
|---|---|
| first_name | required, string, max length |
| last_name | nullable/string |
| email | required, valid email |
| phone | nullable, valid phone |
| country | nullable/string |
| years_racing | integer, min 0, max realistic value |
| highest_series | nullable/string |
| career_wins | integer, min 0 |
| current_team_series | nullable/string |
| instagram_handle | nullable/string |
| instagram_followers | integer, min 0 |
| seeking_sponsorship | boolean |
| status | valid enum only |
| inferred_tier | system generated, should not be directly trusted from request |

## Bad Inputs

```text
email = "driver-email"
years_racing = -3
career_wins = "many"
instagram_followers = "10k"
seeking_sponsorship = "maybe"
status = "approved"
inferred_tier = "fake_professional"
```

## Expected Result

- Invalid driver lead should not be saved.
- Tier should be calculated by system only.
- Negative racing years or career wins should be rejected.
- Boolean sponsorship field should only accept valid boolean values.
- Comments should require body text.

## Example Test

```php
public function test_driver_lead_rejects_negative_years_racing(): void
{
    $response = $this->postJson('/api/v1/driver-leads/webhook', [
        'first_name' => 'Lewis',
        'last_name' => 'Hamilton',
        'email' => 'lewis@example.com',
        'years_racing' => -5,
        'career_wins' => 10,
        'seeking_sponsorship' => true,
    ], [
        'X-Webhook-Secret' => config('services.driver_leads.secret'),
    ]);

    $response->assertStatus(422);
    $response->assertJsonValidationErrors(['years_racing']);
}
```

---

# 11. Driver Tier Logic Validation

## Auto-Tier Rules

```text
If years_racing >= 5 AND career_wins >= 20 → Professional
Else if years_racing >= 3 AND career_wins >= 5 → Pro-Am
Else → Amateur
```

## Test Cases

| years_racing | career_wins | Expected Tier |
|---:|---:|---|
| 6 | 25 | professional |
| 3 | 5 | pro_am |
| 1 | 0 | amateur |
| 5 | 19 | pro_am |
| 2 | 20 | amateur |

## Expected Result

- Tier should be calculated automatically.
- User request should not be able to force tier.
- Tier changes should be logged in tier history.

---

# 12. Sponsor Profile Validation Testing

## Module

Sponsors & Vendors

## Routes

```text
POST /sponsors
PUT /sponsors/{sponsor}
DELETE /sponsors/{sponsor}
POST /sponsors/{sponsor}/activities
POST /sponsors/{sponsor}/link-driver
PATCH /sponsor-driver-links/{link}
DELETE /sponsor-driver-links/{link}
```

## Sponsor Fields

| Field | Validation Rule |
|---|---|
| company_name | required, string, max length |
| type | valid sponsor profile type enum |
| status | valid sponsor status enum |
| contact_name | nullable/string |
| email | nullable/email |
| phone | nullable/valid phone |
| website | nullable/url |
| assigned_to | nullable/exists users |
| notes | nullable/string/max length |

## Bad Inputs

```text
company_name = ""
type = "random_company_type"
status = "paid"
email = "not-email"
website = "not-url"
assigned_to = 999999
```

## Expected Result

- Invalid sponsor profile should not save.
- Invalid enum values should fail validation.
- Invalid website or email should show error.

---

# 13. Sponsorship Deal Validation Testing

## Module

Sponsorship Pipeline

## Routes

```text
GET /sponsorship-pipeline
POST /sponsorship-pipeline
PATCH /sponsorship-pipeline/{deal}/stage
DELETE /sponsorship-pipeline/{deal}
```

## Fields

| Field | Validation Rule |
|---|---|
| sponsor_id | required, exists:sponsor_profiles,id |
| title | required, string |
| stage | valid sponsorship stage enum |
| value | numeric, min 0 |
| probability | integer, min 0, max 100 |
| assigned_to | nullable, exists users |
| expected_close_date | nullable/date |
| notes | nullable/string |

## Bad Inputs

```text
sponsor_id = 999999
title = ""
stage = "money_received"
value = -500
probability = 150
expected_close_date = "not-a-date"
```

## Expected Result

- Deal should not save with invalid sponsor.
- Probability should not exceed 100.
- Negative deal value should be rejected.
- Invalid stage should not move Kanban card.

---

# 14. Sponsor Activity Validation Testing

## Module

Vendor Action Tracking

## Fields

| Field | Validation Rule |
|---|---|
| action_type | valid sponsor action type enum |
| description | nullable/string/max length |
| due_date | nullable/date |
| sponsor_id | exists sponsor_profiles |
| deal_id | nullable/exists sponsorship_deals |
| driver_lead_id | nullable/exists driver_leads |
| attachment | nullable/file/allowed types/max size |

## Bad Inputs

```text
action_type = "random_action"
due_date = "tomorrow-ish"
deal_id = 999999
driver_lead_id = 999999
attachment = malware.exe
attachment = file larger than allowed size
```

## Expected Result

- Invalid action type should fail.
- Unsafe attachment should be rejected.
- Missing linked records should fail.
- Completed action should not accept invalid completion data.

---

# 15. Sponsor To Driver Link Validation

## Route

```text
POST /sponsors/{sponsor}/link-driver
```

## Fields

| Field | Validation Rule |
|---|---|
| driver_lead_id | required, exists driver_leads |
| sponsorship_deal_id | nullable, exists sponsorship_deals |
| funding_type | valid funding type enum |
| funding_amount | nullable/numeric/min 0 |
| start_date | nullable/date |
| end_date | nullable/date/after_or_equal:start_date |
| status | valid link status |

## Bad Inputs

```text
driver_lead_id = 999999
funding_type = "crypto"
funding_amount = -100
start_date = "2026-01-10"
end_date = "2025-01-10"
```

## Expected Result

- Fake driver link should not be created.
- Negative funding amount should fail.
- End date before start date should fail.
- Invalid funding type should fail.

---

# 16. Lead Import Validation Testing

## Module

CSV / XLSX / PDF Lead Imports

## Routes

```text
GET /leads/import
POST /leads/import/preview
POST /leads/import/confirm
GET /leads/import/batches
GET /leads/import/batches/{batch}
```

## File Validation

| File Type | Validation Rule |
|---|---|
| CSV | allowed extension, valid rows |
| XLSX | allowed extension, readable workbook |
| PDF | allowed extension, parseable text |
| Other files | reject |
| Empty file | reject |
| Oversized file | reject |

## Row Validation

| Field | Rule |
|---|---|
| email | valid email if present |
| phone | valid phone if present |
| name | required if email/phone missing |
| source | valid source enum or mapped safely |
| message | max length |
| status | valid status enum |
| priority | valid priority enum |

## Bad Import Cases

```text
Empty CSV
CSV with missing headers
CSV with wrong delimiter
XLSX with merged/unreadable columns
PDF with no parseable text
File type .exe
File size above limit
Rows with invalid email
Rows with invalid phone
Rows with no name/email/phone
Rows with invalid status
Rows with invalid priority
```

## Expected Result

- Invalid file should be rejected.
- Bad rows should be marked with row-level errors.
- Valid rows should still import if partial import is allowed.
- Duplicate rows should merge with existing leads.
- Import summary should show successful and failed rows.

## Example Expected Import Summary

```text
30 rows imported successfully.
4 rows failed.

Row 3: Invalid email address.
Row 7: Missing email or phone.
Row 12: Invalid status.
Row 19: Duplicate lead merged with existing record.
```

---

# 17. User Management Validation

## Module

Users & Roles

## Routes

```text
POST /users
PUT /users/{user}
PATCH /users/{user}/toggle-active
```

## Fields

| Field | Rule |
|---|---|
| name | required, string |
| email | required, valid email, unique |
| password | required on create, confirmed, minimum length |
| role | valid UserRole enum |
| is_active | boolean |
| avatar | nullable/image/max size |

## Bad Inputs

```text
email = "not-email"
email = existing user email
password = "123"
password_confirmation = "different"
role = "owner"
avatar = document.pdf
```

## Expected Result

- Invalid user should not be created.
- Duplicate email should fail.
- Invalid role should fail.
- Weak password should fail.
- Invalid avatar should be rejected.

---

# 18. Role-Based Input Validation

Validation must also protect against users manually sending requests they should not be allowed to send.

## Roles

```text
super_admin
admin
sales_manager
sales_rep
viewer
```

## Test Cases

| User Role | Test | Expected Result |
|---|---|---|
| Viewer | tries to create lead | 403 Forbidden |
| Viewer | tries to edit lead | 403 Forbidden |
| Viewer | tries to delete lead | 403 Forbidden |
| Sales Rep | tries to assign lead to another user | 403 Forbidden |
| Sales Rep | tries to view another rep's assigned lead | 403 Forbidden |
| Sales Rep | tries to export all leads | 403 Forbidden |
| Sales Manager | assigns lead | allowed |
| Admin | manages users | allowed |
| Admin | views Super Admin restricted logs | forbidden if restricted |
| Super Admin | full access | allowed |

## Example Test

```php
public function test_viewer_cannot_create_lead(): void
{
    $viewer = User::factory()->create([
        'role' => UserRole::VIEWER,
    ]);

    $response = $this->actingAs($viewer)->post('/leads', [
        'first_name' => 'John',
        'email' => 'john@example.com',
    ]);

    $response->assertForbidden();

    $this->assertDatabaseMissing('leads', [
        'email' => 'john@example.com',
    ]);
}
```

---

# 19. XSS And Script Injection Testing

## Inputs To Test

Test script injection in:

- Lead name
- Lead message
- Lead notes
- Driver lead comments
- Sponsor notes
- Sponsor activity description
- Company name
- Import file values

## Bad Inputs

```html
<script>alert('xss')</script>
<img src=x onerror=alert(1)>
<a href="javascript:alert(1)">Click</a>
```

## Expected Result

- Input should either be sanitized or escaped when rendered.
- Script should never execute.
- Blade templates should use escaped output:

```php
{{ $lead->message }}
```

Avoid unsafe output unless properly sanitized:

```php
{!! $lead->message !!}
```

---

# 20. Oversized Input Validation

## Test Cases

| Input | Expected Result |
|---|---|
| first_name with 10,000 characters | reject |
| message with very large content | reject |
| JSON payload with huge nested object | reject |
| CSV file above size limit | reject |
| PDF file above size limit | reject |
| note body above max limit | reject |

## Recommended Limits

| Field | Suggested Limit |
|---|---:|
| first_name | 100 |
| last_name | 100 |
| email | 255 |
| phone | 30 |
| company | 255 |
| city/state/country | 100 |
| message | 5000 |
| note body | 5000 |
| sponsor activity description | 5000 |
| file upload | 5MB to 10MB depending on requirement |

---

# 21. API Error Response Standards

For API/webhook validation errors, use consistent JSON responses.

## Validation Error

```json
{
  "message": "The given data was invalid.",
  "errors": {
    "email": ["The email field must be a valid email address."]
  }
}
```

## Unauthorized Webhook

```json
{
  "message": "Invalid webhook secret."
}
```

## Forbidden Role Action

```json
{
  "message": "This action is unauthorized."
}
```

---

# 22. Blade Form Error Standards

Every form field should display validation errors using:

```blade
<x-input-error :messages="$errors->get('email')" class="mt-2" />
```

Or standard Blade:

```blade
@error('email')
    <p class="text-sm text-red-600">{{ $message }}</p>
@enderror
```

---

# 23. Recommended FormRequest Classes

Create or confirm these request classes:

```text
app/Http/Requests/StoreLeadRequest.php
app/Http/Requests/UpdateLeadRequest.php
app/Http/Requests/UpdateLeadStatusRequest.php
app/Http/Requests/AssignLeadRequest.php
app/Http/Requests/StoreLeadNoteRequest.php

app/Http/Requests/Webhooks/GenericLeadWebhookRequest.php
app/Http/Requests/Webhooks/WebsiteLeadWebhookRequest.php
app/Http/Requests/Webhooks/DriverLeadWebhookRequest.php
app/Http/Requests/Webhooks/MetaLeadWebhookRequest.php
app/Http/Requests/Webhooks/GoogleLeadWebhookRequest.php

app/Http/Requests/StoreDriverLeadCommentRequest.php
app/Http/Requests/UpdateDriverLeadStatusRequest.php

app/Http/Requests/StoreSponsorProfileRequest.php
app/Http/Requests/UpdateSponsorProfileRequest.php
app/Http/Requests/StoreSponsorshipDealRequest.php
app/Http/Requests/MoveSponsorshipStageRequest.php
app/Http/Requests/StoreSponsorActivityRequest.php
app/Http/Requests/StoreSponsorDriverLinkRequest.php

app/Http/Requests/ImportLeadPreviewRequest.php
app/Http/Requests/ImportLeadConfirmRequest.php

app/Http/Requests/StoreUserRequest.php
app/Http/Requests/UpdateUserRequest.php
```

---

# 24. Validation Rule Examples

## Lead Request Example

```php
public function rules(): array
{
    return [
        'first_name' => ['required', 'string', 'max:100'],
        'last_name' => ['nullable', 'string', 'max:100'],
        'email' => ['nullable', 'email', 'max:255'],
        'phone' => ['nullable', 'string', 'max:30'],
        'country' => ['nullable', 'string', 'max:100'],
        'city' => ['nullable', 'string', 'max:100'],
        'loc_state' => ['nullable', 'string', 'max:100'],
        'company' => ['nullable', 'string', 'max:255'],
        'message' => ['nullable', 'string', 'max:5000'],
        'status' => ['nullable', Rule::enum(LeadStatus::class)],
        'priority' => ['nullable', Rule::enum(LeadPriority::class)],
        'source_channel' => ['nullable', Rule::enum(SourceChannel::class)],
        'motorsport_interest_type' => ['nullable', Rule::enum(MotorsportInterest::class)],
        'assigned_to' => ['nullable', 'exists:users,id'],
        'tags' => ['nullable', 'array'],
    ];
}
```

## Driver Lead Request Example

```php
public function rules(): array
{
    return [
        'first_name' => ['required', 'string', 'max:100'],
        'last_name' => ['nullable', 'string', 'max:100'],
        'email' => ['required', 'email', 'max:255'],
        'phone' => ['nullable', 'string', 'max:30'],
        'country' => ['nullable', 'string', 'max:100'],
        'years_racing' => ['required', 'integer', 'min:0', 'max:80'],
        'highest_series' => ['nullable', 'string', 'max:255'],
        'career_wins' => ['required', 'integer', 'min:0', 'max:10000'],
        'current_team_series' => ['nullable', 'string', 'max:255'],
        'instagram_handle' => ['nullable', 'string', 'max:100'],
        'instagram_followers' => ['nullable', 'integer', 'min:0'],
        'seeking_sponsorship' => ['required', 'boolean'],
    ];
}
```

---

# 25. Manual QA Checklist

Use this checklist before marking validation testing complete.

```text
[ ] Lead create form rejects invalid email.
[ ] Lead edit form rejects invalid enum values.
[ ] Lead status cannot be changed to invalid status.
[ ] Lead assignment rejects invalid users.
[ ] Lead notes reject empty body.
[ ] Webhook rejects missing secret.
[ ] Webhook rejects wrong secret.
[ ] Webhook rejects invalid JSON.
[ ] Webhook rejects invalid email.
[ ] Webhook handles duplicate email correctly.
[ ] Webhook handles duplicate phone correctly.
[ ] Driver lead webhook rejects negative years racing.
[ ] Driver lead webhook rejects invalid career wins.
[ ] Driver tier is calculated by system.
[ ] Sponsor profile rejects invalid company type.
[ ] Sponsor deal rejects negative value.
[ ] Sponsor deal rejects probability above 100.
[ ] Sponsor-driver link rejects fake driver id.
[ ] Sponsor attachment rejects unsafe file type.
[ ] CSV import rejects invalid file.
[ ] XLSX import rejects unreadable file.
[ ] PDF import handles parsing errors safely.
[ ] Import shows row-level validation errors.
[ ] Viewer cannot create/edit/delete.
[ ] Sales Rep cannot access other rep's leads.
[ ] Sales Rep cannot assign lead to another user.
[ ] XSS payload does not execute.
[ ] Oversized input is rejected.
[ ] API validation responses return 422.
[ ] Forbidden role actions return 403.
[ ] All validation errors are readable in UI.
[ ] php artisan test passes.
```

---

# 26. Priority Order For Developer

## Phase 1: Critical Security

1. Webhook secret validation
2. Role-based validation
3. XSS testing
4. File upload validation

## Phase 2: Core CRM Data Quality

1. Lead create/edit validation
2. Lead assignment validation
3. Lead status validation
4. Duplicate email/phone validation

## Phase 3: Module Validation

1. Driver lead validation
2. Sponsor profile validation
3. Sponsorship deal validation
4. Sponsor-driver link validation

## Phase 4: Import Validation

1. CSV validation
2. XLSX validation
3. PDF validation
4. Row-level error reporting

## Phase 5: Final QA

1. UI validation messages
2. API error response consistency
3. Full regression test using `php artisan test`

---

# 27. Developer Notes

The best implementation approach is:

1. Use **FormRequest classes** for every Blade form.
2. Use separate **API request validators** for webhooks.
3. Keep file import validation inside the existing import validation service.
4. Never trust enum values coming from request payloads.
5. Never trust role permissions from the frontend UI.
6. Always validate again in backend controllers or policies.
7. Use Laravel policies/gates for authorization.
8. Use database transactions for imports and complex multi-table writes.
9. Log rejected webhook requests for debugging without exposing secrets.
10. Escape all user-generated text in Blade views.

---

# 28. Completion Definition

Input validation testing is complete when:

```text
- All validation test files are created.
- All critical modules have positive and negative test cases.
- Invalid inputs do not save to database.
- API validation errors are consistent.
- Blade validation messages show correctly.
- Role bypass attempts fail.
- XSS payloads do not execute.
- File imports cannot crash the system.
- Webhook security is enforced.
- php artisan test passes successfully.
```
