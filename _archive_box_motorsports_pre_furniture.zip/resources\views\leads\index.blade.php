@extends('layouts.app')
@section('title', 'Leads')

@section('header_actions')
    @can('export', App\Models\Lead::class)
        <x-export-menu route="leads.export" />
    @endcan
    @can('create', App\Models\Lead::class)
        <a href="{{ route('leads.create') }}" class="btn btn-primary"><i class="fa-solid fa-plus"></i> New Lead</a>
    @endcan
@endsection

@section('content')
{{-- Filters --}}
<x-card class="mb-6">
    @if (! empty($filters['date_preset']))
        <div class="mb-4 flex items-center gap-2 text-sm">
            <span class="ta-badge bg-brand-50 text-brand">
                <i class="fa-solid fa-calendar-day mr-1"></i>
                {{ $filters['date_preset'] === 'today' ? 'Created today' : 'Created this week' }}
            </span>
            <a href="{{ route('leads.index') }}" class="text-muted hover:text-brand">
                <i class="fa-solid fa-xmark"></i> Clear
            </a>
        </div>
    @endif
    <form method="GET" class="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-6 lg:items-end">
        @if (! empty($filters['date_preset']))
            <input type="hidden" name="date_preset" value="{{ $filters['date_preset'] }}">
        @endif
        <div class="lg:col-span-2">
            <label class="ta-label">Search</label>
            <input type="search" name="search" value="{{ $filters['search'] ?? '' }}" class="ta-input" placeholder="Name, email, phone">
        </div>
        <div>
            <label class="ta-label">Status</label>
            <select name="status" class="ta-input">
                <option value="">All</option>
                @foreach ($statuses as $s)<option value="{{ $s['value'] }}" @selected(($filters['status'] ?? '')===$s['value'])>{{ $s['label'] }}</option>@endforeach
            </select>
        </div>
        <div>
            <label class="ta-label">Source</label>
            <select name="source_channel" class="ta-input">
                <option value="">All</option>
                @foreach ($sources as $s)<option value="{{ $s['value'] }}" @selected(($filters['source_channel'] ?? '')===$s['value'])>{{ $s['label'] }}</option>@endforeach
            </select>
        </div>
        <div>
            <label class="ta-label">Priority</label>
            <select name="priority" class="ta-input">
                <option value="">All</option>
                @foreach ($priorities as $p)<option value="{{ $p['value'] }}" @selected(($filters['priority'] ?? '')===$p['value'])>{{ $p['label'] }}</option>@endforeach
            </select>
        </div>
        <div class="flex gap-2">
            <div class="flex-1">
                <label class="ta-label">Assigned</label>
                <select name="assigned_to" class="ta-input">
                    <option value="">Anyone</option>
                    <option value="unassigned" @selected(($filters['assigned_to'] ?? '')==='unassigned')>Unassigned</option>
                    @foreach ($assignableUsers as $u)<option value="{{ $u->id }}" @selected(($filters['assigned_to'] ?? '')==$u->id)>{{ $u->name }}</option>@endforeach
                </select>
            </div>
            <button class="btn btn-primary self-end"><i class="fa-solid fa-filter"></i></button>
        </div>
    </form>
</x-card>

{{-- ============ Desktop / tablet table (lg and up) ============ --}}
<x-card padding="p-0" class="hidden lg:block">
    {{-- Top scrollbar (synced) so users don't have to scroll to the bottom --}}
    <div id="leadsScrollTop" class="overflow-x-auto" style="overflow-y:hidden;">
        <div id="leadsScrollTopInner" style="height:1px;"></div>
    </div>
    <div id="leadsScrollMain" class="overflow-x-auto">
        <table id="leadsTable" class="w-full text-nowrap">
            <thead class="border-b border-line dark:border-strokedark">
                <tr>
                    <th class="ta-th">Lead</th>
                    <th class="ta-th">Contact</th>
                    <th class="ta-th">Source</th>
                    <th class="ta-th">Interest</th>
                    <th class="ta-th">Status</th>
                    <th class="ta-th">Priority</th>
                    <th class="ta-th">Assigned</th>
                    <th class="ta-th">Created</th>
                    <th class="ta-th"></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-line dark:divide-strokedark">
                @forelse ($leads as $lead)
                    <tr class="transition hover:bg-surface dark:hover:bg-boxdark/40">
                        <td class="ta-td">
                            <a href="{{ route('leads.show', $lead) }}" class="font-semibold text-ink hover:text-brand dark:text-white">{{ $lead->full_name ?: '—' }}</a>
                        </td>
                        <td class="ta-td">
                            <span class="block text-ink dark:text-gray-300">{{ $lead->email ?: '—' }}</span>
                            <span class="text-xs text-muted">{{ $lead->phone }}</span>
                        </td>
                        <td class="ta-td"><x-badge :label="$lead->source_channel->label()" :color="$lead->source_channel->color()" /></td>
                        <td class="ta-td text-muted">{{ $lead->motorsport_interest_type?->label() ?? '—' }}</td>
                        <td class="ta-td">
                            <form method="POST" action="{{ route('leads.status', $lead) }}">
                                @csrf @method('PATCH')
                                <select name="status" onchange="this.form.submit()" class="ta-input !w-auto !py-1.5 text-sm">
                                    @foreach ($statuses as $s)<option value="{{ $s['value'] }}" @selected($lead->status->value===$s['value'])>{{ $s['label'] }}</option>@endforeach
                                </select>
                            </form>
                        </td>
                        <td class="ta-td"><x-badge :label="$lead->priority->label()" :color="$lead->priority->color()" /></td>
                        <td class="ta-td">
                            @if ($lead->assignee)
                                <div class="flex items-center gap-2">
                                    <x-user-avatar :user="$lead->assignee" :px="28" text="text-[10px]" />
                                    <span class="text-ink dark:text-gray-300">{{ $lead->assignee->name }}</span>
                                </div>
                            @else
                                <span class="text-muted">Unassigned</span>
                            @endif
                        </td>
                        <td class="ta-td text-muted">{{ $lead->created_at->diffForHumans() }}</td>
                        <td class="ta-td">
                            <a href="{{ route('leads.show', $lead) }}" class="btn btn-light !px-3 !py-1.5 text-xs">View</a>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="9" class="ta-td py-12 text-center">
                        <p class="mb-3 text-muted">No leads found.</p>
                        @can('create', App\Models\Lead::class)<a href="{{ route('leads.create') }}" class="btn btn-primary"><i class="fa-solid fa-plus"></i> New Lead</a>@endcan
                    </td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="border-t border-line px-6 py-4 dark:border-strokedark">{{ $leads->links() }}</div>
</x-card>

{{-- ============ Mobile / tablet cards (below lg) ============ --}}
<div class="space-y-3 lg:hidden">
    @forelse ($leads as $lead)
        <x-card padding="p-4">
            <div class="flex items-start justify-between gap-3">
                <a href="{{ route('leads.show', $lead) }}" class="font-semibold text-ink hover:text-brand dark:text-white">{{ $lead->full_name ?: '—' }}</a>
                <x-badge :label="$lead->priority->label()" :color="$lead->priority->color()" />
            </div>
            <div class="mt-1 text-sm">
                <p class="text-ink dark:text-gray-300">{{ $lead->email ?: '—' }}</p>
                <p class="text-xs text-muted">{{ $lead->phone }}</p>
            </div>
            <div class="mt-3 flex flex-wrap items-center gap-2">
                <x-badge :label="$lead->source_channel->label()" :color="$lead->source_channel->color()" />
                @if ($lead->motorsport_interest_type)
                    <span class="ta-badge bg-surface text-muted dark:bg-boxdark">{{ $lead->motorsport_interest_type->label() }}</span>
                @endif
            </div>
            <div class="mt-3 grid grid-cols-2 gap-y-2 text-sm">
                <span class="text-muted">Status</span>
                <span class="text-right">
                    <form method="POST" action="{{ route('leads.status', $lead) }}" class="inline">
                        @csrf @method('PATCH')
                        <select name="status" onchange="this.form.submit()" class="ta-input !w-auto !py-1 text-xs">
                            @foreach ($statuses as $s)<option value="{{ $s['value'] }}" @selected($lead->status->value===$s['value'])>{{ $s['label'] }}</option>@endforeach
                        </select>
                    </form>
                </span>
                <span class="text-muted">Assigned</span>
                <span class="text-right text-ink dark:text-gray-300">{{ $lead->assignee?->name ?? 'Unassigned' }}</span>
                <span class="text-muted">Created</span>
                <span class="text-right text-muted">{{ $lead->created_at->diffForHumans() }}</span>
            </div>
            <a href="{{ route('leads.show', $lead) }}" class="btn btn-light mt-3 w-full !py-2 text-sm">View lead</a>
        </x-card>
    @empty
        <x-card padding="p-8">
            <p class="mb-3 text-center text-muted">No leads found.</p>
            @can('create', App\Models\Lead::class)<div class="text-center"><a href="{{ route('leads.create') }}" class="btn btn-primary"><i class="fa-solid fa-plus"></i> New Lead</a></div>@endcan
        </x-card>
    @endforelse
    <div>{{ $leads->links() }}</div>
</div>

@push('scripts')
<script>
    // Sync the top scrollbar with the table's horizontal scroll.
    (function () {
        var top = document.getElementById('leadsScrollTop');
        var topInner = document.getElementById('leadsScrollTopInner');
        var main = document.getElementById('leadsScrollMain');
        var table = document.getElementById('leadsTable');
        if (!top || !main || !table || !topInner) return;

        function sync() { topInner.style.width = table.scrollWidth + 'px'; }
        sync();
        window.addEventListener('resize', sync);

        var lock = false;
        top.addEventListener('scroll', function () {
            if (lock) return; lock = true; main.scrollLeft = top.scrollLeft; lock = false;
        });
        main.addEventListener('scroll', function () {
            if (lock) return; lock = true; top.scrollLeft = main.scrollLeft; lock = false;
        });
    })();
</script>
@endpush

@endsection

@section('content')
{{-- Filters --}}
<x-card class="mb-6">
    @if (! empty($filters['date_preset']))
        <div class="mb-4 flex items-center gap-2 text-sm">
            <span class="ta-badge bg-brand-50 text-brand">
                <i class="fa-solid fa-calendar-day mr-1"></i>
                {{ $filters['date_preset'] === 'today' ? 'Created today' : 'Created this week' }}
            </span>
            <a href="{{ route('leads.index') }}" class="text-muted hover:text-brand">
                <i class="fa-solid fa-xmark"></i> Clear
            </a>
        </div>
    @endif
    <form method="GET" class="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-6 lg:items-end">
        @if (! empty($filters['date_preset']))
            <input type="hidden" name="date_preset" value="{{ $filters['date_preset'] }}">
        @endif
        <div class="lg:col-span-2">
            <label class="ta-label">Search</label>
            <input type="search" name="search" value="{{ $filters['search'] ?? '' }}" class="ta-input" placeholder="Name, email, phone">
        </div>
        <div>
            <label class="ta-label">Status</label>
            <select name="status" class="ta-input">
                <option value="">All</option>
                @foreach ($statuses as $s)<option value="{{ $s['value'] }}" @selected(($filters['status'] ?? '')===$s['value'])>{{ $s['label'] }}</option>@endforeach
            </select>
        </div>
        <div>
            <label class="ta-label">Source</label>
            <select name="source_channel" class="ta-input">
                <option value="">All</option>
                @foreach ($sources as $s)<option value="{{ $s['value'] }}" @selected(($filters['source_channel'] ?? '')===$s['value'])>{{ $s['label'] }}</option>@endforeach
            </select>
        </div>
        <div>
            <label class="ta-label">Priority</label>
            <select name="priority" class="ta-input">
                <option value="">All</option>
                @foreach ($priorities as $p)<option value="{{ $p['value'] }}" @selected(($filters['priority'] ?? '')===$p['value'])>{{ $p['label'] }}</option>@endforeach
            </select>
        </div>
        <div class="flex gap-2">
            <div class="flex-1">
                <label class="ta-label">Assigned</label>
                <select name="assigned_to" class="ta-input">
                    <option value="">Anyone</option>
                    <option value="unassigned" @selected(($filters['assigned_to'] ?? '')==='unassigned')>Unassigned</option>
                    @foreach ($assignableUsers as $u)<option value="{{ $u->id }}" @selected(($filters['assigned_to'] ?? '')==$u->id)>{{ $u->name }}</option>@endforeach
                </select>
            </div>
            <button class="btn btn-primary self-end"><i class="fa-solid fa-filter"></i></button>
        </div>
    </form>
</x-card>

{{-- Table --}}
<x-card padding="p-0">
    <div class="overflow-x-auto">
        <table class="w-full text-nowrap">
            <thead class="border-b border-line dark:border-strokedark">
                <tr>
                    <th class="ta-th">Lead</th>
                    <th class="ta-th">Contact</th>
                    <th class="ta-th">Source</th>
                    <th class="ta-th">Interest</th>
                    <th class="ta-th">Status</th>
                    <th class="ta-th">Priority</th>
                    <th class="ta-th">Assigned</th>
                    <th class="ta-th">Created</th>
                    <th class="ta-th"></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-line dark:divide-strokedark">
                @forelse ($leads as $lead)
                    <tr class="transition hover:bg-surface dark:hover:bg-boxdark/40">
                        <td class="ta-td">
                            <a href="{{ route('leads.show', $lead) }}" class="font-semibold text-ink hover:text-brand dark:text-white">{{ $lead->full_name ?: '—' }}</a>
                        </td>
                        <td class="ta-td">
                            <span class="block text-ink dark:text-gray-300">{{ $lead->email ?: '—' }}</span>
                            <span class="text-xs text-muted">{{ $lead->phone }}</span>
                        </td>
                        <td class="ta-td"><x-badge :label="$lead->source_channel->label()" :color="$lead->source_channel->color()" /></td>
                        <td class="ta-td text-muted">{{ $lead->motorsport_interest_type?->label() ?? '—' }}</td>
                        <td class="ta-td">
                            <form method="POST" action="{{ route('leads.status', $lead) }}">
                                @csrf @method('PATCH')
                                <select name="status" onchange="this.form.submit()" class="ta-input !w-auto !py-1.5 text-sm">
                                    @foreach ($statuses as $s)<option value="{{ $s['value'] }}" @selected($lead->status->value===$s['value'])>{{ $s['label'] }}</option>@endforeach
                                </select>
                            </form>
                        </td>
                        <td class="ta-td"><x-badge :label="$lead->priority->label()" :color="$lead->priority->color()" /></td>
                        <td class="ta-td">
                            @if ($lead->assignee)
                                <div class="flex items-center gap-2">
                                    <x-user-avatar :user="$lead->assignee" :px="28" text="text-[10px]" />
                                    <span class="text-ink dark:text-gray-300">{{ $lead->assignee->name }}</span>
                                </div>
                            @else
                                <span class="text-muted">Unassigned</span>
                            @endif
                        </td>
                        <td class="ta-td text-muted">{{ $lead->created_at->diffForHumans() }}</td>
                        <td class="ta-td">
                            <a href="{{ route('leads.show', $lead) }}" class="btn btn-light !px-3 !py-1.5 text-xs">View</a>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="9" class="ta-td py-12 text-center">
                        <p class="mb-3 text-muted">No leads found.</p>
                        @can('create', App\Models\Lead::class)<a href="{{ route('leads.create') }}" class="btn btn-primary"><i class="fa-solid fa-plus"></i> New Lead</a>@endcan
                    </td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="border-t border-line px-6 py-4 dark:border-strokedark">{{ $leads->links() }}</div>
</x-card>
@endsection