<?php

namespace App\Http\Controllers;

use App\Enums\InteractionType;
use App\Enums\LeadPriority;
use App\Enums\LeadStatus;
use App\Enums\MotorsportInterest;
use App\Enums\SourceChannel;
use App\Enums\UserRole;
use App\Http\Requests\StoreLeadRequest;
use App\Http\Requests\UpdateLeadRequest;
use App\Models\Lead;
use App\Models\User;
use App\Services\AuditService;
use App\Services\LeadInteractionService;
use App\Services\LeadNormalizerService;
use App\Services\LeadNotificationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;

class LeadController extends Controller
{
    public function __construct(
        private LeadInteractionService $interactions,
        private LeadNormalizerService $normalizer,
        private AuditService $audit,
        private LeadNotificationService $notifier,
    ) {}

    public function index(Request $request)
    {
        Gate::authorize('viewAny', Lead::class);

        $query = Lead::query()->with(['assignee', 'creator']);

        if ($request->user()->hasRole(UserRole::SalesRep)) {
            $query->where('assigned_to', $request->user()->id);
        }

        if ($search = $request->string('search')->trim()->value()) {
            $query->where(function ($q) use ($search) {
                $q->where('full_name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%")
                  ->orWhere('phone', 'like', "%{$search}%")
                  ->orWhere('normalized_phone', 'like', "%{$search}%");
            });
        }

        foreach (['source_channel', 'status', 'priority'] as $filter) {
            if ($value = $request->string($filter)->value()) {
                $query->where($filter, $value);
            }
        }

        if ($assigned = $request->string('assigned_to')->value()) {
            $assigned === 'unassigned'
                ? $query->whereNull('assigned_to')
                : $query->where('assigned_to', $assigned);
        }

        // Date preset filter (used by dashboard "New today" / "This week" cards).
        switch ($request->string('date_preset')->value()) {
            case 'today':
                $query->whereDate('created_at', today());
                break;
            case 'week':
                $query->where('created_at', '>=', now()->startOfWeek());
                break;
        }

        $sort = $request->string('sort', 'newest')->value();
        $query->orderBy('created_at', $sort === 'oldest' ? 'asc' : 'desc');

        $leads = $query->paginate(20)->withQueryString();

        return view('leads.index', [
            'leads'             => $leads,
            'statuses'          => LeadStatus::options(),
            'priorities'        => LeadPriority::options(),
            'sources'           => SourceChannel::options(),
            'assignableUsers'   => $this->assignableUsers(),
            'filters'           => $request->only(['search', 'source_channel', 'status', 'priority', 'assigned_to', 'sort', 'date_preset']),
        ]);
    }

    public function create()
    {
        Gate::authorize('create', Lead::class);
        return view('leads.create', $this->formData());
    }

    public function store(StoreLeadRequest $request)
    {
        $data = $request->validated();

        $names = $this->normalizer->names($data['first_name'] ?? null, $data['last_name'] ?? null);
        $lead = new Lead($data);
        $lead->fill($names);
        $lead->email            = $this->normalizer->email($data['email'] ?? null);
        $lead->normalized_phone = $this->normalizer->phone($data['phone'] ?? null);
        $lead->ip_address       = $request->ip();
        $lead->created_by       = Auth::id();
        // A Sales Rep can only view leads assigned to them. Force their new leads
        // to be assigned to themselves (ignore any assignee picked in the form),
        // otherwise they'd get 403 on the lead they just created.
        if ($request->user()->hasRole(UserRole::SalesRep)) {
            $lead->assigned_to = Auth::id();
        }
        $lead->last_activity_at = now();
        $lead->save();

        $this->interactions->record($lead, InteractionType::CREATED, 'Lead created manually.');
        $this->audit->log('lead.created', $lead, "Lead #{$lead->id} created");

        return redirect()->route('leads.show', $lead)->with('toast', 'Lead created successfully.');
    }

    public function show(Lead $lead)
    {
        Gate::authorize('view', $lead);

        $lead->load([
            'assignee', 'creator',
            'interactions.performer',
            'notes.user',
            'rawPayloads',
        ]);

        return view('leads.show', [
            'lead'            => $lead,
            'statuses'        => LeadStatus::options(),
            'priorities'      => LeadPriority::options(),
            'assignableUsers' => $this->assignableUsers(),
        ]);
    }

    public function edit(Lead $lead)
    {
        Gate::authorize('update', $lead);
        return view('leads.edit', array_merge($this->formData(), ['lead' => $lead]));
    }

    public function update(UpdateLeadRequest $request, Lead $lead)
    {
        $data = $request->validated();
        $original = $lead->getRawOriginal();

        $names = $this->normalizer->names($data['first_name'] ?? null, $data['last_name'] ?? null);
        $lead->fill($data);
        $lead->fill($names);
        $lead->email            = $this->normalizer->email($data['email'] ?? null);
        $lead->normalized_phone = $this->normalizer->phone($data['phone'] ?? null);

        $statusChanged   = $lead->status->value !== ($original['status'] ?? null);
        $priorityChanged = $lead->priority->value !== ($original['priority'] ?? null);

        $lead->save();

        if ($statusChanged) {
            $this->interactions->record(
                $lead, InteractionType::STATUS_CHANGED, 'Status updated.',
                LeadStatus::from($original['status'])->label(), $lead->status->label()
            );
        }

        if ($priorityChanged) {
            $this->interactions->record(
                $lead, InteractionType::PRIORITY_CHANGED, 'Priority updated.',
                LeadPriority::from($original['priority'])->label(), $lead->priority->label()
            );
        }

        $this->interactions->record($lead, InteractionType::LEAD_EDITED, 'Lead details edited.');
        $this->audit->log('lead.updated', $lead, "Lead #{$lead->id} updated");

        return redirect()->route('leads.show', $lead)->with('toast', 'Lead updated.');
    }

    public function updateStatus(Request $request, Lead $lead)
    {
        Gate::authorize('update', $lead);

        $validated = $request->validate([
            'status' => ['required', new \Illuminate\Validation\Rules\Enum(LeadStatus::class)],
        ]);

        $old = $lead->status;
        $new = LeadStatus::from($validated['status']);

        if ($old === $new) {
            return back();
        }

        $lead->update(['status' => $new]);

        $this->interactions->record(
            $lead, $this->statusInteractionType($new), 'Status updated.',
            $old->label(), $new->label()
        );
        $this->audit->log('lead.status_changed', $lead, "Status {$old->label()} -> {$new->label()}");

        if ($request->wantsJson()) {
            return response()->json(['status' => $new->value, 'label' => $new->label(), 'color' => $new->color()]);
        }

        return back()->with('toast', "Status changed to {$new->label()}.");
    }

    public function assign(Request $request, Lead $lead)
    {
        Gate::authorize('assign', $lead);

        $validated = $request->validate([
            'assigned_to' => ['nullable', 'exists:users,id'],
        ]);

        $oldUser = $lead->assignee?->name ?? 'Unassigned';
        $lead->update(['assigned_to' => $validated['assigned_to'] ?? null]);
        $lead->refresh()->load('assignee');
        $newUser = $lead->assignee?->name ?? 'Unassigned';

        $lead->assignments()->create([
            'assigned_to' => $lead->assigned_to,
            'assigned_by' => Auth::id(),
        ]);

        $this->interactions->record(
            $lead, InteractionType::USER_ASSIGNED, 'Lead reassigned.', $oldUser, $newUser
        );
        $this->audit->log('lead.assigned', $lead, "Assigned to {$newUser}");

        if ($lead->assignee) {
            $this->notifier->assigned($lead, $lead->assignee, Auth::user()->name);
        }

        return back()->with('toast', "Lead assigned to {$newUser}.");
    }

    public function markHot(Lead $lead)
    {
        Gate::authorize('update', $lead);

        $lead->update(['priority' => LeadPriority::Hot]);
        $this->interactions->record($lead, InteractionType::HOT_MARKED, 'Lead marked as hot.');

        return back()->with('toast', 'Lead marked as hot.');
    }

    public function destroy(Lead $lead)
    {
        Gate::authorize('delete', $lead);

        $this->interactions->record($lead, InteractionType::DELETED, 'Lead soft-deleted.');
        $this->audit->log('lead.deleted', $lead, "Lead #{$lead->id} deleted");
        $lead->delete();

        return redirect()->route('leads.index')->with('toast', 'Lead moved to Trash.');
    }

    /** GET leads/trash — list soft-deleted leads. */
    public function trash(Request $request)
    {
        Gate::authorize('viewAny', Lead::class);

        $query = Lead::onlyTrashed()->with(['assignee', 'creator']);

        if ($request->user()->hasRole(UserRole::SalesRep)) {
            $query->where('assigned_to', $request->user()->id);
        }

        if ($search = $request->string('search')->trim()->value()) {
            $query->where(function ($q) use ($search) {
                $q->where('full_name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%")
                  ->orWhere('phone', 'like', "%{$search}%");
            });
        }

        $leads = $query->latest('deleted_at')->paginate(20)->withQueryString();

        return view('leads.trash', compact('leads'));
    }

    /** DELETE leads/{id}/force — permanently remove a trashed lead. */
    public function forceDelete(int $leadId)
    {
        $lead = Lead::withTrashed()->findOrFail($leadId);
        Gate::authorize('delete', $lead);

        $this->audit->log('lead.force_deleted', null, "Lead #{$lead->id} permanently deleted");
        $lead->forceDelete();

        return redirect()->route('leads.trash')->with('toast', 'Lead permanently deleted.');
    }

    public function restore(int $leadId)
    {
        $lead = Lead::withTrashed()->findOrFail($leadId);
        Gate::authorize('restore', $lead);

        $lead->restore();
        $this->interactions->record($lead, InteractionType::RESTORED, 'Lead restored.');
        $this->audit->log('lead.restored', $lead, "Lead #{$lead->id} restored");

        return redirect()->route('leads.trash')->with('toast', 'Lead restored.');
    }

    private function statusInteractionType(LeadStatus $status): string
    {
        return match ($status) {
            LeadStatus::ClosedWon        => InteractionType::CLOSED_WON,
            LeadStatus::ClosedLost       => InteractionType::CLOSED_LOST,
            LeadStatus::MeetingScheduled => InteractionType::MEETING_SCHEDULED,
            default                      => InteractionType::STATUS_CHANGED,
        };
    }

    private function assignableUsers()
    {
        return User::where('is_active', true)
            ->whereIn('role', [
                UserRole::SuperAdmin->value, UserRole::Admin->value,
                UserRole::SalesManager->value, UserRole::SalesRep->value,
            ])
            ->orderBy('name')
            ->get(['id', 'name', 'avatar_color']);
    }

    private function formData(): array
    {
        return [
            'statuses'        => LeadStatus::options(),
            'priorities'      => LeadPriority::options(),
            'sources'         => SourceChannel::options(),
            'interests'       => MotorsportInterest::options(),
            'assignableUsers' => $this->assignableUsers(),
        ];
    }
}