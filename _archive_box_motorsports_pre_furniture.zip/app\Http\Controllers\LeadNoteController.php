<?php

namespace App\Http\Controllers;

use App\Enums\InteractionType;
use App\Http\Requests\StoreNoteRequest;
use App\Models\Lead;
use App\Services\LeadInteractionService;
use Illuminate\Support\Facades\Auth;

class LeadNoteController extends Controller
{
    public function __construct(private LeadInteractionService $interactions) {}

    public function store(StoreNoteRequest $request, Lead $lead)
    {
        $data = $request->validated();

        $lead->notes()->create([
            'user_id' => Auth::id(),
            'body'    => $data['body'],
            'type'    => $data['type'],
        ]);

        $type = match ($data['type']) {
            'call'    => InteractionType::CALL_LOGGED,
            'meeting' => InteractionType::MEETING_NOTE,
            default   => InteractionType::NOTE_ADDED,
        };

        $this->interactions->record(
            $lead, $type, str($data['body'])->limit(140)->value()
        );

        return back()->with('toast', 'Note added.');
    }
}
