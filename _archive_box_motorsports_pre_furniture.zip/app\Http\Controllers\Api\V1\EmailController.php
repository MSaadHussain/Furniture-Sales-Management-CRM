<?php

namespace App\Http\Controllers\Api\V1;

use App\Enums\SourceChannel;
use App\Services\EmailParsingService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class EmailController extends WebhookController
{
    public function __invoke(Request $request): JsonResponse
    {
        $parser = app(EmailParsingService::class);
        $normalized = $parser->normalize($request->all());

        if (blank($normalized['email']) && blank($normalized['phone'])) {
            return response()->json([
                'success' => false,
                'message' => 'No usable contact info in email.',
            ], 422);
        }

        return $this->process(SourceChannel::Email, $normalized, $request);
    }
}
