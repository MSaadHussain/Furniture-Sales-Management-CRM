@component('mail::message')
# New User Approval Code

A request to create a new CRM user needs your approval.

@component('mail::panel')
**New user:** {{ $newUserName }}

**Email:** {{ $newUserEmail }}

**Requested by:** {{ $requestedBy }}
@endcomponent

Use this one-time code to approve the creation:

@component('mail::panel')
# {{ $otp }}
@endcomponent

This code expires in **{{ $expiryMinutes }} minutes**. If you did not expect this request, you can ignore this email and the user will not be created.

Thanks,<br>
{{ config('app.name') }}
@endcomponent
