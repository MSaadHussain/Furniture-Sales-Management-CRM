<?php

namespace App\Services;

use App\Enums\InteractionType;
use App\Enums\LeadPriority;
use App\Enums\SourceChannel;
use App\Events\HotLeadReceived;
use App\Events\LeadCreated;
use App\Models\Lead;
use App\Models\LeadRawPayload;
use Illuminate\Support\Facades\DB;

class LeadIntakeService
{
    public function __construct(
        private LeadNormalizerService $normalizer,
        private LeadDeduplicationService $dedup,
        private LeadScoringService $scoring,
        private LeadInteractionService $interactions,
    ) {}

    public function ingest(SourceChannel $channel, array $payload, ?string $ip = null): array
    {
        $rawPayload = LeadRawPayload::create([
            'source_channel' => $channel->value,
            'payload'        => $payload,
            'ip_address'     => $ip,
            'processed'      => false,
        ]);

        try {
            return DB::transaction(function () use ($channel, $payload, $ip, $rawPayload) {
                $attributes = $this->normalizer->fromPayload($channel, $payload);

                $existing = $this->dedup->findDuplicate(
                    $attributes['email'] ?? null,
                    $attributes['phone'] ?? null
                );

                if ($existing) {
                    return [$this->mergeIntoExisting($existing, $attributes, $channel, $rawPayload), false];
                }

                return [$this->createNew($attributes, $channel, $ip, $rawPayload), true];
            });
        } catch (\Throwable $e) {
            $rawPayload->update(['error' => $e->getMessage()]);
            throw $e;
        }
    }

    private function createNew(array $attributes, SourceChannel $channel, ?string $ip, LeadRawPayload $rawPayload): Lead
    {
        $lead = new Lead($attributes);
        $lead->ip_address       = $ip;
        $lead->last_activity_at = now();
        $this->scoring->apply($lead, submissionCount: 1);
        app(\App\Services\LeadLocationService::class)->stampLead($lead);
        $lead->save();

        $rawPayload->update(['lead_id' => $lead->id, 'processed' => true]);

        $this->interactions->record(
            $lead, InteractionType::CREATED,
            "Lead created from {$channel->label()}.",
            sourceChannel: $channel->value
        );
        $this->interactions->record(
            $lead, InteractionType::WEBHOOK_RECEIVED,
            "Webhook received from {$channel->label()}.",
            sourceChannel: $channel->value,
            metadata: ['raw_payload_id' => $rawPayload->id]
        );

        $this->channelSpecificInteraction($lead, $channel);

        event(new LeadCreated($lead));
        if ($lead->priority === LeadPriority::Hot) {
            event(new HotLeadReceived($lead));
        }

        return $lead;
    }

    private function mergeIntoExisting(Lead $lead, array $attributes, SourceChannel $channel, LeadRawPayload $rawPayload): Lead
    {
        $submissionCount = $lead->rawPayloads()->count() + 1;
        $wasHot = $lead->priority === LeadPriority::Hot;

        foreach (['email', 'phone', 'normalized_phone', 'loc_state', 'motorsport_interest_type'] as $field) {
            if (blank($lead->$field) && filled($attributes[$field] ?? null)) {
                $lead->$field = $attributes[$field];
            }
        }

        $newSource = $channel->value;
        if ($lead->source_channel->value !== $newSource) {
            $this->interactions->record(
                $lead, InteractionType::WEBHOOK_RECEIVED,
                "Additional submission from a new channel ({$channel->label()}).",
                oldValue: $lead->source_channel->label(),
                newValue: $channel->label(),
                sourceChannel: $newSource
            );
        }

        $this->scoring->apply($lead, submissionCount: $submissionCount);
        $lead->last_activity_at = now();
        $lead->save();

        $rawPayload->update(['lead_id' => $lead->id, 'processed' => true]);

        $this->interactions->record(
            $lead, InteractionType::DUPLICATE_MERGED,
            "Duplicate submission merged from {$channel->label()} (submission #{$submissionCount}).",
            sourceChannel: $newSource,
            metadata: [
                'raw_payload_id'   => $rawPayload->id,
                'incoming_message' => $attributes['message'] ?? null,
            ]
        );

        if (filled($attributes['message'] ?? null)) {
            $lead->notes()->create([
                'user_id' => null,
                'type'    => 'note',
                'body'    => "[{$channel->label()} submission] " . $attributes['message'],
            ]);
        }

        if ($wasHot === false && $lead->priority === LeadPriority::Hot) {
            event(new HotLeadReceived($lead));
        }

        return $lead;
    }

    private function channelSpecificInteraction(Lead $lead, SourceChannel $channel): void
    {
        match ($channel) {
            SourceChannel::WhatsApp => $this->interactions->record($lead, InteractionType::WHATSAPP_RECEIVED, 'WhatsApp message received.', sourceChannel: $channel->value),
            SourceChannel::Email    => $this->interactions->record($lead, InteractionType::EMAIL_CAPTURED, 'Email captured.', sourceChannel: $channel->value),
            default                 => null,
        };
    }
}
