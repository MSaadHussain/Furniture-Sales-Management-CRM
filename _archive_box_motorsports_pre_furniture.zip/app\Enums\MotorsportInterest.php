<?php

namespace App\Enums;

enum MotorsportInterest: string
{
    case Driver = 'driver';
    case Sponsor = 'sponsor';
    case Collaborator = 'collaborator';
    case GeneralInquiry = 'general_inquiry';
    case EventInquiry = 'event_inquiry';
    case BookingInquiry = 'booking_inquiry';
    case Other = 'other';

    public function label(): string
    {
        return match ($this) {
            self::Driver         => 'Driver',
            self::Sponsor        => 'Sponsor',
            self::Collaborator   => 'Collaborator',
            self::GeneralInquiry => 'General Inquiry',
            self::EventInquiry   => 'Event Inquiry',
            self::BookingInquiry => 'Booking Inquiry',
            self::Other          => 'Other',
        };
    }

    public static function options(): array
    {
        return array_map(
            fn (self $i) => ['value' => $i->value, 'label' => $i->label()],
            self::cases()
        );
    }
}
