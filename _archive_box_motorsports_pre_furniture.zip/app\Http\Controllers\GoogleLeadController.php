<?php

namespace App\Http\Controllers;

use App\Models\IntegrationSetting;
use App\Services\Integrations\Google\GoogleLeadApiClient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

class GoogleLeadController extends Controller
{
    public function index()
    {
        Gate::authorize('manage-integrations');

        $setting = IntegrationSetting::firstOrCreate(['channel' => 'google_lead_form'], ['enabled' => false, 'config' => []]);

        return view('integrations.google-leads', [
            'setting'    => $setting,
            'config'     => $setting->config ?? [],
            'webhookUrl' => url('/api/v1/webhooks/google-leads'),
        ]);
    }

    public function save(Request $request)
    {
        Gate::authorize('manage-integrations');

        $data = $request->validate([
            'google_client_id'     => ['nullable', 'string', 'max:191'],
            'google_client_secret' => ['nullable', 'string', 'max:191'],
            'developer_token'      => ['nullable', 'string', 'max:191'],
            'customer_id'          => ['nullable', 'string', 'max:191'],
            'refresh_token'        => ['nullable', 'string', 'max:1000'],
            'webhook_secret'       => ['nullable', 'string', 'max:191'],
            'enabled'              => ['nullable', 'boolean'],
        ]);

        $setting = IntegrationSetting::firstOrCreate(['channel' => 'google_lead_form']);
        $setting->update([
            'enabled' => $request->boolean('enabled'),
            'config'  => array_merge($setting->config ?? [], collect($data)->except('enabled')->toArray()),
        ]);

        return back()->with('toast', 'Google Leads integration saved.');
    }

    public function test(GoogleLeadApiClient $api)
    {
        Gate::authorize('manage-integrations');

        [$ok, $message] = $api->testConnection();

        return back()->with($ok ? 'toast' : 'error', $message);
    }
}
