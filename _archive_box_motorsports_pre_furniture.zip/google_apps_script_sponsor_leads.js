/**
 * Google Apps Script — Send Sponsor/Vendor form responses to Box Motorsports CRM
 *
 * SETUP:
 * 1. Link your Google Form to a response Sheet (Responses → Link to Sheets)
 * 2. In the Sheet: Extensions → Apps Script → paste this script
 * 3. Update WEBHOOK_URL and WEBHOOK_SECRET below (find them in the CRM:
 *    Integrations → Sponsor Lead Form)
 * 4. Triggers → Add Trigger → onFormSubmit → From spreadsheet → On form submit
 * 5. Save and authorize
 */

var WEBHOOK_URL    = 'YOUR_CRM_URL/api/v1/sponsor-leads/webhook';
var WEBHOOK_SECRET = 'YOUR_SPONSOR_LEADS_SECRET_HERE';

function onFormSubmit(e) {
  var v = e.namedValues || {};

  var payload = {
    company_name:      pick(v, '1. What is the official name of the Company/Brand?'),
    company_type:      pick(v, '2. Select the primary classification of this entity:'),
    industry:          pick(v, '3. What industry or sector does the company primarily operate in?'),
    website:           pick(v, "4. Provide the company's official website URL."),
    contact_name:      pick(v, '5. Primary Contact Person Name (within the company):'),
    email:             pick(v, '6. Primary Contact Email Address:'),
    phone:             pick(v, '7. Primary Contact Phone Number:'),
    partnership_scope: pick(v, '8. What is the scope of the partnership or vendor relationship?'),
    agreement_terms:   pick(v, "9. Please describe the specific terms of the agreement or provided services. (e.g., '3-year title sponsorship', 'Supply of racing tires', 'Logistics for European circuit'):"),
    country:           pick(v, 'Country'),
    city:              pick(v, 'City'),
    estimated_budget:  pick(v, 'Estimate Budget'),
  };

  var options = {
    method: 'post',
    contentType: 'application/json',
    headers: { 'X-Webhook-Secret': WEBHOOK_SECRET },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true,
  };

  var response = UrlFetchApp.fetch(WEBHOOK_URL, options);
  Logger.log('CRM Response (' + response.getResponseCode() + '): ' + response.getContentText());
}

/**
 * Reads an answer by question title. Falls back to a "starts with" match
 * (e.g. '1.' or 'Country') so minor edits to question wording don't break
 * the mapping.
 */
function pick(values, title) {
  if (values[title] && values[title][0]) {
    return String(values[title][0]).trim();
  }
  var prefix = title.split(' ')[0];
  var keys = Object.keys(values);
  for (var i = 0; i < keys.length; i++) {
    if (keys[i].indexOf(prefix) === 0 && values[keys[i]][0]) {
      return String(values[keys[i]][0]).trim();
    }
  }
  return '';
}
