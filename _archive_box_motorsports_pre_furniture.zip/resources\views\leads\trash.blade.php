@extends('layouts.app')
@section('title', 'Trash')
@section('breadcrumb')
    <a href="{{ route('leads.index') }}" class="hover:text-brand">Leads</a> / <span>Trash</span>
@endsection

@section('header_actions')
    <a href="{{ route('leads.index') }}" class="btn btn-light"><i class="fa-solid fa-arrow-left"></i> Back to Leads</a>
@endsection

@section('content')
<x-card padding="p-0">
    <div class="flex items-center justify-between border-b border-line px-6 py-4 dark:border-strokedark">
        <div>
            <h3 class="text-lg font-semibold text-ink dark:text-white">Deleted Leads</h3>
            <p class="text-sm text-muted">Restore a lead, or permanently remove it.</p>
        </div>
        <form method="GET" class="hidden sm:block">
            <input type="search" name="search" value="{{ request('search') }}" placeholder="Search trash…" class="ta-input !py-2 text-sm">
        </form>
    </div>

    <div class="overflow-x-auto">
        <table class="w-full">
            <thead class="border-b border-line dark:border-strokedark">
                <tr>
                    <th class="ta-th">Lead</th>
                    <th class="ta-th">Contact</th>
                    <th class="ta-th">Source</th>
                    <th class="ta-th">Deleted</th>
                    <th class="ta-th text-right">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-line dark:divide-strokedark">
                @forelse ($leads as $lead)
                    <tr>
                        <td class="ta-td">
                            <div class="flex items-center gap-3">
                                <span class="flex h-9 w-9 items-center justify-center rounded-full text-xs font-bold text-white"
                                      style="background-color: {{ $lead->source_channel->color() }};">
                                    {{ strtoupper(mb_substr($lead->full_name ?: 'NA', 0, 2)) }}
                                </span>
                                <span class="font-medium text-ink dark:text-gray-200">{{ $lead->full_name ?: 'Unnamed' }}</span>
                            </div>
                        </td>
                        <td class="ta-td text-muted">
                            {{ $lead->email ?: '—' }}<br><span class="text-xs">{{ $lead->phone }}</span>
                        </td>
                        <td class="ta-td"><x-badge :label="$lead->source_channel->label()" :color="$lead->source_channel->color()" /></td>
                        <td class="ta-td text-muted">{{ $lead->deleted_at?->diffForHumans() }}</td>
                        <td class="ta-td">
                            <div class="flex items-center justify-end gap-2">
                                <form method="POST" action="{{ route('leads.restore', $lead->id) }}">
                                    @csrf @method('PATCH')
                                    <button class="btn btn-light !px-3 !py-1.5 text-xs"><i class="fa-solid fa-rotate-left"></i> Restore</button>
                                </form>
                                <form method="POST" action="{{ route('leads.force', $lead->id) }}"
                                      onsubmit="return confirm('Permanently delete this lead? This cannot be undone.');">
                                    @csrf @method('DELETE')
                                    <button class="btn btn-danger !px-3 !py-1.5 text-xs"><i class="fa-solid fa-trash"></i> Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="5" class="ta-td py-12 text-center text-muted">
                        <i class="fa-solid fa-trash-can mb-2 block text-2xl"></i>
                        Trash is empty.
                    </td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="border-t border-line px-6 py-4 dark:border-strokedark">{{ $leads->links() }}</div>
</x-card>
@endsection
