<?php

namespace App\Models;

use App\Enums\SponsorActionType;
use Illuminate\Database\Eloquent\Model;

class SponsorActivity extends Model
{
    protected $fillable = [
        'sponsor_profile_id', 'sponsorship_deal_id', 'driver_lead_id',
        'action_type', 'description', 'performed_by', 'due_date',
        'completed_at', 'attachment_path',
    ];

    protected function casts(): array
    {
        return [
            'action_type'  => SponsorActionType::class,
            'due_date'     => 'date',
            'completed_at' => 'datetime',
        ];
    }

    public function sponsor()
    {
        return $this->belongsTo(SponsorProfile::class, 'sponsor_profile_id');
    }

    public function deal()
    {
        return $this->belongsTo(SponsorshipDeal::class, 'sponsorship_deal_id');
    }

    public function driverLead()
    {
        return $this->belongsTo(DriverLead::class);
    }

    public function performer()
    {
        return $this->belongsTo(User::class, 'performed_by');
    }
}
