<?php

namespace App\Http\Controllers\Api\V1\Webhooks;

use App\Http\Controllers\Controller;
use App\Services\Integrations\Meetings\CalendlyService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CalendlyWebhookController extends Controller
{
    public function __construct(private CalendlyService $service) {}

    /** POST /webhooks/calendly */
    public function receive(Request $request): JsonResponse
    {
        $raw = $request->getContent();

        if (! $this->service->verifySignature($raw, $request->header('Calendly-Webhook-Signature'))) {
            return response()->json(['success' => false, 'message' => 'Invalid signature.'], 403);
        }

        $event = $request->input('event');
        if (in_array($event, ['invitee.created', 'invitee.canceled'], true)) {
            rescue(fn () => $this->service->handleBooking($request->all()), report: true);
        }

        return response()->json(['received' => true]);
    }
}
