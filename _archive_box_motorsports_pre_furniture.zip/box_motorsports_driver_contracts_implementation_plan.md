# Box Motorsports CRM — Driver Contracts, Car Type, DOB & Tier Implementation Plan

## Purpose

This document explains how to extend the existing **Box Motorsports Laravel CRM** Driver Leads module to support:

- Driver contracts
- Manual car type selection
- Driver DOB and age group
- Racing level from Karting to Formula 1
- Improved driver tier classification
- Sponsor/contract linking
- Driver filtering for sponsorship and racing opportunities

This should be implemented inside the existing **Driver Leads** and **Vendor & Sponsor Space** modules, not as a completely separate CRM system.

---

## Important Rule

### Do Not Auto-Select Car Type

The system must **not automatically select car type** based on racing level.

Racing Level and Car Type must remain two separate fields.

Example:

```text
Racing Level: Formula 4
Car Type: Formula Car
```

Example:

```text
Racing Level: Karting
Car Type: Kart
```

The admin or user filling form must manually select both fields.

Do not create logic like:

```text
If Racing Level = Formula 4, Formula 3, Formula 2, or Formula 1,
then automatically set Car Type = Formula Car.
```

Instead, use this rule:

```text
Racing Level and Car Type are independent dropdown fields.
No auto-selection.
No automatic dependency.
Admin/user must manually select both fields.
```

---

## Current CRM Context

The current CRM already has:

- General Leads module
- Driver Leads module
- Driver lead activity logs
- Driver comments
- Driver tier history
- Sponsor profiles
- Sponsorship pipeline
- Sponsor-driver linking
- Sponsor activities
- Role-based access
- Webhook intake for driver leads

This implementation should build on the existing Driver Leads structure.

---

# 1. Driver Lead Field Updates

## Add New Fields to `driver_leads`

Add the following columns to the existing `driver_leads` table:

```text
dob
age_group
racing_level
car_type
contract_interest_type
```

Recommended column types:

```php
$table->date('dob')->nullable();
$table->string('age_group')->nullable();
$table->string('racing_level')->nullable();
$table->string('car_type')->nullable();
$table->string('contract_interest_type')->nullable();
```

---

# 2. DOB and Age Group

## DOB Field

The user/admin should enter the driver's DOB manually.

Example:

```text
DOB: 2008-03-14
```

## Age Calculation

Age should be calculated dynamically from DOB.

Do not store age as a fixed database value unless required for reporting.

Example accessor:

```php
public function getAgeAttribute(): ?int
{
    return $this->dob ? $this->dob->age : null;
}
```

## Age Group Logic

Age group should be calculated from DOB.

Suggested groups:

```text
Under 12 (junior Karting)
12–15 (Senior Karting)
16–18 
19–25
26–35
36+
```

Example logic:

```php
public function getComputedAgeGroupAttribute(): ?string
{
    if (!$this->dob) {
        return null;
    }

    $age = $this->dob->age;

    return match (true) {
        $age < 12 => 'Under 12',
        $age >= 12 && $age <= 15 => '12–15',
        $age >= 16 && $age <= 18 => '16–18',
        $age >= 19 && $age <= 25 => '19–25',
        $age >= 26 && $age <= 35 => '26–35',
        default => '36+',
    };
}
```

The CRM can either store `age_group` during save/update or display it through an accessor.

Recommended approach:

```text
Store DOB.
Calculate age and age group dynamically.
Only store age_group if filtering/reporting requires faster queries.
```

---

# 3. Racing Level

Create a new enum:

```text
DriverRacingLevel
```

Suggested values:

```text
Karting
Formula 4
Formula 3
Formula 2
Formula 1
GT Racing
Touring Car
Prototype
Stock Car
Sim Racing
Other
```

Suggested PHP enum:

```php
enum DriverRacingLevel: string
{
    case Karting = 'karting';
    case Formula4 = 'formula_4';
    case Formula3 = 'formula_3';
    case Formula2 = 'formula_2';
    case Formula1 = 'formula_1';
    case GtRacing = 'gt_racing';
    case TouringCar = 'touring_car';
    case Prototype = 'prototype';
    case StockCar = 'stock_car';
    case SimRacing = 'sim_racing';
    case Other = 'other';

    public function label(): string
    {
        return match ($this) {
            self::Karting => 'Karting',
            self::Formula4 => 'Formula 4',
            self::Formula3 => 'Formula 3',
            self::Formula2 => 'Formula 2',
            self::Formula1 => 'Formula 1',
            self::GtRacing => 'GT Racing',
            self::TouringCar => 'Touring Car',
            self::Prototype => 'Prototype',
            self::StockCar => 'Stock Car',
            self::SimRacing => 'Sim Racing',
            self::Other => 'Other',
        };
    }
}
```

---

# 4. Car Type

Create a new enum:

```text
CarType
```

Suggested values:

```text
Kart
Formula Car
GT Car
Touring Car
Prototype
Stock Car
Sim Racing
Other
```

Suggested PHP enum:

```php
enum CarType: string
{
    case Kart = 'kart';
    case FormulaCar = 'formula_car';
    case GtCar = 'gt_car';
    case TouringCar = 'touring_car';
    case Prototype = 'prototype';
    case StockCar = 'stock_car';
    case SimRacing = 'sim_racing';
    case Other = 'other';

    public function label(): string
    {
        return match ($this) {
            self::Kart => 'Kart',
            self::FormulaCar => 'Formula Car',
            self::GtCar => 'GT Car',
            self::TouringCar => 'Touring Car',
            self::Prototype => 'Prototype',
            self::StockCar => 'Stock Car',
            self::SimRacing => 'Sim Racing',
            self::Other => 'Other',
        };
    }
}
```

## Important

Car Type should be selected manually.

No automatic dependency should exist between:

```text
Racing Level
Car Type
```

---

# 5. Driver Contract System

Create a new table:

```text
driver_contracts
```

This table will store all driver-related contracts.

A driver can have multiple contracts over time.

## Suggested Fields

```text
id
driver_lead_id
sponsor_profile_id
sponsorship_deal_id
contract_type
contract_status
car_type
racing_level
contract_value
currency
start_date
end_date
signed_date
document_path
notes
created_by
updated_by
created_at
updated_at
deleted_at
```

## Suggested Migration

```php
Schema::create('driver_contracts', function (Blueprint $table) {
    $table->id();

    $table->foreignId('driver_lead_id')
        ->constrained('driver_leads')
        ->cascadeOnDelete();

    $table->foreignId('sponsor_profile_id')
        ->nullable()
        ->constrained('sponsor_profiles')
        ->nullOnDelete();

    $table->foreignId('sponsorship_deal_id')
        ->nullable()
        ->constrained('sponsorship_deals')
        ->nullOnDelete();

    $table->string('contract_type');
    $table->string('contract_status')->default('draft');

    $table->string('car_type')->nullable();
    $table->string('racing_level')->nullable();

    $table->decimal('contract_value', 12, 2)->nullable();
    $table->string('currency', 10)->default('USD');

    $table->date('start_date')->nullable();
    $table->date('end_date')->nullable();
    $table->date('signed_date')->nullable();

    $table->string('document_path')->nullable();
    $table->text('notes')->nullable();

    $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
    $table->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();

    $table->timestamps();
    $table->softDeletes();
});
```

---

# 6. Contract Type Enum

Create enum:

```text
DriverContractType
```

Suggested values:

```text
Sponsorship Contract
Team Seat Contract
Driver Management Contract
Track Time Contract
Coaching Contract
Vendor Support Contract
Media Package Contract
Other
```

Suggested PHP enum:

```php
enum DriverContractType: string
{
    case Sponsorship = 'sponsorship_contract';
    case TeamSeat = 'team_seat_contract';
    case DriverManagement = 'driver_management_contract';
    case TrackTime = 'track_time_contract';
    case Coaching = 'coaching_contract';
    case VendorSupport = 'vendor_support_contract';
    case MediaPackage = 'media_package_contract';
    case Other = 'other';
}
```

---

# 7. Contract Status Enum

Create enum:

```text
DriverContractStatus
```

Suggested values:

```text
Draft
Sent
Under Review
Signed
Active
Expired
Cancelled
```

Suggested PHP enum:

```php
enum DriverContractStatus: string
{
    case Draft = 'draft';
    case Sent = 'sent';
    case UnderReview = 'under_review';
    case Signed = 'signed';
    case Active = 'active';
    case Expired = 'expired';
    case Cancelled = 'cancelled';
}
```

---

# 8. Model Relationships

## DriverLead Model

Add relationships:

```php
public function contracts()
{
    return $this->hasMany(DriverContract::class);
}

public function activeContract()
{
    return $this->hasOne(DriverContract::class)
        ->where('contract_status', 'active')
        ->latestOfMany();
}

public function latestContract()
{
    return $this->hasOne(DriverContract::class)->latestOfMany();
}
```

## DriverContract Model

Create model:

```php
class DriverContract extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'driver_lead_id',
        'sponsor_profile_id',
        'sponsorship_deal_id',
        'contract_type',
        'contract_status',
        'car_type',
        'racing_level',
        'contract_value',
        'currency',
        'start_date',
        'end_date',
        'signed_date',
        'document_path',
        'notes',
        'created_by',
        'updated_by',
    ];

    protected $casts = [
        'start_date' => 'date',
        'end_date' => 'date',
        'signed_date' => 'date',
        'contract_value' => 'decimal:2',
    ];

    public function driverLead()
    {
        return $this->belongsTo(DriverLead::class);
    }

    public function sponsor()
    {
        return $this->belongsTo(SponsorProfile::class, 'sponsor_profile_id');
    }

    public function sponsorshipDeal()
    {
        return $this->belongsTo(SponsorshipDeal::class);
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function updater()
    {
        return $this->belongsTo(User::class, 'updated_by');
    }
}
```

---

# 9. Driver Tier Logic

The CRM already has basic tier logic.

Upgrade the tier logic to consider:

```text
DOB / age group
Years racing
Career wins
Racing level
Car type
Current team / series
Seeking sponsorship
Social audience
```

Suggested tiers:

```text
Development
Amateur
Pro-Am
Professional
Elite
```

## Suggested Logic

```text
Karting + Under 16 = Development
Formula 4 + age 16–18 = Development or Pro-Am
Formula 3 + strong wins = Pro-Am
Formula 2 = Professional
Formula 1 = Elite
High wins + high experience = Professional / Elite
Low experience + low wins = Amateur
```

Important:

```text
Tier can be auto-calculated.
Car Type must not be auto-selected.
```

Tier updates should continue to be logged in:

```text
driver_lead_tier_history
```

---

# 10. Controller Updates

## Create New Controller

```text
DriverContractController
```

Suggested actions:

```text
store
edit
update
destroy
changeStatus
uploadDocument
```

## DriverLeadController Updates

Update existing driver lead create/update logic to support:

```text
dob
age_group
racing_level
car_type
contract_interest_type
```

Do not auto-fill `car_type`.

---

# 11. Routes

Add routes:

```php
Route::post('/driver-leads/{driverLead}/contracts', [DriverContractController::class, 'store'])
    ->name('driver-leads.contracts.store');

Route::get('/driver-contracts/{contract}/edit', [DriverContractController::class, 'edit'])
    ->name('driver-contracts.edit');

Route::patch('/driver-contracts/{contract}', [DriverContractController::class, 'update'])
    ->name('driver-contracts.update');

Route::delete('/driver-contracts/{contract}', [DriverContractController::class, 'destroy'])
    ->name('driver-contracts.destroy');

Route::patch('/driver-contracts/{contract}/status', [DriverContractController::class, 'changeStatus'])
    ->name('driver-contracts.status');
```

---

# 12. Driver Lead Form Updates

Update:

```text
resources/views/driver-leads/_form.blade.php
```

Add fields:

```text
DOB
Racing Level
Car Type
Interested Contract Type
```

## Form Field Rules

```text
DOB = date input
Racing Level = dropdown
Car Type = dropdown
Interested Contract Type = dropdown
```

Important:

```text
Racing Level dropdown must not control Car Type dropdown.
Car Type dropdown must remain manually selected.
```

---

# 13. Driver Profile Page Updates

Update:

```text
resources/views/driver-leads/show.blade.php
```

Add cards:

## Driver Overview Card

```text
Name
DOB
Age
Age Group
Country
Years Racing
Highest Series
Racing Level
Car Type
Career Wins
Current Team / Series
Driver Tier
Seeking Sponsorship
```

## Contract Overview Card

Show latest or active contract:

```text
Contract Status
Contract Type
Sponsor
Deal
Racing Level
Car Type
Contract Value
Start Date
End Date
Signed Date
Document
```

## Contract History Table

```text
Contract Type
Sponsor
Deal
Racing Level
Car Type
Value
Status
Start Date
End Date
Document
Actions
```

---

# 14. Driver List Page Updates

Update:

```text
resources/views/driver-leads/index.blade.php
```

Add filters:

```text
Status
Driver Tier
Age Group
Racing Level
Car Type
Seeking Sponsorship
Contract Status
Search
```

Example filter use case:

```text
Show all Formula 4 drivers, age 16–18, seeking sponsorship, with no active contract.
```

---

# 15. Sponsor Linking

The existing Sponsor & Vendor module should remain the commercial engine.

When creating a driver contract, allow optional linking to:

```text
Sponsor Profile
Sponsorship Deal
Driver Lead
```

This creates a clean relationship:

```text
Sponsor Profile → Sponsorship Deal → Driver Contract → Driver Lead
```

Example:

```text
Driver: John Smith
Sponsor: ABC Performance Brand
Deal: 2026 Junior Driver Sponsorship
Contract Type: Sponsorship Contract
Contract Status: Active
Contract Value: $25,000
```

---

# 16. Activity Logging

Every important action should create a driver activity log.

Log actions like:

```text
Contract created
Contract updated
Contract sent
Contract signed
Contract activated
Contract expired
Contract cancelled
Contract document uploaded
Sponsor linked to contract
Racing level updated
Car type updated
DOB updated
Tier recalculated
```

This keeps the CRM audit-friendly.

---

# 17. Webhook / Google Form Updates

The current Google Form driver lead webhook should be updated to include:

```text
DOB
Racing Level
Car Type
Interested Contract Type
```

Updated Google Form order:

```text
1. First Name
2. Last Name
3. Email
4. Phone
5. Country
6. DOB
7. Years Racing
8. Highest Series
9. Racing Level
10. Car Type
11. Career Wins
12. Current Team / Series
13. Instagram Handle
14. Instagram Followers
15. Seeking Sponsorship
16. Interested Contract Type
```

Important:

```text
Webhook should accept Racing Level and Car Type as independent values.
Webhook should not infer or auto-select Car Type.
```

---

# 18. Validation Rules

Suggested validation:

```php
$request->validate([
    'dob' => ['nullable', 'date', 'before:today'],
    'racing_level' => ['nullable', Rule::enum(DriverRacingLevel::class)],
    'car_type' => ['nullable', Rule::enum(CarType::class)],
    'contract_interest_type' => ['nullable', Rule::enum(DriverContractType::class)],
]);
```

For contracts:

```php
$request->validate([
    'driver_lead_id' => ['required', 'exists:driver_leads,id'],
    'sponsor_profile_id' => ['nullable', 'exists:sponsor_profiles,id'],
    'sponsorship_deal_id' => ['nullable', 'exists:sponsorship_deals,id'],
    'contract_type' => ['required', Rule::enum(DriverContractType::class)],
    'contract_status' => ['required', Rule::enum(DriverContractStatus::class)],
    'racing_level' => ['nullable', Rule::enum(DriverRacingLevel::class)],
    'car_type' => ['nullable', Rule::enum(CarType::class)],
    'contract_value' => ['nullable', 'numeric', 'min:0'],
    'currency' => ['nullable', 'string', 'max:10'],
    'start_date' => ['nullable', 'date'],
    'end_date' => ['nullable', 'date', 'after_or_equal:start_date'],
    'signed_date' => ['nullable', 'date'],
    'document' => ['nullable', 'file', 'mimes:pdf,doc,docx,jpg,jpeg,png', 'max:10240'],
    'notes' => ['nullable', 'string'],
]);
```

---

# 19. Dashboard / Reports

Add reporting cards:

```text
Total Drivers by Racing Level
Drivers by Car Type
Drivers by Age Group
Drivers Seeking Sponsorship
Active Driver Contracts
Expired Driver Contracts
Formula 4 Prospects
Karting Development Drivers
Drivers With No Active Contract
Sponsor-Linked Drivers
```

Useful report examples:

```text
Karting drivers under age 12
Formula 4 drivers age 16–18
Drivers with active sponsorship contracts
Drivers seeking sponsorship with no contract
Drivers connected to sponsor deals
```

---

# 20. Final Admin Workflow

```text
Driver submits form
↓
CRM creates or updates driver lead
↓
Admin reviews driver profile
↓
DOB calculates age and age group
↓
driver selects Racing Level
↓
driver selects Car Type
↓
System calculates Driver Tier
↓
Admin links sponsor if available
↓
Admin creates driver contract
↓
Contract status is tracked
↓
Documents are uploaded
↓
Activities are logged automatically
↓
Driver appears in reports and filters

---

# 21. Developer Checklist

## Database

- [ ] Add DOB to driver leads
- [ ] Add age group to driver leads if needed
- [ ] Add racing level to driver leads
- [ ] Add car type to driver leads
- [ ] Add contract interest type to driver leads
- [ ] Create driver contracts table

## Backend

- [ ] Create DriverRacingLevel enum
- [ ] Create CarType enum
- [ ] Create DriverContractType enum
- [ ] Create DriverContractStatus enum
- [ ] Create DriverContract model
- [ ] Add DriverLead relationships
- [ ] Create DriverContractController
- [ ] Update DriverLeadController
- [ ] Update DriverLeadWebhookController
- [ ] Update tier calculation logic
- [ ] Add activity logging

## Frontend

- [ ] Update Driver Lead form
- [ ] Update Driver Lead index filters
- [ ] Update Driver Lead profile page
- [ ] Add Contract Overview card
- [ ] Add Contract History table
- [ ] Add Create Contract modal/form
- [ ] Add document upload field
- [ ] Hide edit/create actions for Viewer role

## Integrations

- [ ] Update Google Form fields
- [ ] Update Google Apps Script mapping
- [ ] Update webhook payload parser
- [ ] Test incoming driver lead payload

## Testing

- [ ] Test creating driver with DOB
- [ ] Test age group calculation
- [ ] Test manual racing level selection
- [ ] Test manual car type selection
- [ ] Confirm car type is not auto-selected
- [ ] Test driver tier recalculation
- [ ] Test contract creation
- [ ] Test sponsor linking
- [ ] Test document upload
- [ ] Test role permissions
- [ ] Test filters and reports

---

# Final Requirement Summary

The CRM should allow Box Motorsports to manage:

```text
Drivers
DOB
Age groups
Racing levels
Car types
Driver tiers
Sponsorship status
Contracts
Sponsors
Contract documents
Sponsor-driver relationships
```

Most important rule:

```text
Do not auto-select car type.
Racing Level and Car Type must be separate manual fields.
```
