<?php

namespace App\Http\Controllers;

use App\Models\IntegrationSetting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Str;

class GoogleContactFormController extends Controller
{
    /** Display the Google Contact Form settings screen. */
    public function index()
    {
        Gate::authorize('manage-integrations');

        $setting = IntegrationSetting::firstOrCreate(
            ['channel' => 'google_form'],
            ['enabled' => false, 'secret_key' => Str::random(40), 'config' => []]
        );

        return view('integrations.google-contact-form', [
            'setting'    => $setting,
            'config'     => $setting->config ?? [],
            'webhookUrl' => url('/api/v1/leads/google-form'),
        ]);
    }

    /** Save the integration settings toggle. */
    public function save(Request $request)
    {
        Gate::authorize('manage-integrations');

        $setting = IntegrationSetting::firstOrCreate(['channel' => 'google_form']);
        $setting->update([
            'enabled' => $request->boolean('enabled'),
        ]);

        return back()->with('toast', 'Google Contact Form settings saved.');
    }

    /** Regenerate the webhook secret key. */
    public function regenerateSecret()
    {
        Gate::authorize('manage-integrations');

        $setting = IntegrationSetting::firstOrCreate(['channel' => 'google_form']);
        $setting->update([
            'secret_key' => Str::random(40),
        ]);

        return back()->with('toast', 'Webhook secret regenerated.');
    }

    /** Test configuration / check secret. */
    public function test()
    {
        Gate::authorize('manage-integrations');

        $setting = IntegrationSetting::where('channel', 'google_form')->first();

        if (! $setting || ! $setting->enabled) {
            return back()->with('error', 'Google Contact Form integration is disabled.');
        }

        return back()->with('toast', 'Google Contact Form webhook configuration is active. Send a test lead from Google Forms to confirm.');
    }
}
