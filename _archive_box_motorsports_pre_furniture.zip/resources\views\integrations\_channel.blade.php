<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title">{{ $title }}</h3>
        <form method="POST" action="{{ route('integrations.update', $channel) }}">@csrf @method('PATCH')
            <input type="hidden" name="enabled" value="{{ $setting->enabled ? 0 : 1 }}">
            <button class="btn btn-sm {{ $setting->enabled ? 'btn-success' : 'btn-default' }}">{{ $setting->enabled ? 'Enabled' : 'Disabled' }}</button>
        </form>
    </div>
    <div class="card-body">
        <p class="text-muted">{{ $instructions }}</p>
        <div class="form-group">
            <label class="small">Webhook URL</label>
            <div class="input-group">
                <input readonly value="{{ $endpoint }}" class="form-control" id="ep-{{ $channel }}">
                <div class="input-group-append"><button type="button" class="btn btn-default" onclick="navigator.clipboard.writeText(document.getElementById('ep-{{ $channel }}').value)">Copy</button></div>
            </div>
        </div>
        <div class="form-group">
            <label class="small">Secret Key</label>
            <div class="input-group">
                <input type="password" readonly value="{{ $setting->secret_key }}" class="form-control" id="sk-{{ $channel }}">
                <div class="input-group-append">
                    <button type="button" class="btn btn-default" onclick="var f=document.getElementById('sk-{{ $channel }}'); f.type=f.type==='password'?'text':'password';">Show</button>
                    <button type="button" class="btn btn-default" onclick="navigator.clipboard.writeText(document.getElementById('sk-{{ $channel }}').value)">Copy</button>
                </div>
            </div>
        </div>
        <form method="POST" action="{{ route('integrations.regenerate', $channel) }}" class="d-inline">@csrf<button class="btn btn-outline-danger btn-sm">Regenerate Secret</button></form>
        <form method="POST" action="{{ route('integrations.test', $channel) }}" class="d-inline">@csrf<button class="btn btn-dark btn-sm">Test Webhook</button></form>
    </div>
</div>
