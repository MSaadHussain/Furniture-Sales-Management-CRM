<?php

namespace App\Policies;

use App\Enums\UserRole;
use App\Models\Lead;
use App\Models\User;

class LeadPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->is_active;
    }

    /**
     * Only Super Admin, Admin, and Sales Manager may export lead sheets.
     * Viewer and Sales Representative are explicitly denied.
     */
    public function export(User $user): bool
    {
        return $user->is_active && $user->hasRole(
            UserRole::SuperAdmin,
            UserRole::Admin,
            UserRole::SalesManager,
        );
    }

    public function view(User $user, Lead $lead): bool
    {
        if (! $user->is_active) {
            return false;
        }

        if ($user->hasRole(UserRole::SalesRep)) {
            return (int) $lead->assigned_to === (int) $user->id;
        }

        return true;
    }

    public function create(User $user): bool
    {
        return ! $user->hasRole(UserRole::Viewer) && $user->is_active;
    }

    public function update(User $user, Lead $lead): bool
    {
        if ($user->hasRole(UserRole::Viewer) || ! $user->is_active) {
            return false;
        }

        if ($user->hasRole(UserRole::SalesRep)) {
            return (int) $lead->assigned_to === (int) $user->id;
        }

        return true;
    }

    public function assign(User $user, Lead $lead): bool
    {
        return $user->role->canManagePipeline() && $user->is_active;
    }

    public function delete(User $user, Lead $lead): bool
    {
        return $user->hasRole(UserRole::SuperAdmin, UserRole::Admin) && $user->is_active;
    }

    public function restore(User $user, Lead $lead): bool
    {
        return $user->hasRole(UserRole::SuperAdmin, UserRole::Admin);
    }
}