<?php

namespace App\Services\Integrations\Meta;

use App\Enums\SourceChannel;
use App\Models\Lead;
use App\Services\LeadIntakeService;

/**
 * Handles a Meta leadgen webhook entry: fetches full lead detail from the
 * Graph API, then runs it through the shared intake pipeline (normalise →
 * dedup → notify → log) with source = Meta.
 */
class MetaLeadService
{
    public function __construct(
        private MetaApiClient $api,
        private LeadIntakeService $intake,
    ) {}

    /**
     * Process one leadgen change. Returns [Lead, isNew] or null if unfetchable.
     */
    public function handleLeadgen(string $leadgenId, ?string $ip = null): ?array
    {
        $detail = $this->api->fetchLead($leadgenId);

        // If the API can't be reached, still capture the raw id so nothing is lost.
        $payload = $detail ?? ['leadgen_id' => $leadgenId, 'field_data' => []];
        $payload['source_external_id'] = $leadgenId;

        [$lead, $isNew] = $this->intake->ingest(SourceChannel::Meta, $payload, $ip);

        if ($isNew && blank($lead->source_external_id)) {
            $lead->forceFill(['source_external_id' => $leadgenId])->saveQuietly();
        }

        return [$lead, $isNew];
    }
}
