@php
    $map = [
        'pending'    => ['Pending', '#667085'],
        'previewing' => ['Previewing', '#2E90FA'],
        'processing' => ['Processing', '#F79009'],
        'completed'  => ['Completed', '#12B76A'],
        'failed'     => ['Failed', '#F04438'],
        'imported'   => ['Imported', '#12B76A'],
        'duplicate'  => ['Duplicate', '#667085'],
        'merged'     => ['Merged', '#7A5AF8'],
        'updated'    => ['Updated', '#2E90FA'],
    ];
    [$label, $color] = $map[$status] ?? [ucfirst($status), '#667085'];
@endphp
<x-badge :label="$label" :color="$color" />
