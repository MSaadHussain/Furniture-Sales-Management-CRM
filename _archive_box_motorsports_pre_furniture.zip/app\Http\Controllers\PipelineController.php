<?php

namespace App\Http\Controllers;

use App\Enums\InteractionType;
use App\Enums\LeadStatus;
use App\Enums\UserRole;
use App\Events\LeadStatusChanged;
use App\Models\Lead;
use App\Services\AuditService;
use App\Services\LeadInteractionService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Validation\Rules\Enum;

class PipelineController extends Controller
{
    public function __construct(
        private LeadInteractionService $interactions,
        private AuditService $audit,
    ) {}

    public function index(Request $request)
    {
        Gate::authorize('viewAny', Lead::class);

        $query = Lead::query()->with(['assignee']);

        if ($request->user()->hasRole(UserRole::SalesRep)) {
            $query->where('assigned_to', $request->user()->id);
        }

        $leads = $query->orderByDesc('last_activity_at')->get();

        $columns = [];
        foreach (LeadStatus::pipelineOrder() as $status) {
            $columns[$status->value] = [
                'status' => $status->value,
                'label'  => $status->label(),
                'color'  => $status->color(),
                'leads'  => $leads->where('status', $status)->values(),
            ];
        }

        return view('pipeline.index', ['columns' => $columns]);
    }

    public function move(Request $request, Lead $lead): JsonResponse
    {
        Gate::authorize('update', $lead);

        $validated = $request->validate([
            'status' => ['required', new Enum(LeadStatus::class)],
        ]);

        $old = $lead->status;
        $new = LeadStatus::from($validated['status']);

        if ($old === $new) {
            return response()->json(['success' => true, 'unchanged' => true]);
        }

        $lead->update(['status' => $new]);

        $type = match ($new) {
            LeadStatus::ClosedWon        => InteractionType::CLOSED_WON,
            LeadStatus::ClosedLost       => InteractionType::CLOSED_LOST,
            LeadStatus::MeetingScheduled => InteractionType::MEETING_SCHEDULED,
            default                      => InteractionType::STATUS_CHANGED,
        };

        $this->interactions->record($lead, $type, 'Moved on pipeline board.', $old->label(), $new->label());
        $this->audit->log('lead.pipeline_moved', $lead, "{$old->label()} -> {$new->label()}");

        event(new LeadStatusChanged($lead, $old->value, $new->value));

        return response()->json([
            'success' => true,
            'lead_id' => $lead->id,
            'status'  => $new->value,
        ]);
    }
}
