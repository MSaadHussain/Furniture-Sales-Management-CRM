<?php

namespace App\Http\Controllers;

use App\Enums\DriverLeadStatus;
use App\Enums\DriverTier;
use App\Enums\UserRole;
use App\Models\DriverLead;
use App\Models\DriverLeadActivity;
use App\Models\DriverLeadComment;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\StreamedResponse;

class DriverLeadController extends Controller
{
    public const IMPORT_FIELDS = [
        'first_name', 'last_name', 'email', 'phone', 'country', 'dob',
        'years_racing', 'highest_series', 'racing_level', 'car_type',
        'career_wins', 'current_team_series',
        'instagram_handle', 'instagram_followers', 'seeking_sponsorship',
        'contract_interest_type',
    ];

    /** Fields a CSV row must carry to become a driver lead. */
    public const IMPORT_REQUIRED = ['first_name', 'email', 'phone'];

    public function index(Request $request)
    {
        $driverLeads = $this->filteredDriverQuery($request)
            ->orderByDesc('created_at')
            ->paginate(15)
            ->withQueryString();

        return view('driver-leads.index', [
            'driverLeads'  => $driverLeads,
            'statuses'     => DriverLeadStatus::options(),
            'tiers'        => DriverTier::options(),
            'racingLevels' => \App\Enums\DriverRacingLevel::options(),
            'carTypes'     => \App\Enums\CarType::options(),
            'ageGroups'    => [
                'under_12' => 'Under 12',
                '12_15'    => '12–15',
                '16_18'    => '16–18',
                '19_25'    => '19–25',
                '26_35'    => '26–35',
                '36_plus'  => '36+',
            ],
            'filters'      => $request->only(['search', 'status', 'tier', 'racing_level', 'car_type', 'age_group', 'seeking', 'contract']),
        ]);
    }

    /** Builds the filtered driver-lead query shared by the list and the export. */
    private function filteredDriverQuery(Request $request)
    {
        $query = DriverLead::query();

        if ($search = $request->string('search')->trim()->value()) {
            $query->where(function ($q) use ($search) {
                $q->where('first_name', 'like', "%{$search}%")
                  ->orWhere('last_name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%")
                  ->orWhere('phone', 'like', "%{$search}%")
                  ->orWhere('instagram_handle', 'like', "%{$search}%");
            });
        }

        if ($status = $request->string('status')->value()) {
            $query->where('status', $status);
        }

        if ($tier = $request->string('tier')->value()) {
            $query->where('inferred_tier', $tier);
        }

        if ($level = $request->string('racing_level')->value()) {
            $query->where('racing_level', $level);
        }

        if ($carType = $request->string('car_type')->value()) {
            $query->where('car_type', $carType);
        }

        if ($request->filled('seeking')) {
            $query->where('seeking_sponsorship', $request->string('seeking')->value() === 'yes');
        }

        if ($ageGroup = $request->string('age_group')->value()) {
            $range = match ($ageGroup) {
                'under_12' => [0, 11],
                '12_15'    => [12, 15],
                '16_18'    => [16, 18],
                '19_25'    => [19, 25],
                '26_35'    => [26, 35],
                '36_plus'  => [36, 200],
                default    => null,
            };
            if ($range) {
                $query->whereNotNull('dob')
                    ->whereRaw('TIMESTAMPDIFF(YEAR, dob, CURDATE()) BETWEEN ? AND ?', $range);
            }
        }

        if ($contract = $request->string('contract')->value()) {
            if ($contract === 'active') {
                $query->whereHas('contracts', fn ($q) => $q->where('contract_status', 'active'));
            } elseif ($contract === 'none') {
                $query->whereDoesntHave('contracts', fn ($q) => $q->where('contract_status', 'active'));
            }
        }

        return $query;
    }

    /** GET /driver-leads/export — CSV or XLSX of the (filtered) driver leads. */
    public function export(Request $request): StreamedResponse
    {
        abort_unless(
            $request->user()->hasRole(UserRole::SuperAdmin, UserRole::Admin, UserRole::SalesManager),
            403
        );

        $format = $request->string('format')->value() === 'xlsx' ? 'xlsx' : 'csv';
        $query  = $this->filteredDriverQuery($request)->orderByDesc('created_at');

        $headers = [
            'ID', 'First Name', 'Last Name', 'Email', 'Phone', 'Country', 'DOB', 'Age', 'Age Group',
            'Years Racing', 'Highest Series', 'Racing Level', 'Car Type', 'Career Wins', 'Team / Series',
            'Instagram', 'Followers', 'Seeking Sponsorship', 'Contract Interest', 'Tier', 'Status', 'Created At',
        ];

        $rows = (function () use ($query) {
            foreach ($query->cursor() as $d) {
                yield [
                    $d->id, $d->first_name, $d->last_name, $d->email, $d->phone, $d->country,
                    $d->dob?->format('Y-m-d'), $d->age, $d->age_group,
                    $d->years_racing, $d->highest_series, $d->racing_level?->label(), $d->car_type?->label(),
                    $d->career_wins, $d->current_team_series,
                    $d->instagram_handle, $d->instagram_followers, $d->seeking_sponsorship ? 'Yes' : 'No',
                    $d->contract_interest_type?->label(), $d->inferred_tier?->label(), $d->status?->label(),
                    $d->created_at?->toDateTimeString(),
                ];
            }
        })();

        return \App\Services\Export\TabularExport::download('driver_leads_' . now()->format('Y_m_d_His'), $headers, $rows, $format);
    }

    public function create()
    {
        return view('driver-leads.create', [
            'statuses'      => DriverLeadStatus::options(),
            'racingLevels'  => \App\Enums\DriverRacingLevel::options(),
            'carTypes'      => \App\Enums\CarType::options(),
            'contractTypes' => \App\Enums\DriverContractType::options(),
        ]);
    }

    public function store(Request $request)
    {
        // Racing Level and Car Type are independent manual selections —
        // no auto-derivation between them.
        $validated = $request->validate([
            'first_name'             => ['required', 'string', 'max:191'],
            'last_name'              => ['required', 'string', 'max:191'],
            'email'                  => ['required', 'email', 'max:191', 'unique:driver_leads,email,NULL,id,deleted_at,NULL'],
            'phone'                  => ['required', 'string', 'max:50'],
            'country'                => ['nullable', 'string', 'max:100'],
            'dob'                    => ['nullable', 'date', 'before:today'],
            'years_racing'           => ['nullable', 'integer', 'min:0', 'max:80'],
            'highest_series'         => ['nullable', 'string', 'max:191'],
            'racing_level'           => ['nullable', new \Illuminate\Validation\Rules\Enum(\App\Enums\DriverRacingLevel::class)],
            'car_type'               => ['nullable', new \Illuminate\Validation\Rules\Enum(\App\Enums\CarType::class)],
            'career_wins'            => ['nullable', 'integer', 'min:0', 'max:10000'],
            'current_team_series'    => ['nullable', 'string', 'max:500'],
            'instagram_handle'       => ['nullable', 'string', 'max:100'],
            'instagram_followers'    => ['nullable', 'integer', 'min:0'],
            'seeking_sponsorship'    => ['nullable', 'boolean'],
            'contract_interest_type' => ['nullable', new \Illuminate\Validation\Rules\Enum(\App\Enums\DriverContractType::class)],
            'status'                 => ['required', new \Illuminate\Validation\Rules\Enum(DriverLeadStatus::class)],
            'photo'                  => ['nullable', 'image', 'mimes:jpeg,jpg,png,webp,gif', 'max:5120'],
        ]);

        self::assertAgeRules(
            $validated['dob'] ?? null,
            $validated['racing_level'] ?? null,
            $validated['car_type'] ?? null,
        );

        unset($validated['photo']);
        $validated['years_racing']        = (int) ($validated['years_racing'] ?? 0);
        $validated['career_wins']         = (int) ($validated['career_wins'] ?? 0);
        $validated['instagram_followers'] = (int) ($validated['instagram_followers'] ?? 0);
        $validated['seeking_sponsorship'] = $request->boolean('seeking_sponsorship');

        if ($request->hasFile('photo')) {
            $validated['photo_path'] = $this->storeDriverPhoto($request->file('photo'));
        }

        $driver = DriverLead::create($validated);
        $driver->recomputeTier(Auth::id());

        DriverLeadActivity::create([
            'driver_lead_id' => $driver->id,
            'user_id'        => Auth::id(),
            'action'         => 'created',
            'description'    => 'Driver lead created manually by ' . Auth::user()->name,
        ]);

        return redirect()->route('driver-leads.show', $driver)->with('toast', "Driver lead {$driver->full_name} created.");
    }

    public function show(DriverLead $driverLead)
    {
        $driverLead->load([
            'activities.user', 'comments.user', 'tierHistory.user',
            'sponsorLinks.sponsor', 'sponsorLinks.deal',
            'contracts.sponsor', 'contracts.deal', 'contracts.creator',
        ]);

        return view('driver-leads.show', [
            'driver'           => $driverLead,
            'statuses'         => DriverLeadStatus::options(),
            'racingLevels'     => \App\Enums\DriverRacingLevel::options(),
            'carTypes'         => \App\Enums\CarType::options(),
            'contractTypes'    => \App\Enums\DriverContractType::options(),
            'contractStatuses' => \App\Enums\DriverContractStatus::options(),
            'sponsors'         => \App\Models\SponsorProfile::orderBy('company_name')->get(['id', 'company_name']),
            'deals'            => \App\Models\SponsorshipDeal::with('sponsor:id,company_name')->orderByDesc('created_at')->get(['id', 'title', 'sponsor_profile_id']),
        ]);
    }

    /**
     * Enforce age-plausibility rules between DOB, Racing Level, and Car Type.
     * Throws a ValidationException with field-level messages on violation.
     */
    public static function assertAgeRules(?string $dob, ?string $racingLevel, ?string $carType): void
    {
        if (! $dob) {
            return;
        }

        $age = \Carbon\Carbon::parse($dob)->age;
        $errors = [];

        $level = $racingLevel ? \App\Enums\DriverRacingLevel::tryFrom($racingLevel) : null;
        if ($msg = \App\Enums\DriverRacingLevel::ageViolation($age, $level)) {
            $errors['racing_level'] = $msg;
        }

        $type = $carType ? \App\Enums\CarType::tryFrom($carType) : null;
        if ($msg = \App\Enums\CarType::ageViolation($age, $type)) {
            $errors['car_type'] = $msg;
        }

        if (! empty($errors)) {
            throw \Illuminate\Validation\ValidationException::withMessages($errors);
        }
    }

    public function update(Request $request, DriverLead $driverLead)
    {
        // Racing Level and Car Type are independent manual selections —
        // no auto-derivation between them, ever.
        $validated = $request->validate([
            'first_name'             => ['required', 'string', 'max:191'],
            'last_name'              => ['required', 'string', 'max:191'],
            'email'                  => ['required', 'email', 'max:191', 'unique:driver_leads,email,' . $driverLead->id . ',id,deleted_at,NULL'],
            'phone'                  => ['required', 'string', 'max:50'],
            'country'                => ['nullable', 'string', 'max:100'],
            'dob'                    => ['nullable', 'date', 'before:today'],
            'years_racing'           => ['nullable', 'integer', 'min:0', 'max:80'],
            'highest_series'         => ['nullable', 'string', 'max:191'],
            'racing_level'           => ['nullable', new \Illuminate\Validation\Rules\Enum(\App\Enums\DriverRacingLevel::class)],
            'car_type'               => ['nullable', new \Illuminate\Validation\Rules\Enum(\App\Enums\CarType::class)],
            'career_wins'            => ['nullable', 'integer', 'min:0', 'max:10000'],
            'current_team_series'    => ['nullable', 'string', 'max:500'],
            'instagram_handle'       => ['nullable', 'string', 'max:100'],
            'instagram_followers'    => ['nullable', 'integer', 'min:0'],
            'seeking_sponsorship'    => ['nullable', 'boolean'],
            'contract_interest_type' => ['nullable', new \Illuminate\Validation\Rules\Enum(\App\Enums\DriverContractType::class)],
            'status'                 => ['required', new \Illuminate\Validation\Rules\Enum(DriverLeadStatus::class)],
            'photo'                  => ['nullable', 'image', 'mimes:jpeg,jpg,png,webp,gif', 'max:5120'],
        ]);

        self::assertAgeRules(
            $validated['dob'] ?? null,
            $validated['racing_level'] ?? null,
            $validated['car_type'] ?? null,
        );

        unset($validated['photo']);
        $validated['years_racing']        = (int) ($validated['years_racing'] ?? 0);
        $validated['career_wins']         = (int) ($validated['career_wins'] ?? 0);
        $validated['instagram_followers'] = (int) ($validated['instagram_followers'] ?? 0);
        $validated['seeking_sponsorship'] = $request->boolean('seeking_sponsorship');

        if ($request->hasFile('photo')) {
            if ($driverLead->photo_path) {
                Storage::disk('public')->delete($driverLead->photo_path);
            }
            $validated['photo_path'] = $this->storeDriverPhoto($request->file('photo'));
        }

        $driverLead->update($validated);
        $driverLead->recomputeTier(Auth::id());

        DriverLeadActivity::create([
            'driver_lead_id' => $driverLead->id,
            'user_id'        => Auth::id(),
            'action'         => 'updated',
            'description'    => 'Driver details updated by ' . Auth::user()->name,
        ]);

        return back()->with('toast', 'Driver lead updated.');
    }

    /**
     * Store a driver profile photo, converting to WebP when GD supports it
     * (falls back to the original file otherwise). Returns the stored path.
     */
    private function storeDriverPhoto(UploadedFile $file): string
    {
        $dir  = 'driver-photos';
        $name = (string) Str::uuid();

        if (function_exists('imagewebp') && function_exists('imagecreatefromstring')) {
            $img = @imagecreatefromstring(file_get_contents($file->getRealPath()));
            if ($img !== false) {
                // Downscale very large uploads (profile photos don't need to be huge).
                $w = imagesx($img);
                $h = imagesy($img);
                $max = 800;
                if ($w > $max || $h > $max) {
                    $ratio = min($max / $w, $max / $h);
                    $nw = max(1, (int) round($w * $ratio));
                    $nh = max(1, (int) round($h * $ratio));
                    $dst = imagecreatetruecolor($nw, $nh);
                    imagealphablending($dst, false);
                    imagesavealpha($dst, true);
                    imagecopyresampled($dst, $img, 0, 0, 0, 0, $nw, $nh, $w, $h);
                    imagedestroy($img);
                    $img = $dst;
                }

                ob_start();
                $ok = imagewebp($img, null, 82);
                $contents = ob_get_clean();
                imagedestroy($img);

                if ($ok && is_string($contents) && $contents !== '') {
                    $path = "{$dir}/{$name}.webp";
                    Storage::disk('public')->put($path, $contents);
                    return $path;
                }
            }
        }

        // Fallback: keep the original upload as-is.
        return $file->store($dir, 'public');
    }

    public function qualify(DriverLead $driverLead)
    {
        $old = $driverLead->status;
        $driverLead->update(['status' => DriverLeadStatus::Qualified]);

        DriverLeadActivity::create([
            'driver_lead_id' => $driverLead->id,
            'user_id'        => Auth::id(),
            'action'         => 'status_changed',
            'description'    => 'Lead qualified',
            'old_value'      => $old->value,
            'new_value'      => 'qualified',
        ]);

        return back()->with('toast', "{$driverLead->full_name} marked as Qualified.");
    }

    public function decline(DriverLead $driverLead)
    {
        $old = $driverLead->status;
        $driverLead->update(['status' => DriverLeadStatus::Declined]);

        DriverLeadActivity::create([
            'driver_lead_id' => $driverLead->id,
            'user_id'        => Auth::id(),
            'action'         => 'status_changed',
            'description'    => 'Lead declined',
            'old_value'      => $old->value,
            'new_value'      => 'declined',
        ]);

        return back()->with('toast', "{$driverLead->full_name} marked as Declined.");
    }

    public function updateStatus(Request $request, DriverLead $driverLead)
    {
        $request->validate(['status' => ['required', 'string']]);

        $newStatus = DriverLeadStatus::from($request->input('status'));
        $old = $driverLead->status;

        $driverLead->update(['status' => $newStatus]);

        DriverLeadActivity::create([
            'driver_lead_id' => $driverLead->id,
            'user_id'        => Auth::id(),
            'action'         => 'status_changed',
            'description'    => "Status changed from {$old->label()} to {$newStatus->label()}",
            'old_value'      => $old->value,
            'new_value'      => $newStatus->value,
        ]);

        return back()->with('toast', 'Status updated.');
    }

    public function comment(Request $request, DriverLead $driverLead)
    {
        $request->validate(['body' => ['required', 'string', 'max:2000']]);

        DriverLeadComment::create([
            'driver_lead_id' => $driverLead->id,
            'user_id'        => Auth::id(),
            'body'           => $request->input('body'),
        ]);

        DriverLeadActivity::create([
            'driver_lead_id' => $driverLead->id,
            'user_id'        => Auth::id(),
            'action'         => 'comment_added',
            'description'    => 'Added a comment',
        ]);

        return back()->with('toast', 'Comment added.');
    }

    public function destroy(DriverLead $driverLead)
    {
        DriverLeadActivity::create([
            'driver_lead_id' => $driverLead->id,
            'user_id'        => Auth::id(),
            'action'         => 'deleted',
            'description'    => 'Driver lead soft-deleted',
        ]);

        $driverLead->delete();

        return redirect()->route('driver-leads.index')->with('toast', 'Driver lead moved to Trash.');
    }

    public function trash(Request $request)
    {
        $query = DriverLead::onlyTrashed();

        if ($search = $request->string('search')->trim()->value()) {
            $query->where(function ($q) use ($search) {
                $q->where('first_name', 'like', "%{$search}%")
                  ->orWhere('last_name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%");
            });
        }

        $leads = $query->latest('deleted_at')->paginate(20)->withQueryString();

        return view('driver-leads.trash', compact('leads'));
    }

    public function restore(int $id)
    {
        $driverLead = DriverLead::withTrashed()->findOrFail($id);
        $driverLead->restore();

        DriverLeadActivity::create([
            'driver_lead_id' => $driverLead->id,
            'user_id'        => Auth::id(),
            'action'         => 'restored',
            'description'    => 'Driver lead restored from trash',
        ]);

        return redirect()->route('driver-leads.trash')->with('toast', 'Driver lead restored.');
    }

    public function forceDelete(int $id)
    {
        $driverLead = DriverLead::withTrashed()->findOrFail($id);
        $driverLead->forceDelete();

        return redirect()->route('driver-leads.trash')->with('toast', 'Driver lead permanently deleted.');
    }

    public function import()
    {
        return view('driver-leads.import');
    }

    public function importUpload(Request $request)
    {
        $request->validate([
            'file' => ['required', 'file', 'mimes:csv,txt', 'max:10240'],
        ]);

        $file = $request->file('file');
        $handle = fopen($file->getRealPath(), 'r');
        $headers = fgetcsv($handle);

        $rows = [];
        while (($row = fgetcsv($handle)) !== false) {
            $rows[] = $row;
        }
        fclose($handle);

        $suggestedMap = $this->autoMapHeaders($headers);

        $storedPath = $file->store('imports/driver-leads');

        return view('driver-leads.import-preview', [
            'headers'      => $headers,
            'rows'         => array_slice($rows, 0, 10),
            'totalRows'    => count($rows),
            'suggestedMap' => $suggestedMap,
            'fields'       => self::IMPORT_FIELDS,
            'storedPath'   => $storedPath,
            'fileName'     => $file->getClientOriginalName(),
        ]);
    }

    public function importConfirm(Request $request)
    {
        $request->validate([
            'stored_path'  => ['required', 'string'],
            'column_map'   => ['required', 'array'],
            'duplicate'    => ['required', 'in:skip,merge,update'],
        ]);

        $path = storage_path('app/private/' . $request->input('stored_path'));
        if (! file_exists($path)) {
            return redirect()->route('driver-leads.import')->with('error', 'Upload expired. Please re-upload the file.');
        }

        $columnMap = $request->input('column_map');
        $duplicate = $request->input('duplicate');

        $handle = fopen($path, 'r');
        fgetcsv($handle); // skip header

        $imported = 0;
        $skipped  = 0;
        $updated  = 0;

        while (($row = fgetcsv($handle)) !== false) {
            $mapped = [];
            foreach ($columnMap as $index => $field) {
                if ($field && $field !== '' && isset($row[$index])) {
                    $mapped[$field] = trim($row[$index]);
                }
            }

            // Normalize enum-backed columns from labels ("Formula 4") or values.
            $mapped['racing_level'] = \App\Http\Controllers\Api\V1\Webhooks\DriverLeadWebhookController::matchEnum(\App\Enums\DriverRacingLevel::class, $mapped['racing_level'] ?? '');
            $mapped['car_type']     = \App\Http\Controllers\Api\V1\Webhooks\DriverLeadWebhookController::matchEnum(\App\Enums\CarType::class, $mapped['car_type'] ?? '');
            $mapped['contract_interest_type'] = \App\Http\Controllers\Api\V1\Webhooks\DriverLeadWebhookController::matchEnum(\App\Enums\DriverContractType::class, $mapped['contract_interest_type'] ?? '');

            // Required columns: first name, email, phone. (DOB and Car Type are optional.)
            $missingRequired = collect(self::IMPORT_REQUIRED)->first(fn ($f) => empty($mapped[$f]));
            $invalidDob = ! empty($mapped['dob']) && (! strtotime($mapped['dob']) || strtotime($mapped['dob']) >= time());
            if ($missingRequired || $invalidDob) {
                $skipped++;
                continue;
            }

            // Age-plausibility rules only apply when DOB / Car Type are present.
            $age = ! empty($mapped['dob']) ? \Carbon\Carbon::parse($mapped['dob'])->age : null;
            $level = $mapped['racing_level'] ? \App\Enums\DriverRacingLevel::from($mapped['racing_level']) : null;
            $type  = $mapped['car_type'] ? \App\Enums\CarType::from($mapped['car_type']) : null;
            if (\App\Enums\DriverRacingLevel::ageViolation($age, $level) || \App\Enums\CarType::ageViolation($age, $type)) {
                $skipped++;
                continue;
            }

            $mapped['years_racing']        = (int) ($mapped['years_racing'] ?? 0);
            $mapped['career_wins']         = (int) ($mapped['career_wins'] ?? 0);
            $mapped['instagram_followers'] = (int) ($mapped['instagram_followers'] ?? 0);
            $mapped['seeking_sponsorship'] = filter_var($mapped['seeking_sponsorship'] ?? false, FILTER_VALIDATE_BOOLEAN);
            $mapped['inferred_tier']       = DriverTier::infer($mapped['years_racing'], $mapped['career_wins']);
            $mapped['status']              = DriverLeadStatus::New;

            $existing = DriverLead::where(function ($q) use ($mapped) {
                if (! empty($mapped['email'])) {
                    $q->orWhere('email', $mapped['email']);
                }
                if (! empty($mapped['phone'])) {
                    $q->orWhere('phone', $mapped['phone']);
                }
            })->first();

            if ($existing) {
                if ($duplicate === 'skip') {
                    $skipped++;
                    continue;
                }

                if ($duplicate === 'merge') {
                    $fillable = array_filter($mapped, function ($value, $key) use ($existing) {
                        $current = $existing->{$key};
                        return ($current === null || $current === '' || $current === 0)
                            && $value !== null && $value !== '';
                    }, ARRAY_FILTER_USE_BOTH);
                    if (empty($fillable)) {
                        $skipped++;
                        continue;
                    }
                    $existing->update($fillable);
                } else {
                    $existing->update($mapped);
                }

                $existing->recomputeTier(Auth::id());
                DriverLeadActivity::create([
                    'driver_lead_id' => $existing->id,
                    'user_id'        => Auth::id(),
                    'action'         => 'import_updated',
                    'description'    => ucfirst($duplicate) . 'd via CSV import',
                ]);
                $updated++;
            } else {
                $driver = DriverLead::create($mapped);
                DriverLeadActivity::create([
                    'driver_lead_id' => $driver->id,
                    'user_id'        => Auth::id(),
                    'action'         => 'imported',
                    'description'    => 'Created via CSV import',
                ]);
                $imported++;
            }
        }

        fclose($handle);
        @unlink($path);

        return redirect()->route('driver-leads.index')
            ->with('toast', "Import complete: {$imported} created, {$updated} updated, {$skipped} skipped.");
    }

    public function downloadTemplate(): StreamedResponse
    {
        return response()->streamDownload(function () {
            $out = fopen('php://output', 'w');
            fputcsv($out, self::IMPORT_FIELDS);
            fputcsv($out, [
                'Lewis', 'Hamilton', 'lewis@example.com', '+44 7700 900000', 'United Kingdom', '1985-01-07',
                '17', 'Formula 1', 'Formula 1', 'Formula Car', '103', 'Mercedes-AMG Petronas F1',
                '@lewishamilton', '35000000', 'Yes', 'Sponsorship Contract',
            ]);
            fputcsv($out, [
                'Max', 'Verstappen', 'max@example.com', '+31 6 1234 5678', 'Netherlands', '1997-09-30',
                '10', 'Formula 1', 'Formula 1', 'Formula Car', '61', 'Oracle Red Bull Racing',
                '@maxverstappen1', '12000000', 'No', 'Team Seat Contract',
            ]);
            fclose($out);
        }, 'driver_leads_import_template.csv', [
            'Content-Type' => 'text/csv',
        ]);
    }

    private function autoMapHeaders(array $headers): array
    {
        $aliases = [
            'first_name'          => ['first name', 'first', 'firstname', 'given name'],
            'last_name'           => ['last name', 'last', 'lastname', 'surname', 'family name'],
            'email'               => ['email', 'email address', 'e-mail'],
            'phone'               => ['phone', 'phone number', 'telephone', 'mobile', 'cell'],
            'country'             => ['country', 'nation', 'location'],
            'dob'                 => ['dob', 'date of birth', 'birthdate', 'birth date'],
            'years_racing'        => ['years racing', 'years', 'experience'],
            'highest_series'      => ['highest series', 'series', 'highest level'],
            'racing_level'        => ['racing level', 'level'],
            'car_type'            => ['car type', 'car', 'vehicle type'],
            'career_wins'         => ['career wins', 'wins', 'total wins'],
            'current_team_series' => ['current team', 'team', 'current team/series', 'team/series'],
            'instagram_handle'    => ['instagram handle', 'instagram', 'ig handle', 'ig'],
            'instagram_followers' => ['instagram followers', 'followers', 'ig followers'],
            'seeking_sponsorship' => ['seeking sponsorship', 'sponsorship', 'seeking sponsor'],
            'contract_interest_type' => ['interested contract type', 'contract interest', 'contract type'],
        ];

        $map = [];
        foreach ($headers as $i => $header) {
            $lower = strtolower(trim($header));
            $map[$i] = '';
            foreach ($aliases as $field => $alts) {
                if ($lower === $field || in_array($lower, $alts, true)) {
                    $map[$i] = $field;
                    break;
                }
            }
        }

        return $map;
    }
}
