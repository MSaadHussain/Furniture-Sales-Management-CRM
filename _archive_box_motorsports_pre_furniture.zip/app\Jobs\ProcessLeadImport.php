<?php

namespace App\Jobs;

use App\Models\ImportBatch;
use App\Services\Import\LeadImportService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class ProcessLeadImport implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $timeout = 600;
    public int $tries = 1;

    public function __construct(public int $batchId) {}

    public function handle(LeadImportService $importService): void
    {
        $batch = ImportBatch::find($this->batchId);
        if (! $batch) {
            return;
        }
        $importService->process($batch);
    }

    public function failed(\Throwable $e): void
    {
        if ($batch = ImportBatch::find($this->batchId)) {
            $batch->update(['status' => 'failed', 'error_log' => $e->getMessage()]);
        }
    }
}
