@extends('layouts.app')
@section('title', 'Sponsors & Vendors')

@section('header_actions')
    <a href="{{ route('sponsorship-pipeline.index') }}" class="btn btn-light"><i class="fa-solid fa-table-columns"></i> Pipeline</a>
    @if (auth()->user()->hasRole(\App\Enums\UserRole::SuperAdmin, \App\Enums\UserRole::Admin, \App\Enums\UserRole::SalesManager))
        <x-export-menu route="sponsors.export" />
    @endif
    @unless (auth()->user()->role->isReadOnly())
        <a href="{{ route('sponsors.create') }}" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Add Sponsor / Vendor</a>
    @endunless
@endsection

@section('content')

{{-- Filters --}}
<x-card class="mb-6">
    <form method="GET" class="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-6 lg:items-end">
        <div class="lg:col-span-2">
            <label class="ta-label">Search</label>
            <input type="search" name="search" value="{{ $filters['search'] ?? '' }}" class="ta-input" placeholder="Company, contact, email, industry...">
        </div>
        <div>
            <label class="ta-label">Type</label>
            <select name="type" class="ta-input">
                <option value="">All</option>
                @foreach ($types as $t)<option value="{{ $t['value'] }}" @selected(($filters['type'] ?? '')===$t['value'])>{{ $t['label'] }}</option>@endforeach
            </select>
        </div>
        <div>
            <label class="ta-label">Status</label>
            <select name="status" class="ta-input">
                <option value="">All</option>
                @foreach ($statuses as $s)<option value="{{ $s['value'] }}" @selected(($filters['status'] ?? '')===$s['value'])>{{ $s['label'] }}</option>@endforeach
            </select>
        </div>
        <div>
            <label class="ta-label">Assigned</label>
            <select name="assigned" class="ta-input">
                <option value="">All</option>
                @foreach ($users as $u)<option value="{{ $u->id }}" @selected(($filters['assigned'] ?? '')==$u->id)>{{ $u->name }}</option>@endforeach
            </select>
        </div>
        <div>
            <button class="btn btn-primary w-full"><i class="fa-solid fa-filter"></i> Filter</button>
        </div>
    </form>
</x-card>

{{-- Desktop table --}}
<x-card padding="p-0" class="hidden lg:block">
    <table class="w-full">
        <thead class="border-b border-line dark:border-strokedark">
            <tr>
                <th class="ta-th">Company</th>
                <th class="ta-th">Type</th>
                <th class="ta-th">Budget</th>
                <th class="ta-th">Deals</th>
                <th class="ta-th">Status</th>
                <th class="ta-th">Assigned</th>
                <th class="ta-th"></th>
            </tr>
        </thead>
        <tbody class="divide-y divide-line dark:divide-strokedark">
            @forelse ($sponsors as $sponsor)
                <tr class="transition hover:bg-surface dark:hover:bg-boxdark/40">
                    <td class="ta-td">
                        <a href="{{ route('sponsors.show', $sponsor) }}" class="font-semibold text-ink hover:text-brand dark:text-white">{{ $sponsor->company_name }}</a>
                        <span class="block text-xs text-muted">{{ $sponsor->contact_name ?: '—' }} · {{ $sponsor->email ?: '—' }}</span>
                        @if ($sponsor->industry)<span class="block text-xs text-muted">{{ $sponsor->industry }}</span>@endif
                    </td>
                    <td class="ta-td"><x-badge :label="$sponsor->company_type->label()" :color="$sponsor->company_type->color()" /></td>
                    <td class="ta-td text-ink dark:text-gray-300">{{ $sponsor->estimated_budget ? '$' . number_format($sponsor->estimated_budget, 0) : '—' }}</td>
                    <td class="ta-td text-ink dark:text-gray-300">{{ $sponsor->deals_count }}</td>
                    <td class="ta-td"><x-badge :label="$sponsor->status->label()" :color="$sponsor->status->color()" /></td>
                    <td class="ta-td text-muted text-sm">{{ $sponsor->assignee?->name ?? 'Unassigned' }}</td>
                    <td class="ta-td">
                        <div class="flex items-center justify-end gap-2">
                            <a href="{{ route('sponsors.show', $sponsor) }}" class="btn btn-light !px-3 !py-1.5 text-xs">View</a>
                            @unless (auth()->user()->role->isReadOnly())
                                <form method="POST" action="{{ route('sponsors.destroy', $sponsor) }}"
                                      onsubmit="return confirm('Delete {{ $sponsor->company_name }}? Its deals and activities will also be removed.')">
                                    @csrf @method('DELETE')
                                    <button class="btn btn-light !px-3 !py-1.5 text-xs text-danger hover:bg-danger/10" title="Delete"><i class="fa-solid fa-trash"></i></button>
                                </form>
                            @endunless
                        </div>
                    </td>
                </tr>
            @empty
                <tr><td colspan="7" class="ta-td py-12 text-center">
                    <p class="text-muted">No sponsors or vendors yet.</p>
                </td></tr>
            @endforelse
        </tbody>
    </table>
    <div class="border-t border-line px-6 py-4 dark:border-strokedark">{{ $sponsors->links() }}</div>
</x-card>

{{-- Mobile cards --}}
<div class="space-y-3 lg:hidden">
    @forelse ($sponsors as $sponsor)
        <x-card padding="p-4">
            <div class="flex items-start justify-between gap-3">
                <a href="{{ route('sponsors.show', $sponsor) }}" class="font-semibold text-ink hover:text-brand dark:text-white">{{ $sponsor->company_name }}</a>
                <x-badge :label="$sponsor->company_type->label()" :color="$sponsor->company_type->color()" />
            </div>
            <p class="mt-1 text-sm text-muted">{{ $sponsor->contact_name ?: '—' }} · {{ $sponsor->email ?: '—' }}</p>
            <div class="mt-3 grid grid-cols-2 gap-y-2 text-sm">
                <span class="text-muted">Budget</span>
                <span class="text-right text-ink dark:text-gray-300">{{ $sponsor->estimated_budget ? '$' . number_format($sponsor->estimated_budget, 0) : '—' }}</span>
                <span class="text-muted">Status</span>
                <span class="text-right"><x-badge :label="$sponsor->status->label()" :color="$sponsor->status->color()" /></span>
            </div>
            <div class="mt-3 flex gap-2">
                <a href="{{ route('sponsors.show', $sponsor) }}" class="btn btn-light flex-1 !py-2 text-sm">View profile</a>
                @unless (auth()->user()->role->isReadOnly())
                    <form method="POST" action="{{ route('sponsors.destroy', $sponsor) }}"
                          onsubmit="return confirm('Delete {{ $sponsor->company_name }}? Its deals and activities will also be removed.')">
                        @csrf @method('DELETE')
                        <button class="btn btn-light !py-2 text-sm text-danger hover:bg-danger/10"><i class="fa-solid fa-trash"></i></button>
                    </form>
                @endunless
            </div>
        </x-card>
    @empty
        <x-card padding="p-8"><p class="text-center text-muted">No sponsors or vendors yet.</p></x-card>
    @endforelse
    <div>{{ $sponsors->links() }}</div>
</div>
@endsection
