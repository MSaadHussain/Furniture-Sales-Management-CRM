<?php

namespace Tests\Feature;

use App\Events\HotLeadReceived;
use App\Models\IntegrationSetting;
use App\Models\User;
use App\Notifications\HotLeadNotification;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Notification;
use Tests\TestCase;

class NotificationTest extends TestCase
{
    use RefreshDatabase;

    public function test_hot_lead_notifies_managers(): void
    {
        Notification::fake();

        $manager = User::factory()->create(['role' => 'sales_manager']);
        IntegrationSetting::create(['channel' => 'website', 'secret_key' => 'sk', 'enabled' => true]);

        $this->withHeaders(['X-Webhook-Secret' => 'sk'])
            ->postJson('/api/v1/leads/website', [
                'name' => 'Hot Lead', 'email' => 'hot@example.com',
                'message' => 'urgent sponsor booking call me ASAP',
            ])->assertCreated();

        Notification::assertSentTo($manager, HotLeadNotification::class);
    }

    public function test_mark_all_read(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $admin->notify(new HotLeadNotification(\App\Models\Lead::factory()->create()));

        $this->assertSame(1, $admin->unreadNotifications()->count());

        $this->actingAs($admin)->post('/notifications/read-all')->assertRedirect();

        $this->assertSame(0, $admin->fresh()->unreadNotifications()->count());
    }
}
