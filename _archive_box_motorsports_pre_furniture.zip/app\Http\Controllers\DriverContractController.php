<?php

namespace App\Http\Controllers;

use App\Enums\CarType;
use App\Enums\DriverContractStatus;
use App\Enums\DriverContractType;
use App\Enums\DriverRacingLevel;
use App\Models\DriverContract;
use App\Models\DriverLead;
use App\Models\DriverLeadActivity;
use App\Models\SponsorActivity;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rules\Enum;

class DriverContractController extends Controller
{
    public function store(Request $request, DriverLead $driverLead)
    {
        $validated = $this->validateContract($request);

        if ($request->hasFile('document')) {
            $validated['document_path'] = $request->file('document')->store('driver-contracts', 'public');
        }
        unset($validated['document']);

        $contract = DriverContract::create(array_merge($validated, [
            'driver_lead_id' => $driverLead->id,
            'created_by'     => Auth::id(),
            'updated_by'     => Auth::id(),
        ]));

        DriverLeadActivity::create([
            'driver_lead_id' => $driverLead->id,
            'user_id'        => Auth::id(),
            'action'         => 'contract_created',
            'description'    => "Contract created: {$contract->contract_type->label()} ({$contract->contract_status->label()})",
        ]);

        if ($contract->sponsor_profile_id) {
            SponsorActivity::create([
                'sponsor_profile_id'  => $contract->sponsor_profile_id,
                'sponsorship_deal_id' => $contract->sponsorship_deal_id,
                'driver_lead_id'      => $driverLead->id,
                'action_type'         => \App\Enums\SponsorActionType::Note,
                'description'         => "Driver contract created for {$driverLead->full_name}: {$contract->contract_type->label()}",
                'performed_by'        => Auth::id(),
                'completed_at'        => now(),
            ]);
        }

        return back()->with('toast', 'Contract created.');
    }

    public function update(Request $request, DriverContract $contract)
    {
        $validated = $this->validateContract($request);

        if ($request->hasFile('document')) {
            $validated['document_path'] = $request->file('document')->store('driver-contracts', 'public');
        }
        unset($validated['document']);

        $validated['updated_by'] = Auth::id();

        $contract->update($validated);

        DriverLeadActivity::create([
            'driver_lead_id' => $contract->driver_lead_id,
            'user_id'        => Auth::id(),
            'action'         => 'contract_updated',
            'description'    => "Contract updated: {$contract->contract_type->label()}",
        ]);

        return back()->with('toast', 'Contract updated.');
    }

    public function changeStatus(Request $request, DriverContract $contract)
    {
        $request->validate(['contract_status' => ['required', new Enum(DriverContractStatus::class)]]);

        $old = $contract->contract_status;
        $new = DriverContractStatus::from($request->input('contract_status'));

        if ($old !== $new) {
            $contract->update([
                'contract_status' => $new,
                'updated_by'      => Auth::id(),
                'signed_date'     => ($new === DriverContractStatus::Signed && ! $contract->signed_date)
                    ? now()->toDateString()
                    : $contract->signed_date,
            ]);

            DriverLeadActivity::create([
                'driver_lead_id' => $contract->driver_lead_id,
                'user_id'        => Auth::id(),
                'action'         => 'contract_status_changed',
                'description'    => "Contract status changed: {$contract->contract_type->label()}",
                'old_value'      => $old->value,
                'new_value'      => $new->value,
            ]);
        }

        return back()->with('toast', 'Contract status updated.');
    }

    public function destroy(DriverContract $contract)
    {
        DriverLeadActivity::create([
            'driver_lead_id' => $contract->driver_lead_id,
            'user_id'        => Auth::id(),
            'action'         => 'contract_deleted',
            'description'    => "Contract deleted: {$contract->contract_type->label()}",
        ]);

        $contract->delete();

        return back()->with('toast', 'Contract deleted.');
    }

    private function validateContract(Request $request): array
    {
        return $request->validate([
            'sponsor_profile_id'  => ['nullable', 'exists:sponsor_profiles,id'],
            'sponsorship_deal_id' => ['nullable', 'exists:sponsorship_deals,id'],
            'contract_type'       => ['required', new Enum(DriverContractType::class)],
            'contract_status'     => ['required', new Enum(DriverContractStatus::class)],
            'racing_level'        => ['nullable', new Enum(DriverRacingLevel::class)],
            'car_type'            => ['nullable', new Enum(CarType::class)],
            'contract_value'      => ['nullable', 'numeric', 'min:0'],
            'currency'            => ['nullable', 'string', 'max:10'],
            'start_date'          => ['nullable', 'date'],
            'end_date'            => ['nullable', 'date', 'after_or_equal:start_date'],
            'signed_date'         => ['nullable', 'date'],
            'document'            => ['nullable', 'file', 'mimes:pdf,doc,docx,jpg,jpeg,png', 'max:10240'],
            'notes'               => ['nullable', 'string', 'max:5000'],
        ]);
    }
}
