<?php

namespace Tests\Feature;

use App\Models\Lead;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class LocationReportTest extends TestCase
{
    use RefreshDatabase;

    public function test_location_data_endpoint_returns_country_aggregation(): void
    {
        $user = User::factory()->create(['role' => 'admin']);

        Lead::factory()->create(['country_code' => 'GB', 'created_at' => now()]);
        Lead::factory()->create(['country_code' => 'GB', 'created_at' => now()]);
        Lead::factory()->create(['country' => 'France', 'created_at' => now()]);

        $response = $this->actingAs($user)->getJson('/dashboard/location-data?range=last_30&source=all');

        $response->assertOk()
            ->assertJsonStructure(['range', 'total', 'countries' => [['code', 'name', 'total', 'percentage', 'lat', 'lng']]]);

        $data = $response->json();
        $this->assertSame(3, $data['total']);
        $this->assertSame('United Kingdom', $data['countries'][0]['name']);
        $this->assertSame(2, $data['countries'][0]['total']);
    }

    public function test_location_data_respects_source_filter(): void
    {
        $user = User::factory()->create(['role' => 'admin']);

        Lead::factory()->create(['country_code' => 'GB', 'source_channel' => 'website']);
        Lead::factory()->create(['country_code' => 'US', 'source_channel' => 'whatsapp']);

        $data = $this->actingAs($user)
            ->getJson('/dashboard/location-data?range=last_30&source=website')
            ->assertOk()->json();

        $this->assertSame(1, $data['total']);
        $this->assertSame('United Kingdom', $data['countries'][0]['name']);
    }

    public function test_location_report_page_loads(): void
    {
        $user = User::factory()->create(['role' => 'admin']);
        Lead::factory()->create(['country_code' => 'GB']);

        $this->actingAs($user)
            ->get('/reports/location')
            ->assertOk()
            ->assertSee('Country Breakdown');
    }

    public function test_dashboard_includes_location_map(): void
    {
        $user = User::factory()->create(['role' => 'admin']);

        $this->actingAs($user)
            ->get('/dashboard')
            ->assertOk()
            ->assertSee('Leads by Country');
    }
}
