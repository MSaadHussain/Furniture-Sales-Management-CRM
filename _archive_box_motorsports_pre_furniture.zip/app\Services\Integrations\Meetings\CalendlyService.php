<?php

namespace App\Services\Integrations\Meetings;

use App\Enums\InteractionType;
use App\Enums\LeadStatus;
use App\Models\IntegrationSetting;
use App\Models\Lead;
use App\Models\LeadMeeting;
use App\Services\LeadInteractionService;
use Carbon\Carbon;
use Illuminate\Support\Facades\Http;

/**
 * Calendly integration: validates the webhook signature, attaches booked
 * meetings to the matching lead (by email), logs a timeline entry, and moves
 * the lead to "Meeting Scheduled".
 */
class CalendlyService
{
    private array $config;

    public function __construct(private LeadInteractionService $interactions)
    {
        $this->config = IntegrationSetting::where('channel', 'calendly')->value('config') ?? [];
    }

    public function cfg(string $key): ?string
    {
        return $this->config[$key] ?? config("services.calendly.{$key}");
    }

    /** Verify Calendly's webhook signature header (HMAC-SHA256). */
    public function verifySignature(string $payload, ?string $signatureHeader): bool
    {
        $key = $this->cfg('webhook_signing_key');
        if (! $key) {
            return true; // no key configured -> skip verification
        }
        if (! $signatureHeader) {
            return false;
        }

        // Header format: "t=timestamp,v1=signature"
        parse_str(str_replace(',', '&', $signatureHeader), $parts);
        $expected = hash_hmac('sha256', ($parts['t'] ?? '') . '.' . $payload, $key);

        return isset($parts['v1']) && hash_equals($expected, $parts['v1']);
    }

    /**
     * Process an invitee.created event. Returns the LeadMeeting or null.
     */
    public function handleBooking(array $payload): ?LeadMeeting
    {
        $event = $payload['event'] ?? null;
        $invitee = $payload['payload'] ?? [];

        $email = $invitee['email'] ?? null;
        $name  = $invitee['name'] ?? null;
        $startsAt = data_get($invitee, 'scheduled_event.start_time');
        $endsAt   = data_get($invitee, 'scheduled_event.end_time');
        $meetingUrl = data_get($invitee, 'scheduled_event.location.join_url')
            ?? ($invitee['uri'] ?? null);
        $externalId = $invitee['uri'] ?? null;

        if (! $email) {
            return null;
        }

        // Match an existing lead by email.
        $lead = Lead::where('email', strtolower(trim($email)))->first();
        if (! $lead) {
            return null; // unmatched bookings are ignored (could be extended to create a lead)
        }

        $meeting = LeadMeeting::create([
            'meetable_type'     => Lead::class,
            'meetable_id'       => $lead->id,
            'provider'          => 'calendly',
            'external_event_id' => $externalId,
            'meeting_title'     => data_get($invitee, 'scheduled_event.name', 'Calendly meeting'),
            'meeting_url'       => $meetingUrl,
            'starts_at'         => $startsAt ? Carbon::parse($startsAt) : null,
            'ends_at'           => $endsAt ? Carbon::parse($endsAt) : null,
            'attendee_email'    => $email,
            'attendee_name'     => $name,
            'status'            => $event === 'invitee.canceled' ? 'canceled' : 'scheduled',
            'raw_payload'       => $payload,
        ]);

        // Timeline + status update (only on creation).
        if ($event !== 'invitee.canceled') {
            $this->interactions->record(
                $lead, InteractionType::MEETING_SCHEDULED,
                "Calendly meeting booked by {$name} for " . ($startsAt ? Carbon::parse($startsAt)->format('M j, Y g:i A') : 'TBD') . '.',
                metadata: ['meeting_id' => $meeting->id]
            );

            if (! in_array($lead->status, [LeadStatus::ClosedWon, LeadStatus::ClosedLost], true)) {
                $lead->update(['status' => LeadStatus::MeetingScheduled]);
            }
        }

        return $meeting;
    }

    public function testConnection(): array
    {
        $token = $this->cfg('api_token');
        if (! $token) {
            return [false, 'Missing Calendly API token.'];
        }
        $response = Http::withToken($token)->timeout(10)->get('https://api.calendly.com/users/me');

        return $response->successful()
            ? [true, 'Connected as ' . data_get($response->json(), 'resource.name', 'Calendly user')]
            : [false, 'Calendly API error: ' . $response->status()];
    }
}
