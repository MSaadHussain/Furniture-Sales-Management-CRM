/**
 * Google Apps Script — Send Google Form responses to Box Motorsports CRM
 *
 * SETUP:
 * 1. Open your Google Form → three-dot menu → Script Editor
 * 2. Paste this entire script
 * 3. Update WEBHOOK_URL and WEBHOOK_SECRET below (find them in the CRM:
 *    Integrations → Driver Lead Form)
 * 4. Triggers → Add Trigger → onFormSubmit → From form → On form submit
 *
 * FORM QUESTIONS (matched by title, order doesn't matter):
 *   First Name, Last Name, Email, Phone, Country, DOB, Years Racing,
 *   Highest Series, Racing Level, Car Type, Career Wins,
 *   Current Team / Series, Instagram Handle, Instagram Followers,
 *   Seeking Sponsorship, Interested Contract Type
 *
 * Racing Level and Car Type are independent questions — the CRM never
 * derives Car Type from Racing Level.
 */

var WEBHOOK_URL    = 'YOUR_CRM_URL/api/v1/driver-leads/webhook';
var WEBHOOK_SECRET = 'YOUR_DRIVER_LEADS_SECRET_HERE';

function onFormSubmit(e) {
  // Map answers by question title — question order in the form doesn't matter.
  var map = {};
  e.response.getItemResponses().forEach(function (r) {
    map[r.getItem().getTitle().trim().toLowerCase()] = r.getResponse();
  });

  var payload = {
    first_name:             pick(map, 'first name'),
    last_name:              pick(map, 'last name'),
    email:                  pick(map, 'email'),
    phone:                  pick(map, 'phone'),
    country:                pick(map, 'country'),
    dob:                    pick(map, 'dob'),
    years_racing:           parseInt(pick(map, 'years racing'), 10) || 0,
    highest_series:         pick(map, 'highest series'),
    racing_level:           pick(map, 'racing level'),
    car_type:               pick(map, 'car type'),
    career_wins:            parseInt(pick(map, 'career wins'), 10) || 0,
    current_team_series:    pick(map, 'current team'),
    instagram_handle:       pick(map, 'instagram handle'),
    instagram_followers:    parseInt(pick(map, 'instagram followers'), 10) || 0,
    seeking_sponsorship:    isTruthy(pick(map, 'seeking sponsorship')),
    contract_interest_type: pick(map, 'interested contract type'),
  };

  var options = {
    method: 'post',
    contentType: 'application/json',
    headers: { 'X-Webhook-Secret': WEBHOOK_SECRET },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true,
  };
  var response = UrlFetchApp.fetch(WEBHOOK_URL, options);
  Logger.log('CRM Response (' + response.getResponseCode() + '): ' + response.getContentText());
}

// Finds the answer whose question title starts with (or contains) the key.
function pick(map, key) {
  if (map[key] !== undefined) return String(map[key]).trim();
  var titles = Object.keys(map);
  for (var i = 0; i < titles.length; i++) {
    if (titles[i].indexOf(key) !== -1) return String(map[titles[i]]).trim();
  }
  return '';
}

function isTruthy(val) {
  if (!val) return false;
  var lower = String(val).toLowerCase().trim();
  return lower === 'yes' || lower === 'true' || lower === '1' || lower === 'y';
}
