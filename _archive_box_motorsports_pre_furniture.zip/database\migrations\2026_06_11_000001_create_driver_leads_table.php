<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('driver_leads', function (Blueprint $table) {
            $table->id();
            $table->string('first_name');
            $table->string('last_name');
            $table->string('email')->index();
            $table->string('phone')->nullable();
            $table->string('country')->nullable();

            $table->unsignedSmallInteger('years_racing')->default(0);
            $table->string('highest_series')->nullable();
            $table->unsignedInteger('career_wins')->default(0);
            $table->string('current_team_series')->nullable();

            $table->string('instagram_handle')->nullable();
            $table->unsignedInteger('instagram_followers')->default(0);

            $table->boolean('seeking_sponsorship')->default(false);
            $table->string('inferred_tier', 20)->default('amateur');
            $table->string('status', 20)->default('new');

            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('driver_leads');
    }
};
