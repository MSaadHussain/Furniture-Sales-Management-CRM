<?php

namespace App\Http\Controllers\Api\V1\Webhooks;

use App\Enums\SponsorActionType;
use App\Enums\SponsorProfileType;
use App\Enums\SponsorStatus;
use App\Http\Controllers\Controller;
use App\Models\SponsorActivity;
use App\Models\SponsorProfile;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SponsorLeadWebhookController extends Controller
{
    public function receive(Request $request): JsonResponse
    {
        $data = $request->validate([
            'company_name'     => ['required', 'string', 'max:255'],
            'company_type'     => ['nullable', 'string', 'max:100'],
            'industry'         => ['nullable', 'string', 'max:255'],
            'website'          => ['nullable', 'string', 'max:255'],
            'contact_name'     => ['nullable', 'string', 'max:255'],
            'email'            => ['required', 'email', 'max:255'],
            'phone'            => ['required', 'string', 'max:50'],
            'country'          => ['nullable', 'string', 'max:100'],
            'city'             => ['nullable', 'string', 'max:100'],
            'estimated_budget' => ['nullable'],
            'partnership_scope'=> ['nullable', 'string', 'max:1000'],
            'agreement_terms'  => ['nullable', 'string', 'max:5000'],
        ]);

        $data['company_type'] = $this->normalizeType($data['company_type'] ?? '');
        $data['status']       = SponsorStatus::Prospect;

        // Budget may arrive as "$50,000", "50000", or blank — strip everything non-numeric.
        $budget = preg_replace('/[^0-9.]/', '', (string) ($data['estimated_budget'] ?? ''));
        $data['estimated_budget'] = $budget !== '' ? (float) $budget : null;

        // Combine the free-text form answers into the internal notes field.
        $notes = collect([
            ($data['partnership_scope'] ?? null) ? 'Partnership scope: ' . $data['partnership_scope'] : null,
            ($data['agreement_terms'] ?? null) ? 'Agreement terms: ' . $data['agreement_terms'] : null,
        ])->filter()->implode("\n\n");
        $data['notes'] = $notes ?: null;
        unset($data['partnership_scope'], $data['agreement_terms']);

        // Dedup by email first, then by exact company name.
        $existing = null;
        if (! empty($data['email'])) {
            $existing = SponsorProfile::where('email', $data['email'])->first();
        }
        if (! $existing) {
            $existing = SponsorProfile::where('company_name', $data['company_name'])->first();
        }

        if ($existing) {
            // Fill only blank fields; never wipe existing data, and append new notes.
            $fillable = array_filter($data, function ($value, $key) use ($existing) {
                if ($key === 'notes' || $key === 'status') {
                    return false;
                }
                $current = $existing->{$key};
                return ($current === null || $current === '') && $value !== null && $value !== '';
            }, ARRAY_FILTER_USE_BOTH);

            if ($data['notes']) {
                $fillable['notes'] = trim(($existing->notes ? $existing->notes . "\n\n" : '') . $data['notes']);
            }

            if (! empty($fillable)) {
                $existing->update($fillable);
            }

            SponsorActivity::create([
                'sponsor_profile_id' => $existing->id,
                'action_type'        => SponsorActionType::Note,
                'description'        => 'Sponsor lead re-submitted via Google Form webhook (existing profile updated)',
                'completed_at'       => now(),
            ]);

            return response()->json([
                'success'    => true,
                'created'    => false,
                'merged'     => true,
                'sponsor_id' => $existing->id,
            ]);
        }

        $sponsor = SponsorProfile::create($data);

        SponsorActivity::create([
            'sponsor_profile_id' => $sponsor->id,
            'action_type'        => SponsorActionType::Note,
            'description'        => 'Sponsor lead created via Google Form webhook',
            'completed_at'       => now(),
        ]);

        return response()->json([
            'success'    => true,
            'created'    => true,
            'merged'     => false,
            'sponsor_id' => $sponsor->id,
        ], 201);
    }

    /** Map a free-text classification answer onto the SponsorProfileType enum. */
    private function normalizeType(string $raw): SponsorProfileType
    {
        $lower = strtolower(trim($raw));

        return match (true) {
            str_contains($lower, 'vendor')                                  => SponsorProfileType::Vendor,
            str_contains($lower, 'track')                                   => SponsorProfileType::TrackPartner,
            str_contains($lower, 'asset') || str_contains($lower, 'racing') => SponsorProfileType::RacingAssetProvider,
            str_contains($lower, 'media')                                   => SponsorProfileType::MediaPartner,
            default                                                         => SponsorProfileType::Sponsor,
        };
    }
}
