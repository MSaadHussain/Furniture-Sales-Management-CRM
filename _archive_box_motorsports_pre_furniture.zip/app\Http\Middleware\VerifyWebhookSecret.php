<?php

namespace App\Http\Middleware;

use App\Services\WebhookSecurityService;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class VerifyWebhookSecret
{
    public function __construct(private WebhookSecurityService $security) {}

    public function handle(Request $request, Closure $next, string $channel, string $mode = 'shared'): Response
    {
        $ok = $mode === 'hmac'
            ? $this->security->verifyHmac($request, $channel)
            : $this->security->verifySharedSecret($request, $channel);

        if (! $ok) {
            $this->security->logFailure($channel, $request, 'invalid_or_missing_secret');

            return response()->json([
                'success' => false,
                'message' => 'Unauthorized webhook request.',
            ], 401);
        }

        return $next($request);
    }
}
