@extends('layouts.app')
@section('title', 'Import Leads')

@section('header_actions')
    <a href="{{ route('leads.import.batches') }}" class="btn btn-light">
        <i class="fa-solid fa-clock-rotate-left"></i> Import History
    </a>
@endsection

@section('content')
<div class="grid grid-cols-1 gap-6 lg:grid-cols-3">

    {{-- Uploader --}}
    <div class="lg:col-span-2">
        <x-card>
            <form method="POST" action="{{ route('leads.import.upload') }}" enctype="multipart/form-data"
                  x-data="uploader()" @submit="submitting = true">
                @csrf

                <div class="mb-2 flex items-center gap-2">
                    <span class="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-50 text-brand">
                        <i class="fa-solid fa-file-arrow-up"></i>
                    </span>
                    <h3 class="text-lg font-semibold text-ink dark:text-white">Upload a file</h3>
                </div>
                <p class="mb-5 text-sm text-muted">
                    Drag &amp; drop or browse. Accepted formats:
                    <span class="font-medium text-ink dark:text-gray-200">CSV, XLSX, XLS, PDF</span> (max 20&nbsp;MB).
                </p>

                {{-- Drop zone --}}
                <label
                    @dragover.prevent="dragging = true"
                    @dragleave.prevent="dragging = false"
                    @drop.prevent="handleDrop($event)"
                    :class="dragging ? 'border-brand bg-brand-50/60' : 'border-line dark:border-strokedark'"
                    class="flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed
                           px-6 py-12 text-center transition-colors">
                    <i class="fa-solid fa-cloud-arrow-up mb-3 text-4xl text-brand"></i>
                    <p class="text-sm font-medium text-ink dark:text-gray-200" x-show="!fileName">
                        Drop your file here, or <span class="text-brand">browse</span>
                    </p>
                    <p class="text-sm font-semibold text-brand" x-show="fileName" x-text="fileName" x-cloak></p>
                    <p class="mt-1 text-xs text-muted" x-show="fileName" x-text="fileSize" x-cloak></p>
                    <input type="file" name="file" class="hidden" required
                           accept=".csv,.txt,.tsv,.xlsx,.xls,.pdf"
                           @change="handleSelect($event)" />
                </label>

                {{-- Upload progress (indeterminate while server parses) --}}
                <div x-show="submitting" x-cloak class="mt-4">
                    <div class="h-2 w-full overflow-hidden rounded-full bg-line dark:bg-strokedark">
                        <div class="h-full w-1/2 animate-pulse rounded-full bg-brand"></div>
                    </div>
                    <p class="mt-2 text-xs text-muted">Uploading &amp; parsing…</p>
                </div>

                <div class="mt-6 flex justify-end gap-2">
                    <a href="{{ route('leads.index') }}" class="btn btn-light">Cancel</a>
                    <button type="submit" class="btn btn-primary" :disabled="!fileName || submitting">
                        <i class="fa-solid fa-arrow-right"></i> Continue to preview
                    </button>
                </div>
            </form>
        </x-card>
    </div>

    {{-- Side help / recent --}}
    <div class="space-y-6">
        <x-card title="Expected columns" subtitle="Headers we auto-detect">
            <div class="flex flex-wrap gap-2">
                @foreach ($fields as $f)
                    <span class="ta-badge bg-surface text-muted dark:bg-boxdark">{{ $f }}</span>
                @endforeach
            </div>
            <p class="mt-4 text-xs text-muted">
                Unknown headers can be mapped manually on the next step. PDFs are scanned for
                name, email, phone, country, city and message.
            </p>
        </x-card>

        <x-card title="Recent imports" padding="p-0">
            <div class="divide-y divide-line dark:divide-strokedark">
                @forelse ($recentBatches as $b)
                    <a href="{{ route('leads.import.batches.show', $b) }}"
                       class="flex items-center gap-3 px-5 py-4 transition hover:bg-surface dark:hover:bg-boxdark">
                        <span class="flex h-10 w-10 flex-none items-center justify-center rounded-lg bg-brand/10 text-brand">
                            <i class="fa-solid {{ $b->file_type === 'pdf' ? 'fa-file-pdf' : ($b->file_type === 'csv' ? 'fa-file-csv' : 'fa-file-excel') }}"></i>
                        </span>
                        <div class="min-w-0 flex-1">
                            <p class="truncate text-sm font-medium text-ink dark:text-gray-200">{{ $b->file_name }}</p>
                            <p class="mt-0.5 text-xs text-muted">
                                {{ strtoupper($b->file_type) }} ·
                                <span class="text-success">{{ $b->successful_rows ?? 0 }} ok</span>
                                @if (($b->failed_rows ?? 0) > 0) · <span class="text-danger">{{ $b->failed_rows }} failed</span> @endif
                                · {{ $b->created_at->diffForHumans() }}
                            </p>
                        </div>
                        @include('leads.import._status', ['status' => $b->status])
                    </a>
                @empty
                    <div class="flex flex-col items-center justify-center px-5 py-10 text-center">
                        <span class="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-surface dark:bg-boxdark">
                            <i class="fa-solid fa-inbox text-lg text-muted"></i>
                        </span>
                        <p class="text-sm font-medium text-ink dark:text-gray-200">No imports yet</p>
                        <p class="mt-1 text-xs text-muted">Upload a CSV, XLSX or PDF to get started.</p>
                    </div>
                @endforelse
            </div>
        </x-card>
    </div>
</div>

@push('scripts')
<script>
function uploader() {
    return {
        dragging: false, submitting: false, fileName: '', fileSize: '',
        handleSelect(e) { const f = e.target.files[0]; if (f) this.setFile(f); },
        handleDrop(e) {
            this.dragging = false;
            const f = e.dataTransfer.files[0];
            if (f) { e.target.closest('label').querySelector('input[type=file]').files = e.dataTransfer.files; this.setFile(f); }
        },
        setFile(f) { this.fileName = f.name; this.fileSize = (f.size/1024/1024).toFixed(2) + ' MB'; },
    };
}
</script>
@endpush
@endsection
