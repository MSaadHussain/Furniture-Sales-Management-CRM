<?php

namespace App\Services;

use App\Enums\MotorsportInterest;
use App\Enums\SourceChannel;

class LeadNormalizerService
{
    public function names(?string $first, ?string $last, ?string $full = null): array
    {
        $first = $this->clean($first);
        $last  = $this->clean($last);
        $full  = $this->clean($full);

        if (! $first && ! $last && $full) {
            $parts = preg_split('/\s+/', $full, 2);
            $first = $parts[0] ?? null;
            $last  = $parts[1] ?? null;
        }

        $computedFull = trim(implode(' ', array_filter([$first, $last]))) ?: $full;

        return [
            'first_name' => $first,
            'last_name'  => $last,
            'full_name'  => $computedFull ?: null,
        ];
    }

    public function email(?string $email): ?string
    {
        $email = strtolower(trim((string) $email));
        return filter_var($email, FILTER_VALIDATE_EMAIL) ? $email : null;
    }

    public function phone(?string $phone): ?string
    {
        if (! $phone) {
            return null;
        }

        $hasPlus = str_starts_with(trim($phone), '+');
        $digits  = preg_replace('/\D+/', '', $phone);

        if ($digits === '') {
            return null;
        }

        return ($hasPlus ? '+' : '') . $digits;
    }

    public function fromPayload(SourceChannel $channel, array $payload): array
    {
        $mapped = match ($channel) {
            SourceChannel::Jotform    => $this->mapJotform($payload),
            SourceChannel::GoogleForm => $this->mapGoogleForm($payload),
            SourceChannel::Website    => $this->mapWebsite($payload),
            SourceChannel::WhatsApp   => $this->mapWhatsApp($payload),
            SourceChannel::Email      => $this->mapEmail($payload),
            SourceChannel::Meta           => $this->mapMeta($payload),
            SourceChannel::GoogleLeadForm => $this->mapGoogleLead($payload),
            default                   => $payload,
        };

        $names = $this->names(
            $mapped['first_name'] ?? null,
            $mapped['last_name'] ?? null,
            $mapped['full_name'] ?? null
        );

        return [
            'first_name'               => $names['first_name'],
            'last_name'                => $names['last_name'],
            'full_name'                => $names['full_name'],
            'email'                    => $this->email($mapped['email'] ?? null),
            'phone'                    => $mapped['phone'] ?? null,
            'normalized_phone'         => $this->phone($mapped['phone'] ?? null),
            'loc_state'                => $this->clean($mapped['loc_state'] ?? null),
            'country'                  => $this->clean($mapped['country'] ?? null),
            'message'                  => $this->clean($mapped['message'] ?? null),
            'motorsport_interest_type' => $this->interest($mapped['motorsport_interest_type'] ?? null),
            'source_channel'           => $channel,
        ];
    }

    public function interest(?string $value): ?MotorsportInterest
    {
        if (! $value) {
            return null;
        }

        $needle = strtolower(trim($value));

        foreach (MotorsportInterest::cases() as $case) {
            if ($needle === $case->value || $needle === strtolower($case->label())) {
                return $case;
            }
        }

        return match (true) {
            str_contains($needle, 'driv')    => MotorsportInterest::Driver,
            str_contains($needle, 'sponsor') => MotorsportInterest::Sponsor,
            str_contains($needle, 'collab')  => MotorsportInterest::Collaborator,
            str_contains($needle, 'event')   => MotorsportInterest::EventInquiry,
            str_contains($needle, 'book')    => MotorsportInterest::BookingInquiry,
            str_contains($needle, 'general') => MotorsportInterest::GeneralInquiry,
            default                          => MotorsportInterest::Other,
        };
    }

    private function mapJotform(array $p): array
    {
        if (isset($p['rawRequest']) && is_string($p['rawRequest'])) {
            $decoded = json_decode($p['rawRequest'], true) ?: [];
            $p = array_merge($p, $decoded);
        }

        $name = $this->firstMatching($p, ['name', 'fullName', 'q3_name']);
        $first = is_array($name) ? ($name['first'] ?? null) : null;
        $last  = is_array($name) ? ($name['last'] ?? null) : null;
        $full  = is_string($name) ? $name : null;

        return [
            'first_name'               => $first ?? $this->firstMatching($p, ['first_name', 'firstName']),
            'last_name'                => $last ?? $this->firstMatching($p, ['last_name', 'lastName']),
            'full_name'                => $full,
            'email'                    => $this->firstMatching($p, ['email', 'q4_email']),
            'phone'                    => $this->flattenPhone($this->firstMatching($p, ['phone', 'phoneNumber', 'q5_phone'])),
            'message'                  => $this->firstMatching($p, ['message', 'comments', 'q6_message']),
            'loc_state'                => $this->firstMatching($p, ['state', 'location', 'city']),
            'motorsport_interest_type' => $this->firstMatching($p, ['interest', 'interest_type', 'category']),
        ];
    }

    private function mapGoogleForm(array $p): array
    {
        // 1. Flatten nested 'raw' or 'lead' arrays if they exist
        $flat = [];
        if (isset($p['raw']) && is_array($p['raw'])) {
            foreach ($p['raw'] as $k => $v) {
                $flat[$k] = is_array($v) ? ($v[0] ?? null) : $v;
            }
        }
        if (isset($p['lead']) && is_array($p['lead'])) {
            foreach ($p['lead'] as $k => $v) {
                if (!isset($flat[$k]) || blank($flat[$k])) {
                    $flat[$k] = is_array($v) ? ($v[0] ?? null) : $v;
                }
            }
        }

        // Merge flat with top-level payload keys
        $merged = array_merge($p, $flat);

        // 2. Build a lowercase key map for case-insensitive lookups
        $normalized = [];
        foreach ($merged as $k => $v) {
            $normalizedKey = strtolower(trim((string)$k));
            if (!isset($normalized[$normalizedKey]) || blank($normalized[$normalizedKey])) {
                $normalized[$normalizedKey] = $v;
            }
        }

        // 3. Helper to lookup values case-insensitively
        $get = function (array $keys) use ($normalized) {
            foreach ($keys as $k) {
                $lowerKey = strtolower(trim($k));
                if (isset($normalized[$lowerKey]) && $normalized[$lowerKey] !== '' && $normalized[$lowerKey] !== []) {
                    return $normalized[$lowerKey];
                }
            }
            return null;
        };

        // 4. Retrieve values
        $firstName = $get(['first name', 'first_name', 'firstname']);
        $lastName  = $get(['last name', 'last_name', 'lastname']);
        $fullName  = $get(['name', 'full name', 'fullname', 'full_name']);
        
        $email = $get(['email', 'email address', 'email_address', 'mail']);
        $phone = $get(['phone', 'phone number', 'phonenumber', 'phone_number', 'mobile', 'contact']);
        
        $locState = $get(['location', 'state', 'region', 'loc_state', 'city']);
        $country  = $get(['country', 'nation']);
        if (blank($country) && filled($locState)) {
            $country = $locState;
        }
        
        // Map address to message if no specific message/comment is found
        $message = $get(['message', 'comments', 'comment', 'notes', 'msg', 'address', 'street']);
        if (blank($message) && filled($country)) {
            $message = $country;
        }

        $interest = $get(['interest', 'i am a', 'motorsport_interest_type', 'category', 'role']);

        return [
            'first_name'               => $firstName,
            'last_name'                => $lastName,
            'full_name'                => $fullName,
            'email'                    => $email,
            'phone'                    => $phone,
            'message'                  => $message,
            'loc_state'                => $locState,
            'country'                  => $country,
            'motorsport_interest_type' => $interest,
        ];
    }

    private function mapWebsite(array $p): array
    {
        return [
            'first_name'               => $p['first_name'] ?? null,
            'last_name'                => $p['last_name'] ?? null,
            'full_name'                => $p['name'] ?? $p['full_name'] ?? null,
            'email'                    => $p['email'] ?? null,
            'phone'                    => $p['phone'] ?? null,
            'message'                  => $p['message'] ?? null,
            'loc_state'                => $p['state'] ?? $p['location'] ?? null,
            'motorsport_interest_type' => $p['interest'] ?? $p['motorsport_interest_type'] ?? null,
        ];
    }

    private function mapWhatsApp(array $p): array
    {
        return [
            'full_name'                => $p['name'] ?? null,
            'phone'                    => $p['phone'] ?? null,
            'message'                  => $p['message'] ?? null,
            'motorsport_interest_type' => $p['interest'] ?? null,
        ];
    }

    private function mapEmail(array $p): array
    {
        return [
            'full_name'                => $p['name'] ?? null,
            'email'                    => $p['email'] ?? null,
            'phone'                    => $p['phone'] ?? null,
            'message'                  => $p['message'] ?? $p['body'] ?? null,
            'loc_state'                => $p['state'] ?? null,
            'motorsport_interest_type' => $p['interest'] ?? null,
        ];
    }

    private function mapMeta(array $p): array
    {
        // Meta Lead Ads deliver answers as field_data: [{name, values:[...]}].
        $fields = [];
        foreach (($p['field_data'] ?? []) as $entry) {
            if (isset($entry['name'])) {
                $fields[strtolower($entry['name'])] = is_array($entry['values'] ?? null)
                    ? ($entry['values'][0] ?? null)
                    : ($entry['values'] ?? null);
            }
        }
        $fields = array_merge($p, $fields); // allow already-flattened payloads

        return [
            'first_name'               => $this->firstMatching($fields, ['first_name', 'firstname']),
            'last_name'                => $this->firstMatching($fields, ['last_name', 'lastname']),
            'full_name'                => $this->firstMatching($fields, ['full_name', 'full name', 'name']),
            'email'                    => $this->firstMatching($fields, ['email', 'email_address', 'work_email']),
            'phone'                    => $this->firstMatching($fields, ['phone_number', 'phone', 'mobile']),
            'message'                  => $this->firstMatching($fields, ['message', 'comments', 'enquiry']),
            'loc_state'                => $this->firstMatching($fields, ['state', 'city', 'region']),
            'country'                  => $this->firstMatching($fields, ['country']),
            'motorsport_interest_type' => $this->firstMatching($fields, ['interest', 'i_am_a', 'category', 'role']),
        ];
    }

    private function mapGoogleLead(array $p): array
    {
        // Google Lead Form Ads deliver user_column_data: [{column_id/column_name, string_value}].
        $fields = [];
        foreach (($p['user_column_data'] ?? []) as $entry) {
            $key = strtolower($entry['column_id'] ?? $entry['column_name'] ?? '');
            if ($key !== '') {
                $fields[$key] = $entry['string_value'] ?? null;
            }
        }
        $fields = array_merge($p, $fields);

        return [
            'first_name'               => $this->firstMatching($fields, ['first_name', 'firstname']),
            'last_name'                => $this->firstMatching($fields, ['last_name', 'lastname']),
            'full_name'                => $this->firstMatching($fields, ['full_name', 'name']),
            'email'                    => $this->firstMatching($fields, ['email', 'user_email', 'email_address']),
            'phone'                    => $this->firstMatching($fields, ['phone_number', 'user_phone_number', 'phone']),
            'message'                  => $this->firstMatching($fields, ['message', 'comments']),
            'loc_state'                => $this->firstMatching($fields, ['region', 'city', 'state', 'postal_code']),
            'country'                  => $this->firstMatching($fields, ['country']),
            'motorsport_interest_type' => $this->firstMatching($fields, ['interest', 'category']),
        ];
    }

    private function firstMatching(array $payload, array $keys): mixed
    {
        foreach ($keys as $key) {
            if (isset($payload[$key]) && $payload[$key] !== '' && $payload[$key] !== []) {
                return $payload[$key];
            }
        }
        return null;
    }

    private function flattenPhone(mixed $value): ?string
    {
        if (is_array($value)) {
            return $value['full'] ?? trim(($value['area'] ?? '') . ($value['phone'] ?? '')) ?: null;
        }
        return is_string($value) ? $value : null;
    }

    private function clean(?string $value): ?string
    {
        $value = trim((string) $value);
        return $value === '' ? null : $value;
    }
}
