@extends('layouts.app')
@section('title', 'Import Driver Leads')
@section('breadcrumb')
    <a href="{{ route('driver-leads.index') }}" class="hover:text-brand">Driver Leads</a> / <span>Import</span>
@endsection

@section('header_actions')
    <a href="{{ route('driver-leads.index') }}" class="btn btn-light"><i class="fa-solid fa-arrow-left"></i> Back to Driver Leads</a>
@endsection

@section('content')
<div class="grid grid-cols-1 gap-6 lg:grid-cols-3">

    {{-- Upload card --}}
    <div class="lg:col-span-2">
        <x-card title="Upload CSV" subtitle="Import driver leads from a CSV file. Use the template to ensure correct formatting.">
            <form method="POST" action="{{ route('driver-leads.import.upload') }}" enctype="multipart/form-data" id="importForm"
                  x-data="{ dragging: false, fileName: '' }">
                @csrf

                <div class="mb-6 rounded-xl border-2 border-dashed p-10 text-center transition-colors"
                     :class="dragging ? 'border-brand bg-brand/5' : 'border-line dark:border-strokedark'"
                     @dragover.prevent="dragging = true"
                     @dragleave.prevent="dragging = false"
                     @drop.prevent="dragging = false; $refs.file.files = $event.dataTransfer.files; fileName = $refs.file.files[0]?.name">
                    <i class="fa-solid fa-cloud-arrow-up mb-3 block text-4xl text-muted"></i>
                    <p class="mb-2 text-sm text-ink dark:text-gray-300">
                        Drag & drop your CSV file here, or
                        <label class="cursor-pointer font-semibold text-brand hover:underline">
                            browse
                            <input type="file" name="file" accept=".csv,.txt" class="hidden" x-ref="file"
                                   @change="fileName = $refs.file.files[0]?.name">
                        </label>
                    </p>
                    <p class="text-xs text-muted">CSV files only, max 10 MB</p>
                    <template x-if="fileName">
                        <p class="mt-3 text-sm font-medium text-brand"><i class="fa-solid fa-file-csv mr-1"></i> <span x-text="fileName"></span></p>
                    </template>
                </div>

                @error('file')
                    <p class="mb-4 text-sm text-red-600">{{ $message }}</p>
                @enderror

                <div class="flex items-center gap-3">
                    <button type="submit" class="btn btn-primary"><i class="fa-solid fa-upload"></i> Upload & Preview</button>
                    <a href="{{ route('driver-leads.import.template') }}" class="btn btn-light"><i class="fa-solid fa-download"></i> Download Template</a>
                </div>
            </form>
        </x-card>
    </div>

    {{-- Expected columns --}}
    <div>
        <x-card title="Expected Columns" subtitle="Your CSV should include these columns.">
            <ul class="space-y-1.5 text-sm">
                @foreach (\App\Http\Controllers\DriverLeadController::IMPORT_FIELDS as $field)
                    <li class="flex items-center gap-2 text-ink dark:text-gray-300">
                        <i class="fa-solid fa-circle text-[5px] text-muted"></i>
                        {{ str_replace('_', ' ', ucfirst($field)) }}
                        @if (in_array($field, \App\Http\Controllers\DriverLeadController::IMPORT_REQUIRED))<span class="text-xs text-danger">(required)</span>@endif
                    </li>
                @endforeach
            </ul>
            <p class="mt-4 text-xs text-muted">
                Column order doesn't matter — you'll map them on the next step.
                Rows missing a required field are skipped.
                Age rules apply: under 12 → Kart/Karting only; under 18 → no Formula 1.
                Download the template for a ready-to-fill example.
            </p>
        </x-card>
    </div>
</div>
@endsection
