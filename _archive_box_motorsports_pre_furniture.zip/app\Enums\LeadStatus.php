<?php

namespace App\Enums;

enum LeadStatus: string
{
    case New = 'new';
    case Contacted = 'contacted';
    case UnderReview = 'under_review';
    case MeetingScheduled = 'meeting_scheduled';
    case ClosedWon = 'closed_won';
    case ClosedLost = 'closed_lost';

    public function label(): string
    {
        return match ($this) {
            self::New              => 'New',
            self::Contacted        => 'Contacted',
            self::UnderReview      => 'Under Review',
            self::MeetingScheduled => 'Meeting Scheduled',
            self::ClosedWon        => 'Closed Won',
            self::ClosedLost       => 'Closed Lost',
        };
    }

    public function color(): string
    {
        return match ($this) {
            self::New              => '#7C3AED',
            self::Contacted        => '#2563EB',
            self::UnderReview      => '#F59E0B',
            self::MeetingScheduled => '#0EA5E9',
            self::ClosedWon        => '#16A34A',
            self::ClosedLost       => '#DC2626',
        };
    }

    public static function pipelineOrder(): array
    {
        return [
            self::New, self::Contacted, self::UnderReview,
            self::MeetingScheduled, self::ClosedWon, self::ClosedLost,
        ];
    }

    public static function options(): array
    {
        return array_map(
            fn (self $s) => ['value' => $s->value, 'label' => $s->label(), 'color' => $s->color()],
            self::cases()
        );
    }
}
