<?php

namespace App\Http\Controllers\Api\V1;

use App\Enums\SourceChannel;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class JotformController extends WebhookController
{
    public function __invoke(Request $request): JsonResponse
    {
        return $this->process(SourceChannel::Jotform, $request->all(), $request);
    }
}
