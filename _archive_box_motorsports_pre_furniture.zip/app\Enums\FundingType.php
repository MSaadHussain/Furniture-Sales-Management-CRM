<?php

namespace App\Enums;

enum FundingType: string
{
    case Cash = 'cash';
    case TrackTime = 'track_time';
    case Equipment = 'equipment';
    case Vehicle = 'vehicle';
    case EventFee = 'event_fee';
    case MediaPackage = 'media_package';
    case Other = 'other';

    public function label(): string
    {
        return match ($this) {
            self::Cash         => 'Cash',
            self::TrackTime    => 'Track Time',
            self::Equipment    => 'Equipment',
            self::Vehicle      => 'Vehicle',
            self::EventFee     => 'Event Fee',
            self::MediaPackage => 'Media Package',
            self::Other        => 'Other',
        };
    }

    public function color(): string
    {
        return match ($this) {
            self::Cash         => '#16A34A',
            self::TrackTime    => '#465FFF',
            self::Equipment    => '#F97316',
            self::Vehicle      => '#7C3AED',
            self::EventFee     => '#0EA5E9',
            self::MediaPackage => '#EC4899',
            self::Other        => '#6B7280',
        };
    }

    public static function options(): array
    {
        return array_map(
            fn (self $t) => ['value' => $t->value, 'label' => $t->label(), 'color' => $t->color()],
            self::cases()
        );
    }
}
