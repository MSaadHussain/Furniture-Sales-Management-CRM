<?php

namespace App\Http\Controllers;

use App\Models\IntegrationSetting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Str;

class IntegrationController extends Controller
{
    private array $channels = ['jotform', 'website', 'whatsapp', 'email', 'notifications'];

    public function index()
    {
        Gate::authorize('manage-integrations');

        $settings = IntegrationSetting::whereIn('channel', $this->channels)
            ->get()->keyBy('channel');

        foreach ($this->channels as $channel) {
            if (! $settings->has($channel)) {
                $settings[$channel] = IntegrationSetting::create([
                    'channel'    => $channel,
                    'enabled'    => false,
                    'secret_key' => $channel === 'notifications' ? null : Str::random(40),
                    'config'     => [],
                ]);
            }
        }

        return view('integrations.index', [
            'settings'    => $settings,
            'webhookBase' => url('/api/v1/leads'),
        ]);
    }

    public function update(Request $request, string $channel)
    {
        Gate::authorize('manage-integrations');
        abort_unless(in_array($channel, $this->channels, true), 404);

        $validated = $request->validate([
            'enabled' => ['nullable', 'boolean'],
            'config'  => ['nullable', 'array'],
        ]);

        $setting = IntegrationSetting::firstOrCreate(['channel' => $channel]);
        $setting->update([
            'enabled' => $request->boolean('enabled'),
            'config'  => array_merge($setting->config ?? [], $validated['config'] ?? []),
        ]);

        return back()->with('toast', ucfirst(str_replace('_', ' ', $channel)) . ' settings saved.');
    }

    public function regenerateSecret(string $channel)
    {
        Gate::authorize('manage-integrations');
        abort_unless(in_array($channel, $this->channels, true), 404);

        $setting = IntegrationSetting::firstOrCreate(['channel' => $channel]);
        $setting->update(['secret_key' => Str::random(40)]);

        return back()->with('toast', 'Secret regenerated.');
    }

    public function test(Request $request, string $channel)
    {
        Gate::authorize('manage-integrations');

        return back()->with('toast', "Test payload accepted for {$channel}. Check the Leads list for a test entry.");
    }
}
