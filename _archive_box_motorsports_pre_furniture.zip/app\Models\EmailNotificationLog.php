<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmailNotificationLog extends Model
{
    protected $fillable = ['type', 'recipient', 'lead_id', 'subject', 'status', 'error'];

    public function lead()
    {
        return $this->belongsTo(Lead::class);
    }

    public static function record(string $type, string $recipient, ?int $leadId, ?string $subject, string $status = 'sent', ?string $error = null): void
    {
        static::create([
            'type'      => $type,
            'recipient' => $recipient,
            'lead_id'   => $leadId,
            'subject'   => $subject,
            'status'    => $status,
            'error'     => $error,
        ]);
    }
}
