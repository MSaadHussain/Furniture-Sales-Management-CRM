<?php

namespace App\Http\Controllers;

use App\Models\IntegrationSetting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Str;

class DriverLeadFormController extends Controller
{
    public function index()
    {
        Gate::authorize('manage-integrations');

        $setting = IntegrationSetting::firstOrCreate(
            ['channel' => 'driver_leads'],
            ['enabled' => true, 'secret_key' => Str::random(40), 'config' => []]
        );

        return view('integrations.driver-lead-form', [
            'setting'    => $setting,
            'webhookUrl' => url('/api/v1/driver-leads/webhook'),
        ]);
    }

    public function save(Request $request)
    {
        Gate::authorize('manage-integrations');

        $setting = IntegrationSetting::firstOrCreate(['channel' => 'driver_leads']);
        $setting->update([
            'enabled' => $request->boolean('enabled'),
        ]);

        return back()->with('toast', 'Driver Lead Form settings saved.');
    }

    public function regenerateSecret()
    {
        Gate::authorize('manage-integrations');

        $setting = IntegrationSetting::firstOrCreate(['channel' => 'driver_leads']);
        $setting->update(['secret_key' => Str::random(40)]);

        return back()->with('toast', 'Webhook secret regenerated. Update your Google Apps Script.');
    }

    public function test()
    {
        Gate::authorize('manage-integrations');

        $setting = IntegrationSetting::where('channel', 'driver_leads')->first();

        if (! $setting || ! $setting->enabled) {
            return back()->with('error', 'Driver Lead Form integration is disabled.');
        }

        return back()->with('toast', 'Driver Lead Form webhook configuration is active. Send a test submission from Google Forms to confirm.');
    }
}
