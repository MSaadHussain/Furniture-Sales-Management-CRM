<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        // Custom middleware aliases used by Box Motorsports CRM
        $middleware->alias([
            'role'           => \App\Http\Middleware\EnsureUserRole::class,
            'webhook.secret' => \App\Http\Middleware\VerifyWebhookSecret::class,
            'password.24h'   => \App\Http\Middleware\ConfirmPasswordEvery24h::class,
            'track.activity' => \App\Http\Middleware\TrackUserActivity::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })->create();
