# Google Forms (Normal) Lead Integration Plan

This document details how to implement and configure the **Normal Google Forms** lead integration within the Box Motorsports CRM. 

> [!NOTE]
> This is separate from the existing **Google Ads Lead Forms** integration (which uses the Google Ads API, Developer Tokens, and client credentials on the **[Google Leads](file:///c:/Users/admin/Downloads/crmapp/app/Http/Controllers/GoogleLeadController.php)** settings screen).

---

## 1. Compatibility & Current System Assessment

Our CRM already has a robust webhook framework. Here is how the components align:

1. **Database settings**: The **[IntegrationSetting](file:///c:/Users/admin/Downloads/crmapp/app/Models/IntegrationSetting.php)** model and the `integration_settings` table are already configured to support a `google_form` channel. We do not need any new tables or database migrations.
2. **API Endpoint**: The route is already registered in **[routes/api.php](file:///c:/Users/admin/Downloads/crmapp/routes/api.php)**:
   ```php
   Route::post('google-form', GoogleFormController::class)
       ->middleware('webhook.secret:google_form');
   ```
   * Full Endpoint: `POST /api/v1/leads/google-form`
   * Authentication Header: `X-Webhook-Secret`
3. **Controller**: **[GoogleFormController](file:///c:/Users/admin/Downloads/crmapp/app/Http/Controllers/Api/V1/GoogleFormController.php)** already handles the route and delegates execution to the core **[LeadIntakeService](file:///c:/Users/admin/Downloads/crmapp/app/Services/LeadIntakeService.php)**.
4. **Data Normalization**: **[LeadNormalizerService](file:///c:/Users/admin/Downloads/crmapp/app/Services/LeadNormalizerService.php)** contains a built-in `mapGoogleForm` mapper that matches sheet column names like `First Name`, `Last Name`, `Full Name`, `Name`, `Email`, `Phone`, `Phone Number`, `Message`, and `Country`.
5. **Pipeline Integration**: Ingested leads are scored, de-duplicated, and logged automatically inside the CRM out-of-the-box.

---

## 2. Required Modifications

To finalize the integration and make it easily accessible to admins, the following changes need to be made:

### 2.1 UI Button in Sidebar
Add a link/button in the admin sidebar specifically for **Google Contact Form** (routing to the Google Forms tab on the Integrations panel).

#### [MODIFY] [sidebar.blade.php](file:///c:/Users/admin/Downloads/crmapp/resources/views/layouts/partials/sidebar.blade.php)
Under the `Integrations` dropdown list (around line 128), insert a sidebar link pointing to `/integrations#tab-google_form`:

```diff
             <ul x-show="open" x-collapse class="mt-1 flex flex-col gap-1 pl-9">
                 <li><a href="{{ route('integrations.index') }}" class="ta-nav-sub {{ request()->routeIs('integrations.index') ? 'active' : '' }}">Channels</a></li>
+                <li><a href="{{ route('integrations.index') }}#tab-google_form" class="ta-nav-sub">Google Contact Form</a></li>
                 <li><a href="{{ route('integrations.meta') }}" class="ta-nav-sub {{ request()->routeIs('integrations.meta') ? 'active' : '' }}">Meta Lead Ads</a></li>
                 <li><a href="{{ route('integrations.google-leads') }}" class="ta-nav-sub {{ request()->routeIs('integrations.google-leads') ? 'active' : '' }}">Google Leads</a></li>
```

Add dynamic JavaScript inside **[resources/views/integrations/index.blade.php](file:///c:/Users/admin/Downloads/crmapp/resources/views/integrations/index.blade.php)** to automatically switch tabs when a hash (like `#tab-google_form`) is present in the URL:

```javascript
document.addEventListener("DOMContentLoaded", function () {
    var hash = window.location.hash;
    if (hash) {
        var tabLink = document.querySelector('a[href="' + hash + '"]');
        if (tabLink) {
            // Deactivate current active tabs
            document.querySelectorAll('.nav-link').forEach(el => el.classList.remove('active'));
            document.querySelectorAll('.tab-pane').forEach(el => el.classList.remove('show', 'active'));
            
            // Activate target tab
            tabLink.classList.add('active');
            var paneId = hash.replace('#', '');
            document.getElementById(paneId).classList.add('show', 'active');
        }
    }
});
```

---

## 3. Google Apps Script Configuration

### 3.1 Link Google Form to Google Sheet
1. Open your **Google Form**.
2. Click **Responses** > **Link to Sheets** to create or link a spreadsheet.
3. Record the exact headers of your response sheet (e.g., `Timestamp`, `Name`, `Email Address`, `Phone number`, `Country`).

### 3.2 Add the Apps Script Code
1. Inside the Google Sheet, go to **Extensions** > **Apps Script**.
2. Paste the following snippet into `Code.gs`:

```javascript
// Configuration: Retrieve these values from the CRM Integrations Settings page.
const CRM_WEBHOOK_URL = 'https://your-crm-domain.com/api/v1/leads/google-form';
const CRM_WEBHOOK_SECRET = 'YOUR_WEBHOOK_SECRET_KEY';

function onFormSubmit(e) {
  var values = e.namedValues || {};
  var data = {};
  
  // Format sheet headers dynamically to match the normalizer expectations
  Object.keys(values).forEach(function(key) {
    if (values[key] && values[key][0]) {
      data[key] = String(values[key][0]).trim();
    }
  });

  try {
    var response = UrlFetchApp.fetch(CRM_WEBHOOK_URL, {
      method: 'post',
      contentType: 'application/json',
      headers: {
        'X-Webhook-Secret': CRM_WEBHOOK_SECRET
      },
      payload: JSON.stringify(data),
      muteHttpExceptions: true
    });

    Logger.log('Response Code: ' + response.getResponseCode());
    Logger.log('Response Body: ' + response.getContentText());
  } catch (error) {
    Logger.log('Error sending lead to CRM: ' + error.toString());
  }
}
```

### 3.3 Configure the Form Trigger
1. In the Apps Script sidebar, click the **Triggers** icon (clock).
2. Click **Add Trigger** (bottom right).
3. Set the parameters:
   * **Choose which function to run**: `onFormSubmit`
   * **Choose which deployment should run**: `Head`
   * **Select event source**: `From spreadsheet`
   * **Select event type**: `On form submit`
4. Click **Save** and complete the Google Authorization prompts.

---

## 4. Local Testing & Verification

### 4.1 Testing Webhook with cURL
You can test the endpoint locally using cURL or Postman. Replace `YOUR_WEBHOOK_SECRET_KEY` with the secret generated on the `/integrations` screen under the **Google Forms** tab.

```bash
curl -X POST "http://localhost:8000/api/v1/leads/google-form" \
  -H "Content-Type: application/json" \
  -H "X-Webhook-Secret: YOUR_WEBHOOK_SECRET_KEY" \
  -d '{
    "Timestamp": "2026-06-09 12:00:00",
    "Name": "Johnny Driver",
    "Email Address": "johnny@motorsports.test",
    "Phone number": "+15551234567",
    "Country": "United States",
    "Interest": "Driver",
    "Message": "I want to join the next GT3 championship race!"
  }'
```

### 4.2 Webhook Testing Protocol
1. Submit a test form response on Forms.
2. Confirm the row inserts in the Sheet.
3. View **Executions** in Apps Script to verify `onFormSubmit` returned status code `201` (New Lead) or `200` (Merged Lead).
4. Verify the lead details in the CRM **[All Leads](file:///c:/Users/admin/Downloads/crmapp/app/Http/Controllers/LeadController.php)** panel.
