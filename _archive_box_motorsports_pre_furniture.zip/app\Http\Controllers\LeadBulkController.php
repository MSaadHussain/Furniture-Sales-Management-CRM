<?php

namespace App\Http\Controllers;

use App\Enums\InteractionType;
use App\Enums\LeadStatus;
use App\Models\Lead;
use App\Services\LeadInteractionService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Validation\Rules\Enum;

class LeadBulkController extends Controller
{
    public function __construct(private LeadInteractionService $interactions) {}

    public function update(Request $request)
    {
        $validated = $request->validate([
            'lead_ids'    => ['required', 'array'],
            'lead_ids.*'  => ['integer', 'exists:leads,id'],
            'action'      => ['required', 'in:status,assign'],
            'status'      => ['required_if:action,status', new Enum(LeadStatus::class)],
            'assigned_to' => ['required_if:action,assign', 'nullable', 'exists:users,id'],
        ]);

        $leads = Lead::whereIn('id', $validated['lead_ids'])->get();

        foreach ($leads as $lead) {
            if ($validated['action'] === 'status') {
                Gate::authorize('update', $lead);
                $old = $lead->status;
                $new = LeadStatus::from($validated['status']);
                if ($old !== $new) {
                    $lead->update(['status' => $new]);
                    $this->interactions->record($lead, InteractionType::STATUS_CHANGED, 'Bulk status update.', $old->label(), $new->label());
                }
            } else {
                Gate::authorize('assign', $lead);
                $lead->update(['assigned_to' => $validated['assigned_to'] ?? null]);
                $this->interactions->record($lead, InteractionType::USER_ASSIGNED, 'Bulk reassignment.');
            }
        }

        return back()->with('toast', count($leads) . ' leads updated.');
    }
}
