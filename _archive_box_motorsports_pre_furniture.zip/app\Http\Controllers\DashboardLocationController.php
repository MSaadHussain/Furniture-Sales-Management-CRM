<?php

namespace App\Http\Controllers;

use App\Enums\SourceChannel;
use App\Enums\UserRole;
use App\Models\Lead;
use App\Services\DateRangeService;
use App\Services\LeadLocationService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DashboardLocationController extends Controller
{
    public function __construct(
        private LeadLocationService $locations,
        private DateRangeService $dates,
    ) {}

    /**
     * GET /dashboard/location-data
     * JSON feed for the dashboard map card (AJAX, honours date + source filters).
     */
    public function data(Request $request): JsonResponse
    {
        [$from, $to, $label] = $this->dates->resolve($request);

        $query = $this->scoped($request->user())
            ->whereBetween('created_at', [$from, $to]);

        if ($source = $request->string('source')->value()) {
            if ($source !== 'all') {
                $query->where('source_channel', $source);
            }
        }

        $result = $this->locations->aggregate($query);

        return response()->json([
            'range'     => $label,
            'total'     => $result['total'],
            'countries' => $result['countries'],
        ]);
    }

    /**
     * GET /reports/location
     * Full-page location report with the same map + a country breakdown table.
     */
    public function report(Request $request)
    {
        \Illuminate\Support\Facades\Gate::authorize('view-reports');

        [$from, $to, $label] = $this->dates->resolve($request);

        $query = $this->scoped($request->user())->whereBetween('created_at', [$from, $to]);
        if (($source = $request->string('source')->value()) && $source !== 'all') {
            $query->where('source_channel', $source);
        }

        $result = $this->locations->aggregate($query);

        return view('reports.location', [
            'rangeLabel' => $label,
            'presets'    => $this->dates->presets(),
            'sources'    => SourceChannel::options(),
            'total'      => $result['total'],
            'countries'  => $result['countries'],
            'filters'    => [
                'range'  => $request->string('range', 'last_30')->value(),
                'source' => $request->string('source', 'all')->value(),
            ],
        ]);
    }

    /** Sales reps only see their own assigned leads (matches existing controllers). */
    private function scoped($user)
    {
        $query = Lead::query();
        if ($user->hasRole(UserRole::SalesRep)) {
            $query->where('assigned_to', $user->id);
        }
        return $query;
    }
}
