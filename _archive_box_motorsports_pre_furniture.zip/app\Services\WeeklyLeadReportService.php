<?php

namespace App\Services;

use App\Enums\DriverLeadStatus;
use App\Enums\LeadStatus;
use App\Enums\SourceChannel;
use App\Enums\SponsorProfileType;
use App\Models\DriverLead;
use App\Models\Lead;
use App\Models\SponsorProfile;
use App\Models\SponsorshipDeal;
use App\Models\User;
use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\DB;

/**
 * Builds the data payload for the weekly lead report email.
 */
class WeeklyLeadReportService
{
    public function __construct(private LeadLocationService $locations) {}

    /**
     * @return array<string,mixed>
     */
    public function build(?CarbonImmutable $weekStart = null): array
    {
        $start = $weekStart ?? CarbonImmutable::now()->subWeek()->startOfWeek();
        $end   = $start->endOfWeek();

        $newThisWeek = Lead::whereBetween('created_at', [$start, $end]);
        $updatedThisWeek = Lead::whereBetween('updated_at', [$start, $end])
            ->whereColumn('created_at', '<', 'updated_at')
            ->where('created_at', '<', $start);

        // Duplicates merged this week (interaction logged by intake/import).
        $duplicates = DB::table('lead_interactions')
            ->where('action_type', 'duplicate_merged')
            ->whereBetween('created_at', [$start, $end])
            ->count();

        $bySource = (clone $newThisWeek)->select('source_channel', DB::raw('count(*) as t'))
            ->groupBy('source_channel')->pluck('t', 'source_channel');
        $sourceRows = collect(SourceChannel::cases())
            ->map(fn ($c) => ['label' => $c->label(), 'value' => (int) ($bySource[$c->value] ?? 0)])
            ->filter(fn ($r) => $r['value'] > 0)->sortByDesc('value')->values();

        $byStatus = (clone $newThisWeek)->select('status', DB::raw('count(*) as t'))
            ->groupBy('status')->pluck('t', 'status');
        $statusRows = collect(LeadStatus::cases())
            ->map(fn ($s) => ['label' => $s->label(), 'value' => (int) ($byStatus[$s->value] ?? 0)])
            ->values();

        // Leads by country (reuse the location aggregator).
        $location = $this->locations->aggregate((clone $newThisWeek));

        $byUser = (clone $newThisWeek)->whereNotNull('assigned_to')
            ->select('assigned_to', DB::raw('count(*) as t'))
            ->groupBy('assigned_to')->pluck('t', 'assigned_to');
        $userRows = User::whereIn('id', $byUser->keys())->get()
            ->map(fn ($u) => ['label' => $u->name, 'value' => (int) ($byUser[$u->id] ?? 0)])
            ->sortByDesc('value')->values();

        // ---- Driver Leads this week ----
        $driverNew = DriverLead::whereBetween('created_at', [$start, $end]);
        $driverByStatusRaw = (clone $driverNew)->select('status', DB::raw('count(*) as t'))
            ->groupBy('status')->pluck('t', 'status');
        $driverStatusRows = collect(DriverLeadStatus::cases())
            ->map(fn ($s) => ['label' => $s->label(), 'value' => (int) ($driverByStatusRaw[$s->value] ?? 0)])
            ->values();

        // ---- Sponsors & Vendors this week ----
        $sponsorNew = SponsorProfile::whereBetween('created_at', [$start, $end]);
        $sponsorByTypeRaw = (clone $sponsorNew)->select('company_type', DB::raw('count(*) as t'))
            ->groupBy('company_type')->pluck('t', 'company_type');
        $sponsorTypeRows = collect(SponsorProfileType::cases())
            ->map(fn ($t) => ['label' => $t->label(), 'value' => (int) ($sponsorByTypeRaw[$t->value] ?? 0)])
            ->filter(fn ($r) => $r['value'] > 0)->values();

        $dealsNew = SponsorshipDeal::whereBetween('created_at', [$start, $end]);
        $dealWonValue = (float) SponsorshipDeal::where('stage', 'closed_won')
            ->whereBetween('updated_at', [$start, $end])->sum('deal_value');

        return [
            'period_start'   => $start,
            'period_end'     => $end,
            'new_count'      => (clone $newThisWeek)->count(),
            'updated_count'  => (clone $updatedThisWeek)->count(),
            'duplicate_count' => $duplicates,
            'hot_count'      => (clone $newThisWeek)->where('priority', 'hot')->count(),
            'closed_won'     => (clone $newThisWeek)->where('status', LeadStatus::ClosedWon->value)->count(),
            'closed_lost'    => (clone $newThisWeek)->where('status', LeadStatus::ClosedLost->value)->count(),
            'by_source'      => $sourceRows,
            'by_status'      => $statusRows,
            'by_country'     => collect($location['countries'])->take(8),
            'by_user'        => $userRows,
            'latest'         => (clone $newThisWeek)->latest()->limit(10)->get(),

            // Driver Leads
            'driver_new_count' => (clone $driverNew)->count(),
            'driver_qualified' => (clone $driverNew)->where('status', DriverLeadStatus::Qualified->value)->count(),
            'driver_declined'  => (clone $driverNew)->where('status', DriverLeadStatus::Declined->value)->count(),
            'driver_seeking'   => (clone $driverNew)->where('seeking_sponsorship', true)->count(),
            'driver_by_status' => $driverStatusRows,
            'driver_latest'    => (clone $driverNew)->latest()->limit(10)->get(),

            // Sponsors & Vendors
            'sponsor_new_count' => (clone $sponsorNew)->count(),
            'sponsor_by_type'   => $sponsorTypeRows,
            'sponsor_latest'    => (clone $sponsorNew)->latest()->limit(10)->get(),
            'deal_new_count'    => (clone $dealsNew)->count(),
            'deal_won_value'    => $dealWonValue,
        ];
    }

    /** Generate a CSV string of the week's new leads (for the email attachment). */
    public function csv(CarbonImmutable $start, CarbonImmutable $end): string
    {
        $leads = Lead::whereBetween('created_at', [$start, $end])->get();

        $fh = fopen('php://temp', 'r+');
        fputcsv($fh, ['Name', 'Email', 'Phone', 'Source', 'Status', 'Priority', 'Country', 'Created']);
        foreach ($leads as $l) {
            fputcsv($fh, [
                $l->full_name, $l->email, $l->phone,
                $l->source_channel->label(), $l->status->label(), $l->priority->label(),
                $l->country, $l->created_at->toDateTimeString(),
            ]);
        }
        rewind($fh);
        $csv = stream_get_contents($fh);
        fclose($fh);

        return $csv;
    }

    /** CSV of the week's new driver leads. */
    public function driverCsv(CarbonImmutable $start, CarbonImmutable $end): string
    {
        $rows = DriverLead::whereBetween('created_at', [$start, $end])->get();

        $fh = fopen('php://temp', 'r+');
        fputcsv($fh, ['Name', 'Email', 'Phone', 'Country', 'Racing Level', 'Car Type', 'Tier', 'Status', 'Seeking Sponsorship', 'Created']);
        foreach ($rows as $d) {
            fputcsv($fh, [
                $d->full_name, $d->email, $d->phone, $d->country,
                $d->racing_level?->label(), $d->car_type?->label(), $d->inferred_tier?->label(),
                $d->status?->label(), $d->seeking_sponsorship ? 'Yes' : 'No', $d->created_at->toDateTimeString(),
            ]);
        }
        rewind($fh);
        $csv = stream_get_contents($fh);
        fclose($fh);

        return $csv;
    }

    /** CSV of the week's new sponsor & vendor profiles. */
    public function sponsorCsv(CarbonImmutable $start, CarbonImmutable $end): string
    {
        $rows = SponsorProfile::whereBetween('created_at', [$start, $end])->get();

        $fh = fopen('php://temp', 'r+');
        fputcsv($fh, ['Company', 'Contact', 'Email', 'Phone', 'Type', 'Industry', 'Country', 'Estimated Budget', 'Status', 'Created']);
        foreach ($rows as $s) {
            fputcsv($fh, [
                $s->company_name, $s->contact_name, $s->email, $s->phone,
                $s->company_type?->label(), $s->industry, $s->country,
                $s->estimated_budget, $s->status?->label(), $s->created_at->toDateTimeString(),
            ]);
        }
        rewind($fh);
        $csv = stream_get_contents($fh);
        fclose($fh);

        return $csv;
    }
}
