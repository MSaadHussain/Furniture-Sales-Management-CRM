<?php

namespace App\Services;

class WhatsAppWebhookService
{
    public function normalize(array $payload): ?array
    {
        if (isset($payload['entry'][0]['changes'][0]['value'])) {
            $value    = $payload['entry'][0]['changes'][0]['value'];
            $contact  = $value['contacts'][0] ?? [];
            $message  = $value['messages'][0] ?? [];

            if (! $message) {
                return null;
            }

            return [
                'name'    => $contact['profile']['name'] ?? null,
                'phone'   => $message['from'] ?? ($contact['wa_id'] ?? null),
                'message' => $message['text']['body'] ?? '',
                'interest'=> null,
            ];
        }

        if (isset($payload['From']) && isset($payload['Body'])) {
            return [
                'name'    => $payload['ProfileName'] ?? null,
                'phone'   => str_replace('whatsapp:', '', $payload['From']),
                'message' => $payload['Body'] ?? '',
                'interest'=> null,
            ];
        }

        if (isset($payload['phone'])) {
            return [
                'name'    => $payload['name'] ?? null,
                'phone'   => $payload['phone'],
                'message' => $payload['message'] ?? '',
                'interest'=> $payload['interest'] ?? null,
            ];
        }

        return null;
    }
}
