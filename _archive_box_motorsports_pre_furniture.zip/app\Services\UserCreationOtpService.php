<?php

namespace App\Services;

use App\Enums\UserRole;
use App\Mail\UserCreationOtpMail;
use App\Models\ReportSetting;
use App\Models\User;
use App\Models\UserCreationOtp;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;

class UserCreationOtpService
{
    public const EXPIRY_MINUTES = 10;
    public const MAX_ATTEMPTS = 5;
    public const MAX_RESENDS = 3;

    /** Resolve the Super Admin email that should receive the OTP. */
    public function superAdminEmail(): ?string
    {
        // Prefer a configured primary email in Security Settings.
        $configured = ReportSetting::get('otp_super_admin_email');
        if (! empty($configured)) {
            return $configured;
        }

        // Otherwise fall back to the first active Super Admin.
        return User::where('role', UserRole::SuperAdmin->value)
            ->where('is_active', true)
            ->orderBy('id')
            ->value('email');
    }

    public function enabled(): bool
    {
        if (app()->environment('testing')) {
            return false;
        }
        return (bool) ReportSetting::get('otp_required_new_user', true);
    }

    /**
     * Create an OTP record + email it. Returns the OTP id, or null if no
     * Super Admin email is available.
     */
    public function start(int $requestedBy, array $userPayload, string $requestedByName): ?UserCreationOtp
    {
        $email = $this->superAdminEmail();
        if (empty($email)) {
            return null;
        }

        $otp = (string) random_int(100000, 999999);

        $record = UserCreationOtp::create([
            'requested_by'        => $requestedBy,
            'target_user_payload' => $userPayload,
            'otp_hash'            => Hash::make($otp),
            'sent_to_email'       => $email,
            'expires_at'          => now()->addMinutes(self::EXPIRY_MINUTES),
            'attempts'            => 0,
            'resent_count'        => 0,
        ]);

        Mail::to($email)->send(new UserCreationOtpMail(
            otp: $otp,
            requestedBy: $requestedByName,
            newUserName: $userPayload['name'] ?? 'New user',
            newUserEmail: $userPayload['email'] ?? '',
            expiryMinutes: self::EXPIRY_MINUTES,
        ));

        // In log/array mail mode (no real email), expose the OTP so it can be
        // shown on screen for testing. Never do this with a real mail driver.
        if (in_array(config('mail.default'), ['log', 'array'], true)) {
            session()->flash('dev_otp', $otp);
        }

        return $record;
    }

    /** Re-send a fresh OTP for an existing pending record (respects limit). */
    public function resend(UserCreationOtp $record, string $requestedByName): bool
    {
        if ($record->isVerified() || $record->resent_count >= self::MAX_RESENDS) {
            return false;
        }

        $otp = (string) random_int(100000, 999999);
        $record->update([
            'otp_hash'     => Hash::make($otp),
            'expires_at'   => now()->addMinutes(self::EXPIRY_MINUTES),
            'resent_count' => $record->resent_count + 1,
            'attempts'     => 0,
        ]);

        Mail::to($record->sent_to_email)->send(new UserCreationOtpMail(
            otp: $otp,
            requestedBy: $requestedByName,
            newUserName: $record->target_user_payload['name'] ?? 'New user',
            newUserEmail: $record->target_user_payload['email'] ?? '',
            expiryMinutes: self::EXPIRY_MINUTES,
        ));

        if (in_array(config('mail.default'), ['log', 'array'], true)) {
            session()->flash('dev_otp', $otp);
        }

        return true;
    }

    /**
     * Verify a submitted OTP. Returns one of:
     *  'ok' | 'expired' | 'too_many' | 'invalid' | 'already'
     */
    public function verify(UserCreationOtp $record, string $code): string
    {
        if ($record->isVerified()) {
            return 'already';
        }
        if ($record->isExpired()) {
            return 'expired';
        }
        if ($record->attempts >= self::MAX_ATTEMPTS) {
            return 'too_many';
        }

        if (! Hash::check(trim($code), $record->otp_hash)) {
            $record->increment('attempts');
            return 'invalid';
        }

        $record->update(['verified_at' => now()]);

        return 'ok';
    }
}