<?php

use App\Http\Controllers\Api\V1\EmailController;
use App\Http\Controllers\Api\V1\GoogleFormController;
use App\Http\Controllers\Api\V1\JotformController;
use App\Http\Controllers\Api\V1\WebhookController;
use App\Http\Controllers\Api\V1\WebsiteController;
use App\Http\Controllers\Api\V1\WhatsAppController;
use Illuminate\Support\Facades\Route;

Route::prefix('v1/leads')
    ->middleware('throttle:webhooks')
    ->group(function () {

        Route::post('webhook', WebhookController::class)
            ->middleware('webhook.secret:generic');

        Route::post('jotform', JotformController::class)
            ->middleware('webhook.secret:jotform');

        Route::post('google-form', GoogleFormController::class)
            ->middleware('webhook.secret:google_form');

        Route::post('website', WebsiteController::class)
            ->middleware('webhook.secret:website');

        Route::get('whatsapp', [WhatsAppController::class, 'verify']);
        Route::post('whatsapp', WhatsAppController::class)
            ->middleware('webhook.secret:whatsapp,hmac');

        Route::post('email', EmailController::class)
            ->middleware('webhook.secret:email');
    });

// Driver Leads webhook (uses shared secret like other channels).
Route::prefix('v1/driver-leads')
    ->middleware('throttle:webhooks')
    ->group(function () {
        Route::post('webhook', [\App\Http\Controllers\Api\V1\Webhooks\DriverLeadWebhookController::class, 'receive'])
            ->middleware('webhook.secret:driver_leads');
    });

// Sponsor Leads webhook (Vendor & Sponsor Space intake from Google Form).
Route::prefix('v1/sponsor-leads')
    ->middleware('throttle:webhooks')
    ->group(function () {
        Route::post('webhook', [\App\Http\Controllers\Api\V1\Webhooks\SponsorLeadWebhookController::class, 'receive'])
            ->middleware('webhook.secret:sponsor_leads');
    });

// Ad-platform webhooks (own verification: Meta verify-token / Google shared key).
Route::prefix('v1/webhooks')
    ->middleware('throttle:webhooks')
    ->group(function () {
        Route::get('meta', [\App\Http\Controllers\Api\V1\Webhooks\MetaWebhookController::class, 'verify']);
        Route::post('meta', [\App\Http\Controllers\Api\V1\Webhooks\MetaWebhookController::class, 'receive']);
        Route::post('google-leads', [\App\Http\Controllers\Api\V1\Webhooks\GoogleLeadWebhookController::class, 'receive']);
        Route::post('calendly', [\App\Http\Controllers\Api\V1\Webhooks\CalendlyWebhookController::class, 'receive']);
    });
