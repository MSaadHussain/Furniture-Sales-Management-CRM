<?php

namespace App\Enums;

enum CarType: string
{
    case Kart = 'kart';
    case FormulaCar = 'formula_car';
    case GtCar = 'gt_car';
    case TouringCar = 'touring_car';
    case Prototype = 'prototype';
    case StockCar = 'stock_car';
    case SimRacing = 'sim_racing';
    case Other = 'other';

    public function label(): string
    {
        return match ($this) {
            self::Kart       => 'Kart',
            self::FormulaCar => 'Formula Car',
            self::GtCar      => 'GT Car',
            self::TouringCar => 'Touring Car',
            self::Prototype  => 'Prototype',
            self::StockCar   => 'Stock Car',
            self::SimRacing  => 'Sim Racing',
            self::Other      => 'Other',
        };
    }

    public function color(): string
    {
        return match ($this) {
            self::Kart       => '#6B7280',
            self::FormulaCar => '#DC2626',
            self::GtCar      => '#16A34A',
            self::TouringCar => '#F59E0B',
            self::Prototype  => '#EC4899',
            self::StockCar   => '#F97316',
            self::SimRacing  => '#14B8A6',
            self::Other      => '#9CA3AF',
        };
    }

    public static function options(): array
    {
        return array_map(
            fn (self $t) => ['value' => $t->value, 'label' => $t->label(), 'color' => $t->color()],
            self::cases()
        );
    }

    /**
     * Age-plausibility rule for car type: drivers under 12 can only drive a Kart.
     * Returns an error message when the combination is not allowed, or null.
     */
    public static function ageViolation(?int $age, ?self $type): ?string
    {
        if ($age === null || $type === null) {
            return null;
        }

        if ($age < 12 && $type !== self::Kart) {
            return 'Drivers under 12 can only have Kart as their car type.';
        }

        return null;
    }
}
