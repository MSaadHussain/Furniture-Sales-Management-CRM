@extends('layouts.adminlte')
@section('title', $lead->full_name ?: 'Lead #'.$lead->id)

@section('header_actions')
    <div class="text-right">
        @can('update', $lead)
            <a href="{{ route('leads.edit', $lead) }}" class="btn btn-default btn-sm"><i class="fas fa-edit mr-1"></i> Edit</a>
            <form method="POST" action="{{ route('leads.markHot', $lead) }}" class="d-inline">@csrf @method('PATCH')
                <button class="btn btn-brand btn-sm"><i class="fas fa-fire mr-1"></i> Mark Hot</button>
            </form>
        @endcan
        @can('delete', $lead)
            <form method="POST" action="{{ route('leads.destroy', $lead) }}" class="d-inline" onsubmit="return confirm('Delete this lead?')">@csrf @method('DELETE')
                <button class="btn btn-outline-danger btn-sm"><i class="fas fa-trash mr-1"></i> Delete</button>
            </form>
        @endcan
    </div>
@endsection

@section('content')
<div class="row">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-body">
                <div class="d-flex align-items-center mb-3">
                    <span class="avatar-circle mr-3" style="background-color: {{ $lead->assignee->avatar_color ?? '#E10600' }}; height:48px; width:48px; font-size:18px;">{{ strtoupper(substr($lead->full_name ?? 'L',0,1)) }}</span>
                    <div>
                        <h4 class="mb-1">{{ $lead->full_name ?: '—' }}</h4>
                        @include('layouts._badge', ['label'=>$lead->source_channel->label(),'color'=>$lead->source_channel->color()])
                        @include('layouts._badge', ['label'=>$lead->priority->label(),'color'=>$lead->priority->color()])
                        <span class="text-muted small ml-2">Score: {{ $lead->lead_score }}</span>
                    </div>
                </div>
                <dl class="row mb-0">
                    <dt class="col-sm-3 text-muted">Email</dt><dd class="col-sm-9">{{ $lead->email ?: '—' }}</dd>
                    <dt class="col-sm-3 text-muted">Phone</dt><dd class="col-sm-9">{{ $lead->phone ?: '—' }}</dd>
                    <dt class="col-sm-3 text-muted">Location</dt><dd class="col-sm-9">{{ $lead->loc_state ?: '—' }}</dd>
                    <dt class="col-sm-3 text-muted">Interest</dt><dd class="col-sm-9">{{ $lead->motorsport_interest_type?->label() ?? '—' }}</dd>
                    <dt class="col-sm-3 text-muted">Message</dt><dd class="col-sm-9" style="white-space:pre-line;">{{ $lead->message ?: '—' }}</dd>
                </dl>
            </div>
        </div>

        <div class="card">
            <div class="card-header"><h3 class="card-title">Notes & Logs</h3></div>
            <div class="card-body">
                @can('update', $lead)
                    <form method="POST" action="{{ route('leads.notes.store', $lead) }}" class="mb-3">
                        @csrf
                        <div class="form-group">
                            <textarea name="body" rows="3" required class="form-control" placeholder="Write a note, call summary, or meeting note..."></textarea>
                        </div>
                        <div class="form-inline">
                            <select name="type" class="form-control form-control-sm mr-2">
                                <option value="note">Note</option><option value="call">Call Log</option><option value="meeting">Meeting Note</option>
                            </select>
                            <button class="btn btn-dark btn-sm">Add</button>
                        </div>
                    </form>
                @endcan
                @forelse ($lead->notes as $note)
                    <div class="callout callout-info py-2">
                        <div class="d-flex justify-content-between">
                            <strong>{{ $note->user?->name ?? 'System' }} <span class="text-muted font-weight-normal">· {{ ucfirst($note->type) }}</span></strong>
                            <span class="text-muted small">{{ $note->created_at->diffForHumans() }}</span>
                        </div>
                        <p class="mb-0" style="white-space:pre-line;">{{ $note->body }}</p>
                    </div>
                @empty<p class="text-muted">No notes yet.</p>@endforelse
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card">
            <div class="card-header"><h3 class="card-title">Status & Assignment</h3></div>
            <div class="card-body">
                @can('update', $lead)
                    <form method="POST" action="{{ route('leads.status', $lead) }}" class="mb-3">@csrf @method('PATCH')
                        <label class="small">Status</label>
                        <select name="status" onchange="this.form.submit()" class="form-control">
                            @foreach ($statuses as $s)<option value="{{ $s['value'] }}" @selected($lead->status->value===$s['value'])>{{ $s['label'] }}</option>@endforeach
                        </select>
                    </form>
                @endcan
                @can('assign', $lead)
                    <form method="POST" action="{{ route('leads.assign', $lead) }}">@csrf @method('PATCH')
                        <label class="small">Assigned To</label>
                        <select name="assigned_to" onchange="this.form.submit()" class="form-control">
                            <option value="">Unassigned</option>
                            @foreach ($assignableUsers as $u)<option value="{{ $u->id }}" @selected($lead->assigned_to==$u->id)>{{ $u->name }}</option>@endforeach
                        </select>
                    </form>
                @endcan
            </div>
        </div>

        @can('update', $lead)
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="card-title">Meetings</h3>
                <a href="{{ route('meetings.index') }}" class="small text-brand">View all</a>
            </div>
            <div class="card-body">
                {{-- Existing meetings --}}
                @forelse ($lead->meetings as $m)
                    <div class="d-flex justify-content-between align-items-center border-bottom py-2">
                        <div>
                            <strong>{{ $m->meeting_title ?: ucfirst($m->provider) }}</strong>
                            <div class="small text-muted">{{ $m->starts_at?->format('M j, Y g:i A') ?? 'TBD' }} · {{ ucfirst(str_replace('_',' ',$m->provider)) }}</div>
                            @if ($m->description)<div class="small text-muted mt-1" style="white-space:pre-line;">{{ $m->description }}</div>@endif
                        </div>
                        <div class="d-flex align-items-center" style="gap:.35rem;">
                            @if ($m->meeting_url)<a href="{{ $m->meeting_url }}" target="_blank" rel="noopener" class="btn btn-sm btn-brand"><i class="fas fa-video"></i></a>@endif
                            <form method="POST" action="{{ route('meetings.destroy', $m) }}" onsubmit="return confirm('Delete this meeting? The lead status will revert to its previous stage.');">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete meeting"><i class="fas fa-trash"></i></button>
                            </form>
                        </div>
                    </div>
                @empty
                    <p class="text-muted small mb-3">No meetings yet.</p>
                @endforelse

                {{-- Schedule a video meeting (Google Meet or Zoom) --}}
                <form method="POST" action="{{ route('leads.meetings.google-meet', $lead) }}" class="mt-3">
                    @csrf
                    <label class="small font-weight-bold">Schedule Meeting</label>
                    <input type="text" name="title" class="form-control form-control-sm mb-1" placeholder="Meeting title" value="Call with {{ $lead->full_name }}" required>
                    <div class="d-flex gap-1" style="gap:.5rem;">
                        <input type="datetime-local" name="starts_at" class="form-control form-control-sm" required>
                        <input type="number" name="duration" class="form-control form-control-sm" style="max-width:90px;" value="30" min="15" max="480" title="Minutes">
                    </div>
                    <textarea name="description" rows="2" class="form-control form-control-sm mt-1" placeholder="Agenda / description (optional) — shown on the calendar / meeting invite"></textarea>
                    <div class="d-flex mt-2" style="gap:.5rem;">
                        <button type="submit" class="btn btn-sm btn-brand w-100"><i class="fab fa-google"></i> Google Meet</button>
                        <button type="submit" formaction="{{ route('leads.meetings.zoom', $lead) }}" class="btn btn-sm w-100 text-white" style="background-color:#2D8CFF;"><i class="fas fa-video"></i> Zoom</button>
                    </div>
                </form>
            </div>
        </div>
        @endcan

        <div class="card">
            <div class="card-header"><h3 class="card-title">Activity Timeline</h3></div>
            <div class="card-body">
                <div class="timeline timeline-inverse">
                    @forelse ($lead->interactions as $event)
                        <div>
                            <i class="fas fa-circle bg-brand" style="font-size:.5rem;"></i>
                            <div class="timeline-item">
                                <span class="time"><i class="far fa-clock"></i> {{ $event->created_at->diffForHumans() }}</span>
                                <h3 class="timeline-header border-0 p-0">{{ \Illuminate\Support\Str::headline($event->action_type) }}</h3>
                                <div class="timeline-body small">
                                    @if ($event->description)<div>{{ $event->description }}</div>@endif
                                    @if ($event->old_value || $event->new_value)<div class="text-muted">{{ $event->old_value }} → {{ $event->new_value }}</div>@endif
                                    <div class="text-muted">{{ $event->performer?->name ?? 'System' }}</div>
                                </div>
                            </div>
                        </div>
                    @empty<p class="text-muted">No activity yet.</p>@endforelse
                </div>
            </div>
        </div>

        @if ($lead->rawPayloads->isNotEmpty())
            <div class="card">
                <div class="card-header"><h3 class="card-title">Raw Submissions ({{ $lead->rawPayloads->count() }})</h3></div>
                <div class="card-body">
                    @foreach ($lead->rawPayloads as $payload)
                        <pre class="bg-dark text-light p-2 rounded small" style="overflow-x:auto;">{{ json_encode($payload->payload, JSON_PRETTY_PRINT) }}</pre>
                    @endforeach
                </div>
            </div>
        @endif
    </div>
</div>
@endsection
