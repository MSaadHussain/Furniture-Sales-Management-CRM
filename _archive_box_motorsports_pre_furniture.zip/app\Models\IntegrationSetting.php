<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IntegrationSetting extends Model
{
    protected $fillable = ['channel', 'enabled', 'secret_key', 'config'];

    protected function casts(): array
    {
        return ['enabled' => 'boolean', 'config' => 'array'];
    }
}
