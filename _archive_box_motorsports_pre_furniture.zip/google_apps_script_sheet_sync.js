

var SECRET_TOKEN = 'ACHFHSAHFHSAIHFIASHOFAOIURWQROIJADSJFAJFAIOFJASOIFJWOIJQIJFQJOISJFIAJSOIFJASIOFJASIF';

var ALLOWED_SHEETS = ['BaseLeads', 'DriverLeads', 'sponserleads'];

function doPost(e) {
  try {
    var body = JSON.parse(e.postData.contents);

    if (body.secret !== SECRET_TOKEN) {
      return jsonResponse({ success: false, error: 'Invalid secret' });
    }

    var sheetName = String(body.sheetName || '');
    if (ALLOWED_SHEETS.indexOf(sheetName) === -1) {
      return jsonResponse({ success: false, error: 'Unknown sheet: ' + sheetName });
    }

    var data = body.data || {};
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = ss.getSheetByName(sheetName) || ss.insertSheet(sheetName);

    // Ensure the header row contains every key in the payload.
    var lastCol = sheet.getLastColumn();
    var headers = lastCol > 0 ? sheet.getRange(1, 1, 1, lastCol).getValues()[0] : [];
    var keys = Object.keys(data);

    keys.forEach(function (key) {
      if (headers.indexOf(key) === -1) {
        headers.push(key);
      }
    });

    if (headers.length > 0) {
      sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    }

    // Build the row in header order.
    var row = headers.map(function (h) {
      return data.hasOwnProperty(h) ? data[h] : '';
    });

    sheet.appendRow(row);

    return jsonResponse({
      success: true,
      sheetName: sheetName,
      rowNumber: sheet.getLastRow(),
    });
  } catch (err) {
    return jsonResponse({ success: false, error: String(err) });
  }
}

function jsonResponse(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
