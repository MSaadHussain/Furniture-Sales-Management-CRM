<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UploadImportRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('create', \App\Models\Lead::class) ?? false;
    }

    public function rules(): array
    {
        return [
            'file' => [
                'required', 'file', 'max:20480', // 20 MB
                'mimes:csv,txt,tsv,xlsx,xls,pdf',
            ],
        ];
    }

    public function messages(): array
    {
        return [
            'file.mimes' => 'Only CSV, XLSX, XLS and PDF files are supported.',
            'file.max'   => 'The file may not be larger than 20 MB.',
        ];
    }
}
