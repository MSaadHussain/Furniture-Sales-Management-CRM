<?php

namespace App\Enums;

enum SponsorActionType: string
{
    case PitchDeckSent = 'pitch_deck_sent';
    case ProposalSent = 'proposal_sent';
    case FollowUpCall = 'follow_up_call';
    case TrackTimeReserved = 'track_time_reserved';
    case LogoAssetsReceived = 'logo_assets_received';
    case ContractSent = 'contract_sent';
    case ContractSigned = 'contract_signed';
    case InvoiceSent = 'invoice_sent';
    case PaymentReceived = 'payment_received';
    case DriverLinked = 'driver_linked';
    case MeetingScheduled = 'meeting_scheduled';
    case StageChanged = 'stage_changed';
    case Note = 'note';

    public function label(): string
    {
        return match ($this) {
            self::PitchDeckSent      => 'Pitch Deck Sent',
            self::ProposalSent       => 'Proposal Sent',
            self::FollowUpCall       => 'Follow-Up Call',
            self::TrackTimeReserved  => 'Track Time Reserved',
            self::LogoAssetsReceived => 'Logo Assets Received',
            self::ContractSent       => 'Contract Sent',
            self::ContractSigned     => 'Contract Signed',
            self::InvoiceSent        => 'Invoice Sent',
            self::PaymentReceived    => 'Payment Received',
            self::DriverLinked       => 'Driver Linked',
            self::MeetingScheduled   => 'Meeting Scheduled',
            self::StageChanged       => 'Stage Changed',
            self::Note               => 'Note',
        };
    }

    public function icon(): string
    {
        return match ($this) {
            self::PitchDeckSent      => 'fa-file-powerpoint',
            self::ProposalSent       => 'fa-file-contract',
            self::FollowUpCall       => 'fa-phone',
            self::TrackTimeReserved  => 'fa-flag-checkered',
            self::LogoAssetsReceived => 'fa-image',
            self::ContractSent       => 'fa-file-signature',
            self::ContractSigned     => 'fa-signature',
            self::InvoiceSent        => 'fa-file-invoice-dollar',
            self::PaymentReceived    => 'fa-money-bill-wave',
            self::DriverLinked       => 'fa-link',
            self::MeetingScheduled   => 'fa-calendar-check',
            self::StageChanged       => 'fa-arrows-turn-right',
            self::Note               => 'fa-note-sticky',
        };
    }

    /** Action types a user can log manually (excludes system-generated ones). */
    public static function manualCases(): array
    {
        return array_filter(self::cases(), fn (self $t) => $t !== self::StageChanged);
    }

    public static function options(): array
    {
        return array_map(
            fn (self $t) => ['value' => $t->value, 'label' => $t->label()],
            self::manualCases()
        );
    }
}
