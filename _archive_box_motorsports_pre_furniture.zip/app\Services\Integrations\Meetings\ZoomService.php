<?php

namespace App\Services\Integrations\Meetings;

use App\Models\IntegrationSetting;
use App\Models\LeadMeeting;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Http;

/**
 * Creates Zoom meetings via the Zoom REST API using Server-to-Server OAuth.
 * Mirrors GoogleCalendarService. Credentials live in the `zoom`
 * integration_settings row (env fallbacks in services.zoom).
 *
 * Set up a "Server-to-Server OAuth" app at https://marketplace.zoom.us and copy
 * its Account ID, Client ID and Client Secret. Scopes needed: meeting:write.
 */
class ZoomService
{
    private const TOKEN_URL = 'https://zoom.us/oauth/token';
    private const API_URL   = 'https://api.zoom.us/v2';

    private array $config;

    public function __construct()
    {
        $this->config = IntegrationSetting::where('channel', 'zoom')->value('config') ?? [];
    }

    private function cfg(string $key, ?string $envKey = null): ?string
    {
        return $this->config[$key] ?? ($envKey ? config("services.zoom.{$envKey}") : null);
    }

    public function accessToken(): ?string
    {
        $accountId = $this->cfg('account_id', 'account_id');
        $clientId  = $this->cfg('client_id', 'client_id');
        $secret    = $this->cfg('client_secret', 'client_secret');

        if (! $accountId || ! $clientId || ! $secret) {
            return null;
        }

        $response = Http::asForm()
            ->withBasicAuth($clientId, $secret)
            ->timeout(10)
            ->post(self::TOKEN_URL, [
                'grant_type' => 'account_credentials',
                'account_id' => $accountId,
            ]);

        return $response->successful() ? $response->json('access_token') : null;
    }

    /**
     * Create a Zoom meeting and persist a LeadMeeting attached to any meetable
     * record (Lead, DriverLead or SponsorProfile).
     */
    public function createMeeting(
        Model $meetable,
        string $title,
        Carbon $start,
        Carbon $end,
        ?string $attendeeEmail = null,
        ?string $attendeeName = null,
        ?int $userId = null,
        ?string $description = null,
    ): LeadMeeting {
        $token = $this->accessToken();

        $meetingUrl = null;
        $externalId = null;
        $raw = [];

        if ($token) {
            $tz = config('app.timezone') ?: 'UTC';
            $body = [
                'topic'      => $title,
                'type'       => 2, // scheduled meeting
                'start_time' => $start->format('Y-m-d\TH:i:s'),
                'duration'   => max(1, $start->diffInMinutes($end)),
                'timezone'   => $tz,
                'settings'   => [
                    'join_before_host' => true,
                    'waiting_room'     => false,
                ],
            ];

            if (filled($description)) {
                $body['agenda'] = mb_substr($description, 0, 2000); // Zoom caps agenda at 2000 chars
            }

            $response = Http::withToken($token)->timeout(15)
                ->post(self::API_URL . '/users/me/meetings', $body);

            if ($response->successful()) {
                $raw = $response->json();
                $externalId = isset($raw['id']) ? (string) $raw['id'] : null;
                $meetingUrl = $raw['join_url'] ?? null;
            }
        }

        $meeting = new LeadMeeting([
            'provider'          => 'zoom',
            'external_event_id' => $externalId,
            'meeting_title'     => $title,
            'description'       => $description,
            'meeting_url'       => $meetingUrl,
            'starts_at'         => $start,
            'ends_at'           => $end,
            'attendee_email'    => $attendeeEmail,
            'attendee_name'     => $attendeeName,
            'status'            => 'scheduled',
            'raw_payload'       => $raw ?: null,
            'created_by'        => $userId,
        ]);
        $meeting->meetable()->associate($meetable);
        $meeting->save();

        return $meeting;
    }

    /** Delete a Zoom meeting by its id. Best-effort. */
    public function deleteMeeting(string $meetingId): bool
    {
        $token = $this->accessToken();
        if (! $token) {
            return false;
        }

        $response = Http::withToken($token)->timeout(15)
            ->delete(self::API_URL . "/meetings/{$meetingId}");

        // 204 = deleted, 404 = already gone — both are success for our purposes.
        return $response->successful() || $response->status() === 404;
    }

    public function testConnection(): array
    {
        return $this->accessToken()
            ? [true, 'Zoom connected.']
            : [false, 'Could not obtain a Zoom access token. Check Account ID, Client ID and Client Secret.'];
    }
}
