<?php

namespace Database\Seeders;

use App\Models\IntegrationSetting;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class IntegrationSettingSeeder extends Seeder
{
    public function run(): void
    {
        foreach (['jotform', 'google_form', 'website', 'whatsapp', 'email', 'generic'] as $channel) {
            IntegrationSetting::updateOrCreate(
                ['channel' => $channel],
                ['enabled' => false, 'secret_key' => Str::random(40), 'config' => []]
            );
        }

        // Notification toggles row (no secret)
        IntegrationSetting::updateOrCreate(
            ['channel' => 'notifications'],
            ['enabled' => true, 'config' => [
                'new_lead' => true, 'hot_lead' => true, 'lead_assigned' => true,
                'meeting_scheduled' => true, 'closed_won' => true,
            ]]
        );
    }
}
