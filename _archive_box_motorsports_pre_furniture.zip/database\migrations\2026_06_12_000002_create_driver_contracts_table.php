<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('driver_contracts', function (Blueprint $table) {
            $table->id();

            $table->foreignId('driver_lead_id')->constrained('driver_leads')->cascadeOnDelete();
            $table->foreignId('sponsor_profile_id')->nullable()->constrained('sponsor_profiles')->nullOnDelete();
            $table->foreignId('sponsorship_deal_id')->nullable()->constrained('sponsorship_deals')->nullOnDelete();

            $table->string('contract_type')->index();
            $table->string('contract_status')->default('draft')->index();

            $table->string('car_type')->nullable();
            $table->string('racing_level')->nullable();

            $table->decimal('contract_value', 12, 2)->nullable();
            $table->string('currency', 10)->default('USD');

            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();
            $table->date('signed_date')->nullable();

            $table->string('document_path')->nullable();
            $table->text('notes')->nullable();

            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();

            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('driver_contracts');
    }
};
