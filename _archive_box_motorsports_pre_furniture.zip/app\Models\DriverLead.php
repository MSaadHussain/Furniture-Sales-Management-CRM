<?php

namespace App\Models;

use App\Enums\CarType;
use App\Enums\DriverContractType;
use App\Enums\DriverLeadStatus;
use App\Enums\DriverRacingLevel;
use App\Enums\DriverTier;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class DriverLead extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'first_name', 'last_name', 'email', 'phone', 'country', 'photo_path', 'dob',
        'years_racing', 'highest_series', 'racing_level', 'car_type',
        'career_wins', 'current_team_series',
        'instagram_handle', 'instagram_followers',
        'seeking_sponsorship', 'contract_interest_type', 'inferred_tier', 'status',
    ];

    protected function casts(): array
    {
        return [
            'dob'                    => 'date',
            'years_racing'           => 'integer',
            'career_wins'            => 'integer',
            'instagram_followers'    => 'integer',
            'seeking_sponsorship'    => 'boolean',
            'racing_level'           => DriverRacingLevel::class,
            'car_type'               => CarType::class,
            'contract_interest_type' => DriverContractType::class,
            'inferred_tier'          => DriverTier::class,
            'status'                 => DriverLeadStatus::class,
        ];
    }

    public function getAgeAttribute(): ?int
    {
        return $this->dob?->age;
    }

    public function getAgeGroupAttribute(): ?string
    {
        $age = $this->age;

        if ($age === null) {
            return null;
        }

        return match (true) {
            $age < 12  => 'Under 12',
            $age <= 15 => '12–15',
            $age <= 18 => '16–18',
            $age <= 25 => '19–25',
            $age <= 35 => '26–35',
            default    => '36+',
        };
    }

    public function getFullNameAttribute(): string
    {
        return trim("{$this->first_name} {$this->last_name}");
    }

    /** Public URL of the uploaded profile photo, or null. */
    public function photoUrl(): ?string
    {
        return $this->photo_path
            ? \Illuminate\Support\Facades\Storage::url($this->photo_path)
            : null;
    }

    public function getInstagramUrlAttribute(): ?string
    {
        if (! $this->instagram_handle) {
            return null;
        }

        $handle = ltrim($this->instagram_handle, '@');

        return "https://instagram.com/{$handle}";
    }

    public function activities()
    {
        return $this->hasMany(DriverLeadActivity::class)->latest();
    }

    public function meetings()
    {
        return $this->morphMany(LeadMeeting::class, 'meetable')->latest('starts_at');
    }

    public function comments()
    {
        return $this->hasMany(DriverLeadComment::class)->latest();
    }

    public function tierHistory()
    {
        return $this->hasMany(DriverLeadTierHistory::class)->latest();
    }

    public function sponsorLinks()
    {
        return $this->hasMany(SponsorDriverLink::class)->latest();
    }

    public function sponsors()
    {
        return $this->belongsToMany(SponsorProfile::class, 'sponsor_driver_links')
            ->withPivot(['funding_amount', 'funding_type', 'season_or_event', 'status', 'start_date', 'end_date'])
            ->withTimestamps();
    }

    public function fundedDeals()
    {
        return $this->hasManyThrough(
            SponsorshipDeal::class,
            SponsorDriverLink::class,
            'driver_lead_id',
            'id',
            'id',
            'sponsorship_deal_id'
        );
    }

    public function contracts()
    {
        return $this->hasMany(DriverContract::class)->latest();
    }

    public function activeContract()
    {
        return $this->hasOne(DriverContract::class)->ofMany(
            ['id' => 'max'],
            fn ($q) => $q->where('contract_status', 'active'),
        );
    }

    public function latestContract()
    {
        return $this->hasOne(DriverContract::class)->latestOfMany();
    }

    public function recomputeTier(?int $userId = null): void
    {
        $newTier = DriverTier::inferFromDriver($this);

        // A freshly created model may not have the DB default hydrated yet.
        $oldTier = $this->inferred_tier ?? DriverTier::Amateur;

        if ($oldTier === $newTier) {
            return;
        }

        DriverLeadTierHistory::create([
            'driver_lead_id' => $this->id,
            'user_id'        => $userId,
            'old_tier'       => $oldTier->value,
            'new_tier'       => $newTier->value,
            'reason'         => 'Auto-computed from racing level, age, career wins, and experience',
        ]);

        $this->update(['inferred_tier' => $newTier]);
    }
}
