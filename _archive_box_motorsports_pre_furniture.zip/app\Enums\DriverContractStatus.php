<?php

namespace App\Enums;

enum DriverContractStatus: string
{
    case Draft = 'draft';
    case Sent = 'sent';
    case UnderReview = 'under_review';
    case Signed = 'signed';
    case Active = 'active';
    case Expired = 'expired';
    case Cancelled = 'cancelled';

    public function label(): string
    {
        return match ($this) {
            self::Draft       => 'Draft',
            self::Sent        => 'Sent',
            self::UnderReview => 'Under Review',
            self::Signed      => 'Signed',
            self::Active      => 'Active',
            self::Expired     => 'Expired',
            self::Cancelled   => 'Cancelled',
        };
    }

    public function color(): string
    {
        return match ($this) {
            self::Draft       => '#6B7280',
            self::Sent        => '#2563EB',
            self::UnderReview => '#F59E0B',
            self::Signed      => '#7C3AED',
            self::Active      => '#16A34A',
            self::Expired     => '#9CA3AF',
            self::Cancelled   => '#DC2626',
        };
    }

    public static function options(): array
    {
        return array_map(
            fn (self $s) => ['value' => $s->value, 'label' => $s->label(), 'color' => $s->color()],
            self::cases()
        );
    }
}
