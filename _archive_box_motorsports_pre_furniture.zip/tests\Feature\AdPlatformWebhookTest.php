<?php

namespace Tests\Feature;

use App\Models\IntegrationSetting;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AdPlatformWebhookTest extends TestCase
{
    use RefreshDatabase;

    public function test_meta_webhook_verification_handshake(): void
    {
        IntegrationSetting::create([
            'channel' => 'meta', 'enabled' => true,
            'config'  => ['webhook_verify_token' => 'verify-123'],
        ]);

        $this->get('/api/v1/webhooks/meta?hub_mode=subscribe&hub_verify_token=verify-123&hub_challenge=CHALLENGE_OK')
            ->assertOk()
            ->assertSee('CHALLENGE_OK');
    }

    public function test_meta_webhook_rejects_bad_verify_token(): void
    {
        IntegrationSetting::create([
            'channel' => 'meta', 'enabled' => true,
            'config'  => ['webhook_verify_token' => 'verify-123'],
        ]);

        $this->get('/api/v1/webhooks/meta?hub_mode=subscribe&hub_verify_token=wrong&hub_challenge=X')
            ->assertForbidden();
    }

    public function test_meta_webhook_acknowledges_post(): void
    {
        // No access token configured -> the leadgen fetch returns a stub payload,
        // but the endpoint must still 200 to satisfy Meta's retry policy.
        $this->postJson('/api/v1/webhooks/meta', [
            'entry' => [[
                'changes' => [[
                    'field' => 'leadgen',
                    'value' => ['leadgen_id' => '99999'],
                ]],
            ]],
        ])->assertOk()->assertJson(['received' => true]);
    }

    public function test_google_lead_webhook_creates_lead(): void
    {
        IntegrationSetting::create([
            'channel' => 'google_lead_form', 'enabled' => true,
            'config'  => ['webhook_secret' => 'gkey-123'],
        ]);

        $this->postJson('/api/v1/webhooks/google-leads', [
            'google_key' => 'gkey-123',
            'lead_id'    => 'g-001',
            'user_column_data' => [
                ['column_id' => 'FULL_NAME', 'string_value' => 'Carlos Sainz'],
                ['column_id' => 'EMAIL', 'string_value' => 'carlos@example.com'],
                ['column_id' => 'PHONE_NUMBER', 'string_value' => '+34 600111222'],
            ],
        ])->assertCreated()->assertJson(['success' => true]);

        $this->assertDatabaseHas('leads', [
            'email'          => 'carlos@example.com',
            'source_channel' => 'google_lead_form',
        ]);
    }

    public function test_google_lead_webhook_rejects_bad_key(): void
    {
        IntegrationSetting::create([
            'channel' => 'google_lead_form', 'enabled' => true,
            'config'  => ['webhook_secret' => 'gkey-123'],
        ]);

        $this->postJson('/api/v1/webhooks/google-leads', [
            'google_key' => 'wrong',
            'user_column_data' => [['column_id' => 'EMAIL', 'string_value' => 'x@example.com']],
        ])->assertForbidden();
    }

    public function test_meta_settings_save(): void
    {
        $admin = \App\Models\User::factory()->create(['role' => 'admin']);

        $this->actingAs($admin)->post('/integrations/meta/save', [
            'page_id' => '12345', 'access_token' => 'tok', 'webhook_verify_token' => 'vt', 'enabled' => '1',
        ])->assertRedirect();

        $config = IntegrationSetting::where('channel', 'meta')->value('config');
        $this->assertSame('12345', $config['page_id']);
    }
}
