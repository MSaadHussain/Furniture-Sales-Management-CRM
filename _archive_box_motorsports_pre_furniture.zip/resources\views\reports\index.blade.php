@extends('layouts.app')
@section('title', 'Reports')

@section('header_actions')
    <a href="{{ route('reports.location') }}" class="btn btn-light"><i class="fa-solid fa-earth-americas"></i> Location</a>
    @can('export', App\Models\Lead::class)
    <a href="{{ route('reports.export', $filters) }}" class="btn btn-primary"><i class="fa-solid fa-download"></i> Export CSV</a>
    @endcan
@endsection

@section('content')
{{-- Date filter --}}
<form method="GET" class="mb-6 flex flex-wrap items-center gap-2">
    <select name="range" onchange="this.form.submit()" class="ta-input !w-auto !py-2 text-sm">
        @foreach ($presets as $value => $label)
            <option value="{{ $value }}" @selected($currentRange === $value)>{{ $label }}</option>
        @endforeach
    </select>
    <span class="text-sm text-muted">{{ $rangeLabel }}</span>
</form>

{{-- Summary cards --}}
<div class="grid grid-cols-2 gap-4 sm:grid-cols-3 xl:grid-cols-6">
    <x-stat-card label="Total" :value="number_format($summary['total'])" icon="fa-users" iconColor="#465FFF" />
    <x-stat-card label="Hot" :value="number_format($summary['hot'])" icon="fa-fire" iconColor="#F04438" />
    <x-stat-card label="Won" :value="number_format($summary['won'])" icon="fa-trophy" iconColor="#12B76A" />
    <x-stat-card label="Lost" :value="number_format($summary['lost'])" icon="fa-circle-xmark" iconColor="#F79009" />
    <x-stat-card label="Meta" :value="number_format($metaCount)" icon="fa-meta" iconColor="#0866FF" />
    <x-stat-card label="Google" :value="number_format($googleCount)" icon="fa-google" iconColor="#EA4335" />
</div>

<div class="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
    {{-- Leads by source --}}
    <x-card title="Leads by Source" padding="p-0">
        <div class="divide-y divide-line dark:divide-strokedark">
            @forelse ($sourceReport as $row)
                <div class="flex items-center justify-between px-6 py-3">
                    <span class="flex items-center gap-2 text-sm text-ink dark:text-gray-200">
                        <span class="h-2.5 w-2.5 rounded-full" style="background:{{ $row['color'] }}"></span>{{ $row['label'] }}
                    </span>
                    <span class="text-sm font-semibold text-ink dark:text-gray-200">{{ $row['value'] }}</span>
                </div>
            @empty
                <p class="px-6 py-6 text-center text-sm text-muted">No data.</p>
            @endforelse
        </div>
    </x-card>

    {{-- By assigned user --}}
    <x-card title="By Assigned User" padding="p-0">
        <div class="divide-y divide-line dark:divide-strokedark">
            @forelse ($userReport as $row)
                <div class="flex items-center justify-between px-6 py-3">
                    <span class="text-sm text-ink dark:text-gray-200">{{ $row['label'] }}</span>
                    <span class="text-sm font-semibold text-ink dark:text-gray-200">{{ $row['value'] }}</span>
                </div>
            @empty
                <p class="px-6 py-6 text-center text-sm text-muted">No assignments.</p>
            @endforelse
        </div>
    </x-card>
</div>

{{-- Imports by file type --}}
<x-card class="mt-6" title="Imports by File Type" padding="p-0">
    <div class="overflow-x-auto">
        <table class="w-full">
            <thead class="border-b border-line dark:border-strokedark">
                <tr><th class="ta-th">Type</th><th class="ta-th">Batches</th><th class="ta-th">Imported</th><th class="ta-th">Duplicates</th><th class="ta-th">Failed</th></tr>
            </thead>
            <tbody class="divide-y divide-line dark:divide-strokedark">
                @forelse ($importsByType as $row)
                    <tr>
                        <td class="ta-td font-medium">{{ strtoupper($row->file_type) }}</td>
                        <td class="ta-td">{{ $row->batches }}</td>
                        <td class="ta-td text-success">{{ $row->ok }}</td>
                        <td class="ta-td text-purple">{{ $row->dupes }}</td>
                        <td class="ta-td text-danger">{{ $row->failed }}</td>
                    </tr>
                @empty
                    <tr><td colspan="5" class="ta-td py-6 text-center text-muted">No imports yet.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</x-card>

<div class="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
    {{-- Meetings --}}
    <x-card title="Meetings Scheduled">
        <p class="text-3xl font-bold text-ink dark:text-white">{{ number_format($meetingsCount) }}</p>
        <div class="mt-3 flex flex-wrap gap-2">
            @foreach ($meetingsByProvider as $provider => $count)
                @continue($provider === 'calendly')
                <x-badge :label="ucfirst(str_replace('_',' ',$provider)).': '.$count" :color="$provider === 'zoom' ? '#2D8CFF' : '#00897B'" />
            @endforeach
        </div>
    </x-card>

    {{-- Email notification stats --}}
    <x-card title="Email Notifications">
        <div class="flex gap-6">
            <div><p class="text-2xl font-bold text-success">{{ $emailStats['sent'] ?? 0 }}</p><p class="text-xs text-muted">Sent</p></div>
            <div><p class="text-2xl font-bold text-danger">{{ $emailStats['failed'] ?? 0 }}</p><p class="text-xs text-muted">Failed</p></div>
        </div>
    </x-card>
</div>

{{-- Weekly report history --}}
<x-card class="mt-6" title="Weekly Report History" padding="p-0">
    <div class="overflow-x-auto">
        <table class="w-full">
            <thead class="border-b border-line dark:border-strokedark">
                <tr><th class="ta-th">Period</th><th class="ta-th">New</th><th class="ta-th">Updated</th><th class="ta-th">Dupes</th><th class="ta-th">Status</th><th class="ta-th">Sent</th></tr>
            </thead>
            <tbody class="divide-y divide-line dark:divide-strokedark">
                @forelse ($weeklyHistory as $w)
                    <tr>
                        <td class="ta-td">{{ $w->period_start?->format('M j') }} – {{ $w->period_end?->format('M j') }}</td>
                        <td class="ta-td">{{ $w->new_leads }}</td>
                        <td class="ta-td">{{ $w->updated_leads }}</td>
                        <td class="ta-td">{{ $w->duplicate_leads }}</td>
                        <td class="ta-td"><x-badge :label="ucfirst($w->status)" :color="$w->status === 'sent' ? '#12B76A' : ($w->status === 'failed' ? '#F04438' : '#667085')" /></td>
                        <td class="ta-td text-muted">{{ $w->created_at->diffForHumans() }}</td>
                    </tr>
                @empty
                    <tr><td colspan="6" class="ta-td py-6 text-center text-muted">No weekly reports sent yet.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</x-card>

{{-- Email notification logs --}}
<x-card class="mt-6" title="Recent Email Notifications" padding="p-0">
    <div class="overflow-x-auto">
        <table class="w-full">
            <thead class="border-b border-line dark:border-strokedark">
                <tr><th class="ta-th">Type</th><th class="ta-th">Recipient</th><th class="ta-th">Subject</th><th class="ta-th">Status</th><th class="ta-th">When</th></tr>
            </thead>
            <tbody class="divide-y divide-line dark:divide-strokedark">
                @forelse ($emailLogs as $log)
                    <tr>
                        <td class="ta-td">{{ \Illuminate\Support\Str::headline($log->type) }}</td>
                        <td class="ta-td text-muted">{{ $log->recipient }}</td>
                        <td class="ta-td text-muted">{{ \Illuminate\Support\Str::limit($log->subject, 40) }}</td>
                        <td class="ta-td"><x-badge :label="ucfirst($log->status)" :color="$log->status === 'sent' ? '#12B76A' : '#F04438'" /></td>
                        <td class="ta-td text-muted">{{ $log->created_at->diffForHumans() }}</td>
                    </tr>
                @empty
                    <tr><td colspan="5" class="ta-td py-6 text-center text-muted">No emails logged yet.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</x-card>
@endsection
