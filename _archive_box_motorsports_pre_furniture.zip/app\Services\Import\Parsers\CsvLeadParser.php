<?php

namespace App\Services\Import\Parsers;

use App\Contracts\LeadFileParser;
use RuntimeException;

/**
 * CSV parser. Uses PHP's native fgetcsv (no external dependency) and handles
 * UTF-8 BOM, delimiter sniffing (',' ';' "\t" '|'), and ragged rows.
 */
class CsvLeadParser implements LeadFileParser
{
    public function extensions(): array
    {
        return ['csv', 'txt', 'tsv'];
    }

    public function parse(string $absolutePath): array
    {
        if (! is_readable($absolutePath)) {
            throw new RuntimeException('CSV file is not readable.');
        }

        $handle = fopen($absolutePath, 'r');
        if ($handle === false) {
            throw new RuntimeException('Unable to open CSV file.');
        }

        // Detect delimiter from the first line.
        $firstLine = fgets($handle) ?: '';
        $firstLine = $this->stripBom($firstLine);
        $delimiter = $this->detectDelimiter($firstLine);
        rewind($handle);

        $headers = [];
        $rows = [];
        $lineNo = 0;

        while (($data = fgetcsv($handle, 0, $delimiter)) !== false) {
            // Skip fully empty lines.
            if ($data === [null] || (count($data) === 1 && trim((string) $data[0]) === '')) {
                continue;
            }

            if ($lineNo === 0) {
                $data[0] = $this->stripBom((string) ($data[0] ?? ''));
                $headers = array_map(fn ($h) => trim((string) $h), $data);
                $lineNo++;
                continue;
            }

            $rows[] = array_map(fn ($v) => $v === null ? null : trim((string) $v), $data);
            $lineNo++;
        }

        fclose($handle);

        if ($headers === []) {
            throw new RuntimeException('CSV file appears to be empty.');
        }

        return ['headers' => $headers, 'rows' => $rows];
    }

    private function detectDelimiter(string $line): string
    {
        $candidates = [',' => 0, ';' => 0, "\t" => 0, '|' => 0];
        foreach ($candidates as $char => $_) {
            $candidates[$char] = substr_count($line, $char);
        }
        arsort($candidates);
        $best = array_key_first($candidates);
        return $candidates[$best] > 0 ? $best : ',';
    }

    private function stripBom(string $value): string
    {
        return preg_replace('/^\xEF\xBB\xBF/', '', $value) ?? $value;
    }
}
