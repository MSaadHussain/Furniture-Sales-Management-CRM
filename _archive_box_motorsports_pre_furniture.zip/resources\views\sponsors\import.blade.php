@extends('layouts.app')
@section('title', 'Import Sponsors & Vendors')
@section('breadcrumb')
    <a href="{{ route('sponsors.index') }}" class="hover:text-brand">Sponsors & Vendors</a> / <span>Import</span>
@endsection

@section('header_actions')
    <a href="{{ route('sponsors.index') }}" class="btn btn-light"><i class="fa-solid fa-arrow-left"></i> Back to Sponsors</a>
@endsection

@section('content')
<div class="grid grid-cols-1 gap-6 lg:grid-cols-3">

    {{-- Upload card --}}
    <div class="lg:col-span-2">
        <x-card class="h-full" title="Upload CSV" subtitle="Import sponsor and vendor profiles from a CSV file. Use the template to ensure correct formatting.">
            <form method="POST" action="{{ route('sponsors.import.upload') }}" enctype="multipart/form-data" id="importForm"
                  x-data="{ dragging: false, fileName: '' }">
                @csrf

                <div class="mb-6 rounded-xl border-2 border-dashed p-10 text-center transition-colors"
                     :class="dragging ? 'border-brand bg-brand/5' : 'border-line dark:border-strokedark'"
                     @dragover.prevent="dragging = true"
                     @dragleave.prevent="dragging = false"
                     @drop.prevent="dragging = false; $refs.file.files = $event.dataTransfer.files; fileName = $refs.file.files[0]?.name">
                    <i class="fa-solid fa-cloud-arrow-up mb-3 block text-4xl text-muted"></i>
                    <p class="mb-2 text-sm text-ink dark:text-gray-300">
                        Drag & drop your CSV file here, or
                        <label class="cursor-pointer font-semibold text-brand hover:underline">
                            browse
                            <input type="file" name="file" accept=".csv,.txt" class="hidden" x-ref="file"
                                   @change="fileName = $refs.file.files[0]?.name">
                        </label>
                    </p>
                    <p class="text-xs text-muted">CSV files only, max 10 MB</p>
                    <template x-if="fileName">
                        <p class="mt-3 text-sm font-medium text-brand"><i class="fa-solid fa-file-csv mr-1"></i> <span x-text="fileName"></span></p>
                    </template>
                </div>

                @error('file')
                    <p class="mb-4 text-sm text-red-600">{{ $message }}</p>
                @enderror

                <div class="flex items-center gap-3">
                    <button type="submit" class="btn btn-primary"><i class="fa-solid fa-upload"></i> Upload & Preview</button>
                    <a href="{{ route('sponsors.import.template') }}" class="btn btn-light"><i class="fa-solid fa-download"></i> Download Template</a>
                </div>
            </form>
        </x-card>
    </div>

    {{-- Expected columns --}}
    <div>
        <x-card class="h-full" title="Expected Columns" subtitle="Your CSV should include these columns.">
            <ul class="space-y-1.5 text-sm">
                @foreach (\App\Http\Controllers\SponsorProfileController::IMPORT_FIELDS as $field)
                    <li class="flex items-center gap-2 text-ink dark:text-gray-300">
                        <i class="fa-solid fa-circle text-[5px] text-muted"></i>
                        {{ str_replace('_', ' ', ucfirst($field)) }}
                        @if (in_array($field, ['company_name', 'email', 'phone']))<span class="text-xs text-danger">(required)</span>@endif
                    </li>
                @endforeach
            </ul>
            <p class="mt-4 text-xs text-muted">
                Column order doesn't matter — you'll map them on the next step.
                Company Type accepts: Sponsor, Vendor, Track Partner, Racing Asset Provider, Media Partner (defaults to Sponsor).
                Status accepts: Prospect, Active, Inactive (defaults to Prospect).
                Budget values like "$50,000" are cleaned automatically.
            </p>
        </x-card>
    </div>
</div>
@endsection
