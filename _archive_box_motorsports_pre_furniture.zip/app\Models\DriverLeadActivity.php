<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DriverLeadActivity extends Model
{
    protected $table = 'driver_leads_activity';

    protected $fillable = [
        'driver_lead_id', 'user_id', 'action', 'description', 'old_value', 'new_value',
    ];

    public function driverLead()
    {
        return $this->belongsTo(DriverLead::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
