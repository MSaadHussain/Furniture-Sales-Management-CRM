<?php

namespace App\Services\Import;

use Illuminate\Support\Facades\Validator;

/**
 * Validates a single mapped row before it becomes a lead.
 * A lead requires a name, an email, and a phone number — rows missing any of
 * them are skipped with a row-level error.
 */
class LeadImportValidationService
{
    /**
     * @param array<string,mixed> $mapped
     * @return array{0: bool, 1: string|null}  [isValid, errorMessage]
     */
    public function validate(array $mapped): array
    {
        $hasName  = filled($mapped['full_name'] ?? null) || filled($mapped['first_name'] ?? null) || filled($mapped['last_name'] ?? null);
        $hasEmail = filled($mapped['email'] ?? null);
        $hasPhone = filled($mapped['phone'] ?? null);

        if (! $hasName) {
            return [false, 'Row skipped: missing name.'];
        }

        if (! $hasEmail) {
            return [false, 'Row skipped: missing email.'];
        }

        if (! $hasPhone) {
            return [false, 'Row skipped: missing phone.'];
        }

        $validator = Validator::make($mapped, [
            'email' => ['required', 'email:rfc'],
            'phone' => ['required', 'string', 'max:50'],
        ]);

        if ($validator->fails()) {
            return [false, $validator->errors()->first()];
        }

        return [true, null];
    }
}
