<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('sponsorship_deals', function (Blueprint $table) {
            $table->id();
            $table->foreignId('sponsor_profile_id')->constrained('sponsor_profiles')->cascadeOnDelete();
            $table->string('title');
            $table->string('stage')->default('lead_identified')->index();
            $table->decimal('deal_value', 12, 2)->nullable();
            $table->unsignedTinyInteger('probability')->default(50);
            $table->date('expected_close_date')->nullable();
            $table->string('package_type')->nullable();
            $table->foreignId('assigned_to')->nullable()->constrained('users')->nullOnDelete();
            $table->string('priority')->default('medium');
            $table->timestamp('closed_at')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('sponsorship_deals');
    }
};
