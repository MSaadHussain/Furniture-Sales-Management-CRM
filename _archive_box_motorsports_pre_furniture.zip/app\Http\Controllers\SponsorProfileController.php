<?php

namespace App\Http\Controllers;

use App\Enums\SponsorActionType;
use App\Enums\SponsorLinkStatus;
use App\Enums\SponsorProfileType;
use App\Enums\SponsorshipStage;
use App\Enums\SponsorStatus;
use App\Enums\FundingType;
use App\Enums\UserRole;
use App\Models\DriverLead;
use App\Models\SponsorActivity;
use App\Models\SponsorProfile;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rules\Enum;
use Symfony\Component\HttpFoundation\StreamedResponse;

class SponsorProfileController extends Controller
{
    public const IMPORT_FIELDS = [
        'company_name', 'contact_name', 'email', 'phone', 'website',
        'company_type', 'industry', 'country', 'state', 'city',
        'estimated_budget', 'status', 'notes',
    ];

    public function index(Request $request)
    {
        $query = SponsorProfile::query()->with('assignee')->withCount('deals');

        // Sales reps only see their own assigned sponsors.
        if ($request->user()->hasRole(UserRole::SalesRep)) {
            $query->where('assigned_to', $request->user()->id);
        }

        if ($search = $request->string('search')->trim()->value()) {
            $query->where(function ($q) use ($search) {
                $q->where('company_name', 'like', "%{$search}%")
                  ->orWhere('contact_name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%")
                  ->orWhere('industry', 'like', "%{$search}%");
            });
        }

        if ($type = $request->string('type')->value()) {
            $query->where('company_type', $type);
        }

        if ($status = $request->string('status')->value()) {
            $query->where('status', $status);
        }

        if ($assigned = $request->integer('assigned')) {
            $query->where('assigned_to', $assigned);
        }

        $sponsors = $query->orderByDesc('created_at')->paginate(15)->withQueryString();

        return view('sponsors.index', [
            'sponsors' => $sponsors,
            'types'    => SponsorProfileType::options(),
            'statuses' => SponsorStatus::options(),
            'users'    => User::where('is_active', true)->orderBy('name')->get(['id', 'name']),
            'filters'  => $request->only(['search', 'type', 'status', 'assigned']),
        ]);
    }

    /** GET /sponsors/export — CSV or XLSX of the (filtered) sponsor profiles. */
    public function export(Request $request): StreamedResponse
    {
        abort_unless(
            $request->user()->hasRole(UserRole::SuperAdmin, UserRole::Admin, UserRole::SalesManager),
            403
        );

        $query = SponsorProfile::query()->with('assignee')->withCount('deals');

        if ($search = $request->string('search')->trim()->value()) {
            $query->where(function ($q) use ($search) {
                $q->where('company_name', 'like', "%{$search}%")
                  ->orWhere('contact_name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%")
                  ->orWhere('industry', 'like', "%{$search}%");
            });
        }
        if ($type = $request->string('type')->value()) {
            $query->where('company_type', $type);
        }
        if ($status = $request->string('status')->value()) {
            $query->where('status', $status);
        }
        if ($assigned = $request->integer('assigned')) {
            $query->where('assigned_to', $assigned);
        }

        $format = $request->string('format')->value() === 'xlsx' ? 'xlsx' : 'csv';

        $headers = [
            'ID', 'Company', 'Contact', 'Email', 'Phone', 'Website', 'Type', 'Industry',
            'Country', 'State', 'City', 'Estimated Budget', 'Status', 'Assigned To', 'Deals', 'Created At', 'Notes',
        ];

        $rows = (function () use ($query) {
            foreach ($query->orderByDesc('created_at')->cursor() as $s) {
                yield [
                    $s->id, $s->company_name, $s->contact_name, $s->email, $s->phone, $s->website,
                    $s->company_type?->label(), $s->industry, $s->country, $s->state, $s->city,
                    $s->estimated_budget, $s->status?->label(), $s->assignee?->name, $s->deals_count,
                    $s->created_at?->toDateTimeString(), $s->notes,
                ];
            }
        })();

        return \App\Services\Export\TabularExport::download('sponsors_' . now()->format('Y_m_d_His'), $headers, $rows, $format);
    }

    public function create()
    {
        return view('sponsors.create', $this->formData());
    }

    public function store(Request $request)
    {
        $validated = $this->validateProfile($request);

        $sponsor = SponsorProfile::create($validated);

        SponsorActivity::create([
            'sponsor_profile_id' => $sponsor->id,
            'action_type'        => SponsorActionType::Note,
            'description'        => 'Sponsor profile created',
            'performed_by'       => Auth::id(),
            'completed_at'       => now(),
        ]);

        return redirect()->route('sponsors.show', $sponsor)->with('toast', 'Sponsor profile created.');
    }

    public function show(Request $request, SponsorProfile $sponsor)
    {
        if ($request->user()->hasRole(UserRole::SalesRep) && $sponsor->assigned_to !== $request->user()->id) {
            abort(403);
        }

        $sponsor->load([
            'assignee',
            'deals.assignee',
            'activities.performer', 'activities.driverLead', 'activities.deal',
            'driverLinks.driverLead', 'driverLinks.deal',
        ]);

        return view('sponsors.show', [
            'sponsor'      => $sponsor,
            'actionTypes'  => SponsorActionType::options(),
            'stages'       => SponsorshipStage::options(),
            'fundingTypes' => FundingType::options(),
            'linkStatuses' => SponsorLinkStatus::options(),
            'drivers'      => DriverLead::orderBy('first_name')->get(['id', 'first_name', 'last_name', 'email']),
            'users'        => User::where('is_active', true)->orderBy('name')->get(['id', 'name']),
        ]);
    }

    public function edit(SponsorProfile $sponsor)
    {
        return view('sponsors.edit', array_merge($this->formData(), ['sponsor' => $sponsor]));
    }

    public function update(Request $request, SponsorProfile $sponsor)
    {
        $validated = $this->validateProfile($request);

        $sponsor->update($validated);

        return redirect()->route('sponsors.show', $sponsor)->with('toast', 'Sponsor profile updated.');
    }

    public function destroy(SponsorProfile $sponsor)
    {
        $sponsor->delete();

        return redirect()->route('sponsors.index')->with('toast', 'Sponsor profile deleted.');
    }

    private function validateProfile(Request $request): array
    {
        return $request->validate([
            'company_name'     => ['required', 'string', 'max:255'],
            'contact_name'     => ['nullable', 'string', 'max:255'],
            'email'            => ['required', 'email', 'max:255'],
            'phone'            => ['required', 'string', 'max:50'],
            'website'          => ['nullable', 'string', 'max:255'],
            'company_type'     => ['required', new Enum(SponsorProfileType::class)],
            'industry'         => ['nullable', 'string', 'max:255'],
            'country'          => ['nullable', 'string', 'max:100'],
            'state'            => ['nullable', 'string', 'max:100'],
            'city'             => ['nullable', 'string', 'max:100'],
            'estimated_budget' => ['nullable', 'numeric', 'min:0'],
            'status'           => ['required', new Enum(SponsorStatus::class)],
            'assigned_to'      => ['nullable', 'exists:users,id'],
            'notes'            => ['nullable', 'string', 'max:5000'],
        ]);
    }

    private function formData(): array
    {
        return [
            'types'    => SponsorProfileType::options(),
            'statuses' => SponsorStatus::options(),
            'users'    => User::where('is_active', true)->orderBy('name')->get(['id', 'name']),
        ];
    }

    public function trash(Request $request)
    {
        $query = SponsorProfile::onlyTrashed();

        if ($search = $request->string('search')->trim()->value()) {
            $query->where(function ($q) use ($search) {
                $q->where('company_name', 'like', "%{$search}%")
                  ->orWhere('contact_name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%");
            });
        }

        $sponsors = $query->latest('deleted_at')->paginate(20)->withQueryString();

        return view('sponsors.trash', compact('sponsors'));
    }

    public function restore(int $id)
    {
        $sponsor = SponsorProfile::withTrashed()->findOrFail($id);
        $sponsor->restore();

        // Bring the sponsor's deals back onto the pipeline (they were
        // soft-deleted by the cascade when the sponsor was trashed).
        \App\Models\SponsorshipDeal::onlyTrashed()
            ->where('sponsor_profile_id', $sponsor->id)
            ->restore();

        SponsorActivity::create([
            'sponsor_profile_id' => $sponsor->id,
            'action_type'        => SponsorActionType::Note,
            'description'        => 'Sponsor profile restored from trash',
            'performed_by'       => Auth::id(),
            'completed_at'       => now(),
        ]);

        return redirect()->route('sponsors.trash')->with('toast', "{$sponsor->company_name} restored.");
    }

    public function forceDelete(int $id)
    {
        $sponsor = SponsorProfile::withTrashed()->findOrFail($id);
        $sponsor->forceDelete();

        return redirect()->route('sponsors.trash')->with('toast', 'Sponsor permanently deleted.');
    }

    public function import()
    {
        return view('sponsors.import');
    }

    public function importUpload(Request $request)
    {
        $request->validate([
            'file' => ['required', 'file', 'mimes:csv,txt', 'max:10240'],
        ]);

        $file = $request->file('file');
        $handle = fopen($file->getRealPath(), 'r');
        $headers = fgetcsv($handle);

        $rows = [];
        while (($row = fgetcsv($handle)) !== false) {
            $rows[] = $row;
        }
        fclose($handle);

        $suggestedMap = $this->autoMapHeaders($headers);

        $storedPath = $file->store('imports/sponsors');

        return view('sponsors.import-preview', [
            'headers'      => $headers,
            'rows'         => array_slice($rows, 0, 10),
            'totalRows'    => count($rows),
            'suggestedMap' => $suggestedMap,
            'fields'       => self::IMPORT_FIELDS,
            'storedPath'   => $storedPath,
            'fileName'     => $file->getClientOriginalName(),
        ]);
    }

    public function importConfirm(Request $request)
    {
        $request->validate([
            'stored_path' => ['required', 'string'],
            'column_map'  => ['required', 'array'],
            'duplicate'   => ['required', 'in:skip,merge,update'],
        ]);

        $path = storage_path('app/private/' . $request->input('stored_path'));
        if (! file_exists($path)) {
            return redirect()->route('sponsors.import')->with('error', 'Upload expired. Please re-upload the file.');
        }

        $columnMap = $request->input('column_map');
        $duplicate = $request->input('duplicate');

        $handle = fopen($path, 'r');
        fgetcsv($handle); // skip header

        $imported = 0;
        $skipped  = 0;
        $updated  = 0;

        while (($row = fgetcsv($handle)) !== false) {
            $mapped = [];
            foreach ($columnMap as $index => $field) {
                if ($field && $field !== '' && isset($row[$index])) {
                    $mapped[$field] = trim($row[$index]);
                }
            }

            // Required columns: company name, email, phone.
            if (empty($mapped['company_name']) || empty($mapped['email']) || empty($mapped['phone'])
                || ! filter_var($mapped['email'], FILTER_VALIDATE_EMAIL)) {
                $skipped++;
                continue;
            }

            $mapped['company_type'] = $this->matchTypeEnum($mapped['company_type'] ?? '');
            $mapped['status']       = $this->matchStatusEnum($mapped['status'] ?? '');

            $budget = preg_replace('/[^0-9.]/', '', (string) ($mapped['estimated_budget'] ?? ''));
            $mapped['estimated_budget'] = $budget !== '' ? (float) $budget : null;

            $existing = SponsorProfile::where(function ($q) use ($mapped) {
                if (! empty($mapped['email'])) {
                    $q->orWhere('email', $mapped['email']);
                }
                $q->orWhere('company_name', $mapped['company_name']);
            })->first();

            if ($existing) {
                if ($duplicate === 'skip') {
                    $skipped++;
                    continue;
                }

                if ($duplicate === 'merge') {
                    $fillable = array_filter($mapped, function ($value, $key) use ($existing) {
                        $current = $existing->{$key};
                        if ($current instanceof \BackedEnum) {
                            return false; // enums always have a value — never overwrite on merge
                        }
                        return ($current === null || $current === '')
                            && $value !== null && $value !== '';
                    }, ARRAY_FILTER_USE_BOTH);
                    if (empty($fillable)) {
                        $skipped++;
                        continue;
                    }
                    $existing->update($fillable);
                } else {
                    $existing->update($mapped);
                }

                SponsorActivity::create([
                    'sponsor_profile_id' => $existing->id,
                    'action_type'        => SponsorActionType::Note,
                    'description'        => ucfirst($duplicate) . 'd via CSV import',
                    'performed_by'       => Auth::id(),
                    'completed_at'       => now(),
                ]);
                $updated++;
            } else {
                $sponsor = SponsorProfile::create($mapped);
                SponsorActivity::create([
                    'sponsor_profile_id' => $sponsor->id,
                    'action_type'        => SponsorActionType::Note,
                    'description'        => 'Created via CSV import',
                    'performed_by'       => Auth::id(),
                    'completed_at'       => now(),
                ]);
                $imported++;
            }
        }

        fclose($handle);
        @unlink($path);

        return redirect()->route('sponsors.index')
            ->with('toast', "Import complete: {$imported} created, {$updated} updated, {$skipped} skipped.");
    }

    public function downloadTemplate(): StreamedResponse
    {
        return response()->streamDownload(function () {
            $out = fopen('php://output', 'w');
            fputcsv($out, self::IMPORT_FIELDS);
            fputcsv($out, [
                'Apex Auto Group', 'John Smith', 'john@apexauto.com', '+1 555 0100', 'apexauto.com',
                'Sponsor', 'Automotive', 'United States', 'California', 'Los Angeles',
                '50000', 'Prospect', '3-year title sponsorship discussion',
            ]);
            fputcsv($out, [
                'Redline Tires', 'Jane Doe', 'jane@redlinetires.com', '+1 555 0200', 'redlinetires.com',
                'Vendor', 'Motorsports', 'United States', 'Texas', 'Austin',
                '15000', 'Active', 'Supplies racing tires for the 2026 season',
            ]);
            fclose($out);
        }, 'sponsors_import_template.csv', [
            'Content-Type' => 'text/csv',
        ]);
    }

    private function autoMapHeaders(array $headers): array
    {
        $aliases = [
            'company_name'     => ['company name', 'company', 'brand', 'company/brand', 'organization'],
            'contact_name'     => ['contact name', 'contact person', 'contact', 'primary contact'],
            'email'            => ['email', 'email address', 'e-mail', 'contact email'],
            'phone'            => ['phone', 'phone number', 'telephone', 'mobile', 'contact phone'],
            'website'          => ['website', 'website url', 'url', 'web'],
            'company_type'     => ['company type', 'type', 'classification', 'entity type'],
            'industry'         => ['industry', 'sector', 'industry/sector'],
            'country'          => ['country', 'nation'],
            'state'            => ['state', 'province', 'region'],
            'city'             => ['city', 'town'],
            'estimated_budget' => ['estimated budget', 'budget', 'estimate budget', 'sponsorship value'],
            'status'           => ['status'],
            'notes'            => ['notes', 'comments', 'description', 'terms'],
        ];

        $map = [];
        foreach ($headers as $i => $header) {
            $lower = strtolower(trim($header));
            $map[$i] = '';
            foreach ($aliases as $field => $alts) {
                if ($lower === $field || in_array($lower, $alts, true)) {
                    $map[$i] = $field;
                    break;
                }
            }
        }

        return $map;
    }

    /** Map a free-text type answer to the enum; defaults to Sponsor. */
    private function matchTypeEnum(string $raw): SponsorProfileType
    {
        $lower = strtolower(trim($raw));

        foreach (SponsorProfileType::cases() as $case) {
            if ($case->value === $lower || strtolower($case->label()) === $lower) {
                return $case;
            }
        }

        return match (true) {
            str_contains($lower, 'vendor')                                  => SponsorProfileType::Vendor,
            str_contains($lower, 'track')                                   => SponsorProfileType::TrackPartner,
            str_contains($lower, 'asset') || str_contains($lower, 'racing') => SponsorProfileType::RacingAssetProvider,
            str_contains($lower, 'media')                                   => SponsorProfileType::MediaPartner,
            default                                                         => SponsorProfileType::Sponsor,
        };
    }

    /** Map a free-text status answer to the enum; defaults to Prospect. */
    private function matchStatusEnum(string $raw): SponsorStatus
    {
        $lower = strtolower(trim($raw));

        foreach (SponsorStatus::cases() as $case) {
            if ($case->value === $lower || strtolower($case->label()) === $lower) {
                return $case;
            }
        }

        return SponsorStatus::Prospect;
    }
}
