<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        $users = [
            ['name' => 'Super Admin', 'email' => 'superadmin@boxmotorsports.test', 'role' => 'super_admin'],
            ['name' => 'Admin User', 'email' => 'admin@boxmotorsports.test', 'role' => 'admin'],
            ['name' => 'Sales Manager', 'email' => 'manager@boxmotorsports.test', 'role' => 'sales_manager'],
            ['name' => 'Sales Rep', 'email' => 'rep@boxmotorsports.test', 'role' => 'sales_rep'],
            ['name' => 'Viewer', 'email' => 'viewer@boxmotorsports.test', 'role' => 'viewer'],
        ];

        foreach ($users as $u) {
            User::updateOrCreate(
                ['email' => $u['email']],
                [
                    'name' => $u['name'],
                    'role' => $u['role'],
                    'password' => Hash::make('password'),
                    'is_active' => true,
                    'email_verified_at' => now(),
                ]
            );
        }
    }
}
