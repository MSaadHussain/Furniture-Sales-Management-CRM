<?php

namespace App\Enums;

enum SourceChannel: string
{
    case Jotform = 'jotform';
    case GoogleForm = 'google_form';
    case Website = 'website';
    case WhatsApp = 'whatsapp';
    case Email = 'email';
    case Manual = 'manual';
    case Meta = 'meta';
    case GoogleLeadForm = 'google_lead_form';
    case ImportedCsv = 'imported_csv';
    case ImportedXlsx = 'imported_xlsx';
    case ImportedPdf = 'imported_pdf';

    public function label(): string
    {
        return match ($this) {
            self::Jotform      => 'Jotform',
            self::GoogleForm   => 'Google Form',
            self::Website      => 'Website',
            self::WhatsApp     => 'WhatsApp',
            self::Email        => 'Email',
            self::Manual       => 'Manual',
            self::Meta         => 'Meta',
            self::GoogleLeadForm => 'Google Lead Form',
            self::ImportedCsv  => 'Imported CSV',
            self::ImportedXlsx => 'Imported XLSX',
            self::ImportedPdf  => 'Imported PDF',
        };
    }

    public function color(): string
    {
        return match ($this) {
            self::Jotform    => '#F97316',
            self::GoogleForm => '#7C3AED',
            self::Website    => '#2563EB',
            self::WhatsApp   => '#16A34A',
            self::Email      => '#0EA5E9',
            self::Manual     => '#6B7280',
            self::Meta         => '#0866FF',
            self::GoogleLeadForm => '#EA4335',
            self::ImportedCsv  => '#0F9D58',
            self::ImportedXlsx => '#1D6F42',
            self::ImportedPdf  => '#D93025',
        };
    }

    public static function options(): array
    {
        return array_map(
            fn (self $c) => ['value' => $c->value, 'label' => $c->label(), 'color' => $c->color()],
            self::cases()
        );
    }

    /** Channels that originate from the file-import module. */
    public static function importCases(): array
    {
        return [self::ImportedCsv, self::ImportedXlsx, self::ImportedPdf];
    }

    public function isImport(): bool
    {
        return in_array($this, self::importCases(), true);
    }
}
