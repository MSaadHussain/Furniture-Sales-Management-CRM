<?php

namespace App\Services;

use App\Models\IntegrationSetting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class WebhookSecurityService
{
    public function secretFor(string $channel): ?string
    {
        $dbSecret = IntegrationSetting::where('channel', $channel)->value('secret_key');
        if ($dbSecret) {
            return $dbSecret;
        }

        $envKey = 'WEBHOOK_SECRET_' . strtoupper($channel);
        return config("services.webhooks.$channel") ?? env($envKey);
    }

    public function verifySharedSecret(Request $request, string $channel): bool
    {
        $expected = $this->secretFor($channel);
        if (! $expected) {
            return false;
        }

        $provided = $request->header('X-Webhook-Secret')
            ?? $request->bearerToken()
            ?? $request->input('secret');

        return is_string($provided) && hash_equals($expected, $provided);
    }

    public function verifyHmac(Request $request, string $channel, string $headerName = 'X-Hub-Signature-256', string $algo = 'sha256'): bool
    {
        $secret = $this->secretFor($channel);
        if (! $secret) {
            return false;
        }

        $signature = $request->header($headerName);
        if (! $signature) {
            return false;
        }

        $signature = str_contains($signature, '=')
            ? explode('=', $signature, 2)[1]
            : $signature;

        $computed = hash_hmac($algo, $request->getContent(), $secret);

        return hash_equals($computed, $signature);
    }

    public function logFailure(string $channel, Request $request, string $reason): void
    {
        Log::warning("Webhook auth failed [{$channel}]: {$reason}", [
            'ip'   => $request->ip(),
            'path' => $request->path(),
        ]);
    }
}
