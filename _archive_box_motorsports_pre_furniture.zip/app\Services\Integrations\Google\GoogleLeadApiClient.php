<?php

namespace App\Services\Integrations\Google;

use App\Models\IntegrationSetting;

/**
 * Reads Google Lead Form integration credentials. Google Lead Form Ads push
 * leads to a configured webhook (the "Webhook integration" in Google Ads),
 * authenticated by a shared key, so the heavy lifting is verification rather
 * than polling an API. Kept thin and dependency-free.
 */
class GoogleLeadApiClient
{
    private array $config;

    public function __construct()
    {
        $this->config = IntegrationSetting::where('channel', 'google_lead_form')->value('config') ?? [];
    }

    public function webhookKey(): ?string
    {
        return $this->config['webhook_secret'] ?? config('services.google_leads.webhook_secret');
    }

    public function get(string $key): ?string
    {
        return $this->config[$key] ?? null;
    }

    /** Basic config completeness check used by the "Test connection" button. */
    public function testConnection(): array
    {
        $required = ['google_client_id', 'webhook_secret'];
        foreach ($required as $key) {
            if (blank($this->config[$key] ?? null)) {
                return [false, "Missing required field: {$key}."];
            }
        }

        return [true, 'Google Lead Form configuration looks complete. Send a test lead from Google Ads to confirm delivery.'];
    }
}
