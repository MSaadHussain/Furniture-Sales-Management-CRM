@extends('layouts.app')
@section('title', $driver->full_name)
@section('breadcrumb')
    <a href="{{ route('driver-leads.index') }}" class="hover:text-brand">Driver Leads</a> / <span>{{ $driver->full_name }}</span>
@endsection

@section('header_actions')
    @if ($driver->status !== \App\Enums\DriverLeadStatus::Qualified)
        <form method="POST" action="{{ route('driver-leads.qualify', $driver) }}" class="inline">@csrf @method('PATCH')
            <button class="btn btn-primary"><i class="fa-solid fa-circle-check"></i> Qualify</button>
        </form>
    @endif
    @if ($driver->status !== \App\Enums\DriverLeadStatus::Declined)
        <form method="POST" action="{{ route('driver-leads.decline', $driver) }}" class="inline" onsubmit="return confirm('Decline this driver lead?')">@csrf @method('PATCH')
            <button class="btn btn-light text-danger hover:bg-danger/10"><i class="fa-solid fa-circle-xmark"></i> Decline</button>
        </form>
    @endif
    <form method="POST" action="{{ route('driver-leads.destroy', $driver) }}" class="inline" onsubmit="return confirm('Move this driver lead to Trash?')">@csrf @method('DELETE')
        <button class="btn btn-light text-danger hover:bg-danger/10"><i class="fa-solid fa-trash"></i> Delete</button>
    </form>
@endsection

@section('content')
<div class="grid grid-cols-1 gap-6 lg:grid-cols-3">

    {{-- Left: Driver info --}}
    <div class="lg:col-span-2 space-y-6">

        {{-- Contact & Racing info --}}
        <x-card title="Driver Information" x-data="{ editing: {{ $errors->any() ? 'true' : 'false' }} }">
            @unless (auth()->user()->role->isReadOnly())
                <x-slot:actions>
                    <button @click="editing = !editing" type="button" class="btn btn-light btn-sm">
                        <i class="fa-solid fa-pen"></i> <span x-text="editing ? 'Cancel' : 'Edit'"></span>
                    </button>
                </x-slot:actions>
            @endunless

            {{-- VIEW MODE --}}
            <div x-show="!editing">
            <div class="flex flex-wrap items-center gap-3 mb-5">
                @if ($driver->photoUrl())
                    <img src="{{ $driver->photoUrl() }}" alt="{{ $driver->full_name }}" class="h-14 w-14 rounded-full object-cover">
                @else
                    <span class="flex h-14 w-14 items-center justify-center rounded-full bg-brand text-xl font-bold text-white">
                        {{ strtoupper(substr($driver->first_name, 0, 1) . substr($driver->last_name, 0, 1)) }}
                    </span>
                @endif
                <div>
                    <h3 class="text-lg font-bold text-ink dark:text-white">{{ $driver->full_name }}</h3>
                    <div class="flex flex-wrap gap-2 mt-1">
                        <x-badge :label="$driver->inferred_tier->label()" :color="$driver->inferred_tier->color()" />
                        <x-badge :label="$driver->status->label()" :color="$driver->status->color()" />
                        @if ($driver->seeking_sponsorship)
                            <span class="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2.5 py-0.5 text-xs font-semibold text-amber-700 dark:bg-amber-900/30 dark:text-amber-400">
                                <i class="fa-solid fa-star text-[10px]"></i> Seeking Sponsorship
                            </span>
                        @endif
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 gap-6 sm:grid-cols-2">
                <div>
                    <h4 class="mb-3 text-xs font-semibold uppercase tracking-wider text-muted">Contact</h4>
                    <dl class="space-y-3 text-sm">
                        <div class="flex items-baseline gap-3"><dt class="w-28 shrink-0 font-medium text-muted">First Name</dt><dd class="text-ink dark:text-gray-300">{{ $driver->first_name }}</dd></div>
                        <div class="flex items-baseline gap-3"><dt class="w-28 shrink-0 font-medium text-muted">Last Name</dt><dd class="text-ink dark:text-gray-300">{{ $driver->last_name }}</dd></div>
                        <div class="flex items-baseline gap-3"><dt class="w-28 shrink-0 font-medium text-muted">Email</dt><dd class="break-all"><a href="mailto:{{ $driver->email }}" class="text-brand hover:underline">{{ $driver->email }}</a></dd></div>
                        <div class="flex items-baseline gap-3"><dt class="w-28 shrink-0 font-medium text-muted">Phone</dt><dd class="text-ink dark:text-gray-300">{{ $driver->phone ?: '—' }}</dd></div>
                        <div class="flex items-baseline gap-3"><dt class="w-28 shrink-0 font-medium text-muted">Country</dt><dd class="text-ink dark:text-gray-300">{{ $driver->country ?: '—' }}</dd></div>
                        <div class="flex items-baseline gap-3"><dt class="w-28 shrink-0 font-medium text-muted">DOB</dt><dd class="text-ink dark:text-gray-300">{{ $driver->dob?->format('M j, Y') ?? '—' }}</dd></div>
                        <div class="flex items-baseline gap-3"><dt class="w-28 shrink-0 font-medium text-muted">Age</dt><dd class="text-ink dark:text-gray-300">{{ $driver->age !== null ? $driver->age : '—' }}</dd></div>
                        <div class="flex items-baseline gap-3"><dt class="w-28 shrink-0 font-medium text-muted">Age Group</dt><dd class="text-ink dark:text-gray-300">{{ $driver->age_group ?? '—' }}</dd></div>
                    </dl>
                </div>
                <div>
                    <h4 class="mb-3 text-xs font-semibold uppercase tracking-wider text-muted">Racing</h4>
                    <dl class="space-y-3 text-sm">
                        <div class="flex items-baseline gap-3"><dt class="w-36 shrink-0 font-medium text-muted">Years Racing</dt><dd class="text-ink dark:text-gray-300">{{ $driver->years_racing }}</dd></div>
                        <div class="flex items-baseline gap-3"><dt class="w-36 shrink-0 font-medium text-muted">Highest Series</dt><dd class="text-ink dark:text-gray-300">{{ $driver->highest_series ?: '—' }}</dd></div>
                        <div class="flex items-baseline gap-3"><dt class="w-36 shrink-0 font-medium text-muted">Career Wins</dt><dd class="text-ink dark:text-gray-300">{{ $driver->career_wins }}</dd></div>
                        <div class="flex items-baseline gap-3"><dt class="w-36 shrink-0 font-medium text-muted">Team / Series</dt><dd class="text-ink dark:text-gray-300">{{ $driver->current_team_series ?: '—' }}</dd></div>
                        <div class="flex items-baseline gap-3"><dt class="w-36 shrink-0 font-medium text-muted">Racing Level</dt><dd>@if ($driver->racing_level)<x-badge :label="$driver->racing_level->label()" :color="$driver->racing_level->color()" />@else<span class="text-muted">—</span>@endif</dd></div>
                        <div class="flex items-baseline gap-3"><dt class="w-36 shrink-0 font-medium text-muted">Car Type</dt><dd>@if ($driver->car_type)<x-badge :label="$driver->car_type->label()" :color="$driver->car_type->color()" />@else<span class="text-muted">—</span>@endif</dd></div>
                        <div class="flex items-baseline gap-3"><dt class="w-36 shrink-0 font-medium text-muted">Contract Interest</dt><dd class="text-ink dark:text-gray-300">{{ $driver->contract_interest_type?->label() ?? '—' }}</dd></div>
                    </dl>
                </div>
            </div>

            <div class="mt-5 border-t border-line pt-4 dark:border-strokedark">
                <h4 class="mb-3 text-xs font-semibold uppercase tracking-wider text-muted">Social</h4>
                <dl class="space-y-3 text-sm">
                    <div class="flex items-baseline gap-3"><dt class="w-44 shrink-0 font-medium text-muted">Instagram</dt><dd>@if ($driver->instagram_handle)<a href="{{ $driver->instagram_url }}" target="_blank" rel="noopener" class="inline-flex items-center gap-1 text-brand hover:underline"><i class="fa-brands fa-instagram"></i> {{ $driver->instagram_handle }}</a>@else<span class="text-muted">—</span>@endif</dd></div>
                    <div class="flex items-baseline gap-3"><dt class="w-44 shrink-0 font-medium text-muted">Followers</dt><dd class="text-ink dark:text-gray-300">{{ number_format($driver->instagram_followers) }}</dd></div>
                    <div class="flex items-baseline gap-3"><dt class="w-44 shrink-0 font-medium text-muted">Seeking Sponsorship</dt><dd class="text-ink dark:text-gray-300">{{ $driver->seeking_sponsorship ? 'Yes' : 'No' }}</dd></div>
                </dl>
            </div>

            </div>{{-- /VIEW MODE --}}

            {{-- EDIT MODE: full driver details. Racing Level and Car Type are
                 independent manual dropdowns — no auto-selection between them. --}}
            @unless (auth()->user()->role->isReadOnly())
            <form x-show="editing" x-cloak method="POST" action="{{ route('driver-leads.update', $driver) }}" enctype="multipart/form-data" class="space-y-6">
                @csrf @method('PATCH')

                {{-- Photo --}}
                <div x-data="{ preview: null, name: '' }">
                    <label class="ta-label">Profile Picture</label>
                    <div class="flex items-center gap-3">
                        <img x-show="preview" x-cloak :src="preview" alt="" class="h-14 w-14 rounded-full object-cover">
                        @if ($driver->photoUrl())
                            <img x-show="!preview" src="{{ $driver->photoUrl() }}" alt="" class="h-14 w-14 rounded-full object-cover">
                        @endif
                        <input type="file" name="photo" accept="image/*" class="ta-input w-full"
                               @change="const f=$event.target.files[0]; preview = f ? URL.createObjectURL(f) : null; name = f ? f.name : ''">
                    </div>
                    <p class="mt-1 text-xs text-brand" x-show="name" x-cloak><i class="fa-solid fa-image"></i> <span x-text="name"></span></p>
                    <p class="mt-1 text-xs text-muted">JPG/PNG/WebP/GIF up to 5 MB — converted to WebP. Leave empty to keep the current photo.</p>
                    @error('photo')<p class="mt-1 text-xs text-danger">{{ $message }}</p>@enderror
                </div>

                <div>
                    <h4 class="mb-3 text-xs font-semibold uppercase tracking-wider text-muted">Contact</h4>
                    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
                        <div>
                            <label class="ta-label">First Name <span class="text-danger">*</span></label>
                            <input name="first_name" value="{{ old('first_name', $driver->first_name) }}" required class="ta-input w-full">
                            @error('first_name')<p class="mt-1 text-xs text-danger">{{ $message }}</p>@enderror
                        </div>
                        <div>
                            <label class="ta-label">Last Name <span class="text-danger">*</span></label>
                            <input name="last_name" value="{{ old('last_name', $driver->last_name) }}" required class="ta-input w-full">
                            @error('last_name')<p class="mt-1 text-xs text-danger">{{ $message }}</p>@enderror
                        </div>
                        <div>
                            <label class="ta-label">Email <span class="text-danger">*</span></label>
                            <input type="email" name="email" value="{{ old('email', $driver->email) }}" required class="ta-input w-full">
                            @error('email')<p class="mt-1 text-xs text-danger">{{ $message }}</p>@enderror
                        </div>
                        <div>
                            <label class="ta-label">Phone <span class="text-danger">*</span></label>
                            <input name="phone" value="{{ old('phone', $driver->phone) }}" required class="ta-input w-full">
                            @error('phone')<p class="mt-1 text-xs text-danger">{{ $message }}</p>@enderror
                        </div>
                        <div>
                            <label class="ta-label">Country</label>
                            <input name="country" value="{{ old('country', $driver->country) }}" class="ta-input w-full">
                        </div>
                        <div>
                            <label class="ta-label">DOB</label>
                            <input type="date" name="dob" value="{{ old('dob', $driver->dob?->format('Y-m-d')) }}" max="{{ now()->subDay()->format('Y-m-d') }}" class="ta-input w-full">
                            @error('dob')<p class="mt-1 text-xs text-danger">{{ $message }}</p>@enderror
                        </div>
                    </div>
                </div>

                <div>
                    <h4 class="mb-3 text-xs font-semibold uppercase tracking-wider text-muted">Racing</h4>
                    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
                        <div>
                            <label class="ta-label">Years Racing</label>
                            <input type="number" min="0" name="years_racing" value="{{ old('years_racing', $driver->years_racing) }}" class="ta-input w-full">
                        </div>
                        <div>
                            <label class="ta-label">Career Wins</label>
                            <input type="number" min="0" name="career_wins" value="{{ old('career_wins', $driver->career_wins) }}" class="ta-input w-full">
                        </div>
                        <div>
                            <label class="ta-label">Highest Series</label>
                            <input name="highest_series" value="{{ old('highest_series', $driver->highest_series) }}" class="ta-input w-full">
                        </div>
                        <div>
                            <label class="ta-label">Team / Series</label>
                            <input name="current_team_series" value="{{ old('current_team_series', $driver->current_team_series) }}" class="ta-input w-full">
                        </div>
                        <div>
                            <label class="ta-label">Racing Level</label>
                            <select name="racing_level" class="ta-input w-full">
                                <option value="">— Not set —</option>
                                @foreach ($racingLevels as $l)<option value="{{ $l['value'] }}" @selected(old('racing_level', $driver->racing_level?->value)===$l['value'])>{{ $l['label'] }}</option>@endforeach
                            </select>
                            @error('racing_level')<p class="mt-1 text-xs text-danger">{{ $message }}</p>@enderror
                        </div>
                        <div>
                            <label class="ta-label">Car Type</label>
                            <select name="car_type" class="ta-input w-full">
                                <option value="">Select car type...</option>
                                @foreach ($carTypes as $c)<option value="{{ $c['value'] }}" @selected(old('car_type', $driver->car_type?->value)===$c['value'])>{{ $c['label'] }}</option>@endforeach
                            </select>
                            @error('car_type')<p class="mt-1 text-xs text-danger">{{ $message }}</p>@enderror
                        </div>
                        <div>
                            <label class="ta-label">Interested Contract Type</label>
                            <select name="contract_interest_type" class="ta-input w-full">
                                <option value="">— Not set —</option>
                                @foreach ($contractTypes as $ct)<option value="{{ $ct['value'] }}" @selected(old('contract_interest_type', $driver->contract_interest_type?->value)===$ct['value'])>{{ $ct['label'] }}</option>@endforeach
                            </select>
                        </div>
                        <div>
                            <label class="ta-label">Status <span class="text-danger">*</span></label>
                            <select name="status" required class="ta-input w-full">
                                @foreach (\App\Enums\DriverLeadStatus::cases() as $s)<option value="{{ $s->value }}" @selected(old('status', $driver->status?->value)===$s->value)>{{ $s->label() }}</option>@endforeach
                            </select>
                        </div>
                    </div>
                    <p class="mt-2 text-xs text-muted">Racing Level and Car Type are selected manually and independently.</p>
                </div>

                <div>
                    <h4 class="mb-3 text-xs font-semibold uppercase tracking-wider text-muted">Social</h4>
                    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
                        <div>
                            <label class="ta-label">Instagram Handle</label>
                            <input name="instagram_handle" value="{{ old('instagram_handle', $driver->instagram_handle) }}" class="ta-input w-full" placeholder="@username">
                        </div>
                        <div>
                            <label class="ta-label">Instagram Followers</label>
                            <input type="number" min="0" name="instagram_followers" value="{{ old('instagram_followers', $driver->instagram_followers) }}" class="ta-input w-full">
                        </div>
                        <div class="sm:col-span-2 flex items-center gap-2">
                            <input type="hidden" name="seeking_sponsorship" value="0">
                            <input type="checkbox" id="edit_seeking" name="seeking_sponsorship" value="1" @checked(old('seeking_sponsorship', $driver->seeking_sponsorship)) class="h-4 w-4 rounded text-brand focus:ring-brand">
                            <label for="edit_seeking" class="ta-label mb-0">Seeking Sponsorship</label>
                        </div>
                    </div>
                </div>

                <div class="flex justify-end gap-2 border-t border-line pt-4 dark:border-strokedark">
                    <button type="button" @click="editing = false" class="btn btn-light">Cancel</button>
                    <button class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save Changes</button>
                </div>
            </form>
            @endunless
        </x-card>

        {{-- Sponsor Funding --}}
        <x-card title="Sponsor Funding" subtitle="Sponsors backing this driver">
            <div class="space-y-3">
                @forelse ($driver->sponsorLinks as $link)
                    <div class="rounded-xl border border-line p-4 dark:border-strokedark">
                        <div class="flex flex-wrap items-center justify-between gap-2">
                            <div>
                                <a href="{{ route('sponsors.show', $link->sponsor_profile_id) }}" class="font-semibold text-ink hover:text-brand dark:text-white">
                                    <i class="fa-solid fa-building mr-1 text-muted"></i>{{ $link->sponsor?->company_name ?? 'Deleted sponsor' }}
                                </a>
                                <div class="mt-1 flex flex-wrap gap-2">
                                    <x-badge :label="$link->funding_type->label()" :color="$link->funding_type->color()" />
                                    <x-badge :label="$link->status->label()" :color="$link->status->color()" />
                                    @if ($link->season_or_event)<span class="text-xs text-muted">{{ $link->season_or_event }}</span>@endif
                                </div>
                                @if ($link->sponsor?->contact_name)
                                    <p class="mt-1 text-xs text-muted">Contact: {{ $link->sponsor->contact_name }}</p>
                                @endif
                            </div>
                            <div class="text-right">
                                <p class="font-bold text-ink dark:text-white">{{ $link->funding_amount ? '$' . number_format($link->funding_amount, 0) : '—' }}</p>
                                @if ($link->deal)
                                    <p class="text-xs text-muted">{{ $link->deal->title }}</p>
                                    <x-badge :label="$link->deal->stage->label()" :color="$link->deal->stage->color()" />
                                @endif
                            </div>
                        </div>
                        @if ($link->start_date || $link->end_date)
                            <p class="mt-2 border-t border-line pt-2 text-xs text-muted dark:border-strokedark">
                                <i class="fa-solid fa-calendar mr-1"></i>{{ $link->start_date?->format('M j, Y') ?? '—' }} → {{ $link->end_date?->format('M j, Y') ?? 'ongoing' }}
                            </p>
                        @endif
                    </div>
                @empty
                    <p class="text-sm text-muted">No sponsor funding linked yet. Link a sponsor from the <a href="{{ route('sponsors.index') }}" class="text-brand hover:underline">Sponsors & Vendors</a> section.</p>
                @endforelse
            </div>
        </x-card>

        {{-- Contracts --}}
        <x-card title="Contracts" subtitle="Driver contracts: sponsorship, team seat, coaching, track time…">

            {{-- Contract Overview: active contract, falling back to the latest one --}}
            @php $overview = $driver->contracts->firstWhere('contract_status', \App\Enums\DriverContractStatus::Active) ?? $driver->contracts->first(); @endphp
            @if ($overview)
                <div class="mb-5 rounded-xl border border-line p-4 dark:border-strokedark">
                    <div class="flex flex-wrap items-center justify-between gap-2">
                        <div>
                            <span class="font-semibold text-ink dark:text-white">
                                <i class="fa-solid {{ $overview->contract_type->icon() }} mr-1 text-muted"></i>{{ $overview->contract_type->label() }}
                            </span>
                            <div class="mt-1 flex flex-wrap gap-2">
                                <x-badge :label="$overview->contract_status->label()" :color="$overview->contract_status->color()" />
                                @if ($overview->racing_level)<x-badge :label="$overview->racing_level->label()" :color="$overview->racing_level->color()" />@endif
                                @if ($overview->car_type)<x-badge :label="$overview->car_type->label()" :color="$overview->car_type->color()" />@endif
                            </div>
                            @if ($overview->sponsor)
                                <p class="mt-1 text-xs text-muted"><i class="fa-solid fa-building mr-1"></i><a href="{{ route('sponsors.show', $overview->sponsor_profile_id) }}" class="text-brand hover:underline">{{ $overview->sponsor->company_name }}</a>@if ($overview->deal) · {{ $overview->deal->title }}@endif</p>
                            @endif
                        </div>
                        <div class="text-right">
                            <p class="font-bold text-ink dark:text-white">{{ $overview->contract_value ? $overview->currency . ' ' . number_format($overview->contract_value, 0) : '—' }}</p>
                            <p class="text-xs text-muted">{{ $overview->start_date?->format('M j, Y') ?? '—' }} → {{ $overview->end_date?->format('M j, Y') ?? 'ongoing' }}</p>
                            @if ($overview->signed_date)<p class="text-xs text-muted">Signed {{ $overview->signed_date->format('M j, Y') }}</p>@endif
                            @if ($overview->document_path)
                                <a href="{{ Storage::url($overview->document_path) }}" target="_blank" class="text-xs text-brand hover:underline"><i class="fa-solid fa-paperclip mr-1"></i>Document</a>
                            @endif
                        </div>
                    </div>
                </div>
            @endif

            {{-- New contract form --}}
            @unless (auth()->user()->role->isReadOnly())
                <div x-data="{ open: false }" class="mb-5">
                    <button @click="open = !open" type="button" class="btn btn-light text-sm"><i class="fa-solid fa-plus"></i> New Contract</button>
                    <form method="POST" action="{{ route('driver-leads.contracts.store', $driver) }}" enctype="multipart/form-data" x-show="open" x-collapse
                          class="mt-4 grid grid-cols-1 gap-4 rounded-xl border border-line p-4 dark:border-strokedark sm:grid-cols-2">
                        @csrf
                        <div>
                            <label class="ta-label">Contract Type <span class="text-danger">*</span></label>
                            <select name="contract_type" required class="ta-input w-full">
                                @foreach ($contractTypes as $ct)<option value="{{ $ct['value'] }}">{{ $ct['label'] }}</option>@endforeach
                            </select>
                        </div>
                        <div>
                            <label class="ta-label">Status <span class="text-danger">*</span></label>
                            <select name="contract_status" required class="ta-input w-full">
                                @foreach ($contractStatuses as $cs)<option value="{{ $cs['value'] }}">{{ $cs['label'] }}</option>@endforeach
                            </select>
                        </div>
                        <div>
                            <label class="ta-label">Sponsor</label>
                            <select name="sponsor_profile_id" class="ta-input w-full">
                                <option value="">None</option>
                                @foreach ($sponsors as $s)<option value="{{ $s->id }}">{{ $s->company_name }}</option>@endforeach
                            </select>
                        </div>
                        <div>
                            <label class="ta-label">Sponsorship Deal</label>
                            <select name="sponsorship_deal_id" class="ta-input w-full">
                                <option value="">None</option>
                                @foreach ($deals as $d)<option value="{{ $d->id }}">{{ $d->title }} ({{ $d->sponsor?->company_name }})</option>@endforeach
                            </select>
                        </div>
                        <div>
                            <label class="ta-label">Racing Level</label>
                            <select name="racing_level" class="ta-input w-full">
                                <option value="">— Not set —</option>
                                @foreach ($racingLevels as $l)<option value="{{ $l['value'] }}" @selected($driver->racing_level?->value === $l['value'])>{{ $l['label'] }}</option>@endforeach
                            </select>
                            <p class="mt-1 text-xs text-muted">Defaults to the driver's racing level.</p>
                        </div>
                        <div>
                            <label class="ta-label">Car Type</label>
                            <select name="car_type" class="ta-input w-full">
                                <option value="">— Not set —</option>
                                @foreach ($carTypes as $c)<option value="{{ $c['value'] }}" @selected($driver->car_type?->value === $c['value'])>{{ $c['label'] }}</option>@endforeach
                            </select>
                            <p class="mt-1 text-xs text-muted">Defaults to the driver's car type.</p>
                        </div>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="ta-label">Value</label>
                                <input type="number" step="0.01" min="0" name="contract_value" class="ta-input w-full">
                            </div>
                            <div>
                                <label class="ta-label">Currency</label>
                                <input name="currency" value="USD" maxlength="10" class="ta-input w-full">
                            </div>
                        </div>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="ta-label">Start Date</label>
                                <input type="date" name="start_date" class="ta-input w-full">
                            </div>
                            <div>
                                <label class="ta-label">End Date</label>
                                <input type="date" name="end_date" class="ta-input w-full">
                            </div>
                        </div>
                        <div>
                            <label class="ta-label">Signed Date</label>
                            <input type="date" name="signed_date" class="ta-input w-full">
                        </div>
                        <div>
                            <label class="ta-label">Document (PDF, DOC, image)</label>
                            <input type="file" name="document" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png" class="ta-input w-full text-xs">
                        </div>
                        <div class="sm:col-span-2">
                            <label class="ta-label">Notes</label>
                            <textarea name="notes" rows="2" class="ta-input w-full"></textarea>
                        </div>
                        <div class="sm:col-span-2 flex items-center justify-end">
                            <button class="btn btn-primary"><i class="fa-solid fa-file-contract"></i> Create Contract</button>
                        </div>
                    </form>
                </div>
            @endunless

            {{-- Contract history --}}
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="border-b border-line dark:border-strokedark">
                        <tr>
                            <th class="ta-th">Contract</th>
                            <th class="ta-th">Sponsor / Deal</th>
                            <th class="ta-th">Value</th>
                            <th class="ta-th">Status</th>
                            <th class="ta-th">Dates</th>
                            <th class="ta-th text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-line dark:divide-strokedark">
                        @forelse ($driver->contracts as $contract)
                            <tr>
                                <td class="ta-td">
                                    <span class="font-medium text-ink dark:text-gray-200">{{ $contract->contract_type->label() }}</span>
                                    <span class="block text-xs text-muted">
                                        {{ $contract->racing_level?->label() ?? '' }}{{ $contract->racing_level && $contract->car_type ? ' · ' : '' }}{{ $contract->car_type?->label() ?? '' }}
                                    </span>
                                </td>
                                <td class="ta-td text-muted text-xs">
                                    {{ $contract->sponsor?->company_name ?? '—' }}
                                    @if ($contract->deal)<span class="block">{{ $contract->deal->title }}</span>@endif
                                </td>
                                <td class="ta-td text-ink dark:text-gray-300">{{ $contract->contract_value ? $contract->currency . ' ' . number_format($contract->contract_value, 0) : '—' }}</td>
                                <td class="ta-td">
                                    @unless (auth()->user()->role->isReadOnly())
                                        <form method="POST" action="{{ route('driver-contracts.status', $contract) }}">
                                            @csrf @method('PATCH')
                                            <select name="contract_status" onchange="this.form.submit()" class="ta-input !w-auto !py-1 text-xs">
                                                @foreach ($contractStatuses as $cs)<option value="{{ $cs['value'] }}" @selected($contract->contract_status->value===$cs['value'])>{{ $cs['label'] }}</option>@endforeach
                                            </select>
                                        </form>
                                    @else
                                        <x-badge :label="$contract->contract_status->label()" :color="$contract->contract_status->color()" />
                                    @endunless
                                </td>
                                <td class="ta-td text-muted text-xs">
                                    {{ $contract->start_date?->format('M j, Y') ?? '—' }} → {{ $contract->end_date?->format('M j, Y') ?? '—' }}
                                    @if ($contract->signed_date)<span class="block">Signed {{ $contract->signed_date->format('M j, Y') }}</span>@endif
                                </td>
                                <td class="ta-td">
                                    <div class="flex items-center justify-end gap-2">
                                        @if ($contract->document_path)
                                            <a href="{{ Storage::url($contract->document_path) }}" target="_blank" class="btn btn-light !px-2.5 !py-1 text-xs" title="View document"><i class="fa-solid fa-paperclip"></i></a>
                                        @endif
                                        @unless (auth()->user()->role->isReadOnly())
                                            <form method="POST" action="{{ route('driver-contracts.destroy', $contract) }}" onsubmit="return confirm('Delete this contract?')">
                                                @csrf @method('DELETE')
                                                <button class="btn btn-light !px-2.5 !py-1 text-xs text-danger hover:bg-danger/10" title="Delete"><i class="fa-solid fa-trash"></i></button>
                                            </form>
                                        @endunless
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr><td colspan="6" class="ta-td py-6 text-center text-muted">No contracts yet.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </x-card>

        {{-- Meetings --}}
        @include('meetings._card', [
            'subject'       => $driver,
            'googleRoute'   => route('driver-leads.meetings.google-meet', $driver),
            'zoomRoute'     => route('driver-leads.meetings.zoom', $driver),
            'calendlyRoute' => route('driver-leads.meetings.calendly-link', $driver),
            'defaultTitle'  => $driver->full_name,
        ])

        {{-- Comments (team discussion) --}}
        <x-card title="Team Discussion">
            <form method="POST" action="{{ route('driver-leads.comments.store', $driver) }}" class="mb-5">
                @csrf
                <textarea name="body" rows="3" required class="ta-input mb-2 w-full" placeholder="Write a comment..."></textarea>
                <button class="btn btn-primary"><i class="fa-solid fa-paper-plane"></i> Add Comment</button>
            </form>

            <div class="space-y-4">
                @forelse ($driver->comments as $comment)
                    <div class="rounded-xl border border-line p-4 dark:border-strokedark">
                        <div class="flex items-center justify-between">
                            <span class="font-semibold text-ink dark:text-white">{{ $comment->user?->name ?? 'System' }}</span>
                            <span class="text-xs text-muted">{{ $comment->created_at->diffForHumans() }}</span>
                        </div>
                        <p class="mt-2 text-sm text-ink dark:text-gray-300" style="white-space:pre-line;">{{ $comment->body }}</p>
                    </div>
                @empty
                    <p class="text-sm text-muted">No comments yet. Start the discussion.</p>
                @endforelse
            </div>
        </x-card>
    </div>

    {{-- Right sidebar --}}
    <div class="space-y-6">

        {{-- Status --}}
        <x-card title="Status">
            <form method="POST" action="{{ route('driver-leads.status', $driver) }}">
                @csrf @method('PATCH')
                <select name="status" onchange="this.form.submit()" class="ta-input w-full">
                    @foreach ($statuses as $s)<option value="{{ $s['value'] }}" @selected($driver->status->value===$s['value'])>{{ $s['label'] }}</option>@endforeach
                </select>
            </form>
        </x-card>

        {{-- Tier info --}}
        <x-card title="Auto-Tier">
            <div class="flex items-center gap-3 mb-3">
                <x-badge :label="$driver->inferred_tier->label()" :color="$driver->inferred_tier->color()" />
            </div>
            <p class="text-xs text-muted mb-3">Tier is auto-computed from racing level, age (DOB), career wins, and experience. Car type is never used.</p>
            <dl class="space-y-1 text-xs text-muted">
                <div><dt class="inline font-semibold">Elite:</dt> <dd class="inline">Formula 1, or 8+ years AND 50+ wins</dd></div>
                <div><dt class="inline font-semibold">Professional:</dt> <dd class="inline">Formula 2, or 5+ years AND 20+ wins</dd></div>
                <div><dt class="inline font-semibold">Pro-Am:</dt> <dd class="inline">Formula 3/4 with strong wins, or 3+ years AND 5+ wins</dd></div>
                <div><dt class="inline font-semibold">Development:</dt> <dd class="inline">Karting under 16, or Formula 3/4 building wins</dd></div>
                <div><dt class="inline font-semibold">Amateur:</dt> <dd class="inline">Everyone else</dd></div>
            </dl>

            @if ($driver->tierHistory->isNotEmpty())
                <h5 class="mt-4 mb-2 text-xs font-semibold uppercase tracking-wider text-muted">Tier History</h5>
                <div class="space-y-2">
                    @foreach ($driver->tierHistory as $th)
                        <div class="text-xs">
                            <x-badge :label="$th->old_tier->label()" :color="$th->old_tier->color()" />
                            <i class="fa-solid fa-arrow-right mx-1 text-muted"></i>
                            <x-badge :label="$th->new_tier->label()" :color="$th->new_tier->color()" />
                            <span class="text-muted block mt-0.5">{{ $th->created_at->diffForHumans() }} · {{ $th->user?->name ?? 'System' }}</span>
                        </div>
                    @endforeach
                </div>
            @endif
        </x-card>

        {{-- Activity log --}}
        <x-card title="Activity Log">
            <div class="space-y-3 max-h-96 overflow-y-auto">
                @forelse ($driver->activities as $activity)
                    <div class="border-l-2 border-brand/40 pl-3 text-sm">
                        <div class="font-semibold text-ink dark:text-white">{{ \Illuminate\Support\Str::headline($activity->action) }}</div>
                        @if ($activity->description)
                            <p class="text-muted text-xs">{{ $activity->description }}</p>
                        @endif
                        @if ($activity->old_value || $activity->new_value)
                            <p class="text-xs text-muted">{{ $activity->old_value }} &rarr; {{ $activity->new_value }}</p>
                        @endif
                        <p class="text-xs text-muted">{{ $activity->user?->name ?? 'System' }} &middot; {{ $activity->created_at->diffForHumans() }}</p>
                    </div>
                @empty
                    <p class="text-sm text-muted">No activity yet.</p>
                @endforelse
            </div>
        </x-card>
    </div>
</div>
@endsection
