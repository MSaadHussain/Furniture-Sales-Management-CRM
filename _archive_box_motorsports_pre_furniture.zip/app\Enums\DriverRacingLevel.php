<?php

namespace App\Enums;

enum DriverRacingLevel: string
{
    case Karting = 'karting';
    case Formula4 = 'formula_4';
    case Formula3 = 'formula_3';
    case Formula2 = 'formula_2';
    case Formula1 = 'formula_1';
    case GtRacing = 'gt_racing';
    case TouringCar = 'touring_car';
    case Prototype = 'prototype';
    case StockCar = 'stock_car';
    case SimRacing = 'sim_racing';
    case Other = 'other';

    public function label(): string
    {
        return match ($this) {
            self::Karting    => 'Karting',
            self::Formula4   => 'Formula 4',
            self::Formula3   => 'Formula 3',
            self::Formula2   => 'Formula 2',
            self::Formula1   => 'Formula 1',
            self::GtRacing   => 'GT Racing',
            self::TouringCar => 'Touring Car',
            self::Prototype  => 'Prototype',
            self::StockCar   => 'Stock Car',
            self::SimRacing  => 'Sim Racing',
            self::Other      => 'Other',
        };
    }

    public function color(): string
    {
        return match ($this) {
            self::Karting    => '#6B7280',
            self::Formula4   => '#0EA5E9',
            self::Formula3   => '#2563EB',
            self::Formula2   => '#7C3AED',
            self::Formula1   => '#DC2626',
            self::GtRacing   => '#16A34A',
            self::TouringCar => '#F59E0B',
            self::Prototype  => '#EC4899',
            self::StockCar   => '#F97316',
            self::SimRacing  => '#14B8A6',
            self::Other      => '#9CA3AF',
        };
    }

    public static function options(): array
    {
        return array_map(
            fn (self $l) => ['value' => $l->value, 'label' => $l->label(), 'color' => $l->color()],
            self::cases()
        );
    }

    /**
     * Age-plausibility rule for racing level. Returns an error message when
     * the combination is not allowed, or null when it is fine.
     *
     *   under 12 → Karting only
     *   under 15 → no Formula 1 / Formula 2
     *   under 18 → no Formula 1
     */
    public static function ageViolation(?int $age, ?self $level): ?string
    {
        if ($age === null || $level === null) {
            return null;
        }

        if ($age < 12 && $level !== self::Karting) {
            return "Drivers under 12 can only have Karting as their racing level.";
        }

        if ($age < 15 && in_array($level, [self::Formula1, self::Formula2], true)) {
            return "Drivers under 15 cannot have {$level->label()} as their racing level.";
        }

        if ($age < 18 && $level === self::Formula1) {
            return 'Drivers under 18 cannot have Formula 1 as their racing level.';
        }

        return null;
    }
}
