<?php

namespace App\Notifications;

use App\Models\Lead;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;

class LeadAssignedNotification extends Notification
{
    use Queueable;

    public function __construct(public Lead $lead, public string $assignedBy) {}

    public function via(object $notifiable): array
    {
        return ['database'];
    }

    public function toArray(object $notifiable): array
    {
        return [
            'type'    => 'lead_assigned',
            'lead_id' => $this->lead->id,
            'title'   => 'Lead assigned to you',
            'message' => ($this->lead->full_name ?: 'A lead') . " was assigned by {$this->assignedBy}",
            'color'   => '#2563EB',
        ];
    }
}
