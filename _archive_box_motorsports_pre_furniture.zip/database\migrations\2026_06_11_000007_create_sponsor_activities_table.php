<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('sponsor_activities', function (Blueprint $table) {
            $table->id();
            $table->foreignId('sponsor_profile_id')->constrained('sponsor_profiles')->cascadeOnDelete();
            $table->foreignId('sponsorship_deal_id')->nullable()->constrained('sponsorship_deals')->nullOnDelete();
            $table->foreignId('driver_lead_id')->nullable()->constrained('driver_leads')->nullOnDelete();
            $table->string('action_type')->index();
            $table->text('description')->nullable();
            $table->foreignId('performed_by')->nullable()->constrained('users')->nullOnDelete();
            $table->date('due_date')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->string('attachment_path')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('sponsor_activities');
    }
};
