@extends('layouts.app')
@section('title', 'Calendar / Meetings')

@php
    // [title, subtitle, collection, subject-column-header] for each section.
    $sections = [
        ['Lead Meetings', 'Google Meet & Zoom meetings attached to CRM leads', $leadMeetings, 'Lead'],
        ['Driver Lead Meetings', 'Meetings with racing drivers', $driverMeetings, 'Driver'],
        ['Sponsor & Vendor Meetings', 'Meetings with sponsors and vendors', $sponsorMeetings, 'Sponsor'],
    ];
@endphp

@section('content')
<div class="space-y-6" x-data="meetingScheduler()">

    {{-- Header + Schedule Meeting button --}}
    <div class="flex flex-wrap items-center justify-between gap-3">
        <div>
            <h2 class="text-xl font-semibold text-ink dark:text-white">Meetings</h2>
            <p class="text-sm text-muted">Google Meet &amp; Zoom meetings across all lead types</p>
        </div>
        @unless (auth()->user()->role->isReadOnly())
            <button type="button" @click="openModal()" class="btn btn-primary">
                <i class="fa-solid fa-calendar-plus"></i> Schedule Meeting
            </button>
        @endunless
    </div>

    @unless (auth()->user()->role->isReadOnly())
        {{-- Schedule modal --}}
        <div x-show="open" x-cloak class="fixed inset-0 z-[9999] flex items-start justify-center overflow-y-auto bg-black/50 p-4 sm:p-8" @keydown.escape.window="open=false">
            <div @click.outside="open=false" class="w-full max-w-lg rounded-2xl bg-white p-6 shadow-xl dark:bg-boxdark">
                <div class="mb-4 flex items-center justify-between">
                    <h3 class="text-lg font-semibold text-ink dark:text-white">Schedule a Meeting</h3>
                    <button type="button" @click="open=false" class="text-muted hover:text-ink dark:hover:text-white"><i class="fa-solid fa-xmark"></i></button>
                </div>

                <form method="POST" action="{{ route('meetings.schedule') }}" class="space-y-4" @submit="onSubmit($event)">
                    @csrf
                    <input type="hidden" name="subject_type">
                    <input type="hidden" name="subject_id">

                    {{-- Existing vs new toggle --}}
                    <div class="inline-flex w-full rounded-lg border border-line p-1 dark:border-strokedark">
                        <button type="button" @click="mode='existing'" :class="mode==='existing' ? 'bg-brand text-white shadow-sm' : 'text-muted'" class="flex-1 rounded-md px-3 py-1.5 text-sm font-medium transition">Existing contact</button>
                        <button type="button" @click="mode='new'" :class="mode==='new' ? 'bg-brand text-white shadow-sm' : 'text-muted'" class="flex-1 rounded-md px-3 py-1.5 text-sm font-medium transition">New lead</button>
                    </div>

                    {{-- EXISTING: search any lead / driver / sponsor --}}
                    <div x-show="mode==='existing'" class="relative">
                        <label class="ta-label">Who is the meeting with?</label>
                        <template x-if="!selected">
                            <input type="text" x-model="q" @input.debounce.300ms="runSearch()" autocomplete="off"
                                   class="ta-input w-full" placeholder="Search basic leads, drivers, or sponsors by name / email…">
                        </template>
                        <template x-if="selected">
                            <div class="flex items-center justify-between rounded-lg border border-line p-2.5 dark:border-strokedark">
                                <div>
                                    <span class="font-medium text-ink dark:text-white" x-text="selected.name"></span>
                                    <span class="ml-2 rounded bg-gray-100 px-1.5 py-0.5 text-xs text-muted dark:bg-meta-4" x-text="selected.label"></span>
                                    <div class="text-xs text-muted" x-text="selected.email"></div>
                                </div>
                                <button type="button" @click="clearSelection()" class="text-muted hover:text-danger"><i class="fa-solid fa-xmark"></i></button>
                            </div>
                        </template>

                        {{-- Results dropdown --}}
                        <div x-show="!selected && results.length" class="absolute z-10 mt-1 max-h-64 w-full overflow-y-auto rounded-lg border border-line bg-white shadow-lg dark:border-strokedark dark:bg-boxdark">
                            <template x-for="item in results" :key="item.type + '-' + item.id">
                                <button type="button" @click="pick(item)" class="flex w-full items-center justify-between gap-2 px-3 py-2 text-left hover:bg-surface dark:hover:bg-meta-4">
                                    <span>
                                        <span class="font-medium text-ink dark:text-gray-200" x-text="item.name"></span>
                                        <span class="block text-xs text-muted" x-text="item.email"></span>
                                    </span>
                                    <span class="rounded px-1.5 py-0.5 text-xs"
                                          :class="{ 'bg-blue-100 text-blue-700': item.type==='basic', 'bg-red-100 text-red-700': item.type==='driver', 'bg-green-100 text-green-700': item.type==='sponsor' }"
                                          x-text="item.label"></span>
                                </button>
                            </template>
                        </div>
                        <p x-show="!selected && searched && !results.length && q.length>=2" class="mt-1 text-xs text-muted">No matches found.</p>
                    </div>

                    {{-- NEW: create a basic lead inline --}}
                    <div x-show="mode==='new'" class="space-y-3 rounded-lg border border-line p-3 dark:border-strokedark">
                        <p class="text-xs text-muted">A new Basic Lead will be created and set to <strong>Meeting Scheduled</strong>.</p>
                        <div>
                            <label class="ta-label">First name</label>
                            <input type="text" name="new_first_name" x-model="newFirstName" @input="if(!title){ title = 'Call with ' + newFirstName }" class="ta-input w-full" :required="mode==='new'">
                        </div>
                        <div class="flex flex-col gap-3 sm:flex-row">
                            <div class="flex-1">
                                <label class="ta-label">Email</label>
                                <input type="email" name="new_email" class="ta-input w-full" :required="mode==='new'">
                            </div>
                            <div class="flex-1">
                                <label class="ta-label">Phone</label>
                                <input type="text" name="new_phone" class="ta-input w-full" :required="mode==='new'">
                            </div>
                        </div>
                        <div>
                            <label class="ta-label">Motorsport interest (optional)</label>
                            <select name="new_motorsport_interest" class="ta-input w-full">
                                <option value="">—</option>
                                @foreach(\App\Enums\MotorsportInterest::cases() as $mi)
                                    <option value="{{ $mi->value }}">{{ $mi->label() }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>

                    {{-- Provider --}}
                    <div>
                        <label class="ta-label">Meeting type</label>
                        <select name="provider" x-model="provider" class="ta-input w-full">
                            <option value="google_meet">Google Meet</option>
                            <option value="zoom">Zoom</option>
                        </select>
                    </div>

                    <div>
                        <label class="ta-label">Title</label>
                        <input type="text" name="title" x-model="title" class="ta-input w-full" placeholder="Meeting title" required>
                    </div>

                    <div class="flex gap-2">
                        <div class="flex-1">
                            <label class="ta-label">Starts at</label>
                            <input type="datetime-local" name="starts_at" class="ta-input w-full" required>
                        </div>
                        <div style="max-width:110px;">
                            <label class="ta-label">Minutes</label>
                            <input type="number" name="duration" class="ta-input w-full" value="30" min="15" max="480">
                        </div>
                    </div>

                    <div>
                        <label class="ta-label">Agenda / description (optional)</label>
                        <textarea name="description" rows="2" class="ta-input w-full" placeholder="Shown on the calendar / meeting invite"></textarea>
                    </div>

                    <div class="flex justify-end gap-2 pt-2">
                        <button type="button" @click="open=false" class="btn btn-light">Cancel</button>
                        <button type="submit" class="btn btn-primary" :disabled="mode==='existing' && !selected" :class="{ 'opacity-50 cursor-not-allowed': mode==='existing' && !selected }">
                            <i class="fa-solid fa-calendar-plus"></i> Create Meeting
                        </button>
                    </div>
                </form>
            </div>
        </div>
    @endunless

    @foreach ($sections as [$title, $subtitle, $meetings, $subjectLabel])
        <x-card padding="p-0">
            <div class="border-b border-line px-6 py-4 dark:border-strokedark flex items-center justify-between">
                <div>
                    <h3 class="text-lg font-semibold text-ink dark:text-white">{{ $title }}</h3>
                    <p class="text-sm text-muted">{{ $subtitle }}</p>
                </div>
                <span class="rounded-full bg-gray-100 px-3 py-1 text-xs font-medium text-muted dark:bg-meta-4">{{ $meetings->total() }}</span>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="border-b border-line dark:border-strokedark">
                        <tr>
                            <th class="ta-th">When</th>
                            <th class="ta-th">{{ $subjectLabel }}</th>
                            <th class="ta-th">Title</th>
                            <th class="ta-th">Provider</th>
                            <th class="ta-th">Status</th>
                            <th class="ta-th">Link</th>
                            <th class="ta-th text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-line dark:divide-strokedark">
                        @forelse ($meetings as $m)
                            <tr>
                                <td class="ta-td whitespace-nowrap">{{ $m->starts_at?->format('M j, Y g:i A') ?? 'TBD' }}</td>
                                <td class="ta-td">
                                    @if ($m->subjectUrl())
                                        <a href="{{ $m->subjectUrl() }}" class="font-medium text-brand">{{ $m->subjectName() }}</a>
                                    @else
                                        <span class="text-muted">{{ $m->attendee_name ?: '—' }}</span>
                                    @endif
                                </td>
                                <td class="ta-td">{{ $m->meeting_title }}</td>
                                <td class="ta-td">
                                    <x-badge :label="ucfirst(str_replace('_',' ',$m->provider))"
                                             :color="match($m->provider) { 'calendly' => '#006BFF', 'zoom' => '#2D8CFF', default => '#00897B' }" />
                                </td>
                                <td class="ta-td">
                                    <x-badge :label="ucfirst($m->status)"
                                             :color="$m->status === 'canceled' ? '#F04438' : ($m->status === 'completed' ? '#12B76A' : '#2E90FA')" />
                                </td>
                                <td class="ta-td">
                                    @if ($m->meeting_url)
                                        <a href="{{ $m->meeting_url }}" target="_blank" rel="noopener" class="text-brand"><i class="fa-solid fa-video"></i> Join</a>
                                    @else
                                        <span class="text-muted">—</span>
                                    @endif
                                </td>
                                <td class="ta-td text-right">
                                    @unless (auth()->user()->role->isReadOnly())
                                        <form method="POST" action="{{ route('meetings.destroy', $m) }}" class="inline"
                                              onsubmit="return confirm('Delete this meeting?{{ $m->meetable instanceof \App\Models\Lead ? ' The lead status will revert to its previous stage.' : '' }}');">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="text-danger hover:underline" title="Delete meeting"><i class="fa-solid fa-trash"></i></button>
                                        </form>
                                    @else
                                        <span class="text-muted">—</span>
                                    @endunless
                                </td>
                            </tr>
                        @empty
                            <tr><td colspan="7" class="ta-td py-8 text-center text-muted">No {{ strtolower($title) }} yet.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            @if ($meetings->hasPages())
                <div class="border-t border-line px-6 py-4 dark:border-strokedark">{{ $meetings->links() }}</div>
            @endif
        </x-card>
    @endforeach
</div>
@endsection

@push('scripts')
<script>
function meetingScheduler() {
    return {
        open: false,
        mode: 'existing',
        q: '',
        results: [],
        searched: false,
        selected: null,
        provider: 'google_meet',
        title: '',
        newFirstName: '',
        openModal() {
            this.open = true;
            this.mode = 'existing';
            this.q = ''; this.results = []; this.searched = false; this.selected = null;
            this.provider = 'google_meet'; this.title = ''; this.newFirstName = '';
        },
        async runSearch() {
            if (this.q.length < 2) { this.results = []; this.searched = false; return; }
            try {
                const res = await fetch(`{{ route('meetings.search') }}?q=` + encodeURIComponent(this.q), {
                    headers: { 'Accept': 'application/json' },
                });
                this.results = await res.json();
                this.searched = true;
            } catch (e) { this.results = []; }
        },
        pick(item) {
            this.selected = item;
            this.results = [];
            if (!this.title) this.title = 'Call with ' + item.name;
        },
        onSubmit(e) {
            // Existing mode requires a picked contact.
            if (this.mode === 'existing' && !this.selected) {
                e.preventDefault();
                return;
            }
            // Populate the hidden subject fields explicitly at submit time.
            const form = e.target;
            form.querySelector('[name=subject_type]').value = this.mode === 'new' ? 'new' : this.selected.type;
            form.querySelector('[name=subject_id]').value = this.mode === 'new' ? '' : this.selected.id;
        },
        clearSelection() {
            this.selected = null; this.q = ''; this.results = []; this.searched = false;
        },
    };
}
</script>
@endpush
