@extends('layouts.app')
@section('title', 'Sponsor Lead Form')
@section('breadcrumb')
    <a href="{{ route('integrations.index') }}" class="hover:text-brand">Integrations</a> / <span>Sponsor Lead Form</span>
@endsection

@section('content')
<div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
    <form method="POST" action="{{ route('integrations.sponsor-lead-form.save') }}" class="lg:col-span-2">
        @csrf
        <x-card class="h-full" title="Sponsor Lead Form Settings" subtitle="Configure the webhook integration for your Google Form that collects sponsor and vendor leads">
            <div class="space-y-4">
                <div class="flex items-center justify-between rounded-xl border border-line p-3 dark:border-strokedark">
                    <span class="text-sm font-medium text-ink dark:text-gray-200">Integration active</span>
                    <input type="checkbox" name="enabled" value="1" @checked($setting->enabled)
                           class="h-5 w-9 rounded-full text-brand focus:ring-brand">
                </div>

                <div class="pt-2">
                    <h4 class="text-sm font-medium text-ink dark:text-gray-200 mb-2">Instructions</h4>
                    <p class="text-xs text-muted leading-relaxed">
                        1. Open your Google Form → <strong>Responses</strong> → <strong>Link to Sheets</strong> to connect a response spreadsheet.<br>
                        2. In the Google Sheet, open <strong>Extensions</strong> → <strong>Apps Script</strong> and paste the script below.<br>
                        3. In the Apps Script editor go to <strong>Triggers</strong> (clock icon) → <strong>Add Trigger</strong> → function <code>onFormSubmit</code> → event source <strong>From spreadsheet</strong> → event type <strong>On form submit</strong>.<br>
                        4. Save and authorize the script.<br>
                        5. Each form submission creates a new Sponsor/Vendor profile with status <strong>Prospect</strong>. Duplicates (same email or company name) merge into the existing profile.
                    </p>
                </div>

                <div class="flex justify-end gap-2 pt-2">
                    <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save Settings</button>
                </div>
            </div>
        </x-card>
    </form>

    <div class="space-y-6">
        <x-card title="Webhook Endpoint" subtitle="Configure in your Apps Script">
            <div>
                <label class="ta-label">Webhook URL</label>
                <div class="flex gap-2">
                    <input type="text" readonly value="{{ $webhookUrl }}" id="sl-webhook-url" class="ta-input flex-1 font-mono text-xs">
                    <button type="button" class="btn btn-light" onclick="navigator.clipboard.writeText(document.getElementById('sl-webhook-url').value); this.innerHTML='<i class=\'fa-solid fa-check\'></i>'; setTimeout(()=>this.innerHTML='<i class=\'fa-regular fa-copy\'></i>',1500)"><i class="fa-regular fa-copy"></i></button>
                </div>
            </div>

            <div class="mt-4">
                <label class="ta-label">Secret Key</label>
                <div class="flex gap-2">
                    <input type="password" readonly value="{{ $setting->secret_key }}" id="sl-secret-key" class="ta-input flex-1 font-mono text-xs">
                    <button type="button" class="btn btn-light" onclick="var f=document.getElementById('sl-secret-key'); f.type=f.type==='password'?'text':'password'; this.querySelector('i').className=f.type==='password'?'fa-solid fa-eye':'fa-solid fa-eye-slash'"><i class="fa-solid fa-eye"></i></button>
                    <button type="button" class="btn btn-light" onclick="navigator.clipboard.writeText(document.getElementById('sl-secret-key').value); this.innerHTML='<i class=\'fa-solid fa-check\'></i>'; setTimeout(()=>this.innerHTML='<i class=\'fa-regular fa-copy\'></i>',1500)"><i class="fa-regular fa-copy"></i></button>
                </div>
            </div>

            <div class="flex gap-2 mt-4">
                <form method="POST" action="{{ route('integrations.sponsor-lead-form.regenerate') }}" class="flex-1"
                      onsubmit="return confirm('Regenerate the secret? You will need to update your Google Apps Script.')">
                    @csrf
                    <button type="submit" class="btn btn-light w-full text-danger hover:bg-danger/10"><i class="fa-solid fa-rotate"></i> Regenerate Secret</button>
                </form>
            </div>
        </x-card>

        <x-card title="Test Connection">
            <form method="POST" action="{{ route('integrations.sponsor-lead-form.test') }}">
                @csrf
                <button type="submit" class="btn btn-light w-full"><i class="fa-solid fa-plug-circle-check"></i> Test Webhook Secret</button>
            </form>
        </x-card>
    </div>
</div>

{{-- Apps Script snippet --}}
<div class="mt-6">
    <x-card title="Google Apps Script" subtitle="Paste into your response Google Sheet: Extensions → Apps Script">
        <div class="relative min-w-0 overflow-hidden rounded-xl">
            <pre class="max-h-96 overflow-auto bg-gray-900 p-4 pr-28 text-xs text-gray-100" id="sponsor-apps-script-code"><code>

var WEBHOOK_URL    = '{{ $webhookUrl }}';
var WEBHOOK_SECRET = '{{ $setting->secret_key }}';

function onFormSubmit(e) {
  var v = e.namedValues || {};

  var payload = {
    company_name:      pick(v, '1. What is the official name of the Company/Brand?'),
    company_type:      pick(v, '2. Select the primary classification of this entity:'),
    industry:          pick(v, '3. What industry or sector does the company primarily operate in?'),
    website:           pick(v, "4. Provide the company's official website URL."),
    contact_name:      pick(v, '5. Primary Contact Person Name (within the company):'),
    email:             pick(v, '6. Primary Contact Email Address:'),
    phone:             pick(v, '7. Primary Contact Phone Number:'),
    partnership_scope: pick(v, '8. What is the scope of the partnership or vendor relationship?'),
    agreement_terms:   pick(v, "9. Please describe the specific terms of the agreement or provided services. (e.g., '3-year title sponsorship', 'Supply of racing tires', 'Logistics for European circuit'):"),
    country:           pick(v, 'Country'),
    city:              pick(v, 'City'),
    estimated_budget:  pick(v, 'Estimate Budget'),
  };

  var options = {
    method: 'post',
    contentType: 'application/json',
    headers: { 'X-Webhook-Secret': WEBHOOK_SECRET },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true,
  };

  var response = UrlFetchApp.fetch(WEBHOOK_URL, options);
  Logger.log('CRM Response (' + response.getResponseCode() + '): ' + response.getContentText());
}

/**
 * Reads an answer by question title. Falls back to a "starts with" match
 * (e.g. '1.') so minor edits to question wording don't break the mapping.
 */
function pick(values, title) {
  if (values[title] && values[title][0]) {
    return String(values[title][0]).trim();
  }
  var prefix = title.split(' ')[0]; // e.g. "1."
  var keys = Object.keys(values);
  for (var i = 0; i &lt; keys.length; i++) {
    if (keys[i].indexOf(prefix) === 0 && values[keys[i]][0]) {
      return String(values[keys[i]][0]).trim();
    }
  }
  return '';
}</code></pre>
            <button type="button" onclick="navigator.clipboard.writeText(document.getElementById('sponsor-apps-script-code').querySelector('code').textContent); this.innerHTML='Copied!'; setTimeout(()=>this.innerHTML='<i class=\'fa-solid fa-copy\'></i> Copy Script',1500)" class="btn btn-primary absolute right-3 top-3 text-xs">
                <i class="fa-solid fa-copy"></i> Copy Script
            </button>
        </div>
        <p class="mt-3 text-xs text-muted leading-relaxed">
            <i class="fa-solid fa-circle-info mr-1"></i>
            Answers are matched by question title (with a fallback on the question's first word, like "1." or "Country"), so column order in the sheet doesn't matter.
            Leave Estimate Budget blank on the form and it stays empty on the profile. Only State isn't collected — fill it in later from the CRM.
        </p>
    </x-card>
</div>

{{-- Field mapping reference --}}
<div class="mt-6">
    <x-card title="Form Question → CRM Field Mapping" padding="p-0">
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="border-b border-line dark:border-strokedark">
                    <tr>
                        <th class="ta-th">Google Form Question</th>
                        <th class="ta-th">CRM Field</th>
                        <th class="ta-th">Notes</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-line dark:divide-strokedark">
                    @foreach ([
                        ['1. Official name of the Company/Brand', 'company_name', 'Required. Also used for duplicate detection.'],
                        ['2. Primary classification of this entity', 'company_type', 'Mapped to: Sponsor / Vendor / Track Partner / Racing Asset Provider / Media Partner (defaults to Sponsor)'],
                        ['3. Industry or sector', 'industry', ''],
                        ['4. Official website URL', 'website', ''],
                        ['5. Primary Contact Person Name', 'contact_name', ''],
                        ['6. Primary Contact Email Address', 'email', 'Used for duplicate detection (merge)'],
                        ['7. Primary Contact Phone Number', 'phone', ''],
                        ['8. Scope of the partnership or vendor relationship', 'notes', 'Stored as "Partnership scope: …"'],
                        ['9. Specific terms of the agreement or services', 'notes', 'Stored as "Agreement terms: …"'],
                        ['Country', 'country', ''],
                        ['City', 'city', ''],
                        ['Estimate Budget', 'estimated_budget', 'Currency symbols and commas are stripped automatically; blank stays empty'],
                        ['—', 'status', 'Always set to Prospect'],
                        ['—', 'state', 'Left blank; fill in from the CRM later'],
                    ] as [$q, $field, $note])
                        <tr>
                            <td class="ta-td text-muted">{{ $q }}</td>
                            <td class="ta-td font-mono text-xs">{{ $field }}</td>
                            <td class="ta-td text-muted text-xs">{{ $note }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </x-card>
</div>
@endsection
