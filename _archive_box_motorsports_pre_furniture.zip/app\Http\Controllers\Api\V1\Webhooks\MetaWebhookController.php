<?php

namespace App\Http\Controllers\Api\V1\Webhooks;

use App\Http\Controllers\Controller;
use App\Models\IntegrationSetting;
use App\Services\Integrations\Meta\MetaLeadService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class MetaWebhookController extends Controller
{
    public function __construct(private MetaLeadService $service) {}

    /** GET /webhooks/meta — Meta webhook verification handshake. */
    public function verify(Request $request): mixed
    {
        $config = IntegrationSetting::where('channel', 'meta')->value('config') ?? [];
        $expected = $config['webhook_verify_token'] ?? config('services.meta.verify_token');

        if ($request->query('hub_mode') === 'subscribe'
            && $request->query('hub_verify_token') === $expected
            && $expected) {
            return response($request->query('hub_challenge'), 200);
        }

        return response('Forbidden', 403);
    }

    /** POST /webhooks/meta — leadgen change notifications. */
    public function receive(Request $request): JsonResponse
    {
        $data = $request->all();

        foreach (($data['entry'] ?? []) as $entry) {
            foreach (($entry['changes'] ?? []) as $change) {
                if (($change['field'] ?? null) !== 'leadgen') {
                    continue;
                }
                $leadgenId = $change['value']['leadgen_id'] ?? null;
                if ($leadgenId) {
                    rescue(fn () => $this->service->handleLeadgen((string) $leadgenId, $request->ip()), report: true);
                }
            }
        }

        // Meta requires a fast 200 acknowledgement.
        return response()->json(['received' => true]);
    }
}
