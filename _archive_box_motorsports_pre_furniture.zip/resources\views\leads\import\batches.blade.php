@extends('layouts.app')
@section('title', 'Import History')

@section('header_actions')
    <a href="{{ route('leads.import.index') }}" class="btn btn-primary">
        <i class="fa-solid fa-file-arrow-up"></i> New import
    </a>
@endsection

@section('content')
<x-card padding="p-0">
    <div class="overflow-x-auto">
        <table class="w-full">
            <thead class="border-b border-line dark:border-strokedark">
                <tr>
                    <th class="ta-th">File</th>
                    <th class="ta-th">Type</th>
                    <th class="ta-th">Rows</th>
                    <th class="ta-th">Imported</th>
                    <th class="ta-th">Dupes</th>
                    <th class="ta-th">Failed</th>
                    <th class="ta-th">Status</th>
                    <th class="ta-th">By</th>
                    <th class="ta-th">When</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-line dark:divide-strokedark">
                @forelse ($batches as $b)
                    <tr class="cursor-pointer transition hover:bg-surface dark:hover:bg-boxdark"
                        onclick="window.location='{{ route('leads.import.batches.show', $b) }}'">
                        <td class="ta-td font-medium">{{ \Illuminate\Support\Str::limit($b->file_name, 32) }}</td>
                        <td class="ta-td">{{ strtoupper($b->file_type) }}</td>
                        <td class="ta-td">{{ number_format($b->total_rows) }}</td>
                        <td class="ta-td text-success">{{ number_format($b->successful_rows) }}</td>
                        <td class="ta-td text-purple">{{ number_format($b->duplicate_rows) }}</td>
                        <td class="ta-td text-danger">{{ number_format($b->failed_rows) }}</td>
                        <td class="ta-td">@include('leads.import._status', ['status' => $b->status])</td>
                        <td class="ta-td text-muted">{{ $b->user?->name ?? 'System' }}</td>
                        <td class="ta-td text-muted">{{ $b->created_at->diffForHumans() }}</td>
                    </tr>
                @empty
                    <tr><td colspan="9" class="ta-td text-center text-muted py-8">No imports yet.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="border-t border-line px-6 py-4 dark:border-strokedark">
        {{ $batches->links() }}
    </div>
</x-card>
@endsection
