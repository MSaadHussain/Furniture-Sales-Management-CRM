@extends('layouts.app')
@section('title', 'Driver Leads — Trash')
@section('breadcrumb')
    <a href="{{ route('driver-leads.index') }}" class="hover:text-brand">Driver Leads</a> / <span>Trash</span>
@endsection

@section('header_actions')
    <a href="{{ route('driver-leads.index') }}" class="btn btn-light"><i class="fa-solid fa-arrow-left"></i> Back to Driver Leads</a>
@endsection

@section('content')
<x-card padding="p-0">
    <div class="flex items-center justify-between border-b border-line px-6 py-4 dark:border-strokedark">
        <div>
            <h3 class="text-lg font-semibold text-ink dark:text-white">Deleted Driver Leads</h3>
            <p class="text-sm text-muted">Restore a driver lead, or permanently remove it.</p>
        </div>
        <form method="GET" class="hidden sm:block">
            <input type="search" name="search" value="{{ request('search') }}" placeholder="Search trash…" class="ta-input !py-2 text-sm">
        </form>
    </div>

    <div class="overflow-x-auto">
        <table class="w-full">
            <thead class="border-b border-line dark:border-strokedark">
                <tr>
                    <th class="ta-th">Driver</th>
                    <th class="ta-th">Email</th>
                    <th class="ta-th">Tier</th>
                    <th class="ta-th">Deleted</th>
                    <th class="ta-th text-right">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-line dark:divide-strokedark">
                @forelse ($leads as $lead)
                    <tr>
                        <td class="ta-td">
                            <div class="flex items-center gap-3">
                                <span class="flex h-9 w-9 items-center justify-center rounded-full bg-brand text-xs font-bold text-white">
                                    {{ strtoupper(substr($lead->first_name, 0, 1) . substr($lead->last_name, 0, 1)) }}
                                </span>
                                <span class="font-medium text-ink dark:text-gray-200">{{ $lead->full_name }}</span>
                            </div>
                        </td>
                        <td class="ta-td text-muted">{{ $lead->email ?: '—' }}</td>
                        <td class="ta-td"><x-badge :label="$lead->inferred_tier->label()" :color="$lead->inferred_tier->color()" /></td>
                        <td class="ta-td text-muted">{{ $lead->deleted_at?->diffForHumans() }}</td>
                        <td class="ta-td">
                            <div class="flex items-center justify-end gap-2">
                                <form method="POST" action="{{ route('driver-leads.restore', $lead->id) }}">
                                    @csrf @method('PATCH')
                                    <button class="btn btn-light !px-3 !py-1.5 text-xs"><i class="fa-solid fa-rotate-left"></i> Restore</button>
                                </form>
                                <form method="POST" action="{{ route('driver-leads.force', $lead->id) }}"
                                      onsubmit="return confirm('Permanently delete this driver lead? This cannot be undone.');">
                                    @csrf @method('DELETE')
                                    <button class="btn btn-danger !px-3 !py-1.5 text-xs"><i class="fa-solid fa-trash"></i> Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="5" class="ta-td py-12 text-center text-muted">
                        <i class="fa-solid fa-trash-can mb-2 block text-2xl"></i>
                        Trash is empty.
                    </td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="border-t border-line px-6 py-4 dark:border-strokedark">{{ $leads->links() }}</div>
</x-card>
@endsection
