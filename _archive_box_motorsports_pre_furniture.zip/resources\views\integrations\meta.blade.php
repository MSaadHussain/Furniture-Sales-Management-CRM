@extends('layouts.app')
@section('title', 'Meta Lead Ads')
@section('breadcrumb')
    <a href="{{ route('integrations.index') }}" class="hover:text-brand">Integrations</a> / <span>Meta Lead Ads</span>
@endsection

@section('content')
<div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
    <form method="POST" action="{{ route('integrations.meta.save') }}" class="lg:col-span-2">
        @csrf
        <x-card class="h-full" title="Meta Lead Ads" subtitle="Connect Facebook/Instagram Lead Ads">
            <div class="space-y-4">
                <div class="flex items-center justify-between rounded-xl border border-line p-3 dark:border-strokedark">
                    <span class="text-sm font-medium text-ink dark:text-gray-200">Integration active</span>
                    <input type="checkbox" name="enabled" value="1" @checked($setting->enabled)
                           class="h-5 w-9 rounded-full text-brand focus:ring-brand">
                </div>

                @foreach ([
                    'app_id' => 'App ID', 'app_secret' => 'App Secret', 'page_id' => 'Page ID',
                    'access_token' => 'Access Token', 'webhook_verify_token' => 'Webhook Verify Token',
                    'lead_form_id' => 'Lead Form ID',
                ] as $field => $label)
                    <div>
                        <label class="ta-label">{{ $label }}</label>
                        <input type="{{ str_contains($field, 'secret') || str_contains($field, 'token') ? 'password' : 'text' }}"
                               name="{{ $field }}" class="ta-input"
                               value="{{ $config[$field] ?? '' }}" autocomplete="off">
                    </div>
                @endforeach

                <div class="flex justify-end gap-2 pt-2">
                    <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save</button>
                </div>
            </div>
        </x-card>
    </form>

    <div class="space-y-6">
        <x-card title="Webhook URL" subtitle="Add this in your Meta App">
            <code class="block break-all rounded-lg bg-surface p-3 text-xs dark:bg-boxdark">{{ $webhookUrl }}</code>
            <p class="mt-3 text-xs text-muted">Subscribe to the <strong>leadgen</strong> field. Use the Verify Token above for the handshake.</p>
        </x-card>
        <x-card title="Test connection">
            <form method="POST" action="{{ route('integrations.meta.test') }}">
                @csrf
                <button type="submit" class="btn btn-light w-full"><i class="fa-solid fa-plug-circle-check"></i> Test connection</button>
            </form>
        </x-card>
    </div>
</div>
@endsection
