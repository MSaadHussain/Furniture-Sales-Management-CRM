<?php

namespace App\Enums;

enum SponsorshipStage: string
{
    case LeadIdentified = 'lead_identified';
    case ProposalSent = 'proposal_sent';
    case Negotiation = 'negotiation';
    case ContractPending = 'contract_pending';
    case ClosedWon = 'closed_won';
    case ClosedLost = 'closed_lost';

    public function label(): string
    {
        return match ($this) {
            self::LeadIdentified  => 'Lead Identified',
            self::ProposalSent    => 'Proposal Sent',
            self::Negotiation     => 'Negotiation',
            self::ContractPending => 'Contract Pending',
            self::ClosedWon       => 'Closed Won',
            self::ClosedLost      => 'Closed Lost',
        };
    }

    public function color(): string
    {
        return match ($this) {
            self::LeadIdentified  => '#7C3AED',
            self::ProposalSent    => '#2563EB',
            self::Negotiation     => '#F59E0B',
            self::ContractPending => '#0EA5E9',
            self::ClosedWon       => '#16A34A',
            self::ClosedLost      => '#DC2626',
        };
    }

    public function isClosed(): bool
    {
        return in_array($this, [self::ClosedWon, self::ClosedLost], true);
    }

    public static function pipelineOrder(): array
    {
        return [
            self::LeadIdentified, self::ProposalSent, self::Negotiation,
            self::ContractPending, self::ClosedWon, self::ClosedLost,
        ];
    }

    public static function options(): array
    {
        return array_map(
            fn (self $s) => ['value' => $s->value, 'label' => $s->label(), 'color' => $s->color()],
            self::cases()
        );
    }
}
