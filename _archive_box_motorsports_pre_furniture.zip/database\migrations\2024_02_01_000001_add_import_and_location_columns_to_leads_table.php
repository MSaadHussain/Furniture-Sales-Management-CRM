<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Additive, production-safe columns on the existing `leads` table.
 * Every column is guarded with hasColumn so the migration is idempotent and
 * never collides with existing data. No columns are dropped or renamed.
 *
 * Covers Phase 2 (import linkage) + Phase 3 (location) + later phases
 * (external id / notification timestamp) in a single safe pass.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('leads', function (Blueprint $table) {
            if (! Schema::hasColumn('leads', 'country')) {
                $table->string('country')->nullable()->after('loc_state');
            }
            if (! Schema::hasColumn('leads', 'country_code')) {
                $table->string('country_code', 2)->nullable()->after('country')->index();
            }
            if (! Schema::hasColumn('leads', 'city')) {
                $table->string('city')->nullable()->after('country_code');
            }
            if (! Schema::hasColumn('leads', 'latitude')) {
                $table->decimal('latitude', 10, 7)->nullable()->after('city');
            }
            if (! Schema::hasColumn('leads', 'longitude')) {
                $table->decimal('longitude', 10, 7)->nullable()->after('latitude');
            }
            if (! Schema::hasColumn('leads', 'company')) {
                $table->string('company')->nullable()->after('longitude');
            }
            if (! Schema::hasColumn('leads', 'source_external_id')) {
                $table->string('source_external_id')->nullable()->after('source_channel')->index();
            }
            if (! Schema::hasColumn('leads', 'imported_batch_id')) {
                // Nullable, no FK constraint to keep it decoupled from the import tables
                // (a lead can outlive its batch record). Indexed for batch lookups.
                $table->unsignedBigInteger('imported_batch_id')->nullable()->after('source_external_id')->index();
            }
            if (! Schema::hasColumn('leads', 'last_notified_at')) {
                $table->timestamp('last_notified_at')->nullable()->after('last_activity_at');
            }
        });
    }

    public function down(): void
    {
        Schema::table('leads', function (Blueprint $table) {
            foreach ([
                'country', 'country_code', 'city', 'latitude', 'longitude',
                'company', 'source_external_id', 'imported_batch_id', 'last_notified_at',
            ] as $col) {
                if (Schema::hasColumn('leads', $col)) {
                    $table->dropColumn($col);
                }
            }
        });
    }
};
