<?php

namespace App\Services;

use App\Models\Lead;
use App\Models\LeadInteraction;
use Illuminate\Support\Facades\Auth;

class LeadInteractionService
{
    public function record(
        Lead $lead,
        string $actionType,
        ?string $description = null,
        ?string $oldValue = null,
        ?string $newValue = null,
        ?string $sourceChannel = null,
        array $metadata = [],
        ?int $performedBy = null,
    ): LeadInteraction {
        $interaction = $lead->interactions()->create([
            'action_type'    => $actionType,
            'description'    => $description,
            'old_value'      => $oldValue,
            'new_value'      => $newValue,
            'source_channel' => $sourceChannel,
            'metadata'       => $metadata ?: null,
            'performed_by'   => $performedBy ?? Auth::id(),
        ]);

        $lead->forceFill(['last_activity_at' => now()])->saveQuietly();

        return $interaction;
    }
}
