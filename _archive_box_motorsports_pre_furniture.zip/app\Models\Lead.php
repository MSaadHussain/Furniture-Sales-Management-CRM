<?php

namespace App\Models;

use App\Enums\LeadPriority;
use App\Enums\LeadStatus;
use App\Enums\MotorsportInterest;
use App\Enums\SourceChannel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Lead extends Model
{
    use HasFactory, SoftDeletes;

    protected $attributes = [
        'status' => 'new',
        'priority' => 'medium',
    ];

    protected $fillable = [
        'first_name', 'last_name', 'full_name', 'email', 'phone',
        'normalized_phone', 'loc_state', 'country', 'country_code', 'city',
        'latitude', 'longitude', 'company', 'ip_address', 'source_channel',
        'source_external_id', 'imported_batch_id', 'status', 'priority',
        'lead_score', 'motorsport_interest_type', 'motorsport_notes', 'message',
        'tags', 'assigned_to', 'created_by', 'last_activity_at', 'last_notified_at',
    ];

    protected function casts(): array
    {
        return [
            'source_channel' => SourceChannel::class,
            'status' => LeadStatus::class,
            'priority' => LeadPriority::class,
            'motorsport_interest_type' => MotorsportInterest::class,
            'tags' => 'array',
            'last_activity_at' => 'datetime',
            'last_notified_at' => 'datetime',
            'latitude' => 'float',
            'longitude' => 'float',
            'lead_score' => 'integer',
            'assigned_to' => 'integer',
            'created_by' => 'integer',
        ];
    }

    public function importBatch()
    {
        return $this->belongsTo(ImportBatch::class, 'imported_batch_id');
    }

    public function meetings()
    {
        return $this->morphMany(LeadMeeting::class, 'meetable')->latest('starts_at');
    }

    public function interactions()
    {
        return $this->hasMany(LeadInteraction::class)->latest();
    }

    public function notes()
    {
        return $this->hasMany(LeadNote::class)->latest();
    }

    public function rawPayloads()
    {
        return $this->hasMany(LeadRawPayload::class)->latest();
    }

    public function assignments()
    {
        return $this->hasMany(LeadAssignment::class)->latest();
    }

    public function assignee()
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function scopeStatus($query, LeadStatus $status)
    {
        return $query->where('status', $status->value);
    }
}