<?php

namespace App\Services;

use Carbon\Carbon;
use Illuminate\Http\Request;

class DateRangeService
{
    public function resolve(Request $request): array
    {
        $preset = $request->string('range', 'last_30')->value();

        return match ($preset) {
            'today'      => [today()->startOfDay(), today()->endOfDay(), 'Today'],
            'yesterday'  => [today()->subDay()->startOfDay(), today()->subDay()->endOfDay(), 'Yesterday'],
            'this_week'  => [now()->startOfWeek(), now()->endOfWeek(), 'This week'],
            'this_month' => [now()->startOfMonth(), now()->endOfMonth(), 'This month'],
            'last_7'     => [today()->subDays(6)->startOfDay(), today()->endOfDay(), 'Last 7 days'],
            'last_30'    => [today()->subDays(29)->startOfDay(), today()->endOfDay(), 'Last 30 days'],
            'custom'     => $this->custom($request),
            default      => [today()->subDays(29)->startOfDay(), today()->endOfDay(), 'Last 30 days'],
        };
    }

    private function custom(Request $request): array
    {
        $from = $request->date('from') ?? today()->subDays(29);
        $to   = $request->date('to') ?? today();

        return [
            Carbon::parse($from)->startOfDay(),
            Carbon::parse($to)->endOfDay(),
            $from->format('M j') . ' - ' . $to->format('M j'),
        ];
    }

    public function presets(): array
    {
        return [
            'today'      => 'Today',
            'yesterday'  => 'Yesterday',
            'this_week'  => 'This week',
            'this_month' => 'This month',
            'last_7'     => 'Last 7 days',
            'last_30'    => 'Last 30 days',
            'custom'     => 'Custom range',
        ];
    }
}
