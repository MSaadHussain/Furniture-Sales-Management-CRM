<?php

namespace App\Models;

use App\Enums\FundingType;
use App\Enums\SponsorLinkStatus;
use Illuminate\Database\Eloquent\Model;

class SponsorDriverLink extends Model
{
    protected $fillable = [
        'sponsor_profile_id', 'driver_lead_id', 'sponsorship_deal_id',
        'funding_amount', 'funding_type', 'season_or_event', 'status',
        'start_date', 'end_date',
    ];

    protected function casts(): array
    {
        return [
            'funding_type'   => FundingType::class,
            'status'         => SponsorLinkStatus::class,
            'funding_amount' => 'decimal:2',
            'start_date'     => 'date',
            'end_date'       => 'date',
        ];
    }

    public function sponsor()
    {
        return $this->belongsTo(SponsorProfile::class, 'sponsor_profile_id');
    }

    public function driverLead()
    {
        return $this->belongsTo(DriverLead::class);
    }

    public function deal()
    {
        return $this->belongsTo(SponsorshipDeal::class, 'sponsorship_deal_id');
    }
}
