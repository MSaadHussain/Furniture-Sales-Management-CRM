<?php

namespace App\Http\Controllers\Api\V1\Webhooks;

use App\Http\Controllers\Controller;
use App\Services\Integrations\Google\GoogleLeadApiClient;
use App\Services\Integrations\Google\GoogleLeadService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class GoogleLeadWebhookController extends Controller
{
    public function __construct(
        private GoogleLeadService $service,
        private GoogleLeadApiClient $api,
    ) {}

    /** POST /webhooks/google-leads */
    public function receive(Request $request): JsonResponse
    {
        // Google Lead Form webhooks include a "google_key" shared secret.
        $expected = $this->api->webhookKey();
        $provided = $request->input('google_key') ?? $request->header('X-Goog-Key');

        if ($expected && ! hash_equals((string) $expected, (string) $provided)) {
            return response()->json(['success' => false, 'message' => 'Invalid key.'], 403);
        }

        try {
            [$lead, $isNew] = $this->service->handle($request->all(), $request->ip());

            return response()->json([
                'success' => true,
                'created' => $isNew,
                'lead_id' => $lead->id,
            ], $isNew ? 201 : 200);
        } catch (\Throwable $e) {
            report($e);
            return response()->json(['success' => false, 'message' => 'Failed to process lead.'], 422);
        }
    }
}
