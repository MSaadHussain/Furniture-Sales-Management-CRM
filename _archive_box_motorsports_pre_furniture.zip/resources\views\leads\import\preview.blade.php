@extends('layouts.app')
@section('title', 'Map & Preview Import')
@section('breadcrumb')
    <a href="{{ route('leads.import.index') }}" class="hover:text-brand">Import</a> /
    <span>{{ $batch->file_name }}</span>
@endsection

@section('content')
<form method="POST" action="{{ route('leads.import.confirm', $batch) }}"
      x-data="{ strategy: 'skip', map: @js(collect($suggestedMap)->map(fn($v)=>$v ?? '')->all()) }">
    @csrf

    {{-- Summary bar --}}
    <x-card class="mb-6">
        <div class="flex flex-wrap items-center justify-between gap-4">
            <div class="flex items-center gap-3">
                <span class="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-50 text-brand">
                    <i class="fa-solid fa-file-lines text-lg"></i>
                </span>
                <div>
                    <p class="font-semibold text-ink dark:text-white">{{ $batch->file_name }}</p>
                    <p class="text-sm text-muted">
                        {{ strtoupper($batch->file_type) }} ·
                        <span class="font-medium text-ink dark:text-gray-200">{{ number_format($total) }}</span> rows ·
                        showing first {{ count($rows) }}
                    </p>
                </div>
            </div>
            @include('leads.import._status', ['status' => $batch->status])
        </div>
    </x-card>

    <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">

        {{-- Column mapping --}}
        <div class="lg:col-span-2 space-y-6">
            <x-card title="Map columns" subtitle="Match each file column to a lead field. Unmapped columns are ignored.">
                <div class="space-y-3">
                    @foreach ($headers as $i => $header)
                        <div class="flex items-center gap-3">
                            <div class="flex-1 truncate rounded-lg border border-line bg-surface px-3 py-2 text-sm
                                        dark:border-strokedark dark:bg-boxdark">
                                <span class="text-muted">Column {{ $i + 1 }}:</span>
                                <span class="font-medium text-ink dark:text-gray-200">{{ $header !== '' ? $header : '(blank)' }}</span>
                            </div>
                            <i class="fa-solid fa-arrow-right text-muted"></i>
                            <select name="column_map[{{ $i }}]" x-model="map[{{ $i }}]" class="ta-input flex-1">
                                <option value="">— Ignore —</option>
                                @foreach ($fields as $field)
                                    <option value="{{ $field }}">{{ \Illuminate\Support\Str::headline($field) }}</option>
                                @endforeach
                            </select>
                        </div>
                    @endforeach
                </div>
            </x-card>

            {{-- Data preview --}}
            <x-card title="Data preview" padding="p-0">
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="border-b border-line dark:border-strokedark">
                            <tr>
                                @foreach ($headers as $i => $header)
                                    <th class="ta-th whitespace-nowrap">
                                        {{ $header !== '' ? $header : 'Col '.($i+1) }}
                                        <span class="block text-[10px] font-normal normal-case text-brand"
                                              x-text="map[{{ $i }}] ? '→ ' + map[{{ $i }}] : ''"></span>
                                    </th>
                                @endforeach
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-line dark:divide-strokedark">
                            @foreach ($rows as $row)
                                <tr>
                                    @foreach ($headers as $i => $header)
                                        <td class="ta-td whitespace-nowrap">{{ \Illuminate\Support\Str::limit($row[$i] ?? '', 40) }}</td>
                                    @endforeach
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </x-card>
        </div>

        {{-- Duplicate strategy + confirm --}}
        <div class="space-y-6">
            <x-card title="Duplicates" subtitle="When a lead matches an existing email or phone">
                <div class="space-y-2">
                    @php
                        $strategies = [
                            'skip'   => ['Skip', 'Leave existing leads untouched; do not import the row.', 'fa-ban', '#667085'],
                            'merge'  => ['Merge', 'Fill only the blank fields on the existing lead.', 'fa-code-merge', '#7A5AF8'],
                            'update' => ['Update', 'Overwrite existing fields with the imported values.', 'fa-pen', '#2E90FA'],
                        ];
                    @endphp
                    @foreach ($strategies as $value => $info)
                        <label :class="strategy === '{{ $value }}' ? 'border-brand ring-1 ring-brand/30' : 'border-line dark:border-strokedark'"
                               class="flex cursor-pointer gap-3 rounded-xl border p-3 transition">
                            <input type="radio" name="duplicate_strategy" value="{{ $value }}"
                                   x-model="strategy" class="mt-1 text-brand focus:ring-brand">
                            <div>
                                <span class="flex items-center gap-2 text-sm font-medium text-ink dark:text-gray-200">
                                    <i class="fa-solid {{ $info[2] }}" style="color: {{ $info[3] }}"></i> {{ $info[0] }}
                                </span>
                                <span class="text-xs text-muted">{{ $info[1] }}</span>
                            </div>
                        </label>
                    @endforeach
                </div>
            </x-card>

            <x-card>
                <p class="mb-4 text-sm text-muted">
                    Source will be set to
                    <span class="font-medium text-ink dark:text-gray-200">{{ $batch->source_channel->label() }}</span>.
                    New leads trigger instant notifications and run through duplicate detection.
                </p>
                <div class="flex flex-col gap-2">
                    <button type="submit" class="btn btn-primary w-full">
                        <i class="fa-solid fa-check"></i> Confirm &amp; Import {{ number_format($total) }} rows
                    </button>
                    <a href="{{ route('leads.import.index') }}" class="btn btn-light w-full">Start over</a>
                </div>
            </x-card>
        </div>
    </div>
</form>
@endsection
