@extends('layouts.app')
@section('title', 'Sponsor & Vendor Report')
@section('breadcrumb')
    <a href="{{ route('reports.index') }}" class="hover:text-brand">Reports</a> / <span>Sponsors & Vendors</span>
@endsection

@section('header_actions')
    <a href="{{ route('sponsorship-pipeline.index') }}" class="btn btn-light"><i class="fa-solid fa-table-columns"></i> Pipeline Board</a>
    <a href="{{ route('reports.sponsors.export', $filters) }}" class="btn btn-primary"><i class="fa-solid fa-download"></i> Export CSV</a>
@endsection

@section('content')
{{-- Date filter --}}
<form method="GET" class="mb-6 flex flex-wrap items-center gap-2">
    <select name="range" onchange="this.form.submit()" class="ta-input !w-auto !py-2 text-sm">
        @foreach ($presets as $value => $label)
            <option value="{{ $value }}" @selected($currentRange === $value)>{{ $label }}</option>
        @endforeach
    </select>
    <span class="text-sm text-muted">{{ $rangeLabel }} — period KPIs only; pipeline &amp; funding cards show live totals</span>
</form>

{{-- In-range KPIs --}}
<div class="grid grid-cols-2 gap-4 xl:grid-cols-4">
    <x-stat-card label="New Sponsors" :value="number_format($kpis['newSponsors'])" :hint="$rangeLabel" icon="fa-building-circle-arrow-right" iconColor="#465FFF" />
    <x-stat-card label="New Deals" :value="number_format($kpis['newDeals'])" :hint="$rangeLabel" icon="fa-handshake" iconColor="#7C3AED" />
    <x-stat-card label="Closed Won Value" :value="'$' . number_format($kpis['wonInRange'], 0)" :hint="$rangeLabel" icon="fa-trophy" iconColor="#12B76A" />
    <x-stat-card label="Deals Lost" :value="number_format($kpis['lostInRange'])" :hint="$rangeLabel" icon="fa-circle-xmark" iconColor="#F04438" />
</div>

{{-- Live commercial KPIs --}}
<div class="mt-4 grid grid-cols-2 gap-4 xl:grid-cols-4">
    <x-stat-card label="Open Pipeline" :value="'$' . number_format($kpis['openPipeline'], 0)" hint="all open deals" icon="fa-sack-dollar" iconColor="#465FFF" />
    <x-stat-card label="Weighted Pipeline" :value="'$' . number_format($kpis['weighted'], 0)" hint="value × probability" icon="fa-scale-balanced" iconColor="#0EA5E9" />
    <x-stat-card label="Contract Pending" :value="'$' . number_format($kpis['contractPending'], 0)" hint="awaiting signature" icon="fa-file-signature" iconColor="#F79009" />
    <x-stat-card label="Driver Funding" :value="'$' . number_format($kpis['fundingCommitted'], 0)" :hint="$kpis['driversFunded'] . ' drivers actively funded'" icon="fa-helmet-safety" iconColor="#12B76A" />
</div>

{{-- Pipeline funnel --}}
<x-card class="mt-6" title="Live Pipeline by Stage" subtitle="Deal count and total value per stage — bars scaled to the largest stage">
    <div class="space-y-4">
        @foreach ($stageReport as $stage)
            <div>
                <div class="mb-1 flex items-center justify-between text-sm">
                    <span class="flex items-center gap-2 font-medium text-ink dark:text-gray-200">
                        <span class="h-2.5 w-2.5 rounded-full" style="background:{{ $stage['color'] }}"></span>
                        {{ $stage['label'] }}
                        <span class="rounded-full bg-surface px-2 py-0.5 text-xs text-muted dark:bg-boxdark">{{ $stage['count'] }} {{ Str::plural('deal', $stage['count']) }}</span>
                    </span>
                    <span class="font-bold text-ink dark:text-white">${{ number_format($stage['value'], 0) }}</span>
                </div>
                <div class="h-3 overflow-hidden rounded-full bg-gray-100 dark:bg-gray-700">
                    <div class="h-full rounded-full transition-all" style="background:{{ $stage['color'] }}; width:{{ max($stage['percent'], $stage['value'] > 0 ? 3 : 0) }}%"></div>
                </div>
            </div>
        @endforeach
    </div>
</x-card>

<div class="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-3">
    {{-- By type --}}
    <x-card title="Sponsors by Type" padding="p-0">
        <div class="divide-y divide-line dark:divide-strokedark">
            @foreach ($typeReport as $row)
                <div class="px-6 py-3">
                    <div class="mb-1 flex items-center justify-between text-sm">
                        <span class="flex items-center gap-2 text-ink dark:text-gray-200">
                            <span class="h-2.5 w-2.5 rounded-full" style="background:{{ $row['color'] }}"></span>{{ $row['label'] }}
                        </span>
                        <span class="font-semibold text-ink dark:text-gray-200">{{ $row['value'] }}</span>
                    </div>
                    <div class="h-1.5 overflow-hidden rounded-full bg-gray-100 dark:bg-gray-700">
                        <div class="h-full rounded-full" style="background:{{ $row['color'] }}; width:{{ $row['percent'] }}%"></div>
                    </div>
                </div>
            @endforeach
        </div>
    </x-card>

    {{-- By status --}}
    <x-card title="Sponsors by Status" padding="p-0">
        <div class="divide-y divide-line dark:divide-strokedark">
            @foreach ($statusReport as $row)
                <div class="flex items-center justify-between px-6 py-4">
                    <span class="flex items-center gap-2 text-sm text-ink dark:text-gray-200">
                        <span class="h-2.5 w-2.5 rounded-full" style="background:{{ $row['color'] }}"></span>{{ $row['label'] }}
                    </span>
                    <span class="text-lg font-bold text-ink dark:text-white">{{ $row['value'] }}</span>
                </div>
            @endforeach
            <div class="flex items-center justify-between bg-surface px-6 py-4 dark:bg-boxdark/40">
                <span class="text-sm font-semibold text-ink dark:text-gray-200">Active right now</span>
                <span class="text-lg font-bold text-success">{{ $kpis['activeSponsors'] }}</span>
            </div>
        </div>
    </x-card>

    {{-- Funding by type --}}
    <x-card title="Driver Funding by Type" padding="p-0">
        <div class="divide-y divide-line dark:divide-strokedark">
            @forelse ($fundingReport as $row)
                <div class="flex items-center justify-between px-6 py-3">
                    <span class="flex items-center gap-2 text-sm text-ink dark:text-gray-200">
                        <span class="h-2.5 w-2.5 rounded-full" style="background:{{ $row['color'] }}"></span>
                        {{ $row['label'] }}
                        <span class="text-xs text-muted">× {{ $row['count'] }}</span>
                    </span>
                    <span class="text-sm font-bold text-ink dark:text-white">${{ number_format($row['amount'], 0) }}</span>
                </div>
            @empty
                <p class="px-6 py-6 text-center text-sm text-muted">No driver funding links yet.</p>
            @endforelse
        </div>
    </x-card>
</div>

{{-- Top sponsors --}}
<x-card class="mt-6" title="Top Sponsors by Open Pipeline" padding="p-0">
    <div class="overflow-x-auto">
        <table class="w-full">
            <thead class="border-b border-line dark:border-strokedark">
                <tr>
                    <th class="ta-th">#</th>
                    <th class="ta-th">Company</th>
                    <th class="ta-th">Type</th>
                    <th class="ta-th">Status</th>
                    <th class="ta-th">Deals</th>
                    <th class="ta-th">Open Pipeline</th>
                    <th class="ta-th">Closed Won</th>
                    <th class="ta-th"></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-line dark:divide-strokedark">
                @forelse ($topSponsors as $i => $sponsor)
                    <tr>
                        <td class="ta-td text-muted">{{ $i + 1 }}</td>
                        <td class="ta-td">
                            <span class="font-medium text-ink dark:text-gray-200">{{ $sponsor->company_name }}</span>
                            @if ($sponsor->industry)<span class="block text-xs text-muted">{{ $sponsor->industry }}</span>@endif
                        </td>
                        <td class="ta-td"><x-badge :label="$sponsor->company_type->label()" :color="$sponsor->company_type->color()" /></td>
                        <td class="ta-td"><x-badge :label="$sponsor->status->label()" :color="$sponsor->status->color()" /></td>
                        <td class="ta-td text-muted">{{ $sponsor->deals_count }}</td>
                        <td class="ta-td font-semibold text-ink dark:text-gray-200">${{ number_format($sponsor->open_value ?? 0, 0) }}</td>
                        <td class="ta-td text-success font-semibold">${{ number_format($sponsor->won_value ?? 0, 0) }}</td>
                        <td class="ta-td"><a href="{{ route('sponsors.show', $sponsor) }}" class="btn btn-light !px-3 !py-1.5 text-xs">View</a></td>
                    </tr>
                @empty
                    <tr><td colspan="8" class="ta-td py-6 text-center text-muted">No sponsors yet.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</x-card>

<div class="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-3">
    {{-- Pending follow-ups --}}
    <x-card title="Pending Follow-Ups" subtitle="Due, not yet completed" padding="p-0" class="lg:col-span-1">
        <div class="divide-y divide-line dark:divide-strokedark">
            @forelse ($pendingFollowUps as $a)
                <div class="px-6 py-3">
                    <div class="flex items-center justify-between text-sm">
                        <span class="font-medium text-ink dark:text-gray-200">{{ $a->sponsor?->company_name }}</span>
                        <span class="rounded px-1.5 py-0.5 text-[11px] font-semibold {{ $a->due_date->isPast() ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400' : 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400' }}">
                            {{ $a->due_date->isPast() ? 'Overdue' : 'Due' }} {{ $a->due_date->format('M j') }}
                        </span>
                    </div>
                    <p class="mt-0.5 text-xs text-muted"><i class="fa-solid {{ $a->action_type->icon() }} mr-1"></i>{{ $a->action_type->label() }}{{ $a->performer ? ' · ' . $a->performer->name : '' }}</p>
                </div>
            @empty
                <p class="px-6 py-6 text-center text-sm text-muted"><i class="fa-solid fa-circle-check mb-1 block text-xl text-success"></i>No pending follow-ups.</p>
            @endforelse
        </div>
    </x-card>

    {{-- Activity mix --}}
    <x-card title="Team Activity Mix" :subtitle="$rangeLabel" padding="p-0">
        <div class="divide-y divide-line dark:divide-strokedark">
            @forelse ($activityReport as $row)
                <div class="flex items-center justify-between px-6 py-3">
                    <span class="flex items-center gap-2 text-sm text-ink dark:text-gray-200">
                        <i class="fa-solid {{ $row['icon'] }} w-4 text-center text-muted"></i>{{ $row['label'] }}
                    </span>
                    <span class="text-sm font-semibold text-ink dark:text-gray-200">{{ $row['value'] }}</span>
                </div>
            @empty
                <p class="px-6 py-6 text-center text-sm text-muted">No activity in this period.</p>
            @endforelse
        </div>
    </x-card>

    {{-- Monthly trend --}}
    <x-card title="New Sponsors (Last 6 Months)" padding="p-0">
        <div class="divide-y divide-line dark:divide-strokedark">
            @forelse ($trend as $month => $count)
                <div class="flex items-center justify-between px-6 py-3">
                    <span class="text-sm text-ink dark:text-gray-200">{{ \Carbon\Carbon::createFromFormat('Y-m', $month)->format('M Y') }}</span>
                    <div class="flex items-center gap-3">
                        <div class="hidden h-2 w-24 overflow-hidden rounded-full bg-gray-100 dark:bg-gray-700 sm:block">
                            @if ($trend->max() > 0)
                                <div class="h-full rounded-full bg-brand" style="width:{{ round($count / $trend->max() * 100) }}%"></div>
                            @endif
                        </div>
                        <span class="text-sm font-semibold text-ink dark:text-gray-200">{{ $count }}</span>
                    </div>
                </div>
            @empty
                <p class="px-6 py-6 text-center text-sm text-muted">No data yet.</p>
            @endforelse
        </div>
    </x-card>
</div>
@endsection
