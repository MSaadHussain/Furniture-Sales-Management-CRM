<?php

namespace App\Jobs;

use App\Services\GoogleSheetSyncService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SyncLeadToGoogleSheet implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 3;

    /** @var array<int> Seconds between retries. */
    public array $backoff = [30, 120];

    public function __construct(
        public string $modelClass,
        public int $modelId,
    ) {}

    public function handle(GoogleSheetSyncService $sheets): void
    {
        if (! $sheets->enabled()) {
            return;
        }

        /** @var Model|null $record */
        $record = $this->modelClass::find($this->modelId);

        if (! $record) {
            return; // deleted before the job ran
        }

        $sheets->sync($record);
    }
}
