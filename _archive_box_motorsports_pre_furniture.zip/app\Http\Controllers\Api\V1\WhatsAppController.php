<?php

namespace App\Http\Controllers\Api\V1;

use App\Enums\SourceChannel;
use App\Services\WhatsAppWebhookService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class WhatsAppController extends WebhookController
{
    public function verify(Request $request): mixed
    {
        $verifyToken = config('services.webhooks.whatsapp');

        if ($request->query('hub_mode') === 'subscribe'
            && $request->query('hub_verify_token') === $verifyToken) {
            return response($request->query('hub_challenge'), 200);
        }

        return response('Forbidden', 403);
    }

    public function __invoke(Request $request): JsonResponse
    {
        $whatsapp = app(WhatsAppWebhookService::class);
        $normalized = $whatsapp->normalize($request->all());

        if (! $normalized) {
            return response()->json(['success' => true, 'ignored' => true], 200);
        }

        return $this->process(SourceChannel::WhatsApp, $normalized, $request);
    }
}
