<?php

namespace App\Services;

use App\Enums\UserRole;
use App\Mail\NewLeadNotificationMail;
use App\Models\EmailNotificationLog;
use App\Models\IntegrationSetting;
use App\Models\Lead;
use App\Models\ReportSetting;
use App\Models\User;
use App\Notifications\HotLeadNotification;
use App\Notifications\LeadAssignedNotification;
use App\Notifications\NewLeadNotification;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Notification;

class LeadNotificationService
{
    private function alertRecipients()
    {
        $roles = [UserRole::SuperAdmin->value, UserRole::Admin->value];

        if (ReportSetting::get('notify_sales_manager', true)) {
            $roles[] = UserRole::SalesManager->value;
        }

        return User::where('is_active', true)->whereIn('role', $roles)->get();
    }

    public function newLead(Lead $lead, bool $isBulkImport = false): void
    {
        if ($this->disabled('new_lead')) {
            return;
        }

        $suppressEmail = $isBulkImport && ReportSetting::get('suppress_bulk_import_emails', true);

        $recipients = $this->alertRecipients();

        if ($lead->assigned_to && ($assignee = $lead->assignee) && ! $recipients->contains('id', $assignee->id)) {
            $recipients->push($assignee);
        }

        Notification::send($recipients, new NewLeadNotification($lead));

        if (! $suppressEmail) {
            foreach ($recipients as $user) {
                $this->sendMail($user->email, new NewLeadNotificationMail($lead), 'new_lead', $lead->id);
            }
        }

        $this->pushExternal("New lead: " . ($lead->full_name ?: 'Unnamed')
            . " via {$lead->source_channel->label()}");

        $lead->forceFill(['last_notified_at' => now()])->saveQuietly();
    }

    public function sendMail(?string $email, $mailable, string $type, ?int $leadId): void
    {
        if (! $email) {
            return;
        }
        try {
            Mail::to($email)->send($mailable);
            $subject = method_exists($mailable, 'envelope') ? $mailable->envelope()->subject : null;
            EmailNotificationLog::record($type, $email, $leadId, $subject, 'sent');
        } catch (\Throwable $e) {
            EmailNotificationLog::record($type, $email, $leadId, null, 'failed', $e->getMessage());
        }
    }

    public function hotLead(Lead $lead): void
    {
        if ($this->disabled('hot_lead')) {
            return;
        }

        Notification::send($this->alertRecipients(), new HotLeadNotification($lead));
        $this->pushExternal("HOT lead: " . ($lead->full_name ?: 'Unnamed')
            . " (score {$lead->lead_score})");
    }

    public function assigned(Lead $lead, User $assignee, string $assignedBy): void
    {
        if ($this->disabled('lead_assigned')) {
            return;
        }

        $assignee->notify(new LeadAssignedNotification($lead, $assignedBy));
    }

    private function disabled(string $type): bool
    {
        $config = IntegrationSetting::where('channel', 'notifications')->value('config') ?? [];
        return ($config[$type] ?? true) === false;
    }

    private function pushExternal(string $text): void
    {
        $config = IntegrationSetting::where('channel', 'notifications')->value('config') ?? [];

        if ($slack = ($config['slack_webhook'] ?? config('services.notifications.slack'))) {
            rescue(fn () => Http::timeout(5)->post($slack, ['text' => $text]), report: false);
        }

        if ($discord = ($config['discord_webhook'] ?? config('services.notifications.discord'))) {
            rescue(fn () => Http::timeout(5)->post($discord, ['content' => $text]), report: false);
        }
    }
}
