<?php

namespace App\Services;

class EmailParsingService
{
    public function normalize(array $payload): array
    {
        $from    = $payload['sender'] ?? $payload['from'] ?? '';
        $body    = $payload['body-plain'] ?? $payload['text'] ?? $payload['stripped-text'] ?? '';
        $subject = $payload['subject'] ?? '';

        return [
            'name'     => $this->extractName($payload['from'] ?? $from),
            'email'    => $this->extractEmail($from),
            'phone'    => $this->extractPhone($body),
            'message'  => trim($subject . "\n\n" . $body),
            'state'    => null,
            'interest' => $this->guessInterest($subject . ' ' . $body),
        ];
    }

    private function extractEmail(string $from): ?string
    {
        if (preg_match('/[\w.+-]+@[\w-]+\.[\w.-]+/', $from, $m)) {
            return strtolower($m[0]);
        }
        return null;
    }

    private function extractName(string $from): ?string
    {
        if (preg_match('/^\s*"?([^"<]+?)"?\s*</', $from, $m)) {
            return trim($m[1]);
        }
        return null;
    }

    private function extractPhone(string $body): ?string
    {
        if (preg_match('/(\+?\d[\d\s().-]{7,}\d)/', $body, $m)) {
            return trim($m[1]);
        }
        return null;
    }

    private function guessInterest(string $text): ?string
    {
        $text = strtolower($text);
        return match (true) {
            str_contains($text, 'sponsor') => 'sponsor',
            str_contains($text, 'driver')  => 'driver',
            str_contains($text, 'book')    => 'booking',
            str_contains($text, 'event')   => 'event',
            default                        => null,
        };
    }
}
