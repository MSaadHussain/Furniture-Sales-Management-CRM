<?php

namespace App\Http\Controllers;

use App\Http\Requests\UploadImportRequest;
use App\Jobs\ProcessLeadImport;
use App\Models\ImportBatch;
use App\Services\AuditService;
use App\Services\Import\LeadFileParserService;
use App\Services\Import\LeadImportMappingService;
use App\Services\Import\LeadImportService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\StreamedResponse;

class LeadImportController extends Controller
{
    /** Files with more rows than this are processed on the queue. */
    private const SYNC_ROW_LIMIT = 200;

    public function __construct(
        private LeadFileParserService $parserService,
        private LeadImportService $importService,
        private LeadImportMappingService $mapper,
        private AuditService $audit,
    ) {}

    /** GET /leads/import — the upload landing page. */
    public function index()
    {
        Gate::authorize('create', \App\Models\Lead::class);

        $recentBatches = ImportBatch::with('user')->latest()->limit(10)->get();

        return view('leads.import.index', [
            'recentBatches' => $recentBatches,
            'fields'        => LeadImportMappingService::FIELDS,
        ]);
    }

    /** POST /leads/import/upload — store the file, parse a preview. */
    public function upload(UploadImportRequest $request)
    {
        $file      = $request->file('file');
        $extension = strtolower($file->getClientOriginalExtension());

        // Store under storage/app/imports so the queued worker can re-read it.
        $storedPath = $file->store('imports');
        $absolute   = Storage::path($storedPath);

        try {
            $preview = $this->importService->preview($absolute, $extension);
        } catch (\Throwable $e) {
            Storage::delete($storedPath);
            return back()->with('error', 'Could not read the file: ' . $e->getMessage());
        }

        // Create a pending batch holding the file + parse metadata.
        $batch = ImportBatch::create([
            'user_id'        => $request->user()->id,
            'file_name'      => $file->getClientOriginalName(),
            'file_path'      => $absolute,
            'file_type'      => $this->parserService->fileTypeFor($extension),
            'source_channel' => $this->parserService->channelFor($extension),
            'total_rows'     => $preview['total'],
            'status'         => 'previewing',
        ]);

        $this->audit->log('lead.import.upload', $batch, "Uploaded {$file->getClientOriginalName()} ({$preview['total']} rows)");

        return view('leads.import.preview', [
            'batch'        => $batch,
            'headers'      => $preview['headers'],
            'rows'         => $preview['rows'],
            'suggestedMap' => $preview['suggested_map'],
            'total'        => $preview['total'],
            'fields'       => LeadImportMappingService::FIELDS,
        ]);
    }

    /** POST /leads/import/preview — (re)render preview for an existing batch with a tweaked map. */
    public function preview(Request $request, ImportBatch $batch)
    {
        Gate::authorize('create', \App\Models\Lead::class);

        $preview = $this->importService->preview($batch->file_path, $batch->file_type);

        return view('leads.import.preview', [
            'batch'        => $batch,
            'headers'      => $preview['headers'],
            'rows'         => $preview['rows'],
            'suggestedMap' => $request->input('column_map', $preview['suggested_map']),
            'total'        => $preview['total'],
            'fields'       => LeadImportMappingService::FIELDS,
        ]);
    }

    /** POST /leads/import/confirm — persist the map + strategy, then run the import. */
    public function confirm(Request $request, ImportBatch $batch)
    {
        Gate::authorize('create', \App\Models\Lead::class);

        $validated = $request->validate([
            'column_map'          => ['required', 'array'],
            'duplicate_strategy'  => ['required', 'in:skip,merge,update'],
        ]);

        // Normalise the map: keep only mapped, allowed fields.
        $allowed = LeadImportMappingService::FIELDS;
        $map = [];
        foreach ($validated['column_map'] as $index => $field) {
            if ($field !== null && $field !== '' && in_array($field, $allowed, true)) {
                $map[(int) $index] = $field;
            }
        }

        $batch->update([
            'column_map'         => $map,
            'duplicate_strategy' => $validated['duplicate_strategy'],
            'status'             => 'processing',
        ]);

        // Large files go to the queue; small ones run inline for instant feedback.
        if ($batch->total_rows > self::SYNC_ROW_LIMIT) {
            ProcessLeadImport::dispatch($batch->id);
            $this->audit->log('lead.import.queued', $batch, "Queued import of {$batch->total_rows} rows");

            return redirect()
                ->route('leads.import.batches.show', $batch)
                ->with('toast', 'Import queued. This page will update as rows are processed.');
        }

        $this->importService->process($batch);
        $this->audit->log('lead.import.completed', $batch,
            "Imported {$batch->successful_rows} ok, {$batch->duplicate_rows} dupes, {$batch->failed_rows} failed");

        return redirect()
            ->route('leads.import.batches.show', $batch)
            ->with('toast', "Import complete: {$batch->successful_rows} added, {$batch->duplicate_rows} duplicates, {$batch->failed_rows} failed.");
    }

    /** GET /leads/import/batches — history list. */
    public function batches()
    {
        Gate::authorize('create', \App\Models\Lead::class);

        $batches = ImportBatch::with('user')->latest()->paginate(20);

        return view('leads.import.batches', compact('batches'));
    }

    /** GET /leads/import/batches/{batch} — single batch result detail. */
    public function show(ImportBatch $batch)
    {
        Gate::authorize('create', \App\Models\Lead::class);

        $rows = $batch->rows()->with('lead')->orderBy('row_number')->paginate(50);

        return view('leads.import.show', compact('batch', 'rows'));
    }

    /** GET /leads/import/batches/{batch}/failed-download — CSV of failed rows. */
    public function downloadFailed(ImportBatch $batch): StreamedResponse
    {
        Gate::authorize('create', \App\Models\Lead::class);

        $filename = 'failed-rows-batch-' . $batch->id . '.csv';

        return response()->streamDownload(function () use ($batch) {
            $out = fopen('php://output', 'w');
            fputcsv($out, ['row_number', 'error_message', 'raw_data']);
            $batch->failedRows()->orderBy('row_number')->chunk(200, function ($rows) use ($out) {
                foreach ($rows as $row) {
                    fputcsv($out, [
                        $row->row_number,
                        $row->error_message,
                        json_encode($row->raw_data, JSON_UNESCAPED_UNICODE),
                    ]);
                }
            });
            fclose($out);
        }, $filename, ['Content-Type' => 'text/csv']);
    }
}
