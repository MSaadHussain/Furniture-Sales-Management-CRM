{{-- TailAdmin top header: hamburger, search, theme toggle, notifications, profile --}}
@php
    $unread = auth()->user()->unreadNotifications->count();
    $latestNotifications = auth()->user()->notifications()->latest()->limit(6)->get();
@endphp

<header class="sticky top-0 z-40 flex w-full border-b border-line bg-white/95 backdrop-blur
               dark:border-strokedark dark:bg-boxdark2/95">
    <div class="flex flex-1 items-center justify-between gap-4 px-4 py-3 sm:px-6">

        {{-- Left: hamburger + search --}}
        <div class="flex flex-1 items-center gap-3">
            <button class="flex h-10 w-10 items-center justify-center rounded-lg border border-line
                           text-ink dark:border-strokedark dark:text-gray-300 lg:hidden"
                    @click="sidebarOpen = true">
                <i class="fa-solid fa-bars"></i>
            </button>

            <form method="GET" action="{{ route('leads.index') }}" class="hidden max-w-md flex-1 sm:block">
                <div class="relative">
                    <i class="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-muted"></i>
                    <input type="search" name="search" value="{{ request('search') }}"
                           placeholder="Search or type command..."
                           class="ta-input pl-11 pr-16" />
                    <span class="absolute right-3 top-1/2 -translate-y-1/2 rounded border border-line
                                 px-1.5 py-0.5 text-xs text-muted dark:border-strokedark">⌘K</span>
                </div>
            </form>
        </div>

        {{-- Right: theme toggle, bell, profile --}}
        <div class="flex items-center gap-2 sm:gap-3">

            {{-- Theme toggle --}}
            <button @click="$store.theme.toggle()"
                    class="flex h-10 w-10 items-center justify-center rounded-full border border-line
                           text-ink transition hover:bg-surface dark:border-strokedark dark:text-gray-300 dark:hover:bg-boxdark"
                    title="Toggle dark mode">
                <i class="fa-solid fa-moon" x-show="!$store.theme.dark"></i>
                <i class="fa-solid fa-sun" x-show="$store.theme.dark" x-cloak></i>
            </button>

            {{-- Notifications --}}
            <div class="relative" x-data="{ open: false }">
                <button @click="open = !open"
                        class="relative flex h-10 w-10 items-center justify-center rounded-full border border-line
                               text-ink transition hover:bg-surface dark:border-strokedark dark:text-gray-300 dark:hover:bg-boxdark">
                    <i class="fa-regular fa-bell"></i>
                    @if ($unread)
                        <span class="absolute right-2 top-2 flex h-2.5 w-2.5">
                            <span class="absolute inline-flex h-full w-full animate-ping rounded-full bg-danger opacity-75"></span>
                            <span class="relative inline-flex h-2.5 w-2.5 rounded-full bg-danger"></span>
                        </span>
                    @endif
                </button>

                <div x-show="open" x-cloak @click.outside="open = false" x-transition
                     class="absolute right-0 mt-2 w-80 overflow-hidden rounded-2xl border border-line bg-white
                            shadow-dropdown dark:border-strokedark dark:bg-boxdark2">
                    <div class="flex items-center justify-between border-b border-line px-4 py-3 dark:border-strokedark">
                        <span class="text-sm font-semibold text-ink dark:text-white">Notifications</span>
                        <span class="ta-badge bg-brand-50 text-brand">{{ $unread }} new</span>
                    </div>
                    <div class="max-h-80 overflow-y-auto">
                        @forelse ($latestNotifications as $n)
                            <a href="{{ route('leads.show', $n->data['lead_id'] ?? 0) }}"
                               class="flex gap-3 border-b border-line px-4 py-3 transition hover:bg-surface
                                      dark:border-strokedark dark:hover:bg-boxdark">
                                <span class="mt-1.5 h-2 w-2 flex-shrink-0 rounded-full"
                                      style="background-color: {{ $n->data['color'] ?? '#667085' }};"></span>
                                <div class="min-w-0">
                                    <p class="truncate text-sm font-medium text-ink dark:text-gray-200">{{ $n->data['title'] ?? 'Notification' }}</p>
                                    <p class="truncate text-xs text-muted">{{ \Illuminate\Support\Str::limit($n->data['message'] ?? '', 48) }}</p>
                                    <p class="mt-0.5 text-xs text-muted">{{ $n->created_at->diffForHumans() }}</p>
                                </div>
                            </a>
                        @empty
                            <p class="px-4 py-8 text-center text-sm text-muted">No notifications</p>
                        @endforelse
                    </div>
                    <a href="{{ route('notifications.index') }}"
                       class="block border-t border-line px-4 py-3 text-center text-sm font-medium text-brand
                              dark:border-strokedark">See all notifications</a>
                </div>
            </div>

            {{-- Profile --}}
            <div class="relative" x-data="{ open: false }">
                <button @click="open = !open" class="flex items-center gap-2.5">
                    <x-user-avatar :user="auth()->user()" :px="40" />
                    <span class="hidden text-left sm:block">
                        <span class="block text-sm font-medium text-ink dark:text-gray-200">{{ auth()->user()->name }}</span>
                        <span class="block text-xs text-muted">{{ auth()->user()->role->label() }}</span>
                    </span>
                    <i class="fa-solid fa-chevron-down hidden text-xs text-muted sm:block"></i>
                </button>

                <div x-show="open" x-cloak @click.outside="open = false" x-transition
                     class="absolute right-0 mt-2 w-56 overflow-hidden rounded-2xl border border-line bg-white
                            shadow-dropdown dark:border-strokedark dark:bg-boxdark2">
                    <div class="border-b border-line px-4 py-3 dark:border-strokedark">
                        <p class="text-sm font-semibold text-ink dark:text-white">{{ auth()->user()->name }}</p>
                        <p class="truncate text-xs text-muted">{{ auth()->user()->email }}</p>
                    </div>
                    @if (Route::has('profile.edit'))
                        <a href="{{ route('profile.edit') }}"
                           class="flex items-center gap-3 px-4 py-2.5 text-sm text-ink transition hover:bg-surface
                                  dark:text-gray-300 dark:hover:bg-boxdark">
                            <i class="fa-solid fa-user w-4 text-muted"></i> Edit profile
                        </a>
                    @endif
                    <form method="POST" action="{{ route('logout') }}" class="border-t border-line dark:border-strokedark">
                        @csrf
                        <button type="submit"
                                class="flex w-full items-center gap-3 px-4 py-2.5 text-sm text-danger transition hover:bg-surface
                                       dark:hover:bg-boxdark">
                            <i class="fa-solid fa-right-from-bracket w-4"></i> Log out
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</header>
