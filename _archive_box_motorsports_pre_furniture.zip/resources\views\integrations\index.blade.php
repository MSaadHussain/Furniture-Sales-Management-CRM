@extends('layouts.adminlte')
@section('title', 'Integrations')

@section('content')
<div class="card card-primary card-outline card-tabs">
    <div class="card-header p-0 pt-1 border-bottom-0">
        <ul class="nav nav-tabs" role="tablist">
            @foreach (['jotform'=>'Jotform','website'=>'Website','whatsapp'=>'WhatsApp','email'=>'Email','notifications'=>'Notifications'] as $key => $label)
                <li class="nav-item">
                    <a class="nav-link {{ $loop->first ? 'active' : '' }}" data-toggle="pill" href="#tab-{{ $key }}" role="tab">{{ $label }}</a>
                </li>
            @endforeach
        </ul>
    </div>
    <div class="card-body">
        <div class="tab-content">
            <div class="tab-pane fade show active" id="tab-jotform">
                @include('integrations._channel', ['channel'=>'jotform','title'=>'Jotform','setting'=>$settings['jotform'],'endpoint'=>$webhookBase.'/jotform','instructions'=>'In Jotform settings, go to Integrations > Webhooks and paste the URL below. Add the secret as a header named X-Webhook-Secret.'])
            </div>

            <div class="tab-pane fade" id="tab-website">
                @include('integrations._channel', ['channel'=>'website','title'=>'Website Form','setting'=>$settings['website'],'endpoint'=>$webhookBase.'/website','instructions'=>'POST your website form submissions to the endpoint below, including the secret header.'])
                <div class="card"><div class="card-header"><h3 class="card-title">Sample AJAX</h3></div>
                    <div class="card-body"><pre class="bg-dark text-light p-3 rounded small" style="overflow-x:auto;">fetch('{{ $webhookBase }}/website', {
  method: 'POST',
  headers: { 'Content-Type':'application/json', 'X-Webhook-Secret':'{{ $settings['website']->secret_key }}' },
  body: JSON.stringify({ name:form.name.value, email:form.email.value, phone:form.phone.value, message:form.message.value })
});</pre></div>
                </div>
            </div>

            <div class="tab-pane fade" id="tab-whatsapp">
                @include('integrations._channel', ['channel'=>'whatsapp','title'=>'WhatsApp','setting'=>$settings['whatsapp'],'endpoint'=>$webhookBase.'/whatsapp','instructions'=>'Configure your WhatsApp provider to send inbound messages to the endpoint below. For Meta Cloud API, use the secret as the verify token and HMAC app secret.'])
                <div class="card"><div class="card-body">
                    <form method="POST" action="{{ route('integrations.update', 'whatsapp') }}" class="form-inline">@csrf @method('PATCH')
                        <label class="mr-2">Provider</label>
                        <select name="config[provider]" class="form-control mr-2">
                            @foreach (['meta'=>'Meta Cloud API','twilio'=>'Twilio','vapi'=>'Vapi','other'=>'Other'] as $val=>$label)<option value="{{ $val }}" @selected(($settings['whatsapp']->config['provider'] ?? '')===$val)>{{ $label }}</option>@endforeach
                        </select>
                        <input type="hidden" name="enabled" value="{{ $settings['whatsapp']->enabled ? 1 : 0 }}">
                        <button class="btn btn-dark">Save Provider</button>
                    </form>
                </div></div>
            </div>

            <div class="tab-pane fade" id="tab-email">
                @include('integrations._channel', ['channel'=>'email','title'=>'Email','setting'=>$settings['email'],'endpoint'=>$webhookBase.'/email','instructions'=>'Point your Mailgun or SendGrid inbound parse webhook to the endpoint below.'])
                <div class="card"><div class="card-header"><h3 class="card-title">Cron (IMAP polling)</h3></div>
                    <div class="card-body"><pre class="bg-dark text-light p-3 rounded small" style="overflow-x:auto;">* * * * * cd /path-to-app &amp;&amp; php artisan schedule:run >> /dev/null 2>&amp;1</pre></div>
                </div>
            </div>

            <div class="tab-pane fade" id="tab-notifications">
                <form method="POST" action="{{ route('integrations.update', 'notifications') }}">@csrf @method('PATCH')
                    <input type="hidden" name="enabled" value="1">
                    @php $nc = $settings['notifications']->config ?? []; @endphp
                    @foreach (['new_lead'=>'New lead received','hot_lead'=>'Hot lead received','lead_assigned'=>'Lead assigned','meeting_scheduled'=>'Meeting scheduled','closed_won'=>'Closed won'] as $key=>$label)
                        <div class="form-check">
                            <input type="hidden" name="config[{{ $key }}]" value="0">
                            <input type="checkbox" name="config[{{ $key }}]" value="1" @checked($nc[$key] ?? true) class="form-check-input" id="nc-{{ $key }}">
                            <label class="form-check-label" for="nc-{{ $key }}">{{ $label }}</label>
                        </div>
                    @endforeach
                    <div class="form-group mt-3"><label class="small">Slack Webhook URL</label><input name="config[slack_webhook]" value="{{ $nc['slack_webhook'] ?? '' }}" class="form-control"></div>
                    <div class="form-group"><label class="small">Discord Webhook URL</label><input name="config[discord_webhook]" value="{{ $nc['discord_webhook'] ?? '' }}" class="form-control"></div>
                    <button class="btn btn-brand">Save Notification Settings</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
