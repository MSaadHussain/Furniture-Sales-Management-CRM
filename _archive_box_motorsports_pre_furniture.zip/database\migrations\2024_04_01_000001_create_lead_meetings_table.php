<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('lead_meetings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('lead_id')->constrained('leads')->cascadeOnDelete();
            $table->string('provider');               // google_meet | calendly
            $table->string('external_event_id')->nullable()->index();
            $table->string('meeting_title')->nullable();
            $table->string('meeting_url')->nullable();
            $table->timestamp('starts_at')->nullable();
            $table->timestamp('ends_at')->nullable();
            $table->string('attendee_email')->nullable();
            $table->string('attendee_name')->nullable();
            $table->string('status')->default('scheduled'); // scheduled | completed | canceled
            $table->json('raw_payload')->nullable();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();

            $table->index(['lead_id', 'starts_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('lead_meetings');
    }
};
