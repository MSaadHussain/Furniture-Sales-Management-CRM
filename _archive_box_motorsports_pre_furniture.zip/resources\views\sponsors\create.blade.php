@extends('layouts.app')
@section('title', 'Add Sponsor / Vendor')
@section('breadcrumb')
    <a href="{{ route('sponsors.index') }}" class="hover:text-brand">Sponsors & Vendors</a> / <span>Add</span>
@endsection

@section('content')
<x-card title="New Sponsor / Vendor Profile" subtitle="Add a company, brand, sponsor, track partner, or racing asset provider">
    <form method="POST" action="{{ route('sponsors.store') }}">
        @include('sponsors._form')
        <div class="mt-6 flex justify-end gap-3">
            <a href="{{ route('sponsors.index') }}" class="btn btn-light">Cancel</a>
            <button class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Create Profile</button>
        </div>
    </form>
</x-card>
@endsection
