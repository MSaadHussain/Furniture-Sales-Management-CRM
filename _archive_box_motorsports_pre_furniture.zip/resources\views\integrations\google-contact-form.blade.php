@extends('layouts.app')
@section('title', 'Google Contact Form')
@section('breadcrumb')
    <a href="{{ route('integrations.index') }}" class="hover:text-brand">Integrations</a> / <span>Google Contact Form</span>
@endsection

@section('content')
<div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
    <form method="POST" action="{{ route('integrations.google-contact-form.save') }}" class="lg:col-span-2">
        @csrf
        <x-card class="h-full" title="Google Forms Settings" subtitle="Configure integration with your normal Google Contact Form">
            <div class="space-y-4">
                <div class="flex items-center justify-between rounded-xl border border-line p-3 dark:border-strokedark">
                    <span class="text-sm font-medium text-ink dark:text-gray-200">Integration active</span>
                    <input type="checkbox" name="enabled" value="1" @checked($setting->enabled)
                           class="h-5 w-9 rounded-full text-brand focus:ring-brand">
                </div>

                <div class="pt-2">
                    <h4 class="text-sm font-medium text-ink dark:text-gray-200 mb-2">Instructions</h4>
                    <p class="text-xs text-muted leading-relaxed">
                        1. Open your Google Form.<br>
                        2. Go to <strong>Responses</strong> > <strong>Link to Sheets</strong> to link a response spreadsheet.<br>
                        3. In the Google Sheet, open <strong>Extensions</strong> > <strong>Apps Script</strong> and paste the Apps Script snippet below.<br>
                        4. Add a trigger to run the script <strong>On form submit</strong>.<br>
                        5. Save and authorize the script.
                    </p>
                </div>

                <div class="flex justify-end gap-2 pt-2">
                    <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save Settings</button>
                </div>
            </div>
        </x-card>
    </form>

    <div class="space-y-6">
        <x-card title="Webhook Endpoint" subtitle="Configure in your Apps Script">
            <div>
                <label class="ta-label">Webhook URL</label>
                <div class="flex gap-2">
                    <input type="text" readonly value="{{ $webhookUrl }}" id="webhookUrl" class="ta-input flex-1">
                    <button type="button" class="btn btn-light" onclick="navigator.clipboard.writeText(document.getElementById('webhookUrl').value)"><i class="fa-regular fa-copy"></i></button>
                </div>
            </div>

            <div class="mt-4">
                <label class="ta-label">Secret Key</label>
                <div class="flex gap-2">
                    <input type="password" readonly value="{{ $setting->secret_key }}" id="secretKey" class="ta-input flex-1">
                    <button type="button" class="btn btn-light" onclick="var f=document.getElementById('secretKey'); f.type=f.type==='password'?'text':'password';"><i class="fa-regular fa-eye"></i></button>
                    <button type="button" class="btn btn-light" onclick="navigator.clipboard.writeText(document.getElementById('secretKey').value)"><i class="fa-regular fa-copy"></i></button>
                </div>
            </div>

            <div class="flex gap-2 mt-4">
                <form method="POST" action="{{ route('integrations.google-contact-form.regenerate') }}" class="flex-1">
                    @csrf
                    <button type="submit" class="btn btn-light w-full text-danger hover:bg-danger/10"><i class="fa-solid fa-rotate"></i> Regenerate Secret</button>
                </form>
            </div>
        </x-card>

        <x-card title="Test Connection">
            <form method="POST" action="{{ route('integrations.google-contact-form.test') }}">
                @csrf
                <button type="submit" class="btn btn-light w-full"><i class="fa-solid fa-plug-circle-check"></i> Test Webhook Secret</button>
            </form>
        </x-card>
    </div>
</div>

<div class="mt-6">
    <x-card title="Apps Script Snippet" subtitle="Copy this code into your Google Apps Script editor">
        <pre class="bg-dark text-light p-4 rounded-xl text-xs overflow-x-auto" style="font-family: monospace;">function onFormSubmit(e) {
  var values = e.namedValues || {};
  var data = {};
  
  Object.keys(values).forEach(function(key) {
    if (values[key] && values[key][0]) {
      data[key] = String(values[key][0]).trim();
    }
  });

  try {
    var response = UrlFetchApp.fetch('{{ $webhookUrl }}', {
      method: 'post',
      contentType: 'application/json',
      headers: {
        'X-Webhook-Secret': '{{ $setting->secret_key }}'
      },
      payload: JSON.stringify(data),
      muteHttpExceptions: true
    });

    Logger.log('Response Code: ' + response.getResponseCode());
    Logger.log('Response Body: ' + response.getContentText());
  } catch (error) {
    Logger.log('Error: ' + error.toString());
  }
}</pre>
    </x-card>
</div>
@endsection
