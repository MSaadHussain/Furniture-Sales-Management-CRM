<?php

namespace App\Http\Controllers\Api\V1;

use App\Enums\SourceChannel;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class WebsiteController extends WebhookController
{
    public function __invoke(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name'    => ['nullable', 'string', 'max:191'],
            'email'   => ['nullable', 'email', 'max:191'],
            'phone'   => ['nullable', 'string', 'max:40'],
            'message' => ['nullable', 'string', 'max:5000'],
        ]);

        if (blank($validated['email'] ?? null) && blank($validated['phone'] ?? null)) {
            return response()->json([
                'success' => false,
                'message' => 'Email or phone is required.',
            ], 422);
        }

        return $this->process(SourceChannel::Website, $request->all(), $request);
    }
}
