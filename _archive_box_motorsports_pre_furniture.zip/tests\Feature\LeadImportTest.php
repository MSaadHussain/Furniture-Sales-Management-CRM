<?php

namespace Tests\Feature;

use App\Models\ImportBatch;
use App\Models\Lead;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class LeadImportTest extends TestCase
{
    use RefreshDatabase;

    private function csvFile(string $contents, string $name = 'leads.csv'): UploadedFile
    {
        $path = tempnam(sys_get_temp_dir(), 'imp') . '.csv';
        file_put_contents($path, $contents);

        return new UploadedFile($path, $name, 'text/csv', null, true);
    }

    public function test_import_landing_page_loads(): void
    {
        $user = User::factory()->create();

        $this->actingAs($user)
            ->get('/leads/import')
            ->assertOk()
            ->assertSee('Import Leads');
    }

    public function test_upload_parses_and_returns_preview(): void
    {
        $user = User::factory()->create();
        $file = $this->csvFile("First Name,Email,Phone\nLewis,lewis@example.com,+44 7700 900123\n");

        $this->actingAs($user)
            ->post('/leads/import/upload', ['file' => $file])
            ->assertOk()
            ->assertSee('Map columns');

        $this->assertDatabaseHas('import_batches', [
            'user_id'        => $user->id,
            'source_channel' => 'imported_csv',
            'status'         => 'previewing',
            'total_rows'     => 1,
        ]);
    }

    public function test_confirm_creates_leads_with_correct_source(): void
    {
        $user = User::factory()->create();
        $file = $this->csvFile("First Name,Email,Phone\nLewis,lewis@example.com,+44 7700 900123\nMax,max@example.com,+31 612345678\n");

        // Upload to create the batch + stored file.
        $this->actingAs($user)->post('/leads/import/upload', ['file' => $file])->assertOk();
        $batch = ImportBatch::latest()->first();

        $this->actingAs($user)->post("/leads/import/confirm/{$batch->id}", [
            'column_map'         => [0 => 'first_name', 1 => 'email', 2 => 'phone'],
            'duplicate_strategy' => 'skip',
        ])->assertRedirect();

        $batch->refresh();
        $this->assertSame(2, $batch->successful_rows);
        $this->assertSame(0, $batch->failed_rows);

        $this->assertDatabaseHas('leads', [
            'email'          => 'lewis@example.com',
            'source_channel' => 'imported_csv',
        ]);
        $this->assertEquals($batch->id, Lead::where('email', 'lewis@example.com')->value('imported_batch_id'));
    }

    public function test_duplicate_is_skipped_when_strategy_is_skip(): void
    {
        $user = User::factory()->create();
        Lead::factory()->create(['email' => 'dupe@example.com', 'source_channel' => 'website']);

        $file = $this->csvFile("Name,Email,Phone\nDupe Lead,dupe@example.com,+44 7700 111222\n");
        $this->actingAs($user)->post('/leads/import/upload', ['file' => $file])->assertOk();
        $batch = ImportBatch::latest()->first();

        $this->actingAs($user)->post("/leads/import/confirm/{$batch->id}", [
            'column_map'         => [0 => 'first_name', 1 => 'email', 2 => 'phone'],
            'duplicate_strategy' => 'skip',
        ])->assertRedirect();

        $batch->refresh();
        $this->assertSame(1, $batch->duplicate_rows);
        // Still only one lead with that email.
        $this->assertSame(1, Lead::where('email', 'dupe@example.com')->count());
    }

    public function test_invalid_rows_are_recorded_as_failed(): void
    {
        $user = User::factory()->create();
        // Row 2 has an invalid email and no phone -> should fail.
        $file = $this->csvFile("Name,Email,Phone\nValid Lead,valid@example.com,+44 7700 900123\nBad Lead,not-an-email,\n");
        $this->actingAs($user)->post('/leads/import/upload', ['file' => $file])->assertOk();
        $batch = ImportBatch::latest()->first();

        $this->actingAs($user)->post("/leads/import/confirm/{$batch->id}", [
            'column_map'         => [0 => 'first_name', 1 => 'email', 2 => 'phone'],
            'duplicate_strategy' => 'skip',
        ])->assertRedirect();

        $batch->refresh();
        $this->assertSame(1, $batch->successful_rows);
        $this->assertSame(1, $batch->failed_rows);
        $this->assertDatabaseHas('import_batch_rows', ['import_batch_id' => $batch->id, 'status' => 'failed']);
    }

    public function test_failed_rows_csv_download(): void
    {
        $user = User::factory()->create();
        $file = $this->csvFile("Email\nbad-email\n");
        $this->actingAs($user)->post('/leads/import/upload', ['file' => $file])->assertOk();
        $batch = ImportBatch::latest()->first();
        $this->actingAs($user)->post("/leads/import/confirm/{$batch->id}", [
            'column_map'         => [0 => 'email'],
            'duplicate_strategy' => 'skip',
        ]);

        $this->actingAs($user)
            ->get("/leads/import/batches/{$batch->id}/failed-download")
            ->assertOk()
            ->assertHeader('content-type', 'text/csv; charset=UTF-8');
    }

    public function test_import_route_not_swallowed_by_lead_wildcard(): void
    {
        $user = User::factory()->create();
        // "/leads/import" must hit the import controller, not leads.show with id="import".
        $this->actingAs($user)->get('/leads/import')->assertOk();
    }
}
