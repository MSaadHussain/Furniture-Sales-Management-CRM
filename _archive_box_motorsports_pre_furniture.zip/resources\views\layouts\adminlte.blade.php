{{--
    COMPATIBILITY SHIM (Phase 1 theme migration)
    --------------------------------------------
    The CRM moved to the TailAdmin-style `layouts.app` shell. Every view that still
    does `@extends('layouts.adminlte')` now transparently renders inside the new
    Tailwind chrome (sidebar/header/dark-mode) via the section contract below.

    Views not yet rewritten in Tailwind still contain Bootstrap/AdminLTE markup,
    so we load AdminLTE's stylesheet *scoped to the page body only* through the
    `head` stack. Migrated views (e.g. dashboard) extend `layouts.app` directly and
    never pull this in. Each later phase rewrites its views to native Tailwind and
    can drop the @extends target to `layouts.app`.

    Original AdminLTE layout preserved at: adminlte.blade.php.bak
--}}
@extends('layouts.app')

@push('head')
    {{-- Legacy CSS for views still using Bootstrap-4/AdminLTE markup. --}}
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2.0/dist/css/adminlte.min.css">
    <style>
        /* Keep legacy AdminLTE components readable inside the Tailwind shell + dark mode */
        .content-wrapper, .content-header, .main-header, .main-sidebar, .main-footer { all: revert; }
        .card { border:1px solid #EAECF0; border-radius:0.75rem; box-shadow:0 1px 3px rgba(16,24,40,.08); }
        .dark .card { background:#24303F; border-color:#2E3A47; color:#e5e7eb; }
        .dark .card .card-header { color:#e5e7eb; border-color:#2E3A47; }
        .dark .table { color:#e5e7eb; }
        .dark .table td, .dark .table th { border-color:#2E3A47; }
        .btn-brand { background:#465FFF; border-color:#465FFF; color:#fff; }
        .btn-brand:hover { background:#3641F5; border-color:#3641F5; color:#fff; }
        .text-brand { color:#465FFF !important; }

        /* --- Dark mode text readability for legacy Bootstrap pages --- */
        .dark .text-dark { color:#e5e7eb !important; }       /* was forced near-black */
        .dark .text-muted { color:#98A6B5 !important; }
        .dark a.text-dark:hover { color:#fff !important; }
        .dark, .dark body { color:#cbd5e1; }
        .dark h1, .dark h2, .dark h3, .dark h4, .dark h5, .dark h6,
        .dark .card-title, .dark label, .dark dt, .dark dd, .dark p, .dark span, .dark strong { color:inherit; }
        .dark .card-title { color:#e5e7eb; }
        /* Form controls */
        .dark .form-control, .dark .custom-select, .dark select.form-control {
            background:#1D2733; border-color:#2E3A47; color:#e5e7eb;
        }
        .dark .form-control::placeholder { color:#64748b; }
        .dark .form-control:focus { border-color:#465FFF; box-shadow:0 0 0 .15rem rgba(70,95,255,.25); }
        /* Tables */
        .dark .table thead th { color:#cbd5e1; }
        .dark .table-hover tbody tr:hover { background:rgba(255,255,255,.03); color:#fff; }
        /* Buttons that default to light backgrounds */
        .dark .btn-default { background:#1D2733; border-color:#2E3A47; color:#e5e7eb; }
        .dark .btn-default:hover { background:#283442; color:#fff; }
        /* List groups / dropdowns / modals */
        .dark .list-group-item, .dark .dropdown-menu, .dark .modal-content { background:#24303F; color:#e5e7eb; border-color:#2E3A47; }
        .dark .dropdown-item { color:#e5e7eb; }
        .dark .dropdown-item:hover { background:#283442; }
        .dark .border, .dark .border-top, .dark .border-bottom, .dark .border-left, .dark .border-right { border-color:#2E3A47 !important; }
        .dark .bg-white, .dark .bg-light { background:#24303F !important; color:#e5e7eb; }
        /* Avatar circle used in legacy tables */
        .avatar-circle { display:inline-flex; align-items:center; justify-content:center; width:28px; height:28px; border-radius:9999px; color:#fff; font-size:11px; font-weight:700; }
    </style>
@endpush

@push('scripts')
    {{-- Legacy JS dependencies for AdminLTE widgets used by not-yet-migrated views. --}}
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
@endpush

{{-- Child views' @section('title') and @section('content') propagate up to layouts.app automatically. --}}
