<?php

namespace App\Http\Requests;

use App\Enums\LeadPriority;
use App\Enums\LeadStatus;
use App\Enums\MotorsportInterest;
use App\Enums\SourceChannel;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rules\Enum;

class UpdateLeadRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('update', $this->route('lead'));
    }

    public function rules(): array
    {
        return [
            'first_name'               => ['required', 'string', 'max:120'],
            'last_name'                => ['nullable', 'string', 'max:120'],
            'email'                    => ['required', 'email', 'max:191'],
            'phone'                    => ['required', 'string', 'max:40'],
            'loc_state'                => ['nullable', 'string', 'max:120'],
            'message'                  => ['nullable', 'string', 'max:5000'],
            'motorsport_interest_type' => ['nullable', new Enum(MotorsportInterest::class)],
            'motorsport_notes'         => ['nullable', 'string', 'max:2000'],
            'source_channel'           => ['required', new Enum(SourceChannel::class)],
            'status'                   => ['required', new Enum(LeadStatus::class)],
            'priority'                 => ['required', new Enum(LeadPriority::class)],
            'assigned_to'              => ['nullable', 'exists:users,id'],
            'tags'                     => ['nullable', 'array'],
            'tags.*'                   => ['string', 'max:40'],
        ];
    }
}
