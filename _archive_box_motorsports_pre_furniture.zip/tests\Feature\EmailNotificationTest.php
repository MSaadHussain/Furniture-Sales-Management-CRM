<?php

namespace Tests\Feature;

use App\Mail\NewLeadNotificationMail;
use App\Mail\WeeklyLeadReportMail;
use App\Models\Lead;
use App\Models\ReportSetting;
use App\Models\User;
use App\Services\LeadNotificationService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Mail;
use Tests\TestCase;

class EmailNotificationTest extends TestCase
{
    use RefreshDatabase;

    public function test_new_lead_sends_instant_email_to_admin(): void
    {
        Mail::fake();
        User::factory()->create(['role' => 'admin', 'email' => 'admin@box.test']);
        $lead = Lead::factory()->create(['full_name' => 'Test Lead', 'source_channel' => 'website']);

        app(LeadNotificationService::class)->newLead($lead);

        Mail::assertQueued(NewLeadNotificationMail::class);
        $this->assertDatabaseHas('email_notification_logs', ['type' => 'new_lead', 'recipient' => 'admin@box.test']);
    }

    public function test_bulk_import_suppresses_email_when_setting_on(): void
    {
        Mail::fake();
        ReportSetting::put('suppress_bulk_import_emails', true);
        User::factory()->create(['role' => 'admin']);
        $lead = Lead::factory()->create(['source_channel' => 'imported_csv']);

        app(LeadNotificationService::class)->newLead($lead, isBulkImport: true);

        Mail::assertNothingQueued();
    }

    public function test_weekly_report_command_sends_email(): void
    {
        Mail::fake();
        User::factory()->create(['role' => 'admin', 'email' => 'admin@box.test']);
        Lead::factory()->count(3)->create(['created_at' => now()->subWeek()->startOfWeek()->addDay()]);

        $this->artisan('crm:weekly-report', ['--force' => true])->assertSuccessful();

        Mail::assertQueued(WeeklyLeadReportMail::class);
        $this->assertDatabaseHas('weekly_report_logs', ['status' => 'sent']);
    }

    public function test_weekly_report_skips_when_disabled(): void
    {
        Mail::fake();
        ReportSetting::put('weekly_report_enabled', false);
        User::factory()->create(['role' => 'admin']);

        $this->artisan('crm:weekly-report')->assertSuccessful();

        Mail::assertNothingQueued();
    }

    public function test_settings_page_saves(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);

        $this->actingAs($admin)->patch('/settings', [
            'weekly_report_enabled'    => '1',
            'weekly_report_recipients' => 'a@box.test, b@box.test',
            'weekly_report_day'        => 1,
            'weekly_report_time'       => '09:00',
            'weekly_report_include_csv' => '1',
        ])->assertRedirect();

        $this->assertSame(['a@box.test', 'b@box.test'], ReportSetting::get('weekly_report_recipients'));
        $this->assertSame(1, ReportSetting::get('weekly_report_day'));
    }
}
