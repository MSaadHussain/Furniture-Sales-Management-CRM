@component('mail::message')
# Weekly Report

**{{ $r['period_start']->format('M j') }} – {{ $r['period_end']->format('M j, Y') }}**

## Overview — All Lead Types
@component('mail::table')
| Type | New This Week |
|:---- | -----:|
| Basic Leads | {{ $r['new_count'] }} |
| Driver Leads | {{ $r['driver_new_count'] }} |
| Sponsors & Vendors | {{ $r['sponsor_new_count'] }} |
| **Total** | **{{ $r['new_count'] + $r['driver_new_count'] + $r['sponsor_new_count'] }}** |
@endcomponent

# Basic Leads

@component('mail::table')
| Metric | Count |
|:------ | -----:|
| New leads | {{ $r['new_count'] }} |
| Existing updated | {{ $r['updated_count'] }} |
| Duplicates merged | {{ $r['duplicate_count'] }} |
| Hot / high priority | {{ $r['hot_count'] }} |
| Closed won | {{ $r['closed_won'] }} |
| Closed lost | {{ $r['closed_lost'] }} |
@endcomponent

@if($r['by_source']->isNotEmpty())
## Leads by Source
@component('mail::table')
| Source | Count |
|:------ | -----:|
@foreach($r['by_source'] as $row)
| {{ $row['label'] }} | {{ $row['value'] }} |
@endforeach
@endcomponent
@endif

@if($r['by_country']->isNotEmpty())
## Leads by Country
@component('mail::table')
| Country | Count | Share |
|:------ | -----:| -----:|
@foreach($r['by_country'] as $c)
| {{ $c['name'] }} | {{ $c['total'] }} | {{ $c['percentage'] }}% |
@endforeach
@endcomponent
@endif

@if($r['by_user']->isNotEmpty())
## By Assigned User
@component('mail::table')
| User | Leads |
|:---- | -----:|
@foreach($r['by_user'] as $row)
| {{ $row['label'] }} | {{ $row['value'] }} |
@endforeach
@endcomponent
@endif

@if($r['latest']->isNotEmpty())
## Latest 10 Leads
@component('mail::table')
| Name | Source | Status |
|:---- |:------ |:------ |
@foreach($r['latest'] as $lead)
| {{ $lead->full_name ?: 'Unnamed' }} | {{ $lead->source_channel->label() }} | {{ $lead->status->label() }} |
@endforeach
@endcomponent
@endif

# Driver Leads

@component('mail::table')
| Metric | Count |
|:------ | -----:|
| New this week | {{ $r['driver_new_count'] }} |
| Qualified | {{ $r['driver_qualified'] }} |
| Declined | {{ $r['driver_declined'] }} |
| Seeking sponsorship | {{ $r['driver_seeking'] }} |
@endcomponent

@if($r['driver_latest']->isNotEmpty())
## Latest Driver Leads
@component('mail::table')
| Name | Racing Level | Tier | Status |
|:---- |:------------ |:---- |:------ |
@foreach($r['driver_latest'] as $d)
| {{ $d->full_name ?: 'Unnamed' }} | {{ $d->racing_level?->label() ?? '-' }} | {{ $d->inferred_tier?->label() ?? '-' }} | {{ $d->status?->label() ?? '-' }} |
@endforeach
@endcomponent
@endif

# Sponsors & Vendors

@component('mail::table')
| Metric | Count |
|:------ | -----:|
| New profiles this week | {{ $r['sponsor_new_count'] }} |
| New deals this week | {{ $r['deal_new_count'] }} |
| Deal value won this week | {{ number_format($r['deal_won_value']) }} |
@endcomponent

@if($r['sponsor_by_type']->isNotEmpty())
## Sponsors by Type
@component('mail::table')
| Type | Count |
|:---- | -----:|
@foreach($r['sponsor_by_type'] as $row)
| {{ $row['label'] }} | {{ $row['value'] }} |
@endforeach
@endcomponent
@endif

@if($r['sponsor_latest']->isNotEmpty())
## Latest Sponsors & Vendors
@component('mail::table')
| Company | Type | Status |
|:------- |:---- |:------ |
@foreach($r['sponsor_latest'] as $s)
| {{ $s->company_name ?: 'Unnamed' }} | {{ $s->company_type?->label() ?? '-' }} | {{ $s->status?->label() ?? '-' }} |
@endforeach
@endcomponent
@endif

@component('mail::button', ['url' => route('dashboard'), 'color' => 'primary'])
Open CRM Dashboard
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent
