<?php

namespace App\Enums;

enum DriverLeadStatus: string
{
    case New = 'new';
    case Qualified = 'qualified';
    case Declined = 'declined';
    case Contacted = 'contacted';

    public function label(): string
    {
        return match ($this) {
            self::New       => 'New',
            self::Qualified => 'Qualified',
            self::Declined  => 'Declined',
            self::Contacted => 'Contacted',
        };
    }

    public function color(): string
    {
        return match ($this) {
            self::New       => '#7C3AED',
            self::Qualified => '#16A34A',
            self::Declined  => '#DC2626',
            self::Contacted => '#2563EB',
        };
    }

    public static function options(): array
    {
        return array_map(
            fn (self $s) => ['value' => $s->value, 'label' => $s->label(), 'color' => $s->color()],
            self::cases()
        );
    }
}
