<?php

namespace App\Services\Import;

use App\Enums\InteractionType;
use App\Enums\LeadPriority;
use App\Enums\LeadStatus;
use App\Enums\MotorsportInterest;
use App\Enums\SourceChannel;
use App\Events\HotLeadReceived;
use App\Events\LeadCreated;
use App\Models\ImportBatch;
use App\Models\ImportBatchRow;
use App\Models\Lead;
use App\Services\LeadDeduplicationService;
use App\Services\LeadInteractionService;
use App\Services\LeadNormalizerService;
use App\Services\LeadScoringService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

/**
 * Processes a confirmed import batch row-by-row, reusing the same normalisation,
 * deduplication, scoring and interaction-logging pipeline as live webhook intake.
 *
 * Duplicate strategy per batch: 'skip' | 'merge' | 'update'.
 */
class LeadImportService
{
    public function __construct(
        private LeadFileParserService $parserService,
        private LeadImportMappingService $mapper,
        private LeadImportValidationService $validator,
        private LeadNormalizerService $normalizer,
        private LeadDeduplicationService $dedup,
        private LeadScoringService $scoring,
        private LeadInteractionService $interactions,
    ) {}

    /**
     * Parse a freshly uploaded file and return a preview payload
     * (headers, suggested map, first N rows) without persisting leads.
     *
     * @return array{headers: array, rows: array, suggested_map: array, total: int}
     */
    public function preview(string $absolutePath, string $extension, int $sample = 20): array
    {
        $parsed = $this->parserService->parse($absolutePath, $extension);

        return [
            'headers'       => $parsed['headers'],
            'rows'          => array_slice($parsed['rows'], 0, $sample),
            'suggested_map' => $this->mapper->suggestMap($parsed['headers']),
            'total'         => count($parsed['rows']),
        ];
    }

    /**
     * Execute the full import for a batch. The batch must already have its
     * file_path, column_map and duplicate_strategy set.
     */
    public function process(ImportBatch $batch): ImportBatch
    {
        $batch->update(['status' => 'processing']);

        try {
            $path = $batch->file_path;
            if (! $path || ! is_readable($path)) {
                throw new \RuntimeException('Import file is no longer available. Please re-upload.');
            }

            $parsed  = $this->parserService->parse($path, $batch->file_type);
            $rows    = $parsed['rows'];
            $map     = $batch->column_map ?? [];
            $channel = $batch->source_channel;          // SourceChannel enum
            $strategy = $batch->duplicate_strategy;

            $success = $dupes = $failed = 0;

            foreach ($rows as $i => $rawRow) {
                $rowNumber = $i + 1;
                $result = $this->processRow($batch, $rowNumber, $rawRow, $map, $channel, $strategy);

                match ($result) {
                    'imported'          => $success++,
                    'updated', 'merged' => $success++,   // an existing lead was enriched
                    'duplicate'         => $dupes++,     // skipped as duplicate
                    default             => $failed++,
                };

                // Merged/updated rows are also counted as duplicates encountered.
                if (in_array($result, ['updated', 'merged'], true)) {
                    $dupes++;
                }
            }

            $batch->update([
                'total_rows'      => count($rows),
                'successful_rows' => $success,
                'duplicate_rows'  => $dupes,
                'failed_rows'     => $failed,
                'status'          => 'completed',
            ]);
        } catch (\Throwable $e) {
            Log::error('Lead import failed', ['batch' => $batch->id, 'error' => $e->getMessage()]);
            $batch->update(['status' => 'failed', 'error_log' => $e->getMessage()]);
        }

        return $batch->refresh();
    }

    /**
     * Process one row. Returns the row status string.
     */
    private function processRow(
        ImportBatch $batch,
        int $rowNumber,
        array $rawRow,
        array $map,
        SourceChannel $channel,
        string $strategy,
    ): string {
        $mapped = $this->mapper->applyMap($rawRow, $map);

        // Build a normalised attribute set, reusing the shared normaliser.
        $names = $this->normalizer->names(
            $mapped['first_name'] ?? null,
            $mapped['last_name'] ?? null,
            $mapped['full_name'] ?? null,
        );

        $attributes = [
            'first_name'               => $names['first_name'],
            'last_name'                => $names['last_name'],
            'full_name'                => $names['full_name'],
            'email'                    => $this->normalizer->email($mapped['email'] ?? null),
            'phone'                    => $mapped['phone'] ?? null,
            'normalized_phone'         => $this->normalizer->phone($mapped['phone'] ?? null),
            'company'                  => $mapped['company'] ?? null,
            'country'                  => $mapped['country'] ?? null,
            'loc_state'                => $mapped['state'] ?? null,
            'city'                     => $mapped['city'] ?? null,
            'message'                  => $mapped['message'] ?? null,
            'motorsport_interest_type' => $this->normalizer->interest($mapped['motorsport_interest_type'] ?? null),
            'status'                   => $this->resolveStatus($mapped['status'] ?? null),
            'priority'                 => $this->resolvePriority($mapped['priority'] ?? null),
            'source_channel'           => $channel,
        ];

        [$valid, $error] = $this->validator->validate(array_merge($mapped, [
            'full_name' => $attributes['full_name'],
            'email'     => $attributes['email'],
        ]));

        $rowModel = $batch->rows()->create([
            'row_number'  => $rowNumber,
            'raw_data'    => $rawRow,
            'mapped_data' => $this->stringifyAttributes($attributes),
            'status'      => 'pending',
        ]);

        if (! $valid) {
            $rowModel->update(['status' => 'failed', 'error_message' => $error]);
            return 'failed';
        }

        try {
            return DB::transaction(function () use ($attributes, $channel, $strategy, $batch, $rowModel, $mapped) {
                $existing = $this->dedup->findDuplicate($attributes['email'], $attributes['normalized_phone']);

                if ($existing) {
                    return $this->handleDuplicate($existing, $attributes, $channel, $strategy, $batch, $rowModel, $mapped);
                }

                $lead = $this->createLead($attributes, $channel, $batch, $mapped);
                $rowModel->update(['status' => 'imported', 'lead_id' => $lead->id]);

                return 'imported';
            });
        } catch (\Throwable $e) {
            $rowModel->update(['status' => 'failed', 'error_message' => $e->getMessage()]);
            return 'failed';
        }
    }

    private function createLead(array $attributes, SourceChannel $channel, ImportBatch $batch, array $mapped): Lead
    {
        $lead = new Lead($attributes);
        $lead->imported_batch_id = $batch->id;
        $lead->created_by        = $batch->user_id;
        $lead->last_activity_at  = now();
        $this->scoring->apply($lead, submissionCount: 1);
        app(\App\Services\LeadLocationService::class)->stampLead($lead);
        $lead->save();

        if (filled($mapped['notes'] ?? null)) {
            $lead->notes()->create(['user_id' => $batch->user_id, 'type' => 'note', 'body' => $mapped['notes']]);
        }

        $this->interactions->record(
            $lead, InteractionType::CREATED,
            "Lead imported from {$channel->label()} (batch #{$batch->id}, file: {$batch->file_name}).",
            sourceChannel: $channel->value,
            metadata: ['import_batch_id' => $batch->id],
            performedBy: $batch->user_id,
        );

        event(new LeadCreated($lead));
        if ($lead->priority === LeadPriority::Hot) {
            event(new HotLeadReceived($lead));
        }

        return $lead;
    }

    private function handleDuplicate(
        Lead $existing,
        array $attributes,
        SourceChannel $channel,
        string $strategy,
        ImportBatch $batch,
        ImportBatchRow $rowModel,
        array $mapped,
    ): string {
        if ($strategy === 'skip') {
            $rowModel->update(['status' => 'duplicate', 'lead_id' => $existing->id, 'error_message' => 'Duplicate skipped.']);
            return 'duplicate';
        }

        $fillable = $strategy === 'update'
            ? ['email', 'phone', 'normalized_phone', 'company', 'country', 'loc_state', 'city', 'motorsport_interest_type', 'full_name', 'first_name', 'last_name']
            : ['email', 'phone', 'normalized_phone', 'company', 'country', 'loc_state', 'city', 'motorsport_interest_type']; // merge = fill blanks only

        foreach ($fillable as $field) {
            $incoming = $attributes[$field] ?? null;
            if ($incoming === null) {
                continue;
            }
            if ($strategy === 'update' || blank($existing->$field)) {
                $existing->$field = $incoming;
            }
        }

        $existing->last_activity_at = now();
        $existing->save();

        if (filled($mapped['notes'] ?? null) || filled($attributes['message'] ?? null)) {
            $existing->notes()->create([
                'user_id' => $batch->user_id,
                'type'    => 'note',
                'body'    => '[Imported ' . strtoupper($batch->file_type) . "] " . ($mapped['notes'] ?? $attributes['message']),
            ]);
        }

        $verb = $strategy === 'update' ? 'updated' : 'merged';
        $this->interactions->record(
            $existing, InteractionType::DUPLICATE_MERGED,
            "Existing lead {$verb} from import batch #{$batch->id} ({$channel->label()}).",
            sourceChannel: $channel->value,
            metadata: ['import_batch_id' => $batch->id, 'strategy' => $strategy],
            performedBy: $batch->user_id,
        );

        $rowModel->update(['status' => $verb, 'lead_id' => $existing->id]);

        return $verb;
    }

    private function resolveStatus(?string $value): LeadStatus
    {
        if (! $value) {
            return LeadStatus::New;
        }
        $needle = strtolower(trim($value));
        foreach (LeadStatus::cases() as $case) {
            if ($needle === $case->value || $needle === strtolower($case->label())) {
                return $case;
            }
        }
        return LeadStatus::New;
    }

    private function resolvePriority(?string $value): LeadPriority
    {
        if (! $value) {
            return LeadPriority::Medium;
        }
        $needle = strtolower(trim($value));
        foreach (LeadPriority::cases() as $case) {
            if ($needle === $case->value || $needle === strtolower($case->label())) {
                return $case;
            }
        }
        return LeadPriority::Medium;
    }

    /** Convert enum-valued attributes to scalars for JSON storage on the row. */
    private function stringifyAttributes(array $attributes): array
    {
        return array_map(function ($v) {
            if ($v instanceof \BackedEnum) {
                return $v->value;
            }
            return $v;
        }, $attributes);
    }
}
