<?php

namespace App\Enums;

enum DriverContractType: string
{
    case Sponsorship = 'sponsorship_contract';
    case TeamSeat = 'team_seat_contract';
    case DriverManagement = 'driver_management_contract';
    case TrackTime = 'track_time_contract';
    case Coaching = 'coaching_contract';
    case VendorSupport = 'vendor_support_contract';
    case MediaPackage = 'media_package_contract';
    case Other = 'other';

    public function label(): string
    {
        return match ($this) {
            self::Sponsorship      => 'Sponsorship Contract',
            self::TeamSeat         => 'Team Seat Contract',
            self::DriverManagement => 'Driver Management Contract',
            self::TrackTime        => 'Track Time Contract',
            self::Coaching         => 'Coaching Contract',
            self::VendorSupport    => 'Vendor Support Contract',
            self::MediaPackage     => 'Media Package Contract',
            self::Other            => 'Other',
        };
    }

    public function icon(): string
    {
        return match ($this) {
            self::Sponsorship      => 'fa-handshake',
            self::TeamSeat         => 'fa-car',
            self::DriverManagement => 'fa-user-tie',
            self::TrackTime        => 'fa-flag-checkered',
            self::Coaching         => 'fa-chalkboard-user',
            self::VendorSupport    => 'fa-toolbox',
            self::MediaPackage     => 'fa-photo-film',
            self::Other            => 'fa-file-contract',
        };
    }

    public static function options(): array
    {
        return array_map(
            fn (self $t) => ['value' => $t->value, 'label' => $t->label()],
            self::cases()
        );
    }
}
