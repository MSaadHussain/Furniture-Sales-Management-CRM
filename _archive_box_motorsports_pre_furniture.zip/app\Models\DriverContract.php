<?php

namespace App\Models;

use App\Enums\CarType;
use App\Enums\DriverContractStatus;
use App\Enums\DriverContractType;
use App\Enums\DriverRacingLevel;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class DriverContract extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'driver_lead_id', 'sponsor_profile_id', 'sponsorship_deal_id',
        'contract_type', 'contract_status', 'car_type', 'racing_level',
        'contract_value', 'currency', 'start_date', 'end_date', 'signed_date',
        'document_path', 'notes', 'created_by', 'updated_by',
    ];

    protected function casts(): array
    {
        return [
            'contract_type'   => DriverContractType::class,
            'contract_status' => DriverContractStatus::class,
            'car_type'        => CarType::class,
            'racing_level'    => DriverRacingLevel::class,
            'contract_value'  => 'decimal:2',
            'start_date'      => 'date',
            'end_date'        => 'date',
            'signed_date'     => 'date',
        ];
    }

    public function driverLead()
    {
        return $this->belongsTo(DriverLead::class);
    }

    public function sponsor()
    {
        return $this->belongsTo(SponsorProfile::class, 'sponsor_profile_id');
    }

    public function deal()
    {
        return $this->belongsTo(SponsorshipDeal::class, 'sponsorship_deal_id');
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function updater()
    {
        return $this->belongsTo(User::class, 'updated_by');
    }
}
