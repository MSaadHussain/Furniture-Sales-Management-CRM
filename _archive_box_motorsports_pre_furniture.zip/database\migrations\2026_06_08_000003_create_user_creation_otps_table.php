<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('user_creation_otps', function (Blueprint $table) {
            $table->id();
            $table->foreignId('requested_by')->nullable()->constrained('users')->nullOnDelete();
            $table->text('target_user_payload'); // encrypted JSON of the new user
            $table->string('otp_hash');
            $table->string('sent_to_email');
            $table->timestamp('expires_at');
            $table->timestamp('verified_at')->nullable();
            $table->unsignedTinyInteger('attempts')->default(0);
            $table->unsignedTinyInteger('resent_count')->default(0);
            $table->timestamps();

            $table->index(['requested_by', 'verified_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('user_creation_otps');
    }
};
