<?php

namespace App\Enums;

class InteractionType
{
    public const CREATED            = 'lead_created';
    public const WEBHOOK_RECEIVED   = 'webhook_received';
    public const DUPLICATE_MERGED   = 'duplicate_merged';
    public const STATUS_CHANGED     = 'status_changed';
    public const USER_ASSIGNED      = 'user_assigned';
    public const NOTE_ADDED         = 'note_added';
    public const CALL_LOGGED        = 'call_logged';
    public const MEETING_NOTE       = 'meeting_note';
    public const LEAD_EDITED        = 'lead_edited';
    public const PRIORITY_CHANGED   = 'priority_changed';
    public const EMAIL_CAPTURED     = 'email_captured';
    public const WHATSAPP_RECEIVED  = 'whatsapp_received';
    public const MEETING_SCHEDULED  = 'meeting_scheduled';
    public const CLOSED_WON         = 'closed_won';
    public const CLOSED_LOST        = 'closed_lost';
    public const HOT_MARKED         = 'marked_hot';
    public const DELETED            = 'lead_deleted';
    public const RESTORED           = 'lead_restored';
}
