@extends('layouts.app')
@section('title', 'Dashboard')

@section('header_actions')
    <a href="{{ route('leads.create') }}" class="btn btn-primary"><i class="fa-solid fa-plus"></i> New Lead</a>
    <a href="{{ route('driver-leads.create') }}" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Driver's Lead</a>
    <a href="{{ route('sponsors.create') }}" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Sponsor's Lead</a>
@endsection

@section('content')
    {{-- ============ KPI stat cards (click to expand per-type breakdown) ============ --}}
    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <x-expand-stat-card label="Total Leads" :value="number_format($stats['all_total'])" icon="fa-users" iconColor="#465FFF"
            hint="All lead types — click to expand"
            :rows="[
                ['label' => 'Basic Leads',            'icon' => 'fa-users',         'color' => '#465FFF', 'value' => number_format($stats['total']),         'href' => route('leads.index')],
                ['label' => 'Driver Leads',           'icon' => 'fa-helmet-safety', 'color' => '#F04438', 'value' => number_format($stats['driver_total']),  'href' => route('driver-leads.index')],
                ['label' => 'Sponsor & Vendor Leads', 'icon' => 'fa-handshake',     'color' => '#12B76A', 'value' => number_format($stats['sponsor_total']), 'href' => route('sponsors.index')],
            ]" />

        <x-expand-stat-card label="New Today" :value="number_format($stats['new_today'] + $stats['driver_new_today'] + $stats['sponsor_new_today'])" icon="fa-bolt" iconColor="#7A5AF8"
            hint="All lead types — click to expand"
            :rows="[
                ['label' => 'Basic Leads',   'icon' => 'fa-users',         'color' => '#465FFF', 'value' => number_format($stats['new_today']),         'href' => route('leads.index', ['date_preset' => 'today'])],
                ['label' => 'Driver Leads',  'icon' => 'fa-helmet-safety', 'color' => '#F04438', 'value' => number_format($stats['driver_new_today']),  'href' => route('driver-leads.index')],
                ['label' => 'Sponsor Leads', 'icon' => 'fa-handshake',     'color' => '#12B76A', 'value' => number_format($stats['sponsor_new_today']), 'href' => route('sponsors.index')],
            ]" />

        <x-expand-stat-card label="Hot" :value="number_format($stats['hot'] + $stats['deals_hot'])" icon="fa-fire" iconColor="#F04438"
            hint="Hot leads + hot deals — click to expand"
            :rows="[
                ['label' => 'Hot Basic Leads', 'icon' => 'fa-users',      'color' => '#465FFF', 'value' => number_format($stats['hot']),       'href' => route('leads.index', ['priority' => 'hot'])],
                ['label' => 'Hot Open Deals',  'icon' => 'fa-sack-dollar','color' => '#F79009', 'value' => number_format($stats['deals_hot']), 'href' => route('sponsorship-pipeline.index')],
            ]" />

        <x-expand-stat-card label="Conversion" :value="$stats['overall_conversion'].'%'" icon="fa-percent" iconColor="#12B76A"
            hint="Won across all types — click to expand"
            :rows="[
                ['label' => 'Basic Leads Won',   'icon' => 'fa-users',         'color' => '#465FFF', 'value' => $stats['conversion'].'%',        'href' => route('leads.index', ['status' => 'closed_won'])],
                ['label' => 'Drivers Qualified', 'icon' => 'fa-helmet-safety', 'color' => '#F04438', 'value' => $stats['driver_conversion'].'%', 'href' => route('driver-leads.index', ['status' => 'qualified'])],
                ['label' => 'Deals Won',         'icon' => 'fa-sack-dollar',   'color' => '#F79009', 'value' => $stats['deal_conversion'].'%',   'href' => route('sponsorship-pipeline.index')],
            ]" />
    </div>

    <div class="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <x-expand-stat-card label="Contacted" :value="number_format($stats['contacted'] + $stats['driver_contacted'])" icon="fa-phone" iconColor="#2E90FA"
            hint="Basic + driver leads — click to expand"
            :rows="[
                ['label' => 'Basic Leads',  'icon' => 'fa-users',         'color' => '#465FFF', 'value' => number_format($stats['contacted']),        'href' => route('leads.index', ['status' => 'contacted'])],
                ['label' => 'Driver Leads', 'icon' => 'fa-helmet-safety', 'color' => '#F04438', 'value' => number_format($stats['driver_contacted']), 'href' => route('driver-leads.index', ['status' => 'contacted'])],
            ]" />

        <x-stat-card label="Meetings"       :value="number_format($stats['meeting_scheduled'])" icon="fa-calendar-check" iconColor="#465FFF" :href="route('meetings.index')" />

        <x-expand-stat-card label="Closed Won" :value="number_format($stats['closed_won'] + $stats['driver_qualified'] + $stats['deals_won'])" icon="fa-trophy" iconColor="#12B76A"
            hint="Won + qualified across all types"
            :rows="[
                ['label' => 'Basic Leads Won',   'icon' => 'fa-users',         'color' => '#465FFF', 'value' => number_format($stats['closed_won']),       'href' => route('leads.index', ['status' => 'closed_won'])],
                ['label' => 'Drivers Qualified', 'icon' => 'fa-helmet-safety', 'color' => '#F04438', 'value' => number_format($stats['driver_qualified']), 'href' => route('driver-leads.index', ['status' => 'qualified'])],
                ['label' => 'Deals Won',         'icon' => 'fa-sack-dollar',   'color' => '#F79009', 'value' => number_format($stats['deals_won']),        'href' => route('sponsorship-pipeline.index')],
            ]" />

        <x-expand-stat-card label="Closed Lost" :value="number_format($stats['closed_lost'] + $stats['driver_declined'] + $stats['deals_lost'])" icon="fa-circle-xmark" iconColor="#F04438"
            hint="Lost + declined across all types"
            :rows="[
                ['label' => 'Basic Leads Lost', 'icon' => 'fa-users',         'color' => '#465FFF', 'value' => number_format($stats['closed_lost']),     'href' => route('leads.index', ['status' => 'closed_lost'])],
                ['label' => 'Drivers Declined', 'icon' => 'fa-helmet-safety', 'color' => '#F04438', 'value' => number_format($stats['driver_declined']), 'href' => route('driver-leads.index', ['status' => 'declined'])],
                ['label' => 'Deals Lost',       'icon' => 'fa-sack-dollar',   'color' => '#F79009', 'value' => number_format($stats['deals_lost']),      'href' => route('sponsorship-pipeline.index')],
            ]" />
    </div>

    {{-- ============ Channel breakdown cards (Phase 7) ============ --}}
    <div class="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-3 xl:grid-cols-5">
        <x-expand-stat-card label="New This Week" :value="number_format($stats['new_week'] + $stats['driver_new_week'] + $stats['sponsor_new_week'])" icon="fa-calendar-week" iconColor="#7A5AF8"
            hint="All lead types"
            :rows="[
                ['label' => 'Basic Leads',   'icon' => 'fa-users',         'color' => '#465FFF', 'value' => number_format($stats['new_week']),         'href' => route('leads.index', ['date_preset' => 'week'])],
                ['label' => 'Driver Leads',  'icon' => 'fa-helmet-safety', 'color' => '#F04438', 'value' => number_format($stats['driver_new_week']),  'href' => route('driver-leads.index')],
                ['label' => 'Sponsor Leads', 'icon' => 'fa-handshake',     'color' => '#12B76A', 'value' => number_format($stats['sponsor_new_week']), 'href' => route('sponsors.index')],
            ]" />
        <x-stat-card label="Imported"      :value="number_format($stats['imported'])"  icon="fa-file-import"   iconColor="#0F9D58" :href="route('leads.index', ['source_channel' => 'imported_csv'])" />
        <x-stat-card label="Meta Leads"    :value="number_format($stats['meta'])"       :img="asset('icons/meta.png')"   iconColor="#0866FF" :href="route('leads.index', ['source_channel' => 'meta'])" />
        <x-stat-card label="Google Leads"  :value="number_format($stats['google'])"     :img="asset('icons/google.svg')" iconColor="#EA4335" :href="route('leads.index', ['source_channel' => 'google_lead_form'])" />
        <x-stat-card label="Meetings"      :value="number_format($stats['meetings_count'])" icon="fa-video"     iconColor="#00897B" :href="route('meetings.index')" />
    </div>

    {{-- ============ Analytics: overall by default, click a tab to drill into one type ============ --}}
    <div class="mt-8" x-data="{ type: 'all' }" x-init="$watch('type', v => window.renderDashCharts && window.renderDashCharts(v))">
        <div class="mb-4 flex flex-wrap items-center justify-between gap-3">
            <div>
                <h2 class="text-xl font-semibold text-ink dark:text-white">Analytics</h2>
                <p class="text-sm text-muted">Showing <span class="font-medium" x-text="({all:'all lead types combined',basic:'Basic Leads only',drivers:'Driver Leads only',sponsors:'Sponsors & Vendors only'})[type]"></span></p>
            </div>
            <div class="inline-flex flex-wrap gap-1 rounded-xl border border-line bg-surface p-1 dark:border-strokedark dark:bg-boxdark">
                @foreach (['all' => 'Overall', 'basic' => 'Basic Leads', 'drivers' => 'Driver Leads', 'sponsors' => 'Sponsors'] as $key => $label)
                    <button type="button" @click="type = '{{ $key }}'"
                        :class="type === '{{ $key }}' ? 'bg-brand text-white shadow-sm' : 'text-muted hover:text-ink dark:hover:text-white'"
                        class="rounded-lg px-3 py-1.5 text-sm font-medium transition">{{ $label }}</button>
                @endforeach
            </div>
        </div>

        {{-- Charts row 1 --}}
        <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
            <x-card class="lg:col-span-2">
                <div class="mb-5"><h3 class="text-lg font-semibold text-ink dark:text-white">Records Over Time</h3><p class="mt-0.5 text-sm text-muted">Last 14 days</p></div>
                <div class="h-72"><canvas id="timelineChart"></canvas></div>
            </x-card>

            <x-card>
                <div class="mb-5"><h3 id="compositionTitle" class="text-lg font-semibold text-ink dark:text-white">Composition</h3></div>
                <div class="flex h-72 items-center justify-center"><canvas id="compositionChart"></canvas></div>
            </x-card>
        </div>

        {{-- Charts row 2 --}}
        <div class="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
            <x-card>
                <div class="mb-5"><h3 id="statusTitle" class="text-lg font-semibold text-ink dark:text-white">Status</h3></div>
                <div class="h-72"><canvas id="statusChart"></canvas></div>
            </x-card>
            <x-card>
                <div class="mb-5"><h3 id="funnelTitle" class="text-lg font-semibold text-ink dark:text-white">Pipeline</h3></div>
                <div class="h-72"><canvas id="funnelChart"></canvas></div>
            </x-card>
        </div>
    </div>

    {{-- ============ Location map ============ --}}
    <div class="mt-6">
        <x-location-map :presets="$datePresets" :sources="$sourceOptions" :compact="true" />
    </div>

    {{-- ============ Recent leads + activity ============ --}}
    <div class="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">

        {{-- Recent leads --}}
        <x-card padding="p-0">
            <div class="flex items-center justify-between border-b border-line px-6 py-4 dark:border-strokedark">
                <h3 class="text-lg font-semibold text-ink dark:text-white">Recent Leads</h3>
                <a href="{{ route('leads.index') }}" class="text-sm font-medium text-brand">View all</a>
            </div>
            <div class="divide-y divide-line dark:divide-strokedark">
                @forelse ($recentLeads as $lead)
                    <a href="{{ route('leads.show', $lead) }}"
                       class="flex items-center justify-between gap-3 px-6 py-3.5 transition hover:bg-surface dark:hover:bg-boxdark">
                        <div class="flex items-center gap-3">
                            <span class="flex h-9 w-9 items-center justify-center rounded-full text-xs font-bold text-white"
                                  style="background-color: {{ $lead->source_channel->color() }};">
                                {{ strtoupper(mb_substr($lead->full_name ?: 'NA', 0, 2)) }}
                            </span>
                            <div>
                                <p class="text-sm font-medium text-ink dark:text-gray-200">{{ $lead->full_name ?: 'Unnamed' }}</p>
                                <p class="text-xs text-muted">{{ $lead->source_channel->label() }}</p>
                            </div>
                        </div>
                        <x-badge :label="$lead->status->label()" :color="$lead->status->color()" />
                    </a>
                @empty
                    <p class="px-6 py-10 text-center text-sm text-muted">No leads yet.</p>
                @endforelse
            </div>
        </x-card>

        {{-- Recent activity timeline --}}
        <x-card title="Recent Activity">
            <div class="space-y-5">
                @forelse ($recentActivity as $event)
                    <div class="flex gap-3">
                        <div class="flex flex-col items-center">
                            <span class="mt-1.5 h-2.5 w-2.5 flex-shrink-0 rounded-full bg-brand"></span>
                            @unless ($loop->last)<span class="mt-1 w-px flex-1 bg-line dark:bg-strokedark"></span>@endunless
                        </div>
                        <div class="min-w-0 pb-1">
                            <p class="text-sm text-ink dark:text-gray-200">
                                <a href="{{ route('leads.show', $event->lead_id) }}" class="font-medium text-brand">
                                    {{ $event->lead?->full_name ?: 'Lead #'.$event->lead_id }}
                                </a>
                                <span class="text-muted">&mdash; {{ \Illuminate\Support\Str::headline($event->action_type) }}</span>
                            </p>
                            <p class="mt-0.5 text-xs text-muted">
                                {{ $event->performer?->name ?? 'System' }} &middot; {{ $event->created_at->diffForHumans() }}
                            </p>
                        </div>
                    </div>
                @empty
                    <p class="text-sm text-muted">No activity yet.</p>
                @endforelse
            </div>
        </x-card>
    </div>
@endsection

@push('scripts')
<script>
(function () {
    const CH = @json($dashCharts);
    const charts = {};
    let ready = false;

    function theme() {
        const dark = document.documentElement.classList.contains('dark');
        return {
            grid: dark ? 'rgba(255,255,255,0.08)' : 'rgba(16,24,40,0.06)',
            tick: dark ? '#94a3b8' : '#667085',
        };
    }

    const el = (id) => document.getElementById(id);
    const setTitle = (id, text) => { const e = el(id); if (e) e.textContent = text; };
    function draw(id, cfg) {
        const node = el(id);
        if (!node) return;
        if (charts[id]) charts[id].destroy();
        charts[id] = new Chart(node, cfg);
    }

    function renderTimeline(type) {
        const t = theme();
        const tl = CH.timeline;
        const meta = { basic: ['Basic Leads', '#465FFF'], drivers: ['Driver Leads', '#F04438'], sponsors: ['Sponsors', '#12B76A'] };
        const keys = type === 'all' ? ['basic', 'drivers', 'sponsors'] : [type];
        const datasets = keys.map(k => ({
            label: meta[k][0], data: tl[k], borderColor: meta[k][1],
            backgroundColor: meta[k][1] + '22', fill: keys.length === 1,
            tension: 0.4, pointRadius: 2, pointBackgroundColor: meta[k][1], borderWidth: 2,
        }));
        draw('timelineChart', {
            type: 'line',
            data: { labels: tl.labels, datasets },
            options: { responsive: true, maintainAspectRatio: false,
                plugins: { legend: { display: keys.length > 1, position: 'bottom', labels: { padding: 14, usePointStyle: true } } },
                scales: { y: { beginAtZero: true, grid: { color: t.grid } }, x: { grid: { display: false } } } },
        });
    }

    function renderDoughnut(id, titleId, block) {
        setTitle(titleId, block.title);
        const d = block.data;
        draw(id, {
            type: 'doughnut',
            data: { labels: d.map(x => x.label), datasets: [{ data: d.map(x => x.value), backgroundColor: d.map(x => x.color), borderWidth: 0 }] },
            options: { responsive: true, maintainAspectRatio: false, cutout: '68%',
                plugins: { legend: { position: 'bottom', labels: { padding: 12, usePointStyle: true } } } },
        });
    }

    function renderBar(id, titleId, block, horizontal) {
        const t = theme();
        setTitle(titleId, block.title);
        const d = block.data;
        draw(id, {
            type: 'bar',
            data: { labels: d.map(x => x.label), datasets: [{ data: d.map(x => x.value), backgroundColor: d.map(x => x.color), borderRadius: 6, maxBarThickness: horizontal ? 28 : 38 }] },
            options: { indexAxis: horizontal ? 'y' : 'x', responsive: true, maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: horizontal
                    ? { x: { beginAtZero: true, grid: { color: t.grid } }, y: { grid: { display: false } } }
                    : { y: { beginAtZero: true, grid: { color: t.grid } }, x: { grid: { display: false } } } },
        });
    }

    function render(type) {
        if (!ready) return;
        renderTimeline(type);
        renderDoughnut('compositionChart', 'compositionTitle', CH.composition[type]);
        renderBar('statusChart', 'statusTitle', CH.status[type], false);
        renderBar('funnelChart', 'funnelTitle', CH.funnel[type], true);
    }

    // Expose so the Alpine tab toggle can trigger re-render.
    window.renderDashCharts = render;

    function boot() {
        if (typeof Chart === 'undefined') return false;
        Chart.defaults.color = theme().tick;
        Chart.defaults.font.family = "'Outfit', sans-serif";
        ready = true;
        render('all');
        return true;
    }

    if (!boot()) {
        let tries = 0;
        const timer = setInterval(function () { if (boot() || ++tries > 20) clearInterval(timer); }, 150);
    }
})();
</script>
@endpush