<?php

namespace App\Enums;

use App\Models\DriverLead;

enum DriverTier: string
{
    case Amateur = 'amateur';
    case ProAm = 'pro_am';
    case Professional = 'professional';
    case Development = 'development';
    case Elite = 'elite';

    public function label(): string
    {
        return match ($this) {
            self::Development  => 'Development',
            self::Amateur      => 'Amateur',
            self::ProAm        => 'Pro-Am',
            self::Professional => 'Professional',
            self::Elite        => 'Elite',
        };
    }

    public function color(): string
    {
        return match ($this) {
            self::Development  => '#0EA5E9',
            self::Amateur      => '#6B7280',
            self::ProAm        => '#F59E0B',
            self::Professional => '#16A34A',
            self::Elite        => '#7C3AED',
        };
    }

    /** Legacy inference from experience numbers only. Kept for old call sites. */
    public static function infer(int $yearsRacing, int $careerWins): self
    {
        if ($yearsRacing >= 5 && $careerWins >= 20) {
            return self::Professional;
        }

        if ($yearsRacing >= 3 && $careerWins >= 5) {
            return self::ProAm;
        }

        return self::Amateur;
    }

    /**
     * Richer inference using racing level, age (from DOB), wins, and experience.
     * Racing level dominates when set; otherwise falls back to the legacy
     * experience-based logic. Car type is NEVER used to infer anything.
     */
    public static function inferFromDriver(DriverLead $driver): self
    {
        $age   = $driver->age; // null when DOB unknown
        $wins  = (int) $driver->career_wins;
        $years = (int) $driver->years_racing;

        switch ($driver->racing_level) {
            case DriverRacingLevel::Formula1:
                return self::Elite;

            case DriverRacingLevel::Formula2:
                return self::Professional;

            case DriverRacingLevel::Formula3:
                return $wins >= 5 ? self::ProAm : self::Development;

            case DriverRacingLevel::Formula4:
                if ($age !== null && $age >= 16 && $age <= 18) {
                    return $wins >= 10 ? self::ProAm : self::Development;
                }
                return $wins >= 10 ? self::ProAm : self::Development;

            case DriverRacingLevel::Karting:
                return ($age !== null && $age < 16) ? self::Development : self::Amateur;

            default:
                // No racing level (or non-formula disciplines): experience-based.
                if ($years >= 8 && $wins >= 50) {
                    return self::Elite;
                }
                return self::infer($years, $wins);
        }
    }

    public static function options(): array
    {
        return array_map(
            fn (self $t) => ['value' => $t->value, 'label' => $t->label(), 'color' => $t->color()],
            self::cases()
        );
    }
}
