<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\IntegrationController;
use App\Http\Controllers\LeadBulkController;
use App\Http\Controllers\LeadController;
use App\Http\Controllers\LeadExportController;
use App\Http\Controllers\LeadNoteController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\PipelineController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return redirect()->route('dashboard');
});

Route::middleware(['auth', 'verified', 'password.24h', 'track.activity'])->group(function () {
    // Dashboard
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/dashboard/location-data', [\App\Http\Controllers\DashboardLocationController::class, 'data'])->name('dashboard.location-data');

    // Leads
    Route::get('leads/export', LeadExportController::class)->name('leads.export');
    Route::post('leads/bulk', [LeadBulkController::class, 'update'])->name('leads.bulk');
    Route::get('leads/trash', [LeadController::class, 'trash'])->name('leads.trash');
    Route::delete('leads/{leadId}/force', [LeadController::class, 'forceDelete'])->name('leads.force')->withTrashed();

    // Lead Import (must be declared before the leads resource so /leads/import
    // is not swallowed by the /leads/{lead} wildcard).
    Route::prefix('leads/import')->name('leads.import.')->group(function () {
        Route::get('/', [\App\Http\Controllers\LeadImportController::class, 'index'])->name('index');
        Route::post('upload', [\App\Http\Controllers\LeadImportController::class, 'upload'])->name('upload');
        Route::post('preview/{batch}', [\App\Http\Controllers\LeadImportController::class, 'preview'])->name('preview');
        Route::post('confirm/{batch}', [\App\Http\Controllers\LeadImportController::class, 'confirm'])->name('confirm');
        Route::get('batches', [\App\Http\Controllers\LeadImportController::class, 'batches'])->name('batches');
        Route::get('batches/{batch}', [\App\Http\Controllers\LeadImportController::class, 'show'])->name('batches.show');
        Route::get('batches/{batch}/failed-download', [\App\Http\Controllers\LeadImportController::class, 'downloadFailed'])->name('batches.failed');
    });

    Route::resource('leads', LeadController::class);
    Route::patch('leads/{lead}/status', [LeadController::class, 'updateStatus'])->name('leads.status');
    Route::patch('leads/{lead}/assign', [LeadController::class, 'assign'])->name('leads.assign');
    Route::patch('leads/{lead}/mark-hot', [LeadController::class, 'markHot'])->name('leads.markHot');
    Route::patch('leads/{leadId}/restore', [LeadController::class, 'restore'])->name('leads.restore')->withTrashed();
    Route::post('leads/{lead}/notes', [LeadNoteController::class, 'store'])->name('leads.notes.store');

    // Driver Leads
    Route::prefix('driver-leads')->name('driver-leads.')->group(function () {
        Route::get('trash', [\App\Http\Controllers\DriverLeadController::class, 'trash'])->name('trash');
        Route::patch('{id}/restore', [\App\Http\Controllers\DriverLeadController::class, 'restore'])->name('restore');
        Route::delete('{id}/force', [\App\Http\Controllers\DriverLeadController::class, 'forceDelete'])->name('force');

        Route::get('import', [\App\Http\Controllers\DriverLeadController::class, 'import'])->name('import');
        Route::post('import/upload', [\App\Http\Controllers\DriverLeadController::class, 'importUpload'])->name('import.upload');
        Route::post('import/confirm', [\App\Http\Controllers\DriverLeadController::class, 'importConfirm'])->name('import.confirm');
        Route::get('import/template', [\App\Http\Controllers\DriverLeadController::class, 'downloadTemplate'])->name('import.template');
        Route::get('export', [\App\Http\Controllers\DriverLeadController::class, 'export'])->name('export');

        Route::get('/', [\App\Http\Controllers\DriverLeadController::class, 'index'])->name('index');
        Route::get('create', [\App\Http\Controllers\DriverLeadController::class, 'create'])->name('create');
        Route::post('/', [\App\Http\Controllers\DriverLeadController::class, 'store'])->name('store');
        Route::get('{driverLead}', [\App\Http\Controllers\DriverLeadController::class, 'show'])->name('show');
        Route::delete('{driverLead}', [\App\Http\Controllers\DriverLeadController::class, 'destroy'])->name('destroy');
        Route::patch('{driverLead}/status', [\App\Http\Controllers\DriverLeadController::class, 'updateStatus'])->name('status');
        Route::patch('{driverLead}/qualify', [\App\Http\Controllers\DriverLeadController::class, 'qualify'])->name('qualify');
        Route::patch('{driverLead}/decline', [\App\Http\Controllers\DriverLeadController::class, 'decline'])->name('decline');
        Route::post('{driverLead}/comments', [\App\Http\Controllers\DriverLeadController::class, 'comment'])->name('comments.store');
        Route::patch('{driverLead}', [\App\Http\Controllers\DriverLeadController::class, 'update'])->name('update');
        Route::post('{driverLead}/contracts', [\App\Http\Controllers\DriverContractController::class, 'store'])->name('contracts.store');
    });

    // Driver Contracts
    Route::patch('driver-contracts/{contract}', [\App\Http\Controllers\DriverContractController::class, 'update'])->name('driver-contracts.update');
    Route::patch('driver-contracts/{contract}/status', [\App\Http\Controllers\DriverContractController::class, 'changeStatus'])->name('driver-contracts.status');
    Route::delete('driver-contracts/{contract}', [\App\Http\Controllers\DriverContractController::class, 'destroy'])->name('driver-contracts.destroy');

    // Pipeline
    Route::get('pipeline', [PipelineController::class, 'index'])->name('pipeline.index');
    Route::patch('pipeline/{lead}/move', [PipelineController::class, 'move'])->name('pipeline.move');

    // Sponsors & Vendors (Vendor & Sponsor Space)
    // Trash + Import are declared before the resource so /sponsors/trash and
    // /sponsors/import are not swallowed by the /sponsors/{sponsor} wildcard.
    Route::get('sponsors/trash', [\App\Http\Controllers\SponsorProfileController::class, 'trash'])->name('sponsors.trash');
    Route::patch('sponsors/{id}/restore', [\App\Http\Controllers\SponsorProfileController::class, 'restore'])->name('sponsors.restore');
    Route::delete('sponsors/{id}/force', [\App\Http\Controllers\SponsorProfileController::class, 'forceDelete'])->name('sponsors.force');
    Route::get('sponsors/export', [\App\Http\Controllers\SponsorProfileController::class, 'export'])->name('sponsors.export');
    Route::get('sponsors/import', [\App\Http\Controllers\SponsorProfileController::class, 'import'])->name('sponsors.import');
    Route::post('sponsors/import/upload', [\App\Http\Controllers\SponsorProfileController::class, 'importUpload'])->name('sponsors.import.upload');
    Route::post('sponsors/import/confirm', [\App\Http\Controllers\SponsorProfileController::class, 'importConfirm'])->name('sponsors.import.confirm');
    Route::get('sponsors/import/template', [\App\Http\Controllers\SponsorProfileController::class, 'downloadTemplate'])->name('sponsors.import.template');
    Route::resource('sponsors', \App\Http\Controllers\SponsorProfileController::class)
        ->parameters(['sponsors' => 'sponsor']);
    Route::post('sponsors/{sponsor}/activities', [\App\Http\Controllers\SponsorActivityController::class, 'store'])->name('sponsors.activities.store');
    Route::patch('sponsor-activities/{activity}/complete', [\App\Http\Controllers\SponsorActivityController::class, 'complete'])->name('sponsor-activities.complete');
    Route::delete('sponsor-activities/{activity}', [\App\Http\Controllers\SponsorActivityController::class, 'destroy'])->name('sponsor-activities.destroy');
    Route::post('sponsors/{sponsor}/link-driver', [\App\Http\Controllers\SponsorDriverLinkController::class, 'store'])->name('sponsors.link-driver');
    Route::patch('sponsor-driver-links/{link}', [\App\Http\Controllers\SponsorDriverLinkController::class, 'update'])->name('sponsor-driver-links.update');
    Route::delete('sponsor-driver-links/{link}', [\App\Http\Controllers\SponsorDriverLinkController::class, 'destroy'])->name('sponsor-driver-links.destroy');

    // Sponsorship Pipeline (Kanban)
    Route::get('sponsorship-pipeline', [\App\Http\Controllers\SponsorshipPipelineController::class, 'index'])->name('sponsorship-pipeline.index');
    Route::post('sponsorship-pipeline', [\App\Http\Controllers\SponsorshipPipelineController::class, 'store'])->name('sponsorship-pipeline.store');
    Route::patch('sponsorship-pipeline/{deal}', [\App\Http\Controllers\SponsorshipPipelineController::class, 'update'])->name('sponsorship-pipeline.update');
    Route::patch('sponsorship-pipeline/{deal}/stage', [\App\Http\Controllers\SponsorshipPipelineController::class, 'moveStage'])->name('sponsorship-pipeline.stage');
    Route::delete('sponsorship-pipeline/{deal}', [\App\Http\Controllers\SponsorshipPipelineController::class, 'destroy'])->name('sponsorship-pipeline.destroy');

    // Reports
    Route::get('reports', [ReportController::class, 'index'])->name('reports.index');
    Route::get('reports/location', [\App\Http\Controllers\DashboardLocationController::class, 'report'])->name('reports.location');
    Route::get('reports/export', [ReportController::class, 'export'])->name('reports.export');
    Route::get('reports/drivers', [\App\Http\Controllers\DriverLeadReportController::class, 'index'])->name('reports.drivers');
    Route::get('reports/drivers/export', [\App\Http\Controllers\DriverLeadReportController::class, 'export'])->name('reports.drivers.export');
    Route::get('reports/sponsors', [\App\Http\Controllers\SponsorReportController::class, 'index'])->name('reports.sponsors');
    Route::get('reports/sponsors/export', [\App\Http\Controllers\SponsorReportController::class, 'export'])->name('reports.sponsors.export');
    // Phase 4 — Super Admin: user activity & time-spent reports
    Route::get('activity/logs', [\App\Http\Controllers\ActivityController::class, 'logs'])->name('activity.logs');
    Route::get('activity/sessions', [\App\Http\Controllers\ActivityController::class, 'sessions'])->name('activity.sessions');

    // Notifications
    Route::get('notifications', [NotificationController::class, 'index'])->name('notifications.index');
    Route::post('notifications/{id}/read', [NotificationController::class, 'markRead'])->name('notifications.read');
    Route::post('notifications/read-all', [NotificationController::class, 'markAllRead'])->name('notifications.readAll');

    // Users (admins only)
    Route::resource('users', UserController::class)->except(['show']);
    Route::patch('users/{user}/toggle', [UserController::class, 'toggleActive'])->name('users.toggle');
    // Phase 5 — user-creation OTP approval flow
    Route::get('users-otp/{otp}/verify', [UserController::class, 'verifyOtpForm'])->name('users.verify-otp.form');
    Route::post('users-otp/{otp}/verify', [UserController::class, 'verifyOtp'])->name('users.verify-otp');
    Route::post('users-otp/{otp}/resend', [UserController::class, 'resendOtp'])->name('users.verify-otp.resend');

    // Integrations (admins only)
    Route::get('integrations', [IntegrationController::class, 'index'])->name('integrations.index');
    Route::patch('integrations/{channel}', [IntegrationController::class, 'update'])->name('integrations.update');
    Route::post('integrations/{channel}/regenerate', [IntegrationController::class, 'regenerateSecret'])->name('integrations.regenerate');
    Route::post('integrations/{channel}/test', [IntegrationController::class, 'test'])->name('integrations.test');

    // Settings (admins only)
    Route::get('settings', [\App\Http\Controllers\SettingsController::class, 'index'])->name('settings.index');    Route::patch('settings', [\App\Http\Controllers\SettingsController::class, 'update'])->name('settings.update');
    Route::post('settings/weekly-report/send', [\App\Http\Controllers\SettingsController::class, 'sendWeeklyNow'])->name('settings.weekly-report.send');
    Route::post('settings/dummy-data', [\App\Http\Controllers\SettingsController::class, 'generateDummyData'])->name('settings.dummy-data.generate');
    Route::post('settings/dummy-data/clear', [\App\Http\Controllers\SettingsController::class, 'clearDummyData'])->name('settings.dummy-data.clear');
    // Phase 3 — Security settings (Admin / Super Admin)
    Route::get('settings/security', [\App\Http\Controllers\SecurityController::class, 'index'])->name('settings.security');
    Route::patch('settings/security', [\App\Http\Controllers\SecurityController::class, 'update'])->name('settings.security.update');

    // Integration: Meta Lead Ads
    Route::get('integrations/meta', [\App\Http\Controllers\MetaLeadController::class, 'index'])->name('integrations.meta');
    Route::post('integrations/meta/save', [\App\Http\Controllers\MetaLeadController::class, 'save'])->name('integrations.meta.save');
    Route::post('integrations/meta/test', [\App\Http\Controllers\MetaLeadController::class, 'test'])->name('integrations.meta.test');

    // Integration: Google Leads
    Route::get('integrations/google-leads', [\App\Http\Controllers\GoogleLeadController::class, 'index'])->name('integrations.google-leads');
    Route::post('integrations/google-leads/save', [\App\Http\Controllers\GoogleLeadController::class, 'save'])->name('integrations.google-leads.save');
    Route::post('integrations/google-leads/test', [\App\Http\Controllers\GoogleLeadController::class, 'test'])->name('integrations.google-leads.test');

    // Integration: Google Contact Form (Normal Google Forms)
    Route::get('integrations/google-contact-form', [\App\Http\Controllers\GoogleContactFormController::class, 'index'])->name('integrations.google-contact-form');
    Route::post('integrations/google-contact-form/save', [\App\Http\Controllers\GoogleContactFormController::class, 'save'])->name('integrations.google-contact-form.save');
    Route::post('integrations/google-contact-form/regenerate', [\App\Http\Controllers\GoogleContactFormController::class, 'regenerateSecret'])->name('integrations.google-contact-form.regenerate');
    Route::post('integrations/google-contact-form/test', [\App\Http\Controllers\GoogleContactFormController::class, 'test'])->name('integrations.google-contact-form.test');

    // Meetings (calendar)
    Route::get('meetings', [\App\Http\Controllers\MeetingController::class, 'index'])->name('meetings.index');
    Route::get('meetings/search', [\App\Http\Controllers\MeetingController::class, 'search'])->name('meetings.search');
    Route::post('meetings/schedule', [\App\Http\Controllers\MeetingController::class, 'schedule'])->name('meetings.schedule');
    Route::post('leads/{lead}/meetings/google-meet', [\App\Http\Controllers\MeetingController::class, 'googleMeet'])->name('leads.meetings.google-meet');
    Route::post('leads/{lead}/meetings/zoom', [\App\Http\Controllers\MeetingController::class, 'zoom'])->name('leads.meetings.zoom');
    Route::post('leads/{lead}/meetings/calendly-link', [\App\Http\Controllers\MeetingController::class, 'calendlyLink'])->name('leads.meetings.calendly-link');
    Route::delete('meetings/{meeting}', [\App\Http\Controllers\MeetingController::class, 'destroy'])->name('meetings.destroy');
    // Driver Lead meetings
    Route::post('driver-leads/{driverLead}/meetings/google-meet', [\App\Http\Controllers\MeetingController::class, 'driverGoogleMeet'])->name('driver-leads.meetings.google-meet');
    Route::post('driver-leads/{driverLead}/meetings/zoom', [\App\Http\Controllers\MeetingController::class, 'driverZoom'])->name('driver-leads.meetings.zoom');
    Route::post('driver-leads/{driverLead}/meetings/calendly-link', [\App\Http\Controllers\MeetingController::class, 'driverCalendlyLink'])->name('driver-leads.meetings.calendly-link');
    // Sponsor meetings
    Route::post('sponsors/{sponsor}/meetings/google-meet', [\App\Http\Controllers\MeetingController::class, 'sponsorGoogleMeet'])->name('sponsors.meetings.google-meet');
    Route::post('sponsors/{sponsor}/meetings/zoom', [\App\Http\Controllers\MeetingController::class, 'sponsorZoom'])->name('sponsors.meetings.zoom');
    Route::post('sponsors/{sponsor}/meetings/calendly-link', [\App\Http\Controllers\MeetingController::class, 'sponsorCalendlyLink'])->name('sponsors.meetings.calendly-link');

    // Integration: Driver Lead Form
    Route::get('integrations/driver-lead-form', [\App\Http\Controllers\DriverLeadFormController::class, 'index'])->name('integrations.driver-lead-form');
    Route::post('integrations/driver-lead-form/save', [\App\Http\Controllers\DriverLeadFormController::class, 'save'])->name('integrations.driver-lead-form.save');
    Route::post('integrations/driver-lead-form/regenerate', [\App\Http\Controllers\DriverLeadFormController::class, 'regenerateSecret'])->name('integrations.driver-lead-form.regenerate');
    Route::post('integrations/driver-lead-form/test', [\App\Http\Controllers\DriverLeadFormController::class, 'test'])->name('integrations.driver-lead-form.test');

    // Integration: Sponsor Lead Form
    Route::get('integrations/sponsor-lead-form', [\App\Http\Controllers\SponsorLeadFormController::class, 'index'])->name('integrations.sponsor-lead-form');
    Route::post('integrations/sponsor-lead-form/save', [\App\Http\Controllers\SponsorLeadFormController::class, 'save'])->name('integrations.sponsor-lead-form.save');
    Route::post('integrations/sponsor-lead-form/regenerate', [\App\Http\Controllers\SponsorLeadFormController::class, 'regenerateSecret'])->name('integrations.sponsor-lead-form.regenerate');
    Route::post('integrations/sponsor-lead-form/test', [\App\Http\Controllers\SponsorLeadFormController::class, 'test'])->name('integrations.sponsor-lead-form.test');

    // Integration: Meetings (Google Meet + Calendly)
    Route::get('integrations/meetings', [\App\Http\Controllers\MeetingIntegrationController::class, 'index'])->name('integrations.meetings');
    Route::post('integrations/google-meet/save', [\App\Http\Controllers\MeetingIntegrationController::class, 'saveGoogle'])->name('integrations.google-meet.save');
    Route::post('integrations/google-meet/test', [\App\Http\Controllers\MeetingIntegrationController::class, 'testGoogle'])->name('integrations.google-meet.test');
    Route::post('integrations/calendly/save', [\App\Http\Controllers\MeetingIntegrationController::class, 'saveCalendly'])->name('integrations.calendly.save');
    Route::post('integrations/calendly/test', [\App\Http\Controllers\MeetingIntegrationController::class, 'testCalendly'])->name('integrations.calendly.test');
    Route::post('integrations/zoom/save', [\App\Http\Controllers\MeetingIntegrationController::class, 'saveZoom'])->name('integrations.zoom.save');
    Route::post('integrations/zoom/test', [\App\Http\Controllers\MeetingIntegrationController::class, 'testZoom'])->name('integrations.zoom.test');

    // Profile
    Route::get('profile', [\App\Http\Controllers\ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('profile', [\App\Http\Controllers\ProfileController::class, 'update'])->name('profile.update');
    Route::delete('profile/avatar', [\App\Http\Controllers\ProfileController::class, 'removeAvatar'])->name('profile.avatar.remove');
    Route::put('profile/password', [\App\Http\Controllers\ProfileController::class, 'updatePassword'])->name('profile.password');
    Route::delete('profile', [\App\Http\Controllers\ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
