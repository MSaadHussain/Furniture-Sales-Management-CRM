<?php

namespace App\Http\Controllers\Api\V1\Webhooks;

use App\Enums\CarType;
use App\Enums\DriverContractType;
use App\Enums\DriverLeadStatus;
use App\Enums\DriverRacingLevel;
use App\Enums\DriverTier;
use App\Http\Controllers\Controller;
use App\Models\DriverLead;
use App\Models\DriverLeadActivity;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DriverLeadWebhookController extends Controller
{
    public function receive(Request $request): JsonResponse
    {
        $data = $request->validate([
            'first_name'             => ['required', 'string', 'max:191'],
            'last_name'              => ['required', 'string', 'max:191'],
            'email'                  => ['required', 'email', 'max:191'],
            'phone'                  => ['required', 'string', 'max:50'],
            'country'                => ['nullable', 'string', 'max:100'],
            'dob'                    => ['required', 'date', 'before:today'],
            'years_racing'           => ['nullable', 'integer', 'min:0', 'max:80'],
            'highest_series'         => ['nullable', 'string', 'max:191'],
            'racing_level'           => ['nullable', 'string', 'max:100'],
            'car_type'               => ['required', 'string', 'max:100'],
            'career_wins'            => ['nullable', 'integer', 'min:0', 'max:10000'],
            'current_team_series'    => ['nullable', 'string', 'max:500'],
            'instagram_handle'       => ['nullable', 'string', 'max:100'],
            'instagram_followers'    => ['nullable', 'integer', 'min:0'],
            'seeking_sponsorship'    => ['nullable'],
            'contract_interest_type' => ['nullable', 'string', 'max:100'],
        ]);

        $data['years_racing']        = (int) ($data['years_racing'] ?? 0);
        $data['career_wins']         = (int) ($data['career_wins'] ?? 0);
        $data['instagram_followers'] = (int) ($data['instagram_followers'] ?? 0);
        $data['seeking_sponsorship'] = filter_var($data['seeking_sponsorship'] ?? false, FILTER_VALIDATE_BOOLEAN);
        $data['status']              = DriverLeadStatus::New;

        // Racing Level and Car Type are independent answers from the form.
        // Each is normalized on its own — Car Type is never derived from Racing Level.
        $data['racing_level'] = self::matchEnum(DriverRacingLevel::class, $data['racing_level'] ?? '');
        $carTypeRaw           = $data['car_type'];
        $data['car_type']     = self::matchEnum(CarType::class, $carTypeRaw);
        $data['contract_interest_type'] = self::matchEnum(DriverContractType::class, $data['contract_interest_type'] ?? '');

        // Car type is required — an unrecognized value is a hard error, never a guess.
        if ($data['car_type'] === null) {
            throw \Illuminate\Validation\ValidationException::withMessages([
                'car_type' => "Unknown car type \"{$carTypeRaw}\". Allowed: Kart, Formula Car, GT Car, Touring Car, Prototype, Stock Car, Sim Racing, Other.",
            ]);
        }

        // Age-plausibility rules (under 12 → Kart/Karting only, under 18 → no F1, etc.)
        \App\Http\Controllers\DriverLeadController::assertAgeRules(
            $data['dob'],
            $data['racing_level'],
            $data['car_type'],
        );

        $existing = DriverLead::where('email', $data['email'])->first();

        if ($existing) {
            $existing->update($data);
            $existing->refresh();
            $existing->recomputeTier();

            DriverLeadActivity::create([
                'driver_lead_id' => $existing->id,
                'action'         => 'webhook_updated',
                'description'    => 'Lead updated via webhook (duplicate email)',
            ]);

            return response()->json([
                'success'  => true,
                'created'  => false,
                'merged'   => true,
                'lead_id'  => $existing->id,
                'tier'     => $existing->inferred_tier->value,
            ]);
        }

        $data['inferred_tier'] = DriverTier::Amateur;
        $driver = DriverLead::create($data);
        $driver->recomputeTier();

        DriverLeadActivity::create([
            'driver_lead_id' => $driver->id,
            'action'         => 'created',
            'description'    => 'Driver lead created via webhook',
        ]);

        return response()->json([
            'success'  => true,
            'created'  => true,
            'merged'   => false,
            'lead_id'  => $driver->id,
            'tier'     => $driver->inferred_tier->value,
        ], 201);
    }

    /**
     * Match a free-text form answer to an enum case by value or label
     * (case-insensitive). Returns null when nothing matches — no guessing.
     */
    public static function matchEnum(string $enumClass, string $raw): ?string
    {
        $raw = trim($raw);
        if ($raw === '') {
            return null;
        }

        $normalized = strtolower($raw);

        foreach ($enumClass::cases() as $case) {
            if ($case->value === $normalized || strtolower($case->label()) === $normalized) {
                return $case->value;
            }
        }

        return null;
    }
}
