@extends('layouts.app')
@section('title', 'Import Result')
@section('breadcrumb')
    <a href="{{ route('leads.import.batches') }}" class="hover:text-brand">Imports</a> /
    <span>Batch #{{ $batch->id }}</span>
@endsection

@section('header_actions')
    @if ($batch->failed_rows > 0)
        <a href="{{ route('leads.import.batches.failed', $batch) }}" class="btn btn-light">
            <i class="fa-solid fa-download"></i> Download failed rows
        </a>
    @endif
    <a href="{{ route('leads.import.index') }}" class="btn btn-primary">
        <i class="fa-solid fa-plus"></i> New import
    </a>
@endsection

@section('content')
    {{-- Auto-refresh while processing/queued --}}
    @if (in_array($batch->status, ['processing', 'previewing']))
        <div x-data x-init="setTimeout(() => window.location.reload(), 4000)"
             class="mb-6 flex items-center gap-2 rounded-xl border border-warning/30 bg-warning/10 px-4 py-3 text-sm text-warning">
            <i class="fa-solid fa-spinner fa-spin"></i> Import in progress — refreshing automatically…
        </div>
    @endif

    {{-- Result summary --}}
    <div class="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
        <x-stat-card label="Total Rows"  :value="number_format($batch->total_rows)"     icon="fa-list"          iconColor="#465FFF" />
        <x-stat-card label="Imported"    :value="number_format($batch->successful_rows)" icon="fa-circle-check"  iconColor="#12B76A" />
        <x-stat-card label="Duplicates"  :value="number_format($batch->duplicate_rows)"  icon="fa-clone"         iconColor="#7A5AF8" />
        <x-stat-card label="Failed"      :value="number_format($batch->failed_rows)"     icon="fa-circle-xmark"  iconColor="#F04438" />
    </div>

    @if ($batch->error_log)
        <div class="mb-6 rounded-xl border border-danger/30 bg-danger/10 px-4 py-3 text-sm text-danger">
            <i class="fa-solid fa-triangle-exclamation mr-2"></i>{{ $batch->error_log }}
        </div>
    @endif

    <x-card padding="p-0">
        <div class="flex items-center justify-between border-b border-line px-6 py-4 dark:border-strokedark">
            <div>
                <h3 class="text-lg font-semibold text-ink dark:text-white">{{ $batch->file_name }}</h3>
                <p class="text-sm text-muted">
                    {{ strtoupper($batch->file_type) }} · {{ $batch->source_channel->label() }} ·
                    by {{ $batch->user?->name ?? 'System' }} · {{ $batch->created_at->format('M j, Y g:i A') }}
                </p>
            </div>
            @include('leads.import._status', ['status' => $batch->status])
        </div>

        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="border-b border-line dark:border-strokedark">
                    <tr>
                        <th class="ta-th">#</th>
                        <th class="ta-th">Status</th>
                        <th class="ta-th">Lead</th>
                        <th class="ta-th">Detail</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-line dark:divide-strokedark">
                    @forelse ($rows as $row)
                        <tr>
                            <td class="ta-td text-muted">{{ $row->row_number }}</td>
                            <td class="ta-td">@include('leads.import._status', ['status' => $row->status])</td>
                            <td class="ta-td">
                                @if ($row->lead)
                                    <a href="{{ route('leads.show', $row->lead) }}" class="font-medium text-brand">
                                        {{ $row->lead->full_name ?: 'Lead #'.$row->lead->id }}
                                    </a>
                                @else
                                    <span class="text-muted">—</span>
                                @endif
                            </td>
                            <td class="ta-td text-muted">
                                {{ $row->error_message ?: ($row->mapped_data['email'] ?? $row->mapped_data['phone'] ?? '') }}
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="4" class="ta-td text-center text-muted">No rows recorded.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="border-t border-line px-6 py-4 dark:border-strokedark">
            {{ $rows->links() }}
        </div>
    </x-card>
@endsection
