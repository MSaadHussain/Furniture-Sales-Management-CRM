<?php

namespace App\Http\Controllers;

use App\Enums\SponsorActionType;
use App\Enums\SponsorshipStage;
use App\Enums\UserRole;
use App\Models\SponsorActivity;
use App\Models\SponsorProfile;
use App\Models\SponsorshipDeal;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rules\Enum;

class SponsorshipPipelineController extends Controller
{
    public function index(Request $request)
    {
        $query = SponsorshipDeal::query()->with(['sponsor', 'assignee', 'driverLinks.driverLead']);

        if ($request->user()->hasRole(UserRole::SalesRep)) {
            $query->where('assigned_to', $request->user()->id);
        }

        $deals = $query->orderByDesc('updated_at')->get();

        $columns = [];
        foreach (SponsorshipStage::pipelineOrder() as $stage) {
            $stageDeals = $deals->where('stage', $stage)->values();
            $columns[$stage->value] = [
                'stage' => $stage->value,
                'label' => $stage->label(),
                'color' => $stage->color(),
                'deals' => $stageDeals,
                'value' => $stageDeals->sum('deal_value'),
            ];
        }

        // Lead Identified intake: every sponsor without an open deal appears
        // here automatically (imported, webhook, or admin-created). Creating
        // a deal converts them — the deal card starts at Proposal Sent.
        $openStages = [SponsorshipStage::ClosedWon->value, SponsorshipStage::ClosedLost->value];
        $prospectQuery = SponsorProfile::whereDoesntHave('deals', fn ($q) => $q->whereNotIn('stage', $openStages));

        if ($request->user()->hasRole(UserRole::SalesRep)) {
            $prospectQuery->where('assigned_to', $request->user()->id);
        }

        $prospects = $prospectQuery->orderByDesc('created_at')->get();

        $columns[SponsorshipStage::LeadIdentified->value]['prospects'] = $prospects;
        $columns[SponsorshipStage::LeadIdentified->value]['value'] += $prospects->sum('estimated_budget');

        return view('sponsorship-pipeline.index', [
            'columns' => $columns,
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'sponsor_profile_id'  => ['required', 'exists:sponsor_profiles,id'],
            'title'               => ['required', 'string', 'max:255'],
            'deal_value'          => ['nullable', 'numeric', 'min:0'],
            'probability'         => ['nullable', 'integer', 'min:0', 'max:100'],
            'expected_close_date' => ['nullable', 'date'],
            'package_type'        => ['nullable', 'string', 'max:255'],
            'priority'            => ['nullable', 'in:low,medium,high,hot'],
        ]);

        // New deals start at Proposal Sent — Lead Identified is the intake
        // column for sponsors that don't have a deal yet.
        $validated['stage'] = SponsorshipStage::ProposalSent;
        $validated['assigned_to'] = $request->input('assigned_to') ?: Auth::id();
        $validated['probability'] = $validated['probability'] ?? 50;
        $validated['priority'] = $validated['priority'] ?? 'medium';

        $deal = SponsorshipDeal::create($validated);

        SponsorActivity::create([
            'sponsor_profile_id'  => $deal->sponsor_profile_id,
            'sponsorship_deal_id' => $deal->id,
            'action_type'         => SponsorActionType::ProposalSent,
            'description'         => "Deal \"{$deal->title}\" created — entered pipeline at Proposal Sent",
            'performed_by'        => Auth::id(),
            'completed_at'        => now(),
        ]);

        return back()->with('toast', 'Deal created and moved to Proposal Sent.');
    }

    public function update(Request $request, SponsorshipDeal $deal)
    {
        $validated = $request->validate([
            'title'               => ['required', 'string', 'max:255'],
            'deal_value'          => ['nullable', 'numeric', 'min:0'],
            'probability'         => ['nullable', 'integer', 'min:0', 'max:100'],
            'expected_close_date' => ['nullable', 'date'],
            'package_type'        => ['nullable', 'string', 'max:255'],
            'priority'            => ['nullable', 'in:low,medium,high,hot'],
        ]);

        $deal->update($validated);

        SponsorActivity::create([
            'sponsor_profile_id'  => $deal->sponsor_profile_id,
            'sponsorship_deal_id' => $deal->id,
            'action_type'         => SponsorActionType::Note,
            'description'         => "Deal \"{$deal->title}\" updated",
            'performed_by'        => Auth::id(),
            'completed_at'        => now(),
        ]);

        return back()->with('toast', 'Deal updated.');
    }

    public function moveStage(Request $request, SponsorshipDeal $deal): JsonResponse
    {
        $validated = $request->validate([
            'stage' => ['required', new Enum(SponsorshipStage::class)],
        ]);

        $old = $deal->stage;
        $new = SponsorshipStage::from($validated['stage']);

        if ($old === $new) {
            return response()->json(['success' => true, 'unchanged' => true]);
        }

        $deal->update([
            'stage'     => $new,
            'closed_at' => $new->isClosed() ? now() : null,
        ]);

        SponsorActivity::create([
            'sponsor_profile_id'  => $deal->sponsor_profile_id,
            'sponsorship_deal_id' => $deal->id,
            'action_type'         => SponsorActionType::StageChanged,
            'description'         => "Deal moved from {$old->label()} to {$new->label()}",
            'performed_by'        => Auth::id(),
            'completed_at'        => now(),
        ]);

        return response()->json([
            'success' => true,
            'deal_id' => $deal->id,
            'stage'   => $new->value,
        ]);
    }

    public function destroy(SponsorshipDeal $deal)
    {
        $deal->delete();

        return back()->with('toast', 'Deal deleted.');
    }
}
